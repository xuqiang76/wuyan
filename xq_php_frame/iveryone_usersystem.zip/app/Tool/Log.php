<?php

namespace HttpApi\Tool;

class Log
{
    public static $log;

    public static function append($content)
    {
        if(is_array($content)) {
            $content = var_export($content, true);
        }
        self::$log[] = $content;
    }

    public static function write($level = 'info')
    {
        $content = implode("\n", self::$log);
        file_put_contents(LOGS_DIR . LOGS_PREFIX . $level . ".runlog",  date("Y-m-d H:i:s") . " " . $content . PHP_EOL, FILE_APPEND);
    }

    public static function debug($content, $level = 'info')
    {
        if(!is_string($content))
        {
            $content = var_export($content, true);
        }
        file_put_contents(LOGS_DIR . LOGS_PREFIX . $level . ".runlog",  date("Y-m-d H:i:s") . " " . $content . PHP_EOL, FILE_APPEND);
    }
}