<?php

namespace HttpApi\Tool;

use Beahoo\Exception;
use Beahoo\Tool\Config;

class BehaviorLogs
{
    const
        ACT_REGISTER = 1,
        ACT_FOLLOW = 2,
        ACT_INVITE = 3,
        ACT_BATTERY_MISSION = 4,
        ACT_PUBLISH_THREAD = 10,
        ACT_RETWEET_THREAD = 11,
        ACT_AUTHORIZED_THREAD = 12,
        ACT_ADVERTISE = 20,
        ACT_WATCHAD = 21;

    /**
     * @param $uid
     * @param $act
     * @param $params
     * @param $description
     * @throws Exception
     */
    public static function addLogs($uid, $act, $params, $description)
    {
        $res = iVeryOneApi::Request('Intra/BehaviorLogs/Add', [
            'uid' => $uid,
            'act' => $act,
            'params' => json_encode($params),
            'description' => $description,
        ]);
        if(!empty($res['data']['id'])) {
            return $res['data']['id'];
        }
        return 0;
    }

    /**
     * @param $sets
     * @return array
     * @throws Exception
     */
    public static function addMulti($sets)
    {
        $res = iVeryOneApi::Request('Intra/BehaviorLogs/AddMulti', [
            'sets' => $sets
        ]);
        if(!empty($res['data']['ids'])) {
            return $res['data']['ids'];
        }
        return [];
    }
}