<?php

namespace HttpApi\Tool;

class Times
{
    public static function format_date($time) {
        $difference = TIMESTAMP - $time;
        $today_begin_timestamp = strtotime(date("Y-m-d 00:00:00"));
        $yesterday_begin_timestamp = $today_begin_timestamp - 86400;
        switch ($difference) {

            case $difference <= '60' :
                $msg = '刚刚';
                break;

            case $difference > '60' && $difference <= '3600' :
                $msg = floor($difference / 60) . '分钟前';
                break;

            case $difference > '3600' && $time > $today_begin_timestamp:
                $msg = "今天 " . date("H:i", $time);
                break;

            case $difference > '3600' && $time < $today_begin_timestamp && $time > $yesterday_begin_timestamp :
                $msg = "昨天 " . date("H:i", $time);
                break;

            default:
                $msg = date("Y-m-d H:i", $time);
                break;
        }

        return $msg;
    }
}