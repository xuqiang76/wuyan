<?php
/**
 * Created by PhpStorm.
 * User: hepenghui
 * Date: 2018/3/14
 * Time: 下午4:56
 */
namespace HttpApi\Tool;

use HttpApi\Tool\SDKs;

//https://www.jianshu.com/p/9f76dd2757c7

class SellerFrequncy
{
    private static $instance;

    private $minNum = 200; //单个用户每分访问数

    private $dayNum = 1000; //单个用户每天总的访问量

    private $minExp = 3600;//过期时间60s//

    private $dayExp = 86400;//过期时间86400s//

    private $redisObj;

    public static function getInstance()
    {
        if(empty(self::$instance) || !(self::$instance instanceof  SellerFrequncy))
        {
            self::$instance = new SellerFrequncy();
        }

        return self::$instance;
    }

    public function auth($key)
    {
        if(empty($key))
        {
            return false;
        }

        $minNumKey = $key . '_minNum';
        $dayNumKey = $key . '_dayNum';

        $this->redisObj = SDKs::getRedis();

        $minRes = $this->getRedis($minNumKey,$this->minNum,$this->minExp);
        $dayRes = $this->getRedis($dayNumKey,$this->dayNum,$this->dayExp);
        if(!$minRes["status"])
        {
            return 1;
        }
        if(!$dayRes["status"]) {
            return 2;
        }
        return 0;
    }

    function getRedis($key , $initNum , $expire)
    {
        $nowtime    = time();
        $result   = ['status' => true, 'msg' => ''];

        $this->redisObj->watch($key);

        $limitVal = $this->redisObj->get($key);
        if ($limitVal) {
            $limitVal = json_decode($limitVal, true);
            $newNum   = min($initNum, ($limitVal['num'] - 1) + (($initNum / $expire) * ($nowtime - $limitVal['time'])));
            if ($newNum > 0)
            {
                $redisVal = json_encode(['num' => $newNum, 'time' => time()]);
            }
            else
            {
                return ['status' => false, 'msg' => '当前时刻令牌消耗完！'];
            }
        }
        else
        {
            $redisVal = json_encode(['num' => $initNum, 'time' => time()]);
        }
        $this->redisObj->multi();
        $this->redisObj->set($key, $redisVal);
        $rob_result = $this->redisObj->exec();
        if (!$rob_result)
        {
            $result = ['status' => false, 'msg' => '访问频次过多！'];
        }
        return $result;
    }
}