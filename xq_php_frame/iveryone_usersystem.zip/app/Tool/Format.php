<?php

namespace HttpApi\Tool;

use Beahoo\Tool\Config;

class Format {
	public static function amount($amount, $scale = 6) {
		return preg_replace('/\.?0*?$/', '', bcdiv($amount, 1000000, $scale));
	}

	public static function amount_k($amount, $scale = 3) {
		return preg_replace('/\.?0*?$/', '', bcdiv($amount, 1000, $scale));
	}

	/**
	 * common function,formatData
	 */
	public static function assColumn($a = array(), $column = 'id', $field = []) {
		$ret = array();
		settype($a, 'array');
		foreach ($a AS $one) {
			if ($field) {
				$temp_item = [];
				foreach ($field as $col) {
					$temp_item[$col] = $one[$col];
				}
				$one = $temp_item;
			}

			if (is_array($one)) {
				if (false == isset($ret[@$one[$column]])) {
					$ret[@$one[$column]] = array();
				}
				$ret[@$one[$column]] = $one;
			} else {
				if (false == isset($ret[@$one->$column])) {
					$ret[@$one->$column] = array();
				}

				$ret[@$one->$column] = $one;
			}
		}
		return $ret;
	}

	public static function getColumn($a = array(), $column = 'id', $null = true, $column2 = null) {
		$ret = array();
		@list($column, $anc) = preg_split('/[\s\-]/', $column, 2, PREG_SPLIT_NO_EMPTY);
		foreach ($a AS $one) {
			if ($null || @$one[$column]) {
				$one[$column] && $ret[] = @$one[$column] . ($anc ? '-' . @$one[$anc] : '');
			}

		}
		return $ret;
	}
	public static function getColumnMulti($a = array(), $column = array()) {
		$ret = array();
		foreach ($a AS $one) {
			foreach ($one as $key => $val) {
				if (in_array($key, $column)) {
					$val && $ret[$key][] = $val;
				}
			}
		}
		return $ret;
	}

	/**
	 * 将V点转换成数据库可存储的格式
	 * @param $amount
	 * @param int $scale
	 * @return mixed
	 */
	public static function encodeV($amount) {
		return $amount * 1000;
	}

	/**
	 * 将数据库V点格式转换成常用格式
	 * @param $amount
	 * @param int $scale
	 * @return mixed
	 */
	public static function decodeV($amount, $scale = 2) {
		return preg_replace('/\.?0*?$/', '', bcdiv($amount, 1000, $scale));
	}

	/**
	 * 将1VRY格式化成数据库百万制
	 * @param $amount
	 * @return mixed
	 */
	public static function formatVry($amount) {
		return $amount * 1000000;
	}

    /**
     * V点转VRY货币汇率转换
     */
	public static function vExchangeVry($amount, $scale = 6) {
        return preg_replace('/\.?0*?$/', '', bcdiv($amount, Config::read('exchange'), $scale));
    }

    /**
     * VRY转V点货币汇率转换
     */
    public static function vryExchangeV($amount) {
        return $amount * Config::read('exchange');
    }

    /**
     * 获取汇率
     * @return mixed
     */
    public static function getExchange()
    {
        return Config::read('exchange');
    }

	/**

	 * 将二维数组的某个字段值作为其key
	 * @param $arr
	 * @param $key
	 * @return array
	 */
	public static function arrayChangeKey($arr, $key) {
		$processedArr = array();
		if (is_array($arr) && !empty($arr)) {
			foreach ($arr as $item) {
				$processedArr[$item[$key]] = $item;
			}
		}
		return $processedArr;
	}

}