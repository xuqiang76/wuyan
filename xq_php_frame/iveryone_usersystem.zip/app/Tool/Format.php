<?php

namespace HttpApi\Tool;

class Format {
	public static function amount($amount, $scale = 6) {
		return preg_replace('/\.?0*?$/', '', bcdiv($amount, 1000000, $scale));
	}

	public static function amount_k($amount, $scale = 3) {
		return preg_replace('/\.?0*?$/', '', bcdiv($amount, 1000, $scale));
	}

	/**
	 * common function,formatData
	 */
	public static function assColumn($a = array(), $column = 'id', $field = []) {
		$ret = array();
		settype($a, 'array');
		foreach ($a AS $one) {
			if ($field) {
				$temp_item = [];
				foreach ($field as $col) {
					$temp_item[$col] = $one[$col];
				}
				$one = $temp_item;
			}

			if (is_array($one)) {
				if (false == isset($ret[@$one[$column]])) {
					$ret[@$one[$column]] = array();
				}
				$ret[@$one[$column]] = $one;
			} else {
				if (false == isset($ret[@$one->$column])) {
					$ret[@$one->$column] = array();
				}

				$ret[@$one->$column] = $one;
			}
		}
		return $ret;
	}

	public static function getColumn($a = array(), $column = 'id', $null = true, $column2 = null) {
		$ret = array();
		@list($column, $anc) = preg_split('/[\s\-]/', $column, 2, PREG_SPLIT_NO_EMPTY);
		foreach ($a AS $one) {
			if ($null || @$one[$column]) {
				$one[$column] && $ret[] = @$one[$column] . ($anc ? '-' . @$one[$anc] : '');
			}

		}
		return $ret;
	}
	public static function getColumnMulti($a = array(), $column = array()) {
		$ret = array();
		foreach ($a AS $one) {
			foreach ($one as $key => $val) {
				if (in_array($key, $column)) {
					$val && $ret[$key][] = $val;
				}
			}
		}
		return $ret;
	}

	/**
	 * V点数据库里转换成百万制vry
	 * @param $amount
	 * @param int $scale
	 * @return mixed
	 */
	public static function vToVry($amount) {
		return $amount * 1000;
	}

	/**
	 * 数据库百万制Vry转换成V点
	 * @param $amount
	 * @param int $scale
	 * @return mixed
	 */
	public static function vryToV($amount, $scale = 2) {
		return preg_replace('/\.?0*?$/', '', bcdiv($amount, 1000, $scale));
	}

	/**
	 * 将1VRY格式化成数据库百万制
	 * @param $amount
	 * @return mixed
	 */
	public static function formatVry($amount) {
		return $amount * 1000000;
	}

	/**

	 * 将二维数组的某个字段值作为其key
	 * @param $arr
	 * @param $key
	 * @return array
	 */
	public static function arrayChangeKey($arr, $key) {
		$processedArr = array();
		if (is_array($arr) && !empty($arr)) {
			foreach ($arr as $item) {
				$processedArr[$item[$key]] = $item;
			}
		}
		return $processedArr;
	}

}