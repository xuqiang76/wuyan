<?php

namespace HttpApi\Tool;

use Beahoo\Exception;
use Beahoo\Tool\Config;

class OpenApi
{
    /**
     * @param $method
     * @param $params
     * @return mixed|\Psr\Http\Message\ResponseInterface|\Psr\Http\Message\StreamInterface
     * @throws Exception
     */
    public static function Request($method, $params)
    {
        $params['secret'] = Config::read('intraapi_secretkey');
        $client = new \GuzzleHttp\Client();
        $data = $client->request('GET', Config::read('iveryone_openapi_url') . $method, [
            'query' => $params
        ]);
        if ($data->getStatusCode() != 200) {
            throw new Exception("", 1003);
        }
        $data = $data->getBody();
        if (empty($data)) {
            throw new Exception("", 1003);
        }

        $data = json_decode($data, true);
        if ($data['errno'] != 0 && $data['errno'] != 4000) {
            throw new Exception($data['errmsg'], $data['errno']);
        }

        if(!empty($data) && !isset($data['data'])) {
            $data['data'] = [];
        }
        return $data;
    }
}