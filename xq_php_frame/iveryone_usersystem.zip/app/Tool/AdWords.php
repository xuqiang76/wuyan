<?php

namespace HttpApi\Tool;

class AdWords {
    private static $privilege = [
        1,
        6,
        1000102,
        1000109,
        2171238,
        2171205,
        2123560
    ];
    public static function privilege($uid) {
        return 1;
        return intval ( in_array ( $uid, self::$privilege ) );
    }
}