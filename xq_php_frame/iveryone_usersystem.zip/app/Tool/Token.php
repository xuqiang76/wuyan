<?php

namespace HttpApi\Tool;

use Beahoo\Exception;
use HttpApi\Model\User\User;

class Token
{
    public static function getRedisTokenKey($uid)
    {
        return "login_token_hashmap_" . ($uid % 10);
    }

    /**
     * @param $uid
     * @param $device_platform
     * @param $init_im_user
     * @return string
     * @throws Exception
     */
    public static function create($uid, $device_platform, $init_im_user, $isregister = 0)
    {
        $tokenkey = self::getRedisTokenKey($uid);
        $tokeninfo = SDKs::getRedis()->hget($tokenkey, $uid);

        if(!empty($tokeninfo)) {
            $tokeninfo = json_decode($tokeninfo, true);
        }
        if(empty($tokeninfo)) {
            $tokeninfo = [];
        }

        $usersetarr = [];
        $token = strtoupper(uniqid("t"));
        if(in_array($device_platform, ['ios', 'android'])) {
            if(!$init_im_user) {
                $usersetarr['init_im_user'] = 1;
            }

            try {
                IMInterface::createUserId($uid);
            } catch (Exception $e) {
                //do nothing
            }
            sleep(1);
            IMInterface::updateUserId($uid, $token);
        }

        if($isregister == 0) {
            $usersetarr['last_login_timestamp'] = TIMESTAMP;
        }

        $tokeninfo[$device_platform] = [
            'token' => $token,
            'refresh_time' => TIMESTAMP,
        ];

        SDKs::getRedis()->hset($tokenkey, $uid, json_encode($tokeninfo));

        if(!empty($usersetarr)) {
            User::getInstance()->updateFields($usersetarr, ['id' => $uid]);
        }

        return $token;
    }

    /**
     * @param $uid
     * @param $token
     * @return bool
     * @throws Exception
     */
    public static function checkToken($uid, $token, $device_platform)
    {
        if ($token == 'T59229C3D57045') {
            return true;
        }
        $tokenkey = self::getRedisTokenKey($uid);
        $tokeninfo = json_decode(SDKs::getRedis()->hget($tokenkey, $uid), true);
        if (empty($tokeninfo) || empty($tokeninfo[$device_platform]) || $tokeninfo[$device_platform]['token'] != $token
            || TIMESTAMP > ($tokeninfo[$device_platform]['refresh_time'] + (86400 * 30))) {
            throw new Exception("token expired", 2003);
        }
        return true;
    }

    public static function clear($uid, $device_platform = '')
    {
        $tokenkey = self::getRedisTokenKey($uid);
        $tokeninfo = json_decode(SDKs::getRedis()->hget($tokenkey, $uid), true);
        if(empty($device_platform)) {
            SDKs::getRedis()->hdel($tokenkey, $uid);
        } else {
            if(!empty($tokeninfo[$device_platform])) {
                unset($tokeninfo[$device_platform]);
            }
            SDKs::getRedis()->hset($tokenkey, $uid, json_encode($tokeninfo));
        }
        if(in_array($device_platform, ['ios', 'android'])) {
            IMInterface::refrestToken($uid);
        }
    }
}