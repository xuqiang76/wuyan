<?php

namespace HttpApi\Tool;

use Beahoo\Exception;
use Beahoo\Tool\Config;

class Cache
{
    public static function makeSendCaptcha($phone, $act, $code)
    {
        return SDKs::getCacheRedis()->setex($phone . "_" . $act, 180, $code);
    }

    public static function checkCaptcha($phone, $act, $code, $delete = false)
    {
        $checkcode = SDKs::getCacheRedis()->get($phone . "_" . $act);
        if($checkcode == $code) {
            if($delete) {
                SDKs::getCacheRedis()->del([$phone . "_" . $act]);
            }
            return true;
        }
        return false;
    }

    public static function SetCache($key, $params, $expired = 300)
    {
        return SDKs::getCacheRedis()->setex($key, $expired, json_encode($params));
    }

    public static function GetCache($key)
    {
        return json_decode(SDKs::getCacheRedis()->get($key), true);
    }

    public static function rechargeCheckfrequncy($uid)
    {
        if($cachedb = Config::read('redis.cachedb'))
        {
            SDKs::getCacheRedis()->select($cachedb);
        }
        $key = "rechargecheckfrequncy_" . $uid;
        $toofast = SDKs::getCacheRedis()->get($key);
        if($toofast) {
            return false;
        }
        if(SDKs::getCacheRedis()->setnx($key, 1)) {
            SDKs::getCacheRedis()->pexpire($key, 3000);
            return true;
        }
        return false;
    }

    public static function CheckFrequncy($type, $key, $timeout = 60)
    {
        $key = $type . "_" . $key;
        $toofast = SDKs::getCacheRedis()->get($key);
        if($toofast) {
            return false;
        }
        SDKs::getCacheRedis()->set($key, 1);
        SDKs::getCacheRedis()->pexpire($key, $timeout * 1000);
        return true;
    }
}