<?php

namespace HttpApi\Tool;

use Beahoo\Tool\Config;
use OSS\OssClient;
use Predis\Client;

class SDKs
{
    /**
     * @var
     */
    private static $oss;

    public static function initsms()
    {
        require_once "/download/WuyanLibs/sms/SMS.php";
    }

    public static function initemail()
    {
        require_once "/download/WuyanLibs/email/Email.php";
    }

    /**
     * @return Client
     */
    public static function getRedis()
    {
        static $redis;
        if(empty($redis))
        {
            $redis = new Client(Config::read('redis.Parameters'));
            $auth = Config::read('redis.auth');
            if(!empty($auth))
                $redis->auth($auth);
            $db = Config::read('redis.db');
            if($db != 0)
                $redis->select($db);
        }
        return $redis;
    }

    /**
     * @return Client
     */
    public static function getCacheRedis()
    {
        static $redis;
        if(empty($redis))
        {
            $redis = new Client(Config::read('redis.Parameters'));
            $auth = Config::read('redis.auth');
            if(!empty($auth))
                $redis->auth($auth);
            $cachedb = Config::read('redis.cachedb');
            if($cachedb != 0)
                $redis->select($cachedb);
        }
        return $redis;
    }

    public static function initidgen()
    {
        require_once "/download/WuyanLibs/idgenerator/idgen.php";
    }

    public static function inittimer()
    {
        require_once "/download/WuyanLibs/timer/timer.php";
    }
}