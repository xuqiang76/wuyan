<?php

namespace HttpApi\Tool;

use Beahoo\Exception;
use HttpApi\Encrypt\Rsa;
use HttpApi\Model\Contacts;
use HttpApi\Model\User\User;
use IDGEN\IDGEN;

class IMInterface
{

    public static function createUserId($uid)
    {
        $res = NeteaseApi::getInstance()->createUserId($uid);
        if($res['code'] != 200) {
            Log::debug($res, 'neteaseapierror');
            throw new Exception($res['desc'], 1000);
        }
        return $res;
    }

    public static function updateUserId($uid, $token)
    {
        $res = NeteaseApi::getInstance()->updateUserId($uid, '', '{}', $token);
        if($res['code'] != 200) {
            Log::debug($res, 'neteaseapierror');
            throw new Exception($res['desc'], 1000);
        }
        return $res;
    }

    public static function refrestToken($uid)
    {
        $res = NeteaseApi::getInstance()->updateUserToken($uid);
        if($res['code'] != 200) {
            Log::debug($res, 'neteaseapierror');
            throw new Exception($res['desc'], 1000);
        }
        return $res;
    }

    public static function send($from, $ope, $to, $type, $body, $ext = [], $pushcontent = '', $option = [])
    {
        if(!empty($option))
        {
            $res = NeteaseApi::getInstance()->sendMsg($from, $ope, $to, $type, $body, $ext, $pushcontent, $option);
        } else {
            $res = NeteaseApi::getInstance()->sendMsg($from, $ope, $to, $type, $body, $ext, $pushcontent);
        }
        if($res['code'] != 200) {
            Log::debug($res, 'neteaseapierror');
            throw new Exception($res['desc'], 1000);
        }
        return $res;
    }

    public static function sendAttachMsg($from, $msgtype, $to, $attach, $pushcontent='',$payload=array(),$sound='',$save=2,$option=array("badge"=>false,"needPushNick"=>false,"route"=>true))
    {
        $res = NeteaseApi::getInstance()->sendAttachMsg($from, $msgtype, $to, $attach, $pushcontent,$payload,$sound,$save,$option);
        if($res['code'] != 200) {
            Log::debug($res, 'neteaseapierror');
            throw new Exception($res['desc'], 1000);
        }
        return $res;
    }

    public static function createGroup($tname,$owner,$members,$announcement='',$intro='',$msg='invite',$magree='0',$joinmode='0',$custom='0')
    {
        $res = NeteaseApi::getInstance()->createGroup($tname,$owner,$members,$announcement,$intro,$msg,$magree,$joinmode,$custom);
        if($res['code'] != 200) {
            Log::debug($res, 'neteaseapierror');
            throw new Exception($res['desc'], 1000);
        }
        return $res;
    }

    public static function addIntoGroup($gid,$founder_uid,$members,$magree='0',$msg='invite'){
        $res = NeteaseApi::getInstance()->addIntoGroup($gid, $founder_uid, $members, $magree, $msg);
        if($res['code'] != 200) {
            Log::debug($res, 'neteaseapierror');
            throw new Exception($res['desc'], 1000);
        }
        return $res;
    }

    public static function kickFromGroup($gid,$founder_uid,$member)
    {
        $res = NeteaseApi::getInstance()->kickFromGroup($gid,$founder_uid,$member);
        if($res['code'] != 200) {
            Log::debug($res, 'neteaseapierror');
            throw new Exception($res['desc'], 1000);
        }
        return $res;
    }

    public static function leaveFromGroup($gid,$uid)
    {
        $res = NeteaseApi::getInstance()->leaveFromGroup($gid,$uid);
        if($res['code'] != 200) {
            Log::debug($res, 'neteaseapierror');
            throw new Exception($res['desc'], 1000);
        }
        return $res;
    }

    public static function queryGroup($tids,$ope='1'){
        $res = NeteaseApi::getInstance()->queryGroup($tids, $ope);
        if($res['code'] != 200) {
            Log::debug($res, 'neteaseapierror');
            throw new Exception($res['desc'], 1000);
        }
        return $res;
    }

    public static function muteTeam($tid, $uid, $ope)
    {
        $res = NeteaseApi::getInstance()->muteTeam($tid, $uid, $ope);
        if($res['code'] != 200) {
            Log::debug($res, 'neteaseapierror');
            throw new Exception($res['desc'], 1000);
        }
        return $res;
    }

    public static function removeGroup($tid, $owner)
    {
        $res = NeteaseApi::getInstance()->removeGroup($tid, $owner);
        if($res['code'] != 200) {
            Log::debug($res, 'neteaseapierror');
            throw new Exception($res['desc'], 1000);
        }
        return $res;
    }

    public static function changeGroupOwner($tid,$owner,$newowner,$leave='2')
    {
        $res = NeteaseApi::getInstance()->changeGroupOwner($tid,$owner,$newowner,$leave);
        if($res['code'] != 200) {
            Log::debug($res, 'neteaseapierror');
            throw new Exception($res['desc'], 1000);
        }
        return $res;
    }

    public static function specializeFriend($accid,$targetAcc,$relationType='1',$value='1')
    {
        $res = NeteaseApi::getInstance()->specializeFriend($accid, $targetAcc, $relationType, $value);
        if($res['code'] != 200) {
            Log::debug($res, 'neteaseapierror');
            throw new Exception($res['desc'], 1000);
        }
        return $res;
    }

    public static function makeExt($uid, $chatid, $msgbody, $redenvelope, $timestamp = TIMESTAMP, $touid = '')
    {
        $userinfo = User::getInstance()->getUserInfoByUid($uid);

        if(empty($userinfo)) {
            throw new Exception("", 2001);
        }

        $UidKey = $userinfo['id'];
        $NameKey = $userinfo['nickname'];
        if(!empty($touid)) {
            $oppositeContact = Contacts::getInstance()->getContact($touid, $uid);
            if(!empty($oppositeContact['remark'])) {
                $NameKey = $oppositeContact['remark'];
            }
        }
        $IconKey = $userinfo['avatar'];

        SDKs::initidgen();
        $msgid = IDGEN::get();

        $redenvelope = strval(round($redenvelope, 2));
        $signkey = uniqid('signkey');
        $sign = md5($UidKey.$msgid.$chatid.$redenvelope.$timestamp.$msgbody.$signkey);
        return ['UidKey'=>$UidKey, 'NameKey'=>$NameKey, 'IconKey'=>$IconKey,'msgid' => $msgid, 'chatid' => $chatid, 'redenvelope' => $redenvelope, 'timestamp' => $timestamp, 'sign' => $sign, 'signkey' => Rsa::privateEncrypt($signkey)];
    }

    public static function makeGroupExt($uid, $gid, $msgbody, $redenvelope, $redenvelope_type, $redenvelope_recipient="", $forcepushlist = "", $timestamp = TIMESTAMP)
    {
        $userinfo = User::getInstance()->getUserInfoByUid($uid);
        if(empty($userinfo)) {
            throw new Exception("", 2001);
        }

        $UidKey = $userinfo['uid'];
        $NameKey = $userinfo['nickname'];
        $IconKey = $userinfo['avatar'];

        SDKs::initidgen();
        $msgid = IDGEN::get();

        $signkey = uniqid('signkey');
        $sign = md5($UidKey.$msgid.$gid.$redenvelope.$redenvelope_type.$redenvelope_recipient.$timestamp.$msgbody.$signkey);
        return ['UidKey'=>$UidKey, 'NameKey'=>$NameKey, 'IconKey'=>$IconKey,'msgid' => $msgid, 'gid' => $gid, 'redenvelope' => $redenvelope, 'redenvelope_type' => $redenvelope_type, 'redenvelope_recipient' => $redenvelope_recipient, 'forcepushlist' => $forcepushlist, 'timestamp' => $timestamp, 'sign' => $sign, 'signkey' => Rsa::privateEncrypt($signkey)];
    }
}