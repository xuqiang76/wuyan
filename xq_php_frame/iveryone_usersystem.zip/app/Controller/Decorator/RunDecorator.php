<?php

namespace HttpApi\Controller\Decorator;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
/**
 * 路由装饰器
 *
 * @package XSDK\Controller\Decorator
 */
class RunDecorator extends BaseDecorator
{
    public $project     = '';
    public $controller  = '';
    public $actionName  = '';

    protected $decorators = array(
        'HttpApi\Controller\Decorator\RouterDecorator' => 'router'
    );

    /**
     * @param Request $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     */
    public function execute(Request $request, Response $response)
    {
        parent::execute($request, $response);
    }
}
