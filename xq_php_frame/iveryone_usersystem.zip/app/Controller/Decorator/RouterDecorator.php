<?php

namespace HttpApi\Controller\Decorator;

use Beahoo\Controller\Decorator;
use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Tool\Config;

/**
 * 路由装饰器
 */
class RouterDecorator extends BaseDecorator
{

    use Decorator\RouterDecoratorTrait;

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request $request
     * @param \Beahoo\Controller\Response $response
     *
     * @result void
     */
    public function execute(Request $request, Response $response)
    {
        $uri = $request->getServerArg('REQUEST_URI');
        $uri = ltrim(strstr($uri . '?', '?', true), '/');
        $project = $request->getServerArg('REQUEST_PROJECT');
        if($project) {
            @list($controller,$action,$method)=explode('/', $uri);
        } else {
            @list($project,$controller,$action,$method)=explode('/', $uri);
        }

        $prefix = (Config::read('decorator.router.prefix.'.$project)??
                  Config::read('decorator.router.default_prefix')??
                  Config::read('decorator.router.prefix'))."\\".$project;

        $default = Config::read('decorator.router.default');

        $controller = $controller??$default['controller'];
        $action     = ($action??$default['action']).'Action';
        $method=$method?$method:"execute";

        $classname=PHP_SAPI == 'cli'?"{$prefix}\\{$controller}\\Shell\\{$action}":"{$prefix}\\{$controller}\\{$action}";

        $request->setServerArg('project', $project);
        $request->setServerArg('controller',$controller);
        $request->setServerArg('action', $action);
        $request->setServerArg('method', $method);

        define('REQ_CLASS', trim($classname,'\\'));
        define('REQ_METHOD', $method);

        $this->getLastAction()->setAction($classname);
        $this->getLastAction()->setMethod($method);

        parent::execute($request, $response);
    }
}
