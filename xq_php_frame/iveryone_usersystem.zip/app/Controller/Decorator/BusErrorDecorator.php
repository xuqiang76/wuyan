<?php

namespace HttpApi\Controller\Decorator;

use Beahoo\Controller\ApiActionTrait;
use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Tool\Log;

/**
 * 路由装饰器
 *
 * @package HttpApi\Controller\Decorator
 */
class BusErrorDecorator extends BaseDecorator
{
    use ApiActionTrait;
    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     */
    public function execute(Request $request, Response $response)
    {
        try{
            parent::execute($request, $response);
        }
        catch (\PDOException $e)
        {
            $data['errno'] = 1002;
            $data['errmsg'] = "数据库错误";
            if($e->getCode() == 23000) {
                $data['errmsg'] = "请勿重复操作";
            }

            Log::debug(json_encode([$e->getCode(), $e->getMessage(), $e->getTrace()]), 'mysql');
            if (PHP_SAPI == 'cli') {
                $response->send($this->formatData($data));
            } else {
                $response->setBody($this->formatData($data));
                $response->send();
            }
            exit;
        }
        catch (Exception $e)
        {
            $data['errno'] = $e->getCode();
            $data['errmsg'] = $e->getMessage();
            if(empty($data['errmsg']))
            {
                eval('$data[\'errmsg\'] = \L::errno_'.$data['errno'].';');
            }
            if(RUN_ENV=='test'){
                @file_put_contents(LOGS_DIR.'userapi_error_trace.log',date('Y-m-d H:i:s')."\n".var_export($e->getTrace(),true),FILE_APPEND);
            }
            Log::debug($data, 'bus');
            if (PHP_SAPI == 'cli') {
                $response->send($this->formatData($data));
            } else {
                $response->setBody($this->formatData($data));
                $response->send();
            }
            exit;
        }
    }
}
