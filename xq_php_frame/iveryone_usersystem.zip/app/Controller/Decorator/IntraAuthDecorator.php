<?php

namespace HttpApi\Controller\Decorator;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\Config;

/**
 * 路由装饰器
 *
 * @package HttpApi\Controller\Decorator
 */
class IntraAuthDecorator extends BaseDecorator
{
    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     * @throws Exception
     */
    public function execute(Request $request, Response $response)
    {
        $secret = $request->getArg('secret');
        \App::setGlobal('device_platform', $request->getArg('device_platform'));
        if (empty($secret) || $secret != Config::read('intraapi_secretkey')) {
            throw new Exception("", 2003);
        }

        parent::execute($request, $response);
    }
}
