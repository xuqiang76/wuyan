<?php

namespace HttpApi\Controller\Decorator;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Tool\Log;
use WhichBrowser\Parser;

/**
 * 路由装饰器
 *
 * @package HttpApi\Controller\Decorator
 */
class InputDecorator extends BaseDecorator {
	/**
	 * 执行
	 *
	 * @param \Beahoo\Controller\Request\HttpRequest $request
	 * @param \HttpApi\Controller\Response\HttpResponse $response
	 *
	 * @result void
	 * @throws Exception
	 */
	public function execute(Request $request, Response $response) {
		$device_platform = strtolower($request->getArg('device_platform'));
		if (empty($device_platform) && !empty($_SERVER['HTTP_USER_AGENT'])) {
			if (empty($_SERVER['HTTP_USER_AGENT'])) {
				throw new Exception("user agent", 1001);
			}

			if (strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'iveryoneappios') !== false) {
				$device_platform = 'ios';
			} else if (strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'iveryoneappandroid') !== false) {
				$device_platform = 'android';
			} else {
				$result = new Parser($_SERVER['HTTP_USER_AGENT']);
				if ($result->isType('desktop')) {
					$device_platform = 'web';
				} else if ($result->isType('mobile', 'tablet')) {
					$device_platform = 'h5';
				} else {
					throw new Exception("", 1001);
				}
			}
		} else if (!in_array($device_platform, ['android', 'ios', 'author_platform', 'ad_platform'])) {
			throw new Exception("", 1001);
		}

		if (!empty($request->getFileArgs())) {
			Log::debug($request->getFileArgs(), 'files');
		}

		$request->setQueryArg('device_platform', $device_platform);
        \App::setGlobal('device_platform', $device_platform);
		$project = $request->getArg('project');
		$controller = $request->getArg('controller');
		$action = $request->getArg('action');
		$uid = $request->getArg('uid');

		if (in_array($uid, [1, 2, 3, 35, 1000006])) {
			Log::debug($project . " " . $controller . " " . $action . " " . print_r($request->getGPArgs(), true), 'request');
		}

		parent::execute($request, $response);
	}
}
