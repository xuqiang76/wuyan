<?php

namespace HttpApi\Controller\Decorator;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Model\Battery;
use HttpApi\Model\Task\Online;
use HttpApi\Model\User\Service;
use HttpApi\Model\User\User;
use HttpApi\Tool\QueryAuth;
use HttpApi\Tool\Token;
use HttpApi\Model\TaskPool\Task;
use HttpApi\Model\TaskPool\LoginTask;

/**
 * 路由装饰器
 *
 * @package HttpApi\Controller\Decorator
 */
class AuthDecorator extends BaseDecorator
{
    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     * @throws Exception
     */
    public function execute(Request $request, Response $response)
    {
        $uid = intval($request->getArg('uid'));
        $token = $request->getArg('token');
        $device_platform = $request->getArg('device_platform');

        if (empty($uid) || empty($token)) {
            throw new Exception("", 2003);
        }

        Token::checkToken($uid, $token, $device_platform);
        $infos = Service::GetRichInfo($uid);

        if ($infos['userinfo']['blocked'] == 1) {
            throw new Exception("", 1006);
        }

        if(!$this->getLastAction()->no_wallet_status_check) {
            if (!in_array($infos['wallet']['status'], [0,1016])) {
                throw new Exception("", $infos['wallet']['status']);
            }
        }

        if(TIMESTAMP - $infos['userinfo']['update_timestamp'] > 60) {
            $stat = Online::getInstance()->getStat($infos['userinfo']['id'], date("Ym"));
            $date = date("Ymd");
            if(empty($stat['stat'][$date])) {
                $stat['stat'][$date] = 1;
            } else {
                $stat['stat'][$date] += 1;
            }
            Online::getInstance()->newStat($stat);
        }

        $request->setQueryArg('userinfo', $infos['userinfo']);
        $request->setQueryArg('wallet', $infos['wallet']);
        $request->setQueryArg('battery', $infos['battery']);
        $request->setQueryArg('battery_expired', $infos['battery_expired']);
        // 全局数组
        \App::setGlobal('userinfo', $infos['userinfo']);

        parent::execute($request, $response);
    }
}
