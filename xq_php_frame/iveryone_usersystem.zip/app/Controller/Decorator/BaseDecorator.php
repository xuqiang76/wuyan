<?php

namespace HttpApi\Controller\Decorator;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;

class BaseDecorator extends \Beahoo\Controller\Decorator
{
    public function execute(Request $request, Response $response)
    {
        $classname=get_class($this->action);

        strtolower($classname)==strtolower(REQ_CLASS)?
            call_user_func_array([$this->action,REQ_METHOD],[$request,$response]):
            $this->action->execute($request, $response);
    }
}
