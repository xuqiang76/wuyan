<?php

namespace HttpApi\Controller\Decorator;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Utility;

/**
 * 路由装饰器
 *
 * @package K7659\Controller\Decorator
 */
class FilterDecorator extends BaseDecorator
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     * @result void
     */
    public function execute(Request $request, Response $response)
    {

        $args = $request->getGPArgs();
        /*
         * 解析该访问所需参数要求
         */
        $params = array();
        $apiconfs = parse_ini_file(__DIR__ . '/api.param.ini', true);
        $apiroute = implode('/', [
            $request->getServerArg('project'),
            $request->getServerArg('controller'),
            $request->getServerArg('action')
        ]);
        if(!empty($apiconfs[$apiroute])) {
            foreach ($apiconfs[$apiroute] as $key => $param) {
                list ($params [$key] ['key'], $params [$key] ['require'], $params [$key] ['not_null']) = explode(',', str_replace(' ', '', $param));
            }

            foreach ($params as $k => $v) {
                if ($v ['require']) {
                    if (isset ($args [$v ['key']])) {
                        if ($v ['not_null']) {
                            if ($this->isempty($args [$v ['key']])) {
                                throw new Exception ($v ['key'], 4100);
                            } else {
                                $params [$k] = $args [$v ['key']];
                            }
                        } else {
                            $params [$k] = $args [$v ['key']];
                        }
                    } else {
                        throw new Exception ($v ['key'], 4101);
                    }
                } else {
                    if (isset ($args [$v ['key']])) {
                        if ($v ['not_null']) {
                            if ($this->isempty($args [$v ['key']])) {
                                throw new Exception ($v ['key'], 4102);
                            } else {
                                $params [$k] = $args [$v ['key']];
                            }
                        } else {
                            $params [$k] = $args [$v ['key']];
                        }
                    } else {
                        unset ($params [$k]);
                    }
                }
            }
            $request->setFormArgs([]);
            $request->setQueryArgs($params);
        }

        parent::execute($request, $response);
    }
}
