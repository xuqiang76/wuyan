<?php

namespace HttpApi\Controller\Decorator;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use HttpApi\Tool\Log;

/**
 * 路由装饰器
 *
 * @package HttpApi\Controller\Decorator
 */
class ErrorDecorator extends BaseDecorator
{
    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     */
    public function execute(Request $request, Response $response)
    {
        try{
            parent::execute($request, $response);
        }
        catch (\Exception $e)
        {
            $code = $e->getCode() ? $e->getCode() : 400;
            $return = array(
                'errno' => $code,
                'errmsg' => $e->getMessage(),
                'time' => time(),
                'data' => new \stdClass(),
            );
            $response->setBody($return);
            Log::debug($e->getMessage() . "\t" . $e->getFile(). "\t" . $e->getLine() . "\n", 'fatal');
        }
    }

}
