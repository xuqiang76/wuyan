<?php

namespace HttpApi\Controller;

/**
 * 所有Shell相关Action的父类
 */
abstract class ShellAction extends \Beahoo\Controller\ShellAction
{
    protected $decorators = array(
        'HttpApi\Controller\Decorator\ErrorDecorator' => 'error',
        'HttpApi\Controller\Decorator\BusErrorDecorator' => 'buserror',
    );
}
