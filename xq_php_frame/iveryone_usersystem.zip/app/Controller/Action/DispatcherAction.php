<?php

namespace HttpApi\Controller\Action;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;

class DispatcherAction extends \Beahoo\Controller\Action {
	/**
	 * 装饰器
	 *
	 * @var array $decorators
	 */
	protected $decorators = array(
		'HttpApi\Controller\Decorator\RunDecorator' => 'run',
	);

	/**
	 * 实际分派的Action类名
	 *
	 * @var string $action
	 */
	protected $action;

	/**
	 * 具体的调用方法
	 * @var string
	 */
	protected $method;

	/**
	 * 获取Action类名
	 *
	 * @result string
	 */
	public function getAction() {
		return $this->action;
	}

	/**
	 * 设置Action类名
	 *
	 * @param string $action
	 *
	 * @result void
	 */
	public function setAction($action) {
		$this->action = $action;
	}

	/**
	 * 获取方法名
	 * @return string
	 */
	public function getMethod() {

		return $this->method;
	}

	/**
	 * 设置方法名
	 * @param
	 */
	public function setMethod($method) {

		$this->method = $method;
	}

	/**
	 * 执行
	 *
	 * @param \Beahoo\Controller\Request $request
	 * @param \HttpApi\Controller\Response\HttpResponse $response
	 *
	 * @result void
	 */
	public function execute(Request $request, Response $response) {
		$action = $this->load($this->getAction());

		$action->build()->execute($request, $response);

		$response->send();
	}
}
