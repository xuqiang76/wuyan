<?php

namespace HttpApi\Controller\Action\BindThird\Alipay;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\Config;
use HttpApi\Model\Wallet\CommunityActivity;

require_once ROOT . DS . 'libs/alipay/AopSdk.php';

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class IndexAction extends \HttpApi\Controller\ApiAuthAction
{

    public $no_wallet_status_check = true;

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     * @throws Exception
     */
    public function execute(Request $request, Response $response)
    {
        $userinfo = $request->getArg('userinfo');
        $wallet = $request->getArg('wallet');
        if(CommunityActivity::getInstance()->query([
            'uid' => $userinfo['id'],
            'community_type' => 2
        ]) && $wallet['status'] == 0) {
            throw new Exception("已成功完成验证", 1012);
        }

        $config = Config::read('iVeryOne_Alipay');

        $url = "https://openauth.alipay.com/oauth2/publicAppAuthorize.htm?app_id=".$config['app_id']."&scope=auth_user&redirect_uri=".urlencode($config['oauth_callback'])."&state=" . $userinfo['id'];
        $payurl =  BASE_URL . "UnlockWallet/Alipay?uid=" . $userinfo['id'];
        $data['data']['url'] = $payurl;
        $data['data']['h5_url'] = $payurl;

        $response->setBody ( $this->formatData ( $data ) );
    }
}