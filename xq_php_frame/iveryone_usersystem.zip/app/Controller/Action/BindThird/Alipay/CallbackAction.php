<?php

namespace HttpApi\Controller\Action\BindThird\Alipay;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\ArrayTool;
use Beahoo\Tool\Config;
use HttpApi\Model\User\LockUserInfo;
use HttpApi\Model\User\User;
use HttpApi\Model\Wallet\CommunityActivity;
use HttpApi\Model\Wallet\RegisterActivity;
use HttpApi\Model\Wallet\Wallet;
use HttpApi\Utility;

require_once ROOT . DS . 'libs/alipay/AopSdk.php';

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class CallbackAction extends \HttpApi\Controller\HttpAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     * @throws Exception
     */
    public function execute(Request $request, Response $response)
    {
        exit;
        $appid = $request->getArg('app_id');
        $auth_code= $request->getArg('auth_code');
        $state = $request->getArg('state', 0);

        $config = Config::read('iVeryOne_Alipay');

        if($appid != $config['app_id']) {
            Utility::renderH5Error("绑定信息验证失败");
        }

        $userinfo = User::getInstance()->getUserinfoByUid($state);
        if(empty($userinfo)) {
            Utility::renderH5Error("用户不存在");
        }

        $aop = new \AopClient();
        $aop->format = "json";
        $aop->gatewayUrl = $config['gatewayUrl'];
        $aop->appId = $config['app_id'];
        $aop->rsaPrivateKey = $config['merchant_private_key'];
        $aop->alipayrsaPublicKey = $config['alipay_public_key'];
        $aop->charset = $config['charset'];
        $aop->signType = $config['sign_type'];

        $request = new \AlipaySystemOauthTokenRequest ();
        $request->setGrantType("authorization_code");
        $request->setCode($auth_code);
        $result = $aop->execute ( $request);
        if(empty($result->alipay_system_oauth_token_response)) {
            Utility::renderH5Error("绑定信息验证失败");
        }

        $accessToken = $result->alipay_system_oauth_token_response->access_token;
        $request = new \AlipayUserInfoShareRequest ();
        $result = $aop->execute ( $request , $accessToken );
        if(empty($result->alipay_user_info_share_response)) {
            Utility::renderH5Error("绑定信息验证失败");
        }

        if($result->alipay_user_info_share_response->user_status != 'T' || $result->alipay_user_info_share_response->is_certified != 'T') {
            Utility::renderH5Error("绑定信息验证失败");
        }

        $exist = CommunityActivity::getInstance()->queryAll([
            'community_type' => 2,
            'community_usermark' => $result->alipay_user_info_share_response->user_id,
        ]);
        if(!empty($exist) && !in_array($userinfo['id'], ArrayTool::getFields($exist, 'uid')) && count($exist) >= 2) {
            Utility::renderH5Error("您的支付宝绑定的iVeryOne帐号已经超过2个了");
        }

        $exist = CommunityActivity::getInstance()->query([
            'uid' => $userinfo['id'],
            'community_type' => 2
        ]);
        if(!empty($exist) && $exist['community_usermark'] != $result->alipay_user_info_share_response->user_id) {
            Utility::renderH5Error("您已经绑定过支付宝了");
        } else if (!empty($exist)) {
            Wallet::getInstance()->status($userinfo['id'], 0);
        } else {
            CommunityActivity::getInstance()->create($userinfo['id'], 2, $result->alipay_user_info_share_response->user_id, $result->alipay_user_info_share_response);
            Wallet::getInstance()->status($userinfo['id'], 0);
        }

        Utility::renderH5Error("验证成功，请您重试刚才的操作");
    }
}