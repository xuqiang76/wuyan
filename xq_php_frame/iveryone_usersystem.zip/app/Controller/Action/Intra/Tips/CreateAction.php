<?php

namespace HttpApi\Controller\Action\Intra\Tips;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use HttpApi\Controller\IntraApiAction;
use HttpApi\Model\WalletNew\Tips;

class CreateAction extends IntraApiAction {
    public function execute(Request $request, Response $response) {
        Tips::getInstance ()->create ( [ 
            'uid' => $request->getArg ( 'uid' ),
            'tid' => $request->getArg ( 'tid' ),
            'author' => $request->getArg ( 'author' ),
            'amount' => $request->getArg ( 'amount' ) ,
            'title'  => $request->getArg('title')
        ] );
        $response->setBody ( $this->formatData ( [ 
            'data' => [ ] 
        ] ) );
    }
}