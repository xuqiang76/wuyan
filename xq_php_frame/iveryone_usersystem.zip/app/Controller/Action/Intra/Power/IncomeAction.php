<?php

namespace HttpApi\Controller\Action\Intra\Power;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Controller\IntraApiAction;
use HttpApi\Model\Wallet\Details;

class IncomeAction extends IntraApiAction {
    public function execute(Request $request, Response $response) {
        try {
            $param = $request->getGPArgs ();
            $data = [ 
                'data' => Details::getInstance ()->query ( [ 
                    'receiver' => 'system',
                    'category' => Details::Power_Auditor,
                    'recorder' => $param ['uid'],
                    'limit' => $param ['limit'] ?? 100,
                    'offset' => $param ['offset'] ?? 0
                ] ) 
            ];
        } catch ( Exception $e ) {
            $data ['errno'] = $e->getCode ();
            $data ['errmsg'] = $e->getMessage ();
        }
        $response->setBody ( $this->formatData ( $data ) );
    }
}