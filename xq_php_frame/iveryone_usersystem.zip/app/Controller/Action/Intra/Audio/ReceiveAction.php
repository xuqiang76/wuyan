<?php

namespace HttpApi\Controller\Action\Intra\Audio;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Controller\IntraApiAction;
use HttpApi\Model\Wallet\RedPack;

class ReceiveAction extends IntraApiAction
{
    public function execute(Request $request, Response $response)
    {
        try {
            $param = $request->getGPArgs();
            unset($param['secret']);
            $param ['category'] = RedPack::Audio;
            $data = [
                'data' => RedPack::getInstance()->recevice($param)
            ];
        } catch (Exception $e) {
            $data ['errno'] = $e->getCode();
            $data ['errmsg'] = $e->getMessage();
        }
        $response->setBody($this->formatData($data));
    }
}