<?php

namespace HttpApi\Controller\Action\Intra\Audio;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Controller\IntraApiAction;
use HttpApi\Model\Wallet\RedPack;
use HttpApi\Model\Wallet\Details;

class BillAction extends IntraApiAction {
    public function execute(Request $request, Response $response) {
        try {
            $param = $request->getGPArgs ();
            unset($param['secret']);
            $param ['category'] = [ 
                RedPack::Audio,
                RedPack::Audio_Cancel 
            ];
            $data = [ 
                'data' => RedPack::getInstance ()->bill ( $param, Details::Audio ) 
            ];
        } catch ( Exception $e ) {
            $data ['errno'] = $e->getCode ();
            $data ['errmsg'] = $e->getMessage ();
        }
        $response->setBody ( $this->formatData ( $data ) );
    }
}