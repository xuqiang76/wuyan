<?php

namespace HttpApi\Controller\Action\Intra\Purchased;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use HttpApi\Controller\IntraApiAction;
use HttpApi\Model\Wallet\Details;

class QueryAction extends IntraApiAction
{
    public function execute(Request $request, Response $response)
    {
        $param = [
            'recorder' => $request->getArg('uid'),
            'offset' => $request->getArg('offset', 0),
            'limit' => $request->getArg('limit', 0)
        ];

        if($category = $request->getArg('category')) {
            $param['category'] = $category;
        }

        if($direction = $request->getArg('direction')) {
            $param['direction'] = $direction;
        }

        $data = [
            'data' => []
        ];
        foreach (Details::getInstance()->query($param) as $item) {
            $data ['data'] [] = [
                'id' => $item['id'],
                'receiver' => $item['receiver'],
                'category' => $item['category'],
                'uniqid' => $item ['uniqid'],
                'amount' => $item['amount'],
                'remark' => $item['remark'],
                'create_timestamp' => $item['create_timestamp']
            ];
        }
        $response->setBody($this->formatData($data));
    }
}