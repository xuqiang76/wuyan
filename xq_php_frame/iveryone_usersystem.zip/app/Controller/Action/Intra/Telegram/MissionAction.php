<?php

namespace HttpApi\Controller\Action\Intra\Telegram;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\Config;
use HttpApi\Model\Battery;
use HttpApi\Model\User\User;
use HttpApi\Model\Wallet\CommunityActivity;
use HttpApi\Model\Wallet\LotteryActivity;
use HttpApi\Tool\Log;
use unreal4u\TelegramAPI\HttpClientRequestHandler;
use unreal4u\TelegramAPI\Telegram\Methods\SendMessage;
use \unreal4u\TelegramAPI\Telegram\Types\Update;
use unreal4u\TelegramAPI\TgLog;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class MissionAction extends \HttpApi\Controller\IntraApiAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     * @throws Exception
     */
    public function execute(Request $request, Response $response)
    {
        $uid = $request->getArg('uid');
        $usermark = $request->getArg('usermark');

        $data['data']['status'] = 0;
        if (!CommunityActivity::getInstance()->query([
            'community_type' => 0,
            'community_usermark' => $usermark
        ])) {
            $userinfo = User::getInstance()->getUserinfoByUid($uid);
            if (!empty($userinfo)) {
                if (!CommunityActivity::getInstance()->query([
                    'uid' => $userinfo['id'],
                    'community_type' => 0
                ])) {
                    Battery::getInstance()->increaseCapacity($userinfo['id'], 1);
                    CommunityActivity::getInstance()->create($userinfo['id'], 0, $usermark);
                    $data['data']['status'] = 1;
                }
            }
        }

        $response->setBody($this->formatData($data));
    }
}