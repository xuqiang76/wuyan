<?php

namespace HttpApi\Controller\Action\Intra\Video;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Controller\ApiAuthAction;
use HttpApi\Controller\IntraApiAction;
use HttpApi\Model\Wallet\RedPack;

class CreateAction extends IntraApiAction {
    public function execute(Request $request, Response $response) {
        try {
            $param = $request->getGPArgs ();
            unset($param['secret']);
            $param ['category'] = RedPack::Video;
            RedPack::getInstance ()->insert ( $param );
            $data ['data'] = '';
        } catch ( Exception $e ) {
            $data ['errno'] = $e->getCode ();
            $data ['errmsg'] = $e->getMessage ();
        }
        $response->setBody ( $this->formatData ( $data ) );
    }
}