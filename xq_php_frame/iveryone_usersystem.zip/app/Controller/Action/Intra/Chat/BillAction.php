<?php

namespace HttpApi\Controller\Action\Intra\Chat;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Controller\IntraApiAction;
use HttpApi\Model\Wallet\RedPack;
use HttpApi\Model\Wallet\Details;

class BillAction extends IntraApiAction {
    public function execute(Request $request, Response $response) {
        try {
            $param = $request->getGPArgs ();
            unset($param['secret']);
            $param ['category'] = [ 
                RedPack::Chat,
                RedPack::Chat_Cancel 
            ];
            $data = [ 
                'data' => RedPack::getInstance ()->bill ( $param, Details::Chat ) 
            ];
        } catch ( Exception $e ) {
            $data ['errno'] = $e->getCode ();
            $data ['errmsg'] = $e->getMessage ();
        }
        $response->setBody ( $this->formatData ( $data ) );
    }
}