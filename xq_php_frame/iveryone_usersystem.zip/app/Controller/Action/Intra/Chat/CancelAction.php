<?php

namespace HttpApi\Controller\Action\Intra\Chat;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Controller\ApiAuthAction;
use HttpApi\Controller\IntraApiAction;
use HttpApi\Model\Wallet\RedPack;

class CancelAction extends IntraApiAction {
    public function execute(Request $request, Response $response) {
        try {
            $param = $request->getGPArgs ();
            unset($param['secret']);
            $data = [ 
                'data' => RedPack::getInstance ()->cancel ( $param, RedPack::Chat )
            ];
        } catch ( Exception $e ) {
            $data ['errno'] = $e->getCode ();
            $data ['errmsg'] = $e->getMessage ();
        }
        $response->setBody ( $this->formatData ( $data ) );
    }
}