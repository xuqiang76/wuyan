<?php

namespace HttpApi\Controller\Action\Intra\Thread;

use afs\Request\V20180112\AnalyzeNvcRequest;
use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\Config;
use HttpApi\Controller\IntraApiAction;
use HttpApi\Model\User\User;
use HttpApi\Model\Wallet\Balance;
use HttpApi\Model\Wallet\Thread;
use HttpApi\Model\Wallet\Wallet;
use HttpApi\Tool\GeeGuardLib;
use HttpApi\Tool\Log;
use HttpApi\Tool\PurchaseFrequncy;
use HttpApi\Tool\SellerFrequncy;
use HttpApi\Tool\Token;
use HttpApi\Tool\WmCheat;
use HttpApi\Utility;

require_once ROOT . '/libs/aliyun-php-sdk-core/Config.php';
class BuyAction extends IntraApiAction
{
    /**
     * @param Request $request
     * @param Response $response
     *
     * @throws Exception
     */
    public function execute(Request $request, Response $response)
    {
        $uid = $request->getArg('buyer');
        $receiver = $request->getArg('seller');
        $amount = $request->getArg('amount');

        $tid = $request->getArg('threadid');
        $channel = $request->getArg('channel');
        $remark = $request->getArg('remark');
        $plan = $request->getArg('plan', 1);
        $ip = $request->getArg('ip');

        $param = [
            'recorder' => $uid,
            'receiver' => $receiver,
            'amount' => $amount,
            'tid' => $tid,
            'channel' => $channel,
            'remark' => $remark,
            'plan' => $plan,
        ];

        if($amount != 0) {
            $userinfo = User::getInstance()->getPureUserInfo($uid);
            if(!in_array($uid, Config::read('white_list_uids'))) {
                $wmtoken = $request->getArg('wmtoken');
                $params = [];
                $params['businessId'] = Config::read('WM_Cheat');
                $params['token'] = $wmtoken;
                $params['account'] = $uid;
                $params['phone'] = $userinfo['phone'];
                $params['ip'] = $ip;
                $params['registerTime'] = $userinfo['create_timestamp'];
                $params['registerIp'] = $userinfo['register_ip'];
                $params["activityId"] = "thread_purchase";
                $params["target"] = $receiver;
                $wmcheckres = WmCheat::check($params);
                if($wmcheckres['code'] == 200 && $wmcheckres['result']['action'] == 20) {
                    $frequncycheck = PurchaseFrequncy::getInstance()->auth($uid . "_thread");
                    if($frequncycheck == 1) {
                        throw new Exception("", 1004);
                    }
                    if($frequncycheck == 2) {
                        Wallet::getInstance()->status($uid, 1014);
                        throw new Exception("", 1014);
                    }
                }
            }
        }

        $data['data'] = [];
        Thread::getInstance()->create($param);
        $response->setBody($this->formatData($data));
    }
    private function unvalidClick($params, $param){
        $iClientProfile = \DefaultProfile::getProfile("cn-beijing", "LTAIgqlgNpdOi1H6", "SbbBjxAroCcHnvxQgA5gZ8GlQ7DqcG");
        $client = new \DefaultAcsClient($iClientProfile);
        \DefaultProfile::addEndpoint("cn-beijing", "cn-beijing", "afs", "afs.aliyuncs.com");
        $screquest = new AnalyzeNvcRequest();
        $screquest->setData($params['a']);
        $screquest->setScoreJsonStr("{\"200\":\"PASS\",\"400\":\"NC\",\"600\":\"SC\",\"800\":\"BLOCK\"}");
        $response = $client->getAcsResponse($screquest);
        $param['validcode'] = $response->BizCode;
        if(in_array($response->BizCode, [200,400,600])) {
            if($response->BizCode != 200){
                Log::debug($param, "buythreadrisk");
            }
            return 0;
        }
        Log::debug($param, "buythreadunvalid");
        return -1;
    }
}