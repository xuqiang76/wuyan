<?php

namespace HttpApi\Controller\Action\Intra\Thread;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use HttpApi\Controller\IntraApiAction;
use HttpApi\Model\Wallet\Thread;
use HttpApi\Model\Wallet\Details;

class PurchaseInfoAction extends IntraApiAction
{
    public function execute(Request $request, Response $response)
    {
        $param = [
            'category' => Details::Thread_Buy,
            'uniqid' => $request->getArg('id'),
            'status' => 1
        ];
        $data = [
            'data' => []
        ];
        $data ['data'] = Thread::getInstance()->getCount($param)/2;
        $response->setBody($this->formatData($data));
    }
}