<?php

namespace HttpApi\Controller\Action\Intra\Thread;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use HttpApi\Controller\IntraApiAction;
use HttpApi\Model\Wallet\Thread;
use HttpApi\Model\Wallet\Details;

class QueryAction extends IntraApiAction
{
    public function execute(Request $request, Response $response)
    {
        $param = [
            'category' => Details::Thread_Buy
        ];
        if($clauses = $request->getArg('clause')) {
            foreach ($clauses as $clause) {
                if (isset ($clause ['buyer']) && isset ($clause ['threadid'])) {
                    $param ['recorder'] = $clause ['buyer'];
                    $param ['uniqid'] [] = $clause ['threadid'];
                }
            }
        } else if($uid = $request->getArg('uid')) {
            $param['recorder'] = $uid;
            if($receiver = $request->getArg('seller')) {
                $param['receiver'] = $receiver;
            }
            if($uniqid = $request->getArg('threadid')) {
                $param['uniqid'] = $uniqid;
            }
            if($offset = $request->getArg('offset')) {
                $param['offset'] = $offset;
            }
        }

        $data = [
            'data' => []
        ];
        foreach (Thread::getInstance()->query($param) as $item) {
            $data ['data'] [] = [
                'buyer' => $item ['recorder'],
                'threadid' => $item ['uniqid']
            ];
        }
        $response->setBody($this->formatData($data));
    }
}