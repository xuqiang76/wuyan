<?php

namespace HttpApi\Controller\Action\Intra\Contacts;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Tool\ArrayTool;
use HttpApi\Controller\IntraApiAction;
use HttpApi\Model\Contacts;
use HttpApi\Model\User\User;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class SetSuggestedContractAction extends IntraApiAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     */
    public function execute(Request $request, Response $response)
    {
        $uid = $request->getArg('uid');
        $groupid = $request->getArg('groupid');

        $uids = [];
        if($groupid == 999) {
            $res = Contacts::getInstance()->getItems(['uid' => $uid, 'contact_status' => 1, 'star_status' => 1]);
            $uids = ArrayTool::getFields($res, 'contact_uid');
        }

        $data['data']['uids'] = $uids;
        $response->setBody($this->formatData($data));
    }
}