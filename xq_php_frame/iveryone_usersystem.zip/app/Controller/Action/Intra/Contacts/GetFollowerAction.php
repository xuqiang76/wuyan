<?php

namespace HttpApi\Controller\Action\Intra\Contacts;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use HttpApi\Controller\IntraApiAction;
use HttpApi\Model\Contacts;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class GetFollowerAction extends IntraApiAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     */
    public function execute(Request $request, Response $response)
    {
        $uid = $request->getArg('uid');
        $limit = $request->getArg('limit', 50);
        $lastid = $request->getArg('lastid', 0);

        $data['data']['list'] = Contacts::getInstance()->getFollowers($uid, $limit, $lastid);

        $response->setBody($this->formatData($data));
    }
}