<?php

namespace HttpApi\Controller\Action\Intra\Shadow;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use HttpApi\Controller\IntraApiAction;
use HttpApi\Model\Ad;

class GetAdsAction extends IntraApiAction {
	/**
	 *
	 * @param Request $request
	 * @param Response $response
	 * @throws \Beahoo\Exception
	 */
	public function execute(Request $request, Response $response) {
		$adids = $request->getArg('adids');

		$ads = [];
		$ads = Ad::getInstance()->query(['id' => $adids]);

		$data['data']['ads'] = $ads;
		$response->setBody($this->formatData($data));
	}
}