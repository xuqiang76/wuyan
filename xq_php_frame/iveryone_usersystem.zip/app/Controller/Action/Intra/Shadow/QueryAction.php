<?php

namespace HttpApi\Controller\Action\Intra\Shadow;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Controller\IntraApiAction;
use HttpApi\Model\Ad;
use HttpApi\Model\User\Service;
use HttpApi\Tool\BehaviorLogs;

class QueryAction extends IntraApiAction {
    /**
     *
     * @param Request $request
     * @param Response $response
     * @throws \Beahoo\Exception
     */
    public function execute(Request $request, Response $response) {

        $userinfo = Service::GetRichInfo($request->getArg('uid'), false);

        $re_data = Ad::getInstance()->query_adsense([
            'userinfo' => $userinfo['userinfo'],
            'register' => $request->getArg('create_timestamp'),
            'limit' => $request->getArg('limit', 3),
            'type' => $request->getArg('type', 'follow'),
            'privilege' => $userinfo['wallet']['status'],
        ]);

        if (!$re_data) {
            //空内容
            throw new Exception('', 4000);
        }

        $data = [
            'data' => $re_data,
        ];
        if (!empty($data['data'])) {
            BehaviorLogs::addLogs($request->getArg('uid'), BehaviorLogs::ACT_WATCHAD, [
                'type' => 1,
            ], 'watch advertise');
        }
        $response->setBody($this->formatData($data));
    }
}