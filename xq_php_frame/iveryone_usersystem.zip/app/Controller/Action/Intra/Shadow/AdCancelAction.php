<?php

namespace HttpApi\Controller\Action\Intra\Shadow;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Controller\IntraApiAction;
use HttpApi\Model\Ad;

class AdCancelAction extends IntraApiAction {
	public function execute(Request $request, Response $response) {

		$id = intval($request->getArg('id'));
		if (!$id) {
			throw new Exception('参数错误', 5000);
		}

		$re_data = Ad::getInstance()->cancel([
			'uid' => '',
			'id' => $id,
		]);
		$response->setBody($this->formatData([
			'data' => $re_data,
		]));
	}
}