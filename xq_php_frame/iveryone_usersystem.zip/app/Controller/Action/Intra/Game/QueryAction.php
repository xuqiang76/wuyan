<?php

namespace HttpApi\Controller\Action\Intra\Game;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use HttpApi\Controller\IntraApiAction;
use HttpApi\Model\Wallet\Details;
use HttpApi\Model\Wallet\Game;

class QueryAction extends IntraApiAction
{
    public function execute(Request $request, Response $response)
    {
        $param = [
            'category' => Details::Game_Booking
        ];
        if ($clauses = $request->getArg('clause')) {
            foreach ($clauses as $clause) {
                if (isset ($clause ['buyer']) && isset ($clause ['gameid']) && isset($clause['cpid'])) {
                    $param ['recorder'] = $clause ['buyer'];
                    $param ['receiver'] = $clause ['cpid'];
                    $param ['uniqid'] [] = $clause ['gameid'];
                }
            }

        } else if ($uid = $request->getArg('uid')) {
            $param['recorder'] = $uid;
            if ($receiver = $request->getArg('seller')) {
                $param['receiver'] = $receiver;
            }
            if ($uniqid = $request->getArg('gameid')) {
                $param['uniqid'] = $uniqid;
            }
            if ($offset = $request->getArg('offset')) {
                $param['offset'] = $offset;
            }
        }

        $data = [
            'data' => []
        ];
        foreach (Game::getInstance()->query($param) as $item) {
            $data ['data'] [] = [
                'buyer' => $item ['recorder'],
                'gameid' => $item ['uniqid'],
                'feedid' => $item['remark']
            ];
        }
        $response->setBody($this->formatData($data));
    }
}