<?php

namespace HttpApi\Controller\Action\Intra\Game;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use HttpApi\Controller\IntraApiAction;
use HttpApi\Model\Wallet\Details;
use HttpApi\Model\Wallet\Game;

class PurchaseAction extends IntraApiAction
{
    public function execute(Request $request, Response $response)
    {
        $orderid = Game::getInstance()->purchase([
            'uid' => $request->getArg('uid'),
            'cp' => $request->getArg('cpid'),
            'amount' => $request->getArg('amount'),
            'gameid' => $request->getArg('gameid'),
            'channel' => $request->getArg('channel'),
            'orderid' => $request->getArg('orderid'),
            'remark' => $request->getArg('remark')
        ]);
        $response->setBody($this->formatData(['data' => ['orderid' => $orderid]]));
    }
}