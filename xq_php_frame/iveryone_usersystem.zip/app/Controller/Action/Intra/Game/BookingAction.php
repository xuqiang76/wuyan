<?php

namespace HttpApi\Controller\Action\Intra\Game;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Controller\IntraApiAction;
use HttpApi\Model\User\User;
use HttpApi\Model\Wallet\Balance;
use HttpApi\Model\Wallet\Game;

class BookingAction extends IntraApiAction
{
    public function execute(Request $request, Response $response)
    {
        $uid = $request->getArg('buyer');
        $userinfo = User::getInstance()->getUserinfoByUid($uid);
        $wallet = Balance::getInstance()->query([
            'uid' => $userinfo ['id']
        ]);

        if ($wallet ['token'] <= 20 && $userinfo ['create_timestamp'] == $userinfo ['last_login_timestamp'] && $userinfo ['menuunread'] == 3 && $userinfo ['follow_num'] == 2 && $userinfo ['favguide'] == 1 && ($userinfo ['real_actived'] == 0 || $userinfo ['lastview_bill_timestamp'] == 0)) {
            throw new Exception ("", 1007);
        }
        Game::getInstance()->booking([
            'uid' => $uid,
            'cp' => $request->getArg('cpid'),
            'amount' => $request->getArg('amount'),
            'gameid' => $request->getArg('gameid'),
            'channel' => $request->getArg('channel'),
            'remark' => $request->getArg('feedid')
        ]);
        $response->setBody($this->formatData([
            'data' => []
        ]));
    }
}