<?php

namespace HttpApi\Controller\Action\Intra\User;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use HttpApi\Controller\IntraApiAction;
use HttpApi\Model\User\User;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class GetInfosAction extends IntraApiAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     */
    public function execute(Request $request, Response $response)
    {
        $uids = $request->getArg('uids');
        $userinfos = User::getInstance()->getUserinfoByUids($uids);

        $data['data']['list'] = $userinfos;
        $response->setBody($this->formatData($data));
    }
}