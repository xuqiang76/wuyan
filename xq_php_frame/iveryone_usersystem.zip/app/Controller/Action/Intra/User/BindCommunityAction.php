<?php

namespace HttpApi\Controller\Action\Intra\User;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Controller\IntraApiAction;
use HttpApi\Model\User\User;
use HttpApi\Model\Wallet\CommunityActivity;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class BindCommunityAction extends IntraApiAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     * @throws Exception
     */
    public function execute(Request $request, Response $response)
    {
        $uid = $request->getArg('uid');
        $community_type = $request->getArg('community_type');
        $community_usermark = $request->getArg('community_usermark');

        $exist1 = CommunityActivity::getInstance()->query([
            'uid' => $uid,
            'community_type' => $community_type
        ]);
        if (!empty($exist1) && $exist1['community_usermark'] != $community_usermark) {
            throw new Exception("您的iVeryOne帐号已经绑定过其他帐号了", 1001);
        }

        $exist2 = CommunityActivity::getInstance()->query([
            'community_type' => $community_type,
            'community_usermark' => $community_usermark,
        ]);
        if (!empty($exist2) && $exist2['uid'] != $uid) {
            throw new Exception("您的第三方帐号已经绑定过其他帐号了", 1001);
        }

        if(empty($exist1)) {
            CommunityActivity::getInstance()->create($uid, $community_type, $community_usermark);
        }

        $data['data']['status'] = 1;
        $response->setBody($this->formatData($data));
    }
}