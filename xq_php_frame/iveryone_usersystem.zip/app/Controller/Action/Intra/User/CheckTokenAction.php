<?php

namespace HttpApi\Controller\Action\Intra\User;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Controller\IntraApiAction;
use HttpApi\Model\Task\Online;
use HttpApi\Model\User\Service;
use HttpApi\Model\User\User;
use HttpApi\Tool\Token;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class CheckTokenAction extends IntraApiAction {

	/**
	 * 执行
	 *
	 * @param \Beahoo\Controller\Request\HttpRequest $request
	 * @param \HttpApi\Controller\Response\HttpResponse $response
	 *
	 * @result void
	 * @throws Exception
	 */
	public function execute(Request $request, Response $response) {
		$uid = $request->getArg('uid');
		$token = $request->getArg('token');
		$device_platform = strtolower($request->getArg('device_platform'));
		$no_wallet_status_check = $request->getArg('no_wallet_status_check', 0);
		$get_bbs_info = $request->getArg('get_bbs_info', 0);

		Token::checkToken($uid, $token, $device_platform);
		$infos = Service::GetRichInfo($uid, false, $get_bbs_info);

		if ($infos['userinfo']['blocked'] == 1) {
			throw new Exception("", 1006);
		}

		if (!$no_wallet_status_check) {
			if (!in_array($infos['wallet']['status'], [0, 1016])) {
				throw new Exception("", $infos['wallet']['status']);
			}
		}

		if (TIMESTAMP - $infos['userinfo']['update_timestamp'] > 60) {
			$stat = Online::getInstance()->getStat($infos['userinfo']['id'], date("Ym"));
			$date = date("Ymd");
			if (empty($stat['stat'][$date])) {
				$stat['stat'][$date] = 1;
			} else {
				$stat['stat'][$date] += 1;
			}
			Online::getInstance()->newStat($stat);
			User::getInstance()->updateFields(['update_timestamp' => TIMESTAMP], ['id' => $infos['userinfo']['id']]);
		}

		$data['data'] = $infos;
		$response->setBody($this->formatData($data));
	}
}