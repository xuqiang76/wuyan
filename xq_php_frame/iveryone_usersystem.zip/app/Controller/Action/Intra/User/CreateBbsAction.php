<?php

namespace HttpApi\Controller\Action\Intra\User;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Controller\IntraApiAction;
use HttpApi\Model\User\Bbs;
use HttpApi\Model\User\User;

require_once "/download/WuyanLibs/sms/SMS.php";

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class CreateBbsAction extends IntraApiAction {

	/**
	 * 执行
	 *
	 * @param \Beahoo\Controller\Request\HttpRequest $request
	 * @param \HttpApi\Controller\Response\HttpResponse $response
	 *
	 * @result void
	 * @throws Exception
	 */
	public function execute(Request $request, Response $response) {
		$uid = $request->getArg('uid');

		$data = Bbs::getInstance()->bbs_create(
			['content' => $request->getArg('content', '')
				, 'title' => $request->getArg('title', '')
				, 'url' => $request->getArg('url', ''),
			]);

		$response->setBody($this->formatData(['data' => $data]));
	}

}