<?php

namespace HttpApi\Controller\Action\Intra\User;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Controller\IntraApiAction;
use HttpApi\Model\Contacts;
use HttpApi\Model\User\User;
use HttpApi\Model\WalletNew\WalletNew;
use HttpApi\Tool\Team;

require_once "/download/WuyanLibs/sms/SMS.php";

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class GetInfoAction extends IntraApiAction {

	/**
	 * 执行
	 *
	 * @param \Beahoo\Controller\Request\HttpRequest $request
	 * @param \HttpApi\Controller\Response\HttpResponse $response
	 *
	 * @result void
	 * @throws Exception
	 */
	public function execute(Request $request, Response $response) {
		$uid = $request->getArg('uid');
		$country_code = strtoupper($request->getArg('country_code'));
		$phone = $request->getArg('phone');
		$code = $request->getArg('code');
		$ivoid = $request->getArg('ivoid', 0);

		if (!empty($country_code) && !empty($phone) && !empty($code)) {
			$userinfo = User::getInstance()->getUserinfoByPhone($country_code, $phone);
			if (empty($userinfo)) {
				throw new Exception("", 2001);
			}
			$transPhoneInfo = Team::transformPhoneNum($country_code, $phone);
			$res = \SMS::verifyCaptcha([
				'country_code' => $transPhoneInfo[0],
				'tel' => $transPhoneInfo[1],
				'template_code' => '5',
				'msg' => $code,
				'doexpire' => 1,
			]);
			if ($res['code'] != 0 && $code != '999999') {
				if (!in_array(RUN_ENV, ['test', 'development', 'local'])) {
					throw new Exception($res['msg'], 2011);
				}
			}
		} else if (!empty($uid)) {
			$userinfo = User::getInstance()->getUserinfoByUid($uid);
		} else {
			throw new Exception("", 1001);
		}

		$data['data']['userinfo'] = $userinfo;
		$data['data']['ivoUserinfo'] = [];
		$data['data']['contactInfo'] = [];
		$data['data']['oppositeContactInfo'] = [];
		$data['data']['contractInfo'] = [];
		$data['data']['contact_status'] = 0;
		if (!empty($ivoid)) {
			$ivouserinfo = User::getInstance()->getUserinfoByUid($ivoid);
			if (!empty($ivouserinfo)) {
				$data['data']['ivoUserinfo'] = $ivouserinfo;
				$data['data']['contactInfo'] = Contacts::getInstance()->getContact($userinfo['id'], $ivouserinfo['id']);
				$data['data']['oppositeContactInfo'] = Contacts::getInstance()->getContact($ivouserinfo['id'], $userinfo['id']);
				$data['data']['contact_status'] = Contacts::getContactStatus($data['data']['contactInfo'], $data['data']['oppositeContactInfo']);
				$data['data']['contractInfo'] = \HttpApi\Model\Contract\User::getInstance()->getBothContactMssageContract($userinfo['id'], $ivouserinfo['id']);
			}
		}

		//$data['data']['wallet'] = Balance::getInstance()->query(['uid' => $userinfo['id']]);
		$data['data']['wallet'] = WalletNew::getInstance()->getWalletInfo($userinfo['id']);
		$response->setBody($this->formatData($data));
	}
}