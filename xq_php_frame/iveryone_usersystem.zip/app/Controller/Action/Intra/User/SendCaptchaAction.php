<?php

namespace HttpApi\Controller\Action\Intra\User;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Model\User\User;
use HttpApi\Tool\Log;
use HttpApi\Tool\Team;
use HttpApi\Utility;

require_once "/download/WuyanLibs/sms/SMS.php";

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class SendCaptchaAction extends \HttpApi\Controller\IntraApiAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     * @throws Exception
     */
    public function execute(Request $request, Response $response)
    {
        $country_code = strtoupper($request->getArg('country_code'));
        $phone = $request->getArg('phone');

        $userinfo = User::getInstance()->getUserinfoByPhone($country_code, $phone);
        if (empty($userinfo)) {
            throw new Exception("", 2001);
        }

        $data['data'] = [
            'status' => 1
        ];

        $transPhoneInfo = Team::transformPhoneNum($country_code, $phone);
        $res = \SMS::sendCaptcha([
            'country_code' => $transPhoneInfo[0],
            'tel' => $transPhoneInfo[1],
            'template_code' => 5,
            'product_name' => "iVeryOne社区",
            'risk' => 0
        ]);
        if ($res['code'] != 0) {
            throw new Exception($res['msg'], 2008);
        }

        $response->setBody($this->formatData($data));
    }
}