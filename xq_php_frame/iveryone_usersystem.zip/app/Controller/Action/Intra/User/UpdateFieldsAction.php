<?php

namespace HttpApi\Controller\Action\Intra\User;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use HttpApi\Controller\IntraApiAction;
use HttpApi\Model\User\User;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class UpdateFieldsAction extends IntraApiAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     */
    public function execute(Request $request, Response $response)
    {
        $uid = $request->getArg('uid');
        $userinfo = User::getInstance()->getUserinfoByUid($uid);
        $menuunread = $request->getArg('menuunread');
        $beginnerguide = $request->getArg('beginnerguide');
        $favguide = $request->getArg('favguide');
        $real_actived = $request->getArg('real_actived');

        $setarr = [];
        if(isset($menuunread)) {
            $setarr['menuunread'] = intval($menuunread);
        }
        if(isset($beginnerguide)) {
            $setarr['beginnerguide'] = intval($beginnerguide);
        }
        if(isset($favguide)) {
            $setarr['favguide'] = intval($favguide);
        }
        if(isset($real_actived)) {
            $setarr['real_actived'] = intval($real_actived);
        }

        if(!empty($setarr)) {
            User::getInstance()->updateFields($setarr, ['id' => $userinfo['id']]);
        }

        $data['data']['status'] = 1;
        $response->setBody($this->formatData($data));
    }
}