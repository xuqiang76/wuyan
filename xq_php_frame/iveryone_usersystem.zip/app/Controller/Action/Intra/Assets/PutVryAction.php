<?php

namespace HttpApi\Controller\Action\Intra\Assets;

use function Amp\Parallel\Worker\create;
use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use HttpApi\Controller\IntraApiAction;
use HttpApi\Model\WalletNew\Transfers;

class PutVryAction extends IntraApiAction
{
    public function execute(Request $request, Response $response)
    {
        $orderid = Transfers::getInstance()->create([
            'incomeid' => $request->getArg('uid'),
            'income_title' => '外部游戏获取',
            'expendid' => $request->getArg('cpid'),
            'expend_title' => '游戏奖励发放',
            'amount' => $request->getArg('amount'),
            'remark' => $request->getArg('remark'),
            'uniqid' => $request->getArg('gameid').'-'.$request->getArg('orderid'),
            'category' => 'Game_Reward'
        ]);
        $response->setBody($this->formatData(['data' => ['orderid' => $orderid]]));
    }
}