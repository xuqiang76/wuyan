<?php

namespace HttpApi\Controller\Action\Intra\Feedback;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Controller\IntraApiAction;
use HttpApi\Model\Wallet\Details;

class CancelAction extends IntraApiAction {
    public function execute(Request $request, Response $response) {
        try {
            $param = $request->getGPArgs ();
            Details::getInstance ()->transaction_start ();
            Details::getInstance ()->confirm ( [
                'id' => Details::getInstance ()->create ( [
                    'receiver' => 'system',
                    'amount' => abs ( $param ['amount'] ),
                    'category' => Details::Feedback_Cancel,
                    'recorder' => $param ['uid'],
                    'uniqid' => $param ['uniqid']
                ], true )
            ] );
            Details::getInstance ()->transaction_commit ();
            $data = [
                'data' => [ ]
            ];
        } catch ( Exception $e ) {
            $data ['errno'] = $e->getCode ();
            $data ['errmsg'] = $e->getMessage ();
        }
        $response->setBody ( $this->formatData ( $data ) );
    }
}