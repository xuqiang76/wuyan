<?php

namespace HttpApi\Controller\Action\UnlockWallet\Alipay;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Tool\Config;
use HttpApi\Utility;

require_once ROOT . DS . 'libs/alipay/lib/AlipayTradeService.php';
require_once ROOT . DS . 'libs/alipay/lib/AlipayTradeWapPayContentBuilder.php';

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class IndexAction extends \HttpApi\Controller\HttpAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     */
    public function execute(Request $request, Response $response)
    {
        $uid = $request->getArg('uid');
        if(empty($uid)) {
            Utility::renderH5Error("用户信息错误");
            return;
        }

        $config = Config::read('iVeryOne_Alipay');

        //商户订单号，商户网站订单系统中唯一订单号，必填
        $out_trade_no = str_pad($uid, 10, "0", STR_PAD_LEFT) . date("YmdHis") . rand(000000, 999999);

        //订单名称，必填
        $subject = "iVeryOne账户验证";

        //付款金额，必填
        $total_amount = "0.01";

        //商品描述，可空
        $body = "iVeryOne账户验证";

        //超时时间
        $timeout_express = "5m";

        $payRequestBuilder = new \AlipayTradeWapPayContentBuilder();
        $payRequestBuilder->setBody($body);
        $payRequestBuilder->setSubject($subject);
        $payRequestBuilder->setOutTradeNo($out_trade_no);
        $payRequestBuilder->setTotalAmount($total_amount);
        $payRequestBuilder->setTimeExpress($timeout_express);
        $payRequestBuilder->setExtendParams(['needBuyerRealnamed' => 'T']);

        $payResponse = new \AlipayTradeService($config);
        $wappay = $payResponse->wapPay($payRequestBuilder, $config['return_url'], $config['notify_url']);

        $response->setBody($wappay);
    }
}