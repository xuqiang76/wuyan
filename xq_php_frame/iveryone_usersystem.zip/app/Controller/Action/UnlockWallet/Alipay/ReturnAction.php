<?php

namespace HttpApi\Controller\Action\UnlockWallet\Alipay;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\Config;
use HttpApi\Model\User\User;
use HttpApi\Model\Wallet\CommunityActivity;
use HttpApi\Utility;

require_once ROOT . DS . 'libs/alipay/lib/AlipayTradeService.php';

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class ReturnAction extends \HttpApi\Controller\HttpAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     * @throws Exception
     */
    public function execute(Request $request, Response $response)
    {
        $config = Config::read('iVeryOne_Alipay');

        $arr = $_GET;
        $alipaySevice = new \AlipayTradeService($config);
        $alipaySevice->writeLog(var_export($arr,true));
        $result = $alipaySevice->check($arr);

        if($arr['app_id'] != $config['app_id']) {
            throw new Exception("", 1010);
        }
        
        if($result) {//验证成功
            $uid = intval(substr($arr['out_trade_no'],0, 10));
            $userinfo = User::getInstance()->getUserinfoByUid($uid);
            if(empty($userinfo)) {
                Utility::renderH5Error("用户不存在");
            }

            $exist = CommunityActivity::getInstance()->query([
                'uid' => $uid,
                'community_type' => 2
            ]);
            if(!empty($exist) && $exist['ext']['out_trade_no'] == $arr['out_trade_no']) {
                Utility::renderH5Error("<h2>iVeryOne账号验证成功</h2><br/>您已激活VRY使用<br/>回到iVeryOne正常使用即可<br/><br/><a href='".Config::read('h5_url')."'>回到iVeryOne</a>");
            }

            Utility::renderH5Error("<h2>iVeryOne账号验证</h2>暂未收到支付宝返回的结果<br/><br/>（1个支付宝账号，最多验证2个iVeryOne账号）<br/><a href='".Config::read('h5_url')."'>回到iVeryOne</a>");
        } else {
            Utility::renderH5Error("账号验证失败");
        }
    }
}