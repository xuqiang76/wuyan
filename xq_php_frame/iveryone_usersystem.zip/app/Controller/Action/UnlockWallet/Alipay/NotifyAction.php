<?php

namespace HttpApi\Controller\Action\UnlockWallet\Alipay;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\ArrayTool;
use Beahoo\Tool\Config;
use HttpApi\Model\User\LockUserInfo;
use HttpApi\Model\User\User;
use HttpApi\Model\Wallet\AlipayPurchase;
use HttpApi\Model\Wallet\CommunityActivity;
use HttpApi\Model\Wallet\RegisterActivity;
use HttpApi\Model\Wallet\Wallet;

require_once ROOT . DS . 'libs/alipay/lib/AlipayTradeService.php';

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class NotifyAction extends \HttpApi\Controller\HttpAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     * @throws Exception
     */
    public function execute(Request $request, Response $response)
    {
        $config = Config::read('iVeryOne_Alipay');
        $arr = $_POST;
        $alipaySevice = new \AlipayTradeService($config);
        $alipaySevice->writeLog(var_export($_POST, true));
        $result = $alipaySevice->check($arr);

        if ($result) {//验证成功
            if ($arr['app_id'] != $config['app_id']) {
                throw new Exception("", 1010);
            }

            if ($arr['trade_status'] == 'TRADE_SUCCESS') {
                $uid = intval(substr($arr['out_trade_no'], 0, 10));
                $userinfo = User::getInstance()->getUserinfoByUid($uid);
                if (empty($userinfo)) {
                    AlipayPurchase::getInstance()->insert([
                        'uid' => $uid,
                        'purchase_info' => $arr,
                    ]);
                    echo "success";
                    exit;
                }

                $exist = CommunityActivity::getInstance()->queryAll([
                    'community_type' => 2,
                    'community_usermark' => $arr['buyer_id'],
                ]);
                if (!empty($exist) && !in_array($uid, ArrayTool::getFields($exist, 'uid')) && count($exist) >= 2) {
                    AlipayPurchase::getInstance()->insert([
                        'uid' => $uid,
                        'purchase_info' => $arr,
                    ]);
                    echo "success";
                    exit;
                }

                $exist = CommunityActivity::getInstance()->query([
                    'uid' => $uid,
                    'community_type' => 2
                ]);
                if (!empty($exist) && $exist['community_usermark'] != $arr['buyer_id']) {
                    AlipayPurchase::getInstance()->insert([
                        'uid' => $uid,
                        'purchase_info' => $arr,
                    ]);
                } else if (!empty($exist)) {
                    Wallet::getInstance()->status($userinfo['id'], 0);
                    AlipayPurchase::getInstance()->insert([
                        'uid' => $uid,
                        'purchase_info' => $arr,
                        'status' => 1
                    ]);
                } else {
                    CommunityActivity::getInstance()->create($userinfo['id'], 2, $arr['buyer_id'], $arr);
                    Wallet::getInstance()->status($userinfo['id'], 0);
                    AlipayPurchase::getInstance()->insert([
                        'uid' => $uid,
                        'purchase_info' => $arr,
                        'status' => 1
                    ]);
                }
            }

            echo "success";        //请不要修改或删除

        } else {
            //验证失败
            echo "fail";    //请不要修改或删除

        }
    }
}