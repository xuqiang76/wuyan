<?php

namespace HttpApi\Controller\Action\Crontab\Wallet\Shell;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use HttpApi\Controller\ShellAction;
use HttpApi\Model\WalletNew\Bill;
use HttpApi\Model\WalletNew\WalletNew;


class ImportAdWalletAction extends ShellAction
{
    /**
     * @param Request\ShellRequest $request
     * @param Response $response
     * @throws \Beahoo\Exception
     */
    public function execute(Request $request, Response $response)
    {
        //暂定停机执行方案
        $sql = "SELECT * FROM adwords WHERE status = 1";
        $result = Bill::getInstance()->getOne()->exec($sql)['data'];
        foreach($result as $value) {
            $noOver = $value['quota'] * $value['price'];
            //检测是否有新钱包
            WalletNew::getInstance()->getWalletInfo($value['advertisers']);
            //剩余VRY 转移至未确认的钱包
            if(WalletNew::getInstance()->updateUnconfirmed($value['advertisers'], $noOver, 'add')){
                $logs = "AdId:".$value['id'].'--Uid:'.$value['advertisers'].'--amount:'.$noOver."\n";
                file_put_contents(LOGS_DIR.'importAdWallet.log', $logs, FILE_APPEND);
            }
        }
    }
}