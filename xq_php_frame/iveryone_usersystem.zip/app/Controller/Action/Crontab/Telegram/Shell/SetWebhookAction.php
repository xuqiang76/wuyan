<?php

namespace HttpApi\Controller\Action\Crontab\Telegram\Shell;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Tool\Config;
use HttpApi\Controller\ShellAction;
use unreal4u\TelegramAPI\HttpClientRequestHandler;
use unreal4u\TelegramAPI\Telegram\Methods\GetWebhookInfo;
use unreal4u\TelegramAPI\Telegram\Methods\SetWebhook;
use unreal4u\TelegramAPI\Telegram\Types\WebhookInfo;
use unreal4u\TelegramAPI\TgLog;

class SetWebhookAction extends ShellAction
{
    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\ShellRequest $request
     * @param \Beahoo\Controller\Response\ShellResponse $response
     *
     * @result void
     */
    public function execute(Request $request, Response $response)
    {
        $loop = \React\EventLoop\Factory::create();
        $handler = new HttpClientRequestHandler($loop);
//        $setWebhook = new SetWebhook();
//        $setWebhook->url = 'https://userapi.ivery.one/Api/Telegram/GetUpdates';
        $tgLog = new TgLog(Config::read('Telegram_Bot_Token'), $handler);
//        $tgLog->performApiRequest($setWebhook);

        $webHookInfo = new GetWebhookInfo();
        $promise = $tgLog->performApiRequest($webHookInfo);
        $promise->then(
            function (WebhookInfo $info) {
                echo '<pre>';
                var_dump($info);
                echo '</pre>';
            },
            function (\Exception $e) {
                var_dump($e);
            }
        );
        $loop->run();
    }
}