<?php

namespace HttpApi\Controller\Action\Crontab\UnlockWallet\Shell;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\ArrayTool;
use Beahoo\Tool\Config;
use HttpApi\Controller\ShellAction;
use HttpApi\Model\TaskPool\LoginTask;
use HttpApi\Model\User\User;
use HttpApi\Model\Wallet\AdWords;
use HttpApi\Model\Wallet\AlipayPurchase;
use HttpApi\Tool\BehaviorLogs;

require_once ROOT . DS .'libs/alipay/lib/AlipayTradeService.php';
require_once ROOT . DS .'libs/alipay/lib/AlipayTradeRefundContentBuilder.php';

class RefundAction extends ShellAction {
    public function execute(Request $request, Response $response)
    {
        $config = Config::read('iVeryOne_Alipay');
        while (true) {
            $list = AlipayPurchase::getInstance()->getItems([
                'refund' => 0
            ]);
            if(empty($list)) {
                break;
            }

            AlipayPurchase::getInstance()->modify(['refund' => 1], ['id' => ArrayTool::getFields($list, 'id')]);
            foreach ($list as $item)
            {
                if(empty($item['purchase_info'])) {
                    continue;
                }

                $trade_no = trim($item['purchase_info']['trade_no']);
                $refund_amount=trim($item['purchase_info']['buyer_pay_amount']);
                $refund_reason=trim("认证费用退还");
                $out_request_no=trim($item['id'].$item['purchase_info']['out_trade_no']);

                $RequestBuilder = new \AlipayTradeRefundContentBuilder();
                $RequestBuilder->setTradeNo($trade_no);
                $RequestBuilder->setRefundAmount($refund_amount);
                $RequestBuilder->setRefundReason($refund_reason);
                $RequestBuilder->setOutRequestNo($out_request_no);

                $Response = new \AlipayTradeService($config);
                $result=$Response->Refund($RequestBuilder);
                var_dump($result);
            }
        }

    }
}