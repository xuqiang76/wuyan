<?php

namespace HttpApi\Controller\Action\Crontab\DangerUser\Shell;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Tool\ArrayTool;
use Beahoo\Tool\Config;
use HttpApi\Controller\ShellAction;
use HttpApi\Model\TaskPool\LoginTask;
use HttpApi\Model\User\Stat;
use HttpApi\Model\User\User;
use HttpApi\Model\Wallet\AdWords;
use HttpApi\Tool\BehaviorLogs;

class StatAction extends ShellAction {

    /**
     * @param Request\ShellRequest $request
     * @param Response $response
     * @throws \Beahoo\Exception
     */
    public function execute(Request $request, Response $response)
    {
        $lastid = $request->getArg('lastid');
        $breakid = $request->getArg('breakid');

        $db = User::getInstance()->getDb();
        $i = 0;
        while (true) {
            $sql = "SELECT * FROM userinfo";
            if(!empty($lastid)) {
                $sql .= " WHERE id > $lastid";
            }
            $sql .= " ORDER BY id ASC LIMIT 0,1000";
            $query = $db->query($sql);
            $users = $query->fetchAll(\PDO::FETCH_ASSOC);
            if(empty($users)) {
                break;
            }

            foreach ($users as $user) {
                if($user['id'] > $breakid) {
                    break 2;
                }
                $stat = [
                    'uid' => $user['id']
                ];
                $q = $db->query("SELECT sum(amount) as totalamount,category,receiver FROM wallet_details WHERE recorder = '". $user['id'] ."' and direction = 'income' group by category, receiver" );
                $res = $q->fetchAll(\PDO::FETCH_ASSOC);
                if(!empty($res)) {
                    $data = [];
                    foreach ($res as $item) {
                        $data[$item['category']][] = $item;
                    }
                    if(!empty($data[1])) {
                        foreach ($data[1] as $item) {
                            @$stat['register_income'] += $item['totalamount'];
                        }
                    }

                    if(!empty($data[2])) {
                        foreach ($data[2] as $item) {
                            @$stat['invite_income'] += $item['totalamount'];
                        }
                    }

                    if(!empty($data[6])) {
                        foreach ($data[6] as $item) {
                            @$stat['thread_income'] += $item['totalamount'];
                        }
                    }

                    if(!empty($data[10])) {
                        foreach ($data[10] as $item) {
                            @$stat['ad_income'] += $item['totalamount'];
                        }
                    }

                    if(!empty($data[23])) {
                        foreach ($data[23] as $item) {
                            @$stat['tips_income'] += $item['totalamount'];
                        }
                    }
                }

                $q = $db->query("SELECT sum(amount) as totalamount,category,receiver FROM wallet_details WHERE recorder = '". $user['id'] ."' and direction = 'outlay' group by category, receiver" );
                $res = $q->fetchAll(\PDO::FETCH_ASSOC);
                if(!empty($res)) {
                    $data = [];
                    foreach ($res as $item) {
                        if($item ['receiver'] == 'system_token' || $item['receiver'] == 'system_balance') {
                            continue;
                        }
                        $item['totalamount'] = abs($item['totalamount']);
                        $data[$item['category']][] = $item;
                    }

                    $outlay_receiver_details = [];
                    if(!empty($data[6])) {
                        foreach ($data[6] as $item) {
                            @$stat['thread_outlay'] += $item['totalamount'];
                            $outlay_receiver_details[$item['receiver']]['thread_outlay'] = $item;
                        }
                    }

                    if(!empty($data[23])) {
                        foreach ($data[23] as $item) {
                            @$stat['tips_outlay'] += $item['totalamount'];
                            $outlay_receiver_details[$item['receiver']]['tips_outlay'] = $item;
                        }
                    }

                    if(!empty($data[9])) {
                        foreach ($data[9] as $item) {
                            @$stat['ad_outlay'] += $item['totalamount'];
                        }
                    }

                    if(!empty($data[15])) {
                        foreach ($data[15] as $item) {
                            @$stat['ad_outlay'] -= $item['totalamount'];
                        }
                    }

                    $stat['outlay_receiver_num'] = count($outlay_receiver_details);
                    $stat['outlay_receiver_details'] = json_encode($outlay_receiver_details);
                }

                Stat::getInstance()->add($stat);
                $lastid = $user['id'];
            }
            $i+= count($users);
            echo $i . " done" . PHP_EOL;
        }
    }
}