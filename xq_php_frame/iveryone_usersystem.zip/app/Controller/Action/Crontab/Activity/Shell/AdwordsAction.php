<?php

namespace HttpApi\Controller\Action\Crontab\Activity\Shell;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use HttpApi\Controller\ShellAction;
use HttpApi\Model\Ad;

class AdwordsAction extends ShellAction {

	// public $plans = [
	// 	1, 2, 3, 10001, 10002, 10003,
	// ];

	public function execute(Request $request, Response $response) {
		Ad::getInstance()->set_cache();

		// foreach ($this->plans as $plan) {
		//     AdWords::getInstance()->redis()->del('adwords_plan_' . $plan);
		//     AdWords::getInstance()->redis()->del('adwords_plan_' . $plan . "_noprivilege");
		// }

		// foreach (AdWords::getInstance()->getOne()->select('adwords', '*', ['status' => 1])['data'] as $item) {
		//     $value = $item['advertisers'];
		//     if ($item['plan'] > 10000) {
		//         $value = $item['id'];
		//     }
		//     AdWords::getInstance()->redis()->zAdd('adwords_plan_' . $item['plan'], intval($item['price'] / 1000) . $item['start_timestamp'], $value);
		//     if (empty($item['privilege'])) {
		//         AdWords::getInstance()->redis()->zAdd('adwords_plan_' . $item['plan'] . '_noprivilege', intval($item['price'] / 1000) . $item['start_timestamp'], $value);
		//     }
		// }

	}
}