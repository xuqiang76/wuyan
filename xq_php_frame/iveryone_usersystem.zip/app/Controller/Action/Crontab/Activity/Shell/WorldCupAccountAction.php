<?php

namespace HttpApi\Controller\Action\Crontab\Activity\Shell;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use HttpApi\Controller\ShellAction;
use HttpApi\Model\Wallet\WorldCup;
use HttpApi\Model\Wallet\WorldCupUserLogs;
use HttpApi\Model\Wallet\Details;
use HttpApi\Model\Wallet\Activity;

class WorldCupAccountAction extends ShellAction {
    public function execute(Request $request, Response $response) {

        //每天10点左右 给昨天的用户发奖
        $yestoday_date = date('Y-m-d', time() - 86400);
        //$yestoday_date = date('Y-m-d', time() + 86400*2); //test
        $params = array(
            'sche_date' => $yestoday_date,
        );

        //根据计划任务时间 找出昨天比赛的ID和结果
        $wc = WorldCup::getInstance()->getSche($params);

        foreach ($wc as $key => $value) {
            $sche_id = $value['id'];
            $params = array(
                'sche_id' => $value['id'],
            );

            //出比赛结果后才继续执行
            if (!is_null($value['result'])) {

                //根据赛程ID找昨天投注的用户
                $wc_logs = WorldCupUserLogs::getInstance()->getUserLogsById($params);
                foreach ($wc_logs as $k => $val) {
                    //echo "===================" . PHP_EOL;
                    if (is_null($val['is_vic'])) { //未为被修改过、为发过奖

                        //根据用户的押注victory对比-比赛的结果result
                        if (($val['victory'] == $value['result'])) { //中奖

                            //根据结果选取赔率*用户押注的金额->写入钱包
                            $res_price = $val['price'] * $val['user_odds'];

                            Details::getInstance()->transaction_start();

                            //回写用户投注记录表
                            WorldCupUserLogs::getInstance()->update([
                                'res_price' => abs($res_price),
                                'is_vic' => '1',
                            ], [
                                'id' => $val['id'],
                            ]);

                            //写钱包
                            Details::getInstance()->confirm([
                                'id' => Details::getInstance()->create([
                                    'recorder' => $val['uid'],
                                    'receiver' => 'system',
                                    'amount' => abs($res_price),
                                    'category' => Details::Activity,
                                    'uniqid' => Activity::WorldCup . '_' . Details::Activity . '_' . ($val['id'] ?? uniqid())
                                ], true)
                            ]);
                            Details::getInstance()->transaction_commit();
                            echo 'Log_id:' . $val['id'] . ' UID:' . $val['uid'] . ' is_vic:1' . ' res_price:' . $res_price . PHP_EOL;
                        } else { //没中奖
                            WorldCupUserLogs::getInstance()->update([
                                'is_vic' => '2',
                            ], [
                                'id' => $val['id'],
                            ]);
                            echo 'Log_id:' . $val['id'] . ' UID:' . $val['uid'] . ' is_vic:2' . PHP_EOL;
                        }
                    } //
                    //echo "===================" . PHP_EOL;
                } //end foreach
            }
        }

        echo "all done " . date('Y-m-d H:i:s') . PHP_EOL;
    }
}