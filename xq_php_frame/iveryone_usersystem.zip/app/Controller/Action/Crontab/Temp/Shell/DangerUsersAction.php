<?php

namespace HttpApi\Controller\Action\Crontab\Temp\Shell;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Tool\ArrayTool;
use Beahoo\Tool\Config;
use HttpApi\Controller\ShellAction;
use HttpApi\Model\TaskPool\LoginTask;
use HttpApi\Model\User\User;
use HttpApi\Model\Wallet\AdWords;
use HttpApi\Tool\BehaviorLogs;

class DangerUsersAction extends ShellAction {
    public function execute(Request $request, Response $response)
    {
        $db = User::getInstance()->getDb();
        $one = User::getInstance()->getOne();
        $levels = Config::read('level');
        $i = 0;
        $lastid = 0;
        while (true) {
            $sql = "SELECT * FROM userinfo";
            if(!empty($lastid)) {
                $sql .= " WHERE id > $lastid";
            }
            $sql .= " ORDER BY id ASC LIMIT 0,1000";
            $query = $db->query($sql);
            $users = $query->fetchAll(\PDO::FETCH_ASSOC);
            if(empty($users)) {
                break;
            }

            $uids = ArrayTool::getFields($users, 'id');
            $query = $db->query("SELECT * FROM communitymission WHERE uid IN (". implode(",", $uids).")");
            $communitymissions = ArrayTool::list2Map($query->fetchAll(\PDO::FETCH_ASSOC), 'uid');
            foreach ($users as $user) {
                if($user['create_timestamp'] != $user['last_login_timestamp'] || $user['menuunread'] != 3 || $user['favguide'] != 1 || $user['lastview_bill_timestamp'] != 0 || !empty($communitymissions[$user['id']])) {
                    continue;
                }
                $q = $db->query("SELECT * FROM wallet_details WHERE recorder = '". $user['id'] ."' and category = 6 and direction = 'outlay' limit 1" );
                $purchased = $q->fetch(\PDO::FETCH_ASSOC);
                if(empty($purchased)) {
                    $one->insert("robot", ['uid' => $user['id']], [], [] , [], true);
                    $genealogys = $one->select('genealogy', '*', ['uid' => $user['id']])['data'];
                    foreach ($genealogys as $genealogy) {
                        if($genealogy['level'] == 0 || $genealogy['level'] > 6) {
                            continue;
                        }
                        if($genealogy['freeze'] == 1) {
                            continue;
                        }
                        $one->insert('mechanic', ['uid' => $genealogy['referer'], 'illegal' => $levels[$genealogy['level']]], [], ['illegal' => $levels[$genealogy['level']]]);
                        $one->insert('robot_detail', [
                            'uid' => $user['id'],
                            'mechanic_uid' => $genealogy['referer'],
                            'amount' => $levels[$genealogy['level']]
                        ]);
                    }
                }
                $lastid = $user['id'];
            }
            $i+= count($users);
            echo $i . " done" . PHP_EOL;
        }
    }
}