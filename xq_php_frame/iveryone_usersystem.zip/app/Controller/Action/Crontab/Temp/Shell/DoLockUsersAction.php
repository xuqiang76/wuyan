<?php

namespace HttpApi\Controller\Action\Crontab\Temp\Shell;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Tool\ArrayTool;
use HttpApi\Controller\ShellAction;
use HttpApi\Model\User\LockUserInfo;
use HttpApi\Model\User\User;

class DoLockUsersAction extends ShellAction
{
    public function execute(Request $request, Response $response)
    {
        $one = User::getInstance()->getOne();
        $db = User::getInstance()->getDb();

        $lastid = 0;
        $i = 0;
        while (true) {
            $sql = "SELECT * FROM wallet WHERE status = 0 AND uid > " . $lastid . " ORDER BY uid ASC LIMIT 1000";
            $query = $db->query($sql);
            $res = $query->fetchAll(\PDO::FETCH_ASSOC);

            $uids = ArrayTool::getFields($res, 'uid');
            $query = $db->query("SELECT * FROM alipay_purchase WHERE uid IN ('".implode("','", $uids)."')");
            $paid_uids = ArrayTool::getFields($query->fetchAll(\PDO::FETCH_ASSOC), 'uid');

            foreach ($res as $user) {
                if(!in_array($user['uid'], $paid_uids)) {
                    echo "lock " . $user['uid'] . PHP_EOL;
                    $db->exec("UPDATE wallet SET status = 1009 WHERE uid = '" . $user['uid'] . "'");
                }
                $lastid = $user['uid'];
            }
            $i += count($res);
            echo $i . " done" . PHP_EOL;
        }
    }
}