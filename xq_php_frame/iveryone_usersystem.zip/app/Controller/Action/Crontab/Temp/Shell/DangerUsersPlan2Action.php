<?php

namespace HttpApi\Controller\Action\Crontab\Temp\Shell;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Tool\ArrayTool;
use Beahoo\Tool\Config;
use HttpApi\Controller\ShellAction;
use HttpApi\Model\TaskPool\LoginTask;
use HttpApi\Model\User\User;
use HttpApi\Model\Wallet\AdWords;
use HttpApi\Tool\BehaviorLogs;

class DangerUsersPlan2Action extends ShellAction
{
    public function execute(Request $request, Response $response)
    {
        $db = User::getInstance()->getDb();
        $one = User::getInstance()->getOne();
        $levels = Config::read('level');
        $i = 0;

        while (true) {
            $lastid = 0;
            while (true) {
                $sql = "SELECT * FROM genealogy WHERE referer = " . $uid . " AND level < 7 and freeze = 0";
                if (!empty($lastid)) {
                    $sql .= " AND uid > $lastid";
                }
                $sql .= " ORDER BY uid ASC LIMIT 0,1000";
                $query = $db->query($sql);
                $users = $query->fetchAll(\PDO::FETCH_ASSOC);
                if (empty($users)) {
                    break;
                }

                $iuids = ArrayTool::getFields($users, 'uid');
                $query = $db->query("SELECT * FROM communitymission WHERE uid IN (" . implode(",", $iuids) . ")");
                $communitymissions = ArrayTool::list2Map($query->fetchAll(\PDO::FETCH_ASSOC), 'uid');
                $userinfos = ArrayTool::list2Map(User::getInstance()->getUserinfoByUids($iuids), 'id');
                foreach ($users as $user) {
                    $userinfo = $userinfos[$user['uid']];
                    if ($userinfo['avatar'] != 'http://image.ivery.one/default_avatar.png') {
                        if ($userinfo['create_timestamp'] != $userinfo['last_login_timestamp'] || $userinfo['menuunread'] != 3 || $userinfo['favguide'] != 1 || $userinfo['lastview_bill_timestamp'] != 0 || !empty($communitymissions[$userinfo['id']])) {
                            continue;
                        }
                    }

                    $one->insert("robot", ['uid' => $userinfo['id']], [], [], [], true);
                    $genealogys = $one->select('genealogy', '*', ['uid' => $userinfo['id'], 'referer' => $uid])['data'];
                    foreach ($genealogys as $genealogy) {
                        if ($genealogy['level'] == 0 || $genealogy['level'] > 6) {
                            continue;
                        }
                        if ($genealogy['freeze'] == 1) {
                            continue;
                        }
                        $one->insert('mechanic', ['uid' => $genealogy['referer'], 'illegal' => $levels[$genealogy['level']]], [], ['illegal' => $levels[$genealogy['level']]]);
                        $one->insert('robot_detail', [
                            'uid' => $user['uid'],
                            'mechanic_uid' => $genealogy['referer'],
                            'amount' => $levels[$genealogy['level']]
                        ]);
                    }
                    $lastid = $user['uid'];
                }
                $i += count($users);
                echo $i . " done" . PHP_EOL;
            }
        }
    }
}