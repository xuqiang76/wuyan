<?php

namespace HttpApi\Controller\Action\Crontab\Temp\Shell;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Tool\ArrayTool;
use Beahoo\Tool\Config;
use HttpApi\Controller\ShellAction;
use HttpApi\Model\TaskPool\LoginTask;
use HttpApi\Model\User\User;
use HttpApi\Model\Wallet\AdWords;
use HttpApi\Tool\BehaviorLogs;

class DangerUsersPlan1Action extends ShellAction
{
    public function execute(Request $request, Response $response)
    {
        $uids = [1987889,1913342,1892575,1916381,1692309,1844430,1987838,1987888,1700582,1902507,1989855,1860313,1843757,2101775,1969201,1981785,1979484,1981803,2112134,1791227,1870396,1916060];
        $db = User::getInstance()->getDb();
        $one = User::getInstance()->getOne();
        $levels = Config::read('level');
        $i = 0;
        $lastid = 0;
        foreach ($uids as $uid) {
            $sql = "SELECT sum(amount) as num, receiver as uid FROM wallet_details WHERE recorder = '" . $uid . "' AND category = 6 AND direction = 'income' GROUP BY receiver";
            $query = $db->query($sql);
            $lusers = $query->fetchAll(\PDO::FETCH_ASSOC);
            if(empty($lusers)) {
                echo $uid . " empty done" . PHP_EOL;
                continue;
            }
            $luids = ArrayTool::getFields($lusers, 'uid');
            $userinfos = ArrayTool::list2Map(User::getInstance()->getUserinfoByUids($luids), 'id');

            foreach ($lusers as $luser) {
                $userinfo = $userinfos[$luser['uid']];

                if($luser['num'] > 10000000) {
                    $one->insert('robot_t' , ['uid' => $luser['uid']], [], [], [], true);
                }

            }
            echo $uid . " done" . PHP_EOL;
        }
    }
}