<?php

namespace HttpApi\Controller\Action\Crontab\Temp\Shell;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use HttpApi\Controller\ShellAction;
use HttpApi\Model\User\LockUserInfo;
use HttpApi\Model\User\User;

class DoLockUserstAction extends ShellAction
{
    public function execute(Request $request, Response $response)
    {
        $one = User::getInstance()->getOne();
        $db = User::getInstance()->getDb();
        $uids = [1715680,1789849,1701444,1749434,1763806,1723623,1747872,1789952,1697759,1704599,1741353,1722839,1821255,1726724,1750737,1706940,1708701,1741693,1774261,1809501,1904862,1727623,1885321,1891300,1878736,1842973,1924880,1757337,1787784,1718456,1691182,1771072,1687783,1700165,1716608,1906319,1798889,1879415];
        foreach ($uids as $uid)
        {
            $lastid = 0;
            while (true) {
                $query = $db->query("SELECT * FROM robot_detail_t WHERE mechanic_uid = " . $uid . (!empty($lastid) ? " AND uid < " . $lastid : "") . " ORDER BY uid DESC LIMIT 0,500");
                $robots = $query->fetchAll(\PDO::FETCH_ASSOC);
                if(empty($robots)) {
                    break;
                }
                foreach ($robots as $robot) {
                    LockUserInfo::getInstance()->DoLock($robot['uid'], $robot['mechanic_uid'], $robot['amount']);
                    $lastid = $robot['uid'];
                    echo $lastid . " done" . PHP_EOL;
                }
                echo count($robots) . " done" . PHP_EOL;
            }
            echo $uid . " user done " . PHP_EOL;
        }
    }
}