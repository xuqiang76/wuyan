<?php

namespace HttpApi\Controller\Action\Crontab\Temp\Shell;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Tool\ArrayTool;
use Beahoo\Tool\Config;
use HttpApi\Controller\ShellAction;
use HttpApi\Model\TaskPool\LoginTask;
use HttpApi\Model\User\User;
use HttpApi\Model\Wallet\AdWords;
use HttpApi\Tool\BehaviorLogs;

class MechanicInfoAction extends ShellAction {
    public function execute(Request $request, Response $response)
    {
        $db = User::getInstance()->getDb();
        $one = User::getInstance()->getOne();
        $levels = Config::read('level');
        $i = 0;
        $lastid = 0;
        while (true) {
            $sql = "SELECT * FROM mechanic";
            if(!empty($lastid)) {
                $sql .= " WHERE uid > $lastid";
            }
            $sql .= " ORDER BY uid ASC LIMIT 0,1000";
            $query = $db->query($sql);
            $users = $query->fetchAll(\PDO::FETCH_ASSOC);
            if(empty($users)) {
                break;
            }

            $uids = ArrayTool::getFields($users, 'uid');
            $query = $db->query("SELECT * FROM wallet where uid IN (".implode(",", $uids).")");
            $wallets = ArrayTool::list2Map($query->fetchAll(\PDO::FETCH_ASSOC), 'uid');
            foreach ($users as $user) {
                $q = $db->query("SELECT sum(amount) as income FROM wallet_details WHERE recorder = '".$user['uid']."' AND category NOT IN (11,15) AND direction = 'income'");
                $income = $q->fetch(\PDO::FETCH_ASSOC)['income'];
                $q = $db->query("SELECT sum(amount) as income FROM wallet_details WHERE recorder = '".$user['uid']."' AND category = 2 AND direction = 'income'");
                $inviteincome = $q->fetch(\PDO::FETCH_ASSOC)['income'];
                $one->update('mechanic', [
                    'income' => round($income/1000000),
                    'balance' => round($wallets[$user['uid']]['balance']/1000000),
                    'inviteincome' => round($inviteincome/1000000)
                ], [], ['uid' => $user['uid']]);
                $lastid = $user['uid'];
            }
            $i+= count($users);
            echo $i . " done" . PHP_EOL;
        }
    }
}