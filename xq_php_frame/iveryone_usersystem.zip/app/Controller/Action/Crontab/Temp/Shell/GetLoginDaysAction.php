<?php

namespace HttpApi\Controller\Action\Crontab\Temp\Shell;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use HttpApi\Controller\ShellAction;
use HttpApi\Model\TaskPool\LoginTask;
use HttpApi\Model\User\User;
use HttpApi\Model\Wallet\AdWords;
use HttpApi\Tool\BehaviorLogs;

class GetLoginDaysAction extends ShellAction {
    public function execute(Request $request, Response $response)
    {
        $db = User::getInstance()->getDb();
        $i = 0;
        $lastid = 0;
        while (true) {
            $sql = "SELECT * FROM userinfo";
            if(!empty($lastid)) {
                $sql .= " WHERE id > $lastid";
            }
            $sql .= " ORDER BY id ASC LIMIT 0,500";
            $query = $db->query($sql);
            $users = $query->fetchAll(\PDO::FETCH_ASSOC);
            if(empty($users)) {
                break;
            }
            foreach ($users as $user) {
                $loginstat = "";
                $starttimestamp = $user['create_timestamp'];
                $endtimestamp = strtotime(date("Y-m-d", $user['create_timestamp']) . " 23:59:59");
                while ($starttimestamp < TIMESTAMP) {
                    $q = $db->query('SELECT * FROM behavior_logs WHERE uid = ' . $user['id'] . ' AND timestamp >= ' . $starttimestamp . ' AND timestamp < ' . $endtimestamp . " LIMIT 0,1");
                    $res = $q->fetch(\PDO::FETCH_ASSOC);
                    if($res) {
                        $loginstat .= "1";
                    } else {
                        $loginstat .= "0";
                    }
                    $starttimestamp = $endtimestamp;
                    $endtimestamp+= 86400;
                }
                $setarr = [
                    'uid' => $user['id'],
                    'stat' => $loginstat,
                    'timestamp' => TIMESTAMP
                ];
                LoginTask::getInstance()->getOne()->insert('task_login', $setarr, ['stat', 'timestamp']);
                echo $user['id'] . ":" . $loginstat . PHP_EOL;
                $lastid = $user['id'];
            }
            $i+= count($users);
            echo $i . " done" . PHP_EOL;
        }
    }
}