<?php

namespace HttpApi\Controller\Action\Crontab\Temp\Shell;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use HttpApi\Controller\ShellAction;
use HttpApi\Model\User\LockUserInfo;
use HttpApi\Model\User\User;

class TestLockUsersAction extends ShellAction
{
    public function execute(Request $request, Response $response)
    {
        $db = User::getInstance()->getDb();

        $query = $db->query("select DISTINCT(d.ruid) from danger_user_lock d left join wallet w on d.ruid = w.uid where w.status = 0 and d.islock = 'Y'");
        $res = $query->fetchAll(\PDO::FETCH_ASSOC);

        foreach ($res as $item) {
            LockUserInfo::getInstance()->UnlockByRuid($item['ruid']);
            echo $item['ruid'] . " unlock" . PHP_EOL;
        }

    }
}