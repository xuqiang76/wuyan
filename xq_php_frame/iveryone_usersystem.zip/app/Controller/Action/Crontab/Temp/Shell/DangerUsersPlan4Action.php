<?php

namespace HttpApi\Controller\Action\Crontab\Temp\Shell;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Tool\ArrayTool;
use Beahoo\Tool\Config;
use HttpApi\Controller\ShellAction;
use HttpApi\Model\TaskPool\LoginTask;
use HttpApi\Model\User\User;
use HttpApi\Model\Wallet\AdWords;
use HttpApi\Tool\BehaviorLogs;

class DangerUsersPlan4Action extends ShellAction
{
    public function execute(Request $request, Response $response)
    {
        $uids = [1954053]; //,1791227,1896019,1942239,1895979,1895964,1890444
        $db = User::getInstance()->getDb();
        $one = User::getInstance()->getOne();
        $levels = Config::read('level');
        $i = 0;

        foreach ($uids as $uid) {
            $lastid = 0;
            $sql = "SELECT sum(amount) as num, receiver as uid FROM wallet_details WHERE recorder = '" . $uid . "' AND category = 6 AND direction = 'income' GROUP BY receiver";
            $query = $db->query($sql);
            $users = $query->fetchAll(\PDO::FETCH_ASSOC);
            $iuids = ArrayTool::getFields($users, 'uid');

            $sql = "SELECT uid FROM genealogy WHERE referer = " . $uid . " AND freeze = 0";
            $query = $db->query($sql);
            $users = $query->fetchAll(\PDO::FETCH_ASSOC);
            $iuids = array_unique(array_merge($iuids, ArrayTool::getFields($users, 'uid')));

            if(empty($iuids)) {
                echo $uid . " empty user" . PHP_EOL;
                continue;
            }

            $query = $db->query("SELECT * FROM communitymission WHERE uid IN (" . implode(",", $iuids) . ") and community_type = 2");
            $communitymissions = ArrayTool::list2Map($query->fetchAll(\PDO::FETCH_ASSOC), 'uid');

            $query = $db->query("SELECT * FROM wallet WHERE uid IN (" . implode(",", $iuids) . ")");
            $wallets = ArrayTool::list2Map($query->fetchAll(\PDO::FETCH_ASSOC), 'uid');

            $userinfos = ArrayTool::list2Map(User::getInstance()->getUserinfoByUids($iuids), 'id');
            foreach ($iuids as $iuid) {
                $lastid = $iuid;
                $userinfo = $userinfos[$iuid];
                if ($userinfo['avatar'] != 'http://image.ivery.one/default_avatar.png') {
                    echo "avatar jump " . $userinfo['id'] . PHP_EOL;
                    continue;
                }

                if ($userinfo['menuunread'] != 3 || $userinfo['favguide'] != 1) {
                    echo "basic jump " . $userinfo['id'] . PHP_EOL;
                    continue;
                }

                $details = [];
                $query = $db->query("SELECT sum(amount) as num, recorder, receiver FROM wallet_details WHERE recorder = '" . $userinfo['id'] . "' AND category = 6 AND direction = 'outlay' group by receiver");
                $res = $query->fetchAll(\PDO::FETCH_ASSOC);

                if(!empty($communitymissions[$userinfo['id']])) {
                    $risk = 0;
                    if(!empty($res) && $wallets[$userinfo['id']]['balance'] < 50000000) {
                        $total = 0;
                        foreach ($res as $item) {
                            $total += abs($item['num']);
                        }
                        if($total >= 50000000) {
                            $risk = 1;
                        }
                    }
                    if(!empty($res) && $risk == 0) {
                        echo "alipay jump " . $userinfo['id'] . PHP_EOL;
                        continue;
                    }
                } else if ($wallets[$userinfo['id']]['status'] == 0) {
                    echo "wallet jump " . $userinfo['id'] . PHP_EOL;
                    continue;
                }

                $query = $db->query("SELECT count(*) as num FROM wallet_details WHERE recorder = '" . $userinfo['id'] . "' AND direction = 'income'");
                $num = $query->fetch(\PDO::FETCH_ASSOC)['num'];
                if ($num > 5) {
                    echo "income num jump " . $userinfo['id'] . PHP_EOL;
                    continue;
                }

                foreach ($res as $item) {
                    $details[$item['receiver']] = [
                        'uid' => $userinfo['id'],
                        'mechanic_uid' => $item['receiver'],
                        'amount' => round(-$item['num'] / 1000000)
                    ];
                }

                $genealogys = $one->select('genealogy', '*', ['uid' => $userinfo['id']])['data'];
                foreach ($genealogys as $genealogy) {
                    if ($genealogy['level'] == 0 || $genealogy['level'] > 6) {
                        continue;
                    }
                    if ($genealogy['freeze'] == 1) {
                        continue;
                    }

                    if(!empty($details[$genealogy['referer']])) {
                        $details[$genealogy['referer']]['amount'] += $levels[$genealogy['level']];
                    } else {
                        $details[$genealogy['referer']] = [
                            'uid' => $userinfo['id'],
                            'mechanic_uid' => $genealogy['referer'],
                            'amount' => $levels[$genealogy['level']]
                        ];
                    }
                }

                foreach ($details as $detail) {
                    $res = $one->insert('robot_detail_t', [
                        'uid' => $userinfo['id'],
                        'mechanic_uid' => $detail['mechanic_uid'],
                        'amount' => $detail['amount']
                    ], [], [], [], true);
                    $one->insert('mechanic_t', ['uid' => $detail['mechanic_uid'], 'illegal' => $detail['amount']], [], ['illegal' => $detail['amount']]);
                }
            }
            echo count($iuids) . " done" . PHP_EOL;
            echo $uid . " user done" . PHP_EOL;
        }
    }
}