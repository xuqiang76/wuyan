<?php

namespace HttpApi\Controller\Action\Crontab\Temp\Shell;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use HttpApi\Controller\ShellAction;
use HttpApi\Model\User\LockUserInfo;
use HttpApi\Model\User\User;
use HttpApi\Model\Wallet\Balance;
use HttpApi\Model\Wallet\RegisterActivity;

class ReissueInviteAction extends ShellAction
{
    public function execute(Request $request, Response $response)
    {
        echo "123";
        $uid = 1709020;
        $invite_uid = [2094711,2094720,2096089];

        if(!empty($uid) && !empty($invite_uid)) {
            if(is_array($invite_uid)) {
                foreach ($invite_uid as $iuid) {
                    $wallet = Balance::getInstance()->query(['uid' => $iuid]);
                    var_dump($wallet);
                    RegisterActivity::getInstance()->Reissueinsert(['uid' => $iuid, 'referer' => $uid]);
                    if($wallet['status'] == 0) {
                        LockUserInfo::getInstance()->UnlockByRuid($iuid);
                    }
                    echo $iuid . PHP_EOL;
                }
            } else {
                $wallet = Balance::getInstance()->query(['uid' => $invite_uid]);
                RegisterActivity::getInstance()->Reissueinsert(['uid' => $invite_uid, 'referer' => $uid]);
                if($wallet['status'] == 0) {
                    LockUserInfo::getInstance()->UnlockByRuid($invite_uid);
                }
                echo $invite_uid . PHP_EOL;
            }
        }
    }
}