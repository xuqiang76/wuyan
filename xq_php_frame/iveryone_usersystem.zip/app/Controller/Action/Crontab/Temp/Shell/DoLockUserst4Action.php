<?php

namespace HttpApi\Controller\Action\Crontab\Temp\Shell;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\ArrayTool;
use HttpApi\Controller\ShellAction;
use HttpApi\Model\User\LockUserInfo;
use HttpApi\Model\User\User;
use HttpApi\Model\Wallet\Wallet;

class DoLockUserst4Action extends ShellAction
{
    public function execute(Request $request, Response $response)
    {
        $one = User::getInstance()->getOne();
        $db = User::getInstance()->getDb();
        $uids = [1698850];
        foreach ($uids as $uid)
        {
            $lastid = 0;
            while (true) {
                $query = $db->query("SELECT * FROM robot_detail_t WHERE mechanic_uid = " . $uid . (!empty($lastid) ? " AND uid < " . $lastid : "") . " ORDER BY uid DESC LIMIT 0,500");
                $robots = $query->fetchAll(\PDO::FETCH_ASSOC);
                if(empty($robots)) {
                    break;
                }
                $ruids = ArrayTool::getFields($robots, 'uid');
                $query = $db->query("SELECT * FROM wallet WHERE uid IN (" . implode(",", $ruids) . ")");
                $wallets = ArrayTool::list2Map($query->fetchAll(\PDO::FETCH_ASSOC), 'uid');

                foreach ($robots as $robot) {
                    LockUserInfo::getInstance()->DoLock($robot['uid'], $robot['mechanic_uid'], $robot['amount']);
                    try {
                        Wallet::getInstance()->status($robot['uid'], 1009);
                    } catch (Exception $e) {
                        //do nothing
                    }

                    $lastid = $robot['uid'];
                    echo $lastid . " done" . PHP_EOL;
                }
                echo count($robots) . " done" . PHP_EOL;
            }
            echo $uid . " user done " . PHP_EOL;
        }
    }
}