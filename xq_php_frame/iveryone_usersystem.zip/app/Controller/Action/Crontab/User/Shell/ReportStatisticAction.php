<?php

namespace HttpApi\Controller\Action\Crontab\User\Shell;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Tool\ArrayTool;
use Beahoo\Tool\Config;
use HttpApi\Controller\ShellAction;
use HttpApi\Model\Contacts;
use HttpApi\Model\User\Stat;
use HttpApi\Model\User\User;
use HttpApi\Tool\SDKs;
use HttpApi\Model\WalletNew\Bill;
use HttpApi\Model\Wallet\Details;
use HttpApi\Tool\IMInterface;
use HttpApi\Tool\Log;

/**
 * 昨日账户部分收益账单总计
 * 晚七点跑计划任务推送
 * TODO::随着一天内账单数据量激增,会伴随着效率的降低，就需要分批进行统计啦
 */
class ReportStatisticAction extends ShellAction {

    public function execute(Request $request, Response $response){

        @ini_set('memory_limit', '1024M');

        $iveryone_helper_uid=Config::read('iveryone_helper_uid');

        $filter_types=[
            // Details::Candy_Register, // 注册邀请奖励
            Details::Candy_Level, // 注册邀请奖励
            Details::Thread_Buy, // 文章购买
            Details::Tips, // 文章打赏
            Details::Thread_Spread, // 文章转发
            Details::AdSense, // 查看广告
            Details::Audio, // IM 音频
            Details::Chat, // IM 文本
            Details::Video, // IM 视频
            Details::Transfer, // 用户转账
            Details::Power_Auditor, // 审核者收入
            Details::Feedback_Reward, // 举报者奖励
        ];

        $yestoday=strtotime(date('Y-m-d',strtotime('-1 day')));
        $today=strtotime(date('Y-m-d'));

        $m_user=User::getInstance()->getOne();
        $m_wallet_detail=Details::getInstance()->getOne();
        $redis = SDKs::getRedis();

        try{

            $sql="SELECT income_id,scene_category,sum(amount) as total FROM bill WHERE create_timestamp>=".$yestoday.' AND create_timestamp<'.$today.' AND direction_type=1 AND income_role=1 AND status=2 AND scene_category IN ('.implode(',',$filter_types).')'.' GROUP BY income_id,scene_category';

            $result=$m_wallet_detail->exec($sql)['data'];

        }catch(Exception $e){
            Log::debug('MySQL Exception:'.PHP_EOL.$sql.PHP_EOL.$e->getMessage(), "push.statistic");
        }
        
        $user_count=[];
        
        foreach ($result as $res) {

            $user_count[$res['income_id']][$res['scene_category']]=$res['total']/1000000;
        }
        
        foreach ($user_count as $uid=>$count) {
            
            $messages=[];

            $sql='SELECT id,report_push_statistic,fans_num FROM userinfo WHERE id='.$uid;

            $userinfo=$m_user->exec($sql)['data'][0];

            if($userinfo['report_push_statistic']){
                // 获取昨天的用户关注数
                $yestoday_follow_num=$redis->hget('report_push_follow_'.date('ymd',$yestoday),$uid);

                $yestoday_follow_num && $messages[]='关注我的: '.$userinfo['fans_num'].'人,新增: '.floatval($yestoday_follow_num).'人';
                $count[Details::Thread_Buy]>0 && $messages[]='文章售出收益: '.floatval($count[Details::Thread_Buy]).'VRY';
                $count[Details::Tips]>0 && $messages[]='文章打赏: '.floatval($count[Details::Tips]).'VRY';
                $count[Details::Thread_Spread]>0 && $messages[]='文章转发分成: '.floatval($count[Details::Thread_Spread]).'VRY';
                $count[Details::AdSense]>0 && $messages[]='查看广告收益: '.floatval($count[Details::AdSense]).'VRY';
                (isset($count[Details::Chat]) || isset($count[Details::Audio]) || isset($count[Details::Video]))  && $messages[]='IM收益: '.(floatval($count[Details::Audio])+floatval($count[Details::Chat])+floatval($count[Details::Video])).'VRY';
                $count[Details::Candy_Level]>0 && $messages[]='邀请奖励: '.floatval($count[Details::Candy_Level]).'VRY';
                $count[Details::Transfer]>0 && $messages[]='接收转账: '.floatval($count[Details::Transfer]).'VRY';
                $count[Details::Feedback_Reward]>0 && $messages[]='举报成功奖励: '.floatval($count[Details::Feedback_Reward]).'VRY';
                $count[Details::Power_Auditor]>0 && $messages[]='审核工资: '.floatval($count[Details::Power_Auditor]).'VRY';

                Log::debug($uid.':'.var_export($messages,true), "push.statistic");
            }else{
                Log::debug($uid.':report_push_statistic=0', "push.statistic");
            }
            
            if(!empty($messages)){

                array_unshift($messages, "每日报告\n".date('Y-m-d',$yestoday));

                try{

                    $msgbody=['msg'=>implode("\n", $messages)];

                    $daychat_res = IMInterface::send($iveryone_helper_uid,0,$uid,0,$msgbody,IMInterface::makeExt($uid,0,json_encode($msgbody), 0));
                }catch(Exception $e){

                    Log::debug('IM Exception:'.PHP_EOL.$uid.PHP_EOL.$e->getMessage(), "push.statistic");
                }
            }
        }
        // 设置失效时间
        $redis->expire('report_push_follow_'.date('ymd',$yestoday),3600*24*3);
    }
}