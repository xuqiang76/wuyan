<?php

namespace HttpApi\Controller\Action\Crontab\User\Shell;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Tool\ArrayTool;
use Beahoo\Tool\Config;
use HttpApi\Controller\ShellAction;
use HttpApi\Model\User\User;
use HttpApi\Tool\iVeryOneApi;
use HttpApi\Model\Wallet\Details;
use HttpApi\Tool\IMInterface;
use HttpApi\Tool\Log;

/**
 * 部分收益通过小v助手进行实时推送
 * 作为后台进程一直循环跑数据。没有数据则休眠10秒
 */
class ReportEveryoneAction extends ShellAction {

    public function execute(Request $request, Response $response){

        $m_user=User::getInstance();
        $m_wallet_detail=Details::getInstance()->getOne();

        $iveryone_helper_uid=Config::read('iveryone_helper_uid');

        $filter_types=[
            // Details::Candy_Register, //
            Details::Candy_Level, // 注册邀请奖励
            Details::Thread_Buy, // 文章购买
            Details::Tips, // 文章打赏
            Details::Thread_Spread, // 文章转发
            Details::AdSense, // 查看广告
            // Details::Audio, // IM 音频
            // Details::Chat, // IM 文本
            // Details::Video, // IM 视频
            Details::Transfer, // 用户转账
            Details::Power_Auditor, // 审核者收入
            Details::Feedback_Reward, // 举报者奖励
        ];

        $limit=1000;

        $sql='SELECT id FROM bill ORDER BY id DESC LIMIT 1';

        $result=$m_wallet_detail->exec($sql)['data'][0];
        
        $last_wallet_detail_id=$result['id']; //TODO::
        
        while (true) {

            $sql='SELECT id,income_id,expend_id,scene_category,uniqid,amount FROM bill WHERE scene_category IN ('.implode(',',$filter_types).') AND direction_type=1 AND income_role=1 AND status=2 '; // !important 只取用户收益部分。

            if($last_wallet_detail_id) $sql.=' AND id>'.$last_wallet_detail_id;
        
            $sql.=' ORDER BY id ASC LIMIT '.$limit;

            // Log::debug($sql, "push.everyone");

            $details=$m_wallet_detail->exec($sql)['data'];
            
            if($details){

                foreach ($details as $detail) {

                    Log::debug(var_export($detail,true), "push.everyone");

                    try{
                        $target_userinfo=$m_user->getUserinfoByUid($detail['income_id']);
                        Log::debug('uid:'.$target_userinfo['id'].",report_push_everyone:".$target_userinfo['report_push_everyone'], "push.everyone");
                        if(!$target_userinfo['report_push_everyone']) continue;

                        $amount=(abs($detail['amount'])/1000000).'VRY';
                        
                        switch ($detail['scene_category']) {
                            case Details::Candy_Level:{
                                
                                $match_status=preg_match('/^candy\-register\-(\d+)/',$detail['uniqid'],$match);
                                if($match_status && $match){
                                    if($match[1]){
                                        $userinfo=$m_user->getUserinfoByUid($match[1]);
                                        $content=$userinfo['nickname'].'接受了你的邀请奖励'.$amount;
                                    }
                                }
                                Log::debug("Candy_Level:".$content, "push.everyone");
                                break;
                            }
                            case Details::Thread_Buy:{
                                
                                $thread=$this->getThreadDetail($detail['uniqid']);

                                if(!empty($thread)){
                                        
                                    $userinfo=$m_user->getUserinfoByUid($detail['expend_id']);

                                    $content=$userinfo['nickname'].'购买了你的文章"'.$thread['title'].'"';
                                }
                                Log::debug("Thread_Buy:".$content, "push.everyone");
                                break;
                            }
                            case Details::Tips:{
                                
                                $match_status=preg_match('/^transferTips_(\d+)/',$detail['uniqid'],$match);

                                if($match_status && $match && $match[1]){

                                    $thread=$this->getThreadDetail($match[1]);
                                    if(!empty($thread)){
                                        
                                        $userinfo=$m_user->getUserinfoByUid($detail['expend_id']);

                                        $content=$userinfo['nickname'].'给你的文章"'.$thread['title'].'"打赏'.$amount;
                                    }
                                }
                                Log::debug("Thread_Tips:".$content, "push.everyone");
                                break;
                            }
                            case Details::Thread_Spread:{
                                
                                $match_status=preg_match('/^(\d+)-/',$detail['uniqid'],$match);
                                
                                if($match_status && $match){

                                    $thread=$this->getThreadDetail($match[1]);
                                    
                                    if(!empty($thread)){
                                        
                                        $content='转发文章"'.$thread['title'].'"获得分成'.$amount;
                                     }
                                }
                                Log::debug("Thread_Spread:".$content, "push.everyone");
                                break;
                            }
                            case Details::AdSense:{
                                $content='查看广告获得'.$amount.' V点';
                                Log::debug("AdSense:".$content, "push.everyone");
                                break;
                            }
                            case Details::Audio:
                            case Details::Chat:
                            case Details::Video:{
                                Log::debug("Audio&&Chat&&Video", "push.everyone");
                                break;
                            }
                            case Details::Transfer:{
                                $userinfo=$m_user->getUserinfoByUid($detail['income_id']);
                                $content=$userinfo['nickname'].'向你转账'.$amount;
                                Log::debug("AdSense:".$content, "push.everyone");
                                break;
                            }
                            case Details::Power_Auditor:{
                                $content='审核工资'.$amount.'已发放至钱包';
                                Log::debug("Power_Auditor:".$content, "push.everyone");
                                break;
                            }
                            case Details::Feedback_Reward:{
                                $feedback_id=$detail['uniqid'];
                                $feedback=iVeryOneApi::Request('Intra/Feedback/Feedback',['id'=>[$feedback_id]])['data'][$feedback_id];
                                if($feedback){
                                    $thread=$this->getThreadDetail($feedback['tid']);
                                    if($thread && $thread['uid']){
                                        $content='举报文章“'.$thread['title'].'”通过，获得'.$amount;
                                    }
                                }
                                Log::debug("Feedback_Reward:".$content, "push.everyone");
                                break;
                            }
                        }

                        if($content){
                            try{
                                $msgbody=['msg'=>$content];
                                IMInterface::send($iveryone_helper_uid,0,$detail['income_id'],0,$msgbody,IMInterface::makeExt($detail['income_id'],0,json_encode($msgbody), 0));
                            }catch(Exception $e){
                                Log::debug('IM Exception:'.PHP_EOL.var_export($detail,true).PHP_EOL.$e->getMessage(), "push.everyone");
                            }
                        }
                        
                        
                    }catch(Exception $e){

                        Log::debug('RUN Exception:'.var_export($detail,true).PHP_EOL.$e->getMessage(), "push.everyone");
                    }finally{
                        $last_wallet_detail_id=$detail['id'];
                    }
                }
            }else{
                // 暂停10秒
                sleep(10);
            }
        }
    }

    private function getThreadDetail($thread_id){

        return iVeryOneApi::Request('Intra/Thread/Info',['tid'=>$thread_id])['data'];
    }
}