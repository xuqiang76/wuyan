<?php

namespace HttpApi\Controller\Action\Crontab\User\Shell;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Tool\ArrayTool;
use Beahoo\Tool\Config;
use HttpApi\Controller\ShellAction;
use HttpApi\Model\Contacts;
use HttpApi\Model\TaskPool\LoginTask;
use HttpApi\Model\User\LockUserInfo;
use HttpApi\Model\User\Stat;
use HttpApi\Model\User\User;
use HttpApi\Model\Wallet\AdWords;
use HttpApi\Model\Wallet\Balance;
use HttpApi\Model\Wallet\Wallet;
use HttpApi\Tool\BehaviorLogs;

class Upgrade093Action extends ShellAction {

    /**
     * @param Request\ShellRequest $request
     * @param Response $response
     * @throws \Beahoo\Exception
     */
    public function execute(Request $request, Response $response)
    {
        $lastid = $request->getArg('lastid');
        $breakid = $request->getArg('breakid');

        $db = User::getInstance()->getDb();
        $one = User::getInstance()->getOne();
        $i = 0;
        while (true) {
            $sql = "SELECT * FROM userinfo";
            if(!empty($lastid)) {
                $sql .= " WHERE id > $lastid";
            }
            $sql .= " ORDER BY id ASC LIMIT 0,1000";
            $query = $db->query($sql);
            $users = $query->fetchAll(\PDO::FETCH_ASSOC);
            if(empty($users)) {
                break;
            }

            $wallets = ArrayTool::list2Map($one->selectOne('wallet', '*', ['uid' => ArrayTool::getFields($users, 'id')]), 'uid');

            foreach ($users as $user) {
                if(!empty($breakid) && $user['id'] > $breakid) {
                    break 2;
                }

                User::getInstance()->transaction_start();
                $addsetarr = [
                    'upgraded' => 1
                ];
                $q = $db->query("SELECT sum(amount) as totalamount FROM wallet_details WHERE recorder = '". $user['id'] ."' and category = 10 and direction = 'income'" );
                $res = $q->fetch(\PDO::FETCH_ASSOC);
                if(!empty($res['totalamount'])) {
                    $addsetarr['adwords'] = $res['totalamount'];
                }

                $haslock = LockUserInfo::getInstance()->getItem(['ruid' => $user['id'], 'lock_uid' => $user['id'], 'islock' => 'Y']);
                if($haslock) {
                    if($wallets[$user['id']]['freeze'] >= $haslock['lock_amount']) {
                        Balance::getInstance()->freeze($haslock['lock_uid'], -bcdiv($haslock['lock_amount'], 1000000, 6));
                    }
                    $one->update('danger_user_lock', ['islock' => 'N'], [], ['id' => $haslock['id']]);
                }

                Balance::getInstance()->lockBalance($user['id']);
                Wallet::getInstance()->status($user['id'], 1016, false, $addsetarr);
                User::getInstance()->transaction_commit();
                $lastid = $user['id'];
            }
            $i+= count($users);
            echo $i . " done" . PHP_EOL;
        }
    }
}