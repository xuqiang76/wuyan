<?php

namespace HttpApi\Controller\Action\Index\Index;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Tool\Config;
use EasyWeChat\Factory;
use HttpApi\Controller\HttpAction;
use HttpApi\Model\User\InviteCode;

/**
 * @package \HttpApi\Controller\Action\Index\Index
 */
class IndexAction extends HttpAction
{
    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     */
    public function execute(Request $request, Response $response)
    {
        echo "xc";
    }
}