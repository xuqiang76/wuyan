<?php
/**
 * Created by PhpStorm.
 * User: zhangyuanhao
 * Date: 2018/6/20
 * Time: 15:15
 */

namespace HttpApi\Controller\Action\Order\Alipay;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\ArrayTool;
use Beahoo\Tool\Config;

use HttpApi\Model\Orders\Orders;
use HttpApi\Model\Pay\Alipay;
use HttpApi\Model\Goods\Goods;
use HttpApi\Model\WalletNew\Bill;

require_once ROOT . DS . 'libs/alipay/lib/AlipayTradeService.php';

class PayNotifyAction extends \HttpApi\Controller\HttpAction
{
    public function execute(Request $request, Response $response)
    {
        $config = Config::read('iVeryOne_Alipay');
        $arr = $_POST;
        $alipaySevice = new \AlipayTradeService($config);
        $alipaySevice->writeLog(var_export($_POST, true));
        $result = $alipaySevice->check($arr);
        // 验证成功
        if($result) {
            if ($arr['app_id'] != $config['app_id']) {
                throw new Exception("", 1010);
            }
            if ($arr['trade_status'] == 'TRADE_SUCCESS') {
                $tradeNoId = $arr['out_trade_no'];

                $orderInfo = Orders::getInstance()->getOrderInfoByTradeNo($tradeNoId);
                if(!$orderInfo) {
                    throw new Exception("订单不存在", 4416);
                }

                // 记录log
                Alipay::getInstance()->notifyLog($orderInfo['id'], $tradeNoId, $orderInfo['uid'], $arr['total_amount'], $arr);

                if($orderInfo['status'] != 3) {
                    // 更新订单
                    Orders::getInstance()->updateOrderStatus($tradeNoId, 3, [
                        'pay_timestamp' => strtotime($arr['gmt_payment'])
                    ]);

                    // 获取商品
                    $goodsInfo = Goods::getInstance()->getGoodsInfo($orderInfo['goods_id']);
                    if(!$goodsInfo)
                        throw new Exception("商品不存在", 4415);

                    // 增加充值余额
                    Bill::getInstance()->rechargeV($orderInfo['uid'], $goodsInfo['value'], [
                        'uniqid' => $tradeNoId,
                        'title'  => $orderInfo['order_title']
                    ], $orderInfo['platform'] == 1 ? true : false);
                }
            }
            echo "success";
        } else {
            echo "fail";
        }
    }
}