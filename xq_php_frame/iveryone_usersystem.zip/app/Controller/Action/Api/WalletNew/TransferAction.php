<?php
/**
 * Created by PhpStorm.
 * User: zhangyuanhao
 * Date: 2018/6/13
 * Time: 18:05
 */

namespace HttpApi\Controller\Action\Api\WalletNew;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\Config;

use HttpApi\Model\User\User;
use HttpApi\Model\WalletNew\Transfers;
use HttpApi\Model\WalletNew\WalletNew;
use HttpApi\Tool\Format;
use HttpApi\Tool\SDKs;

class TransferAction extends \HttpApi\Controller\ApiAuthAction
{
    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     */
    public function execute(Request $request, Response $response)
    {
        $uid = $request->getArg('uid');
        $touid = $request->getArg('touid');
        $amount = $request->getArg('amount');
        $paypassword = $request->getArg('paypassword');
        $userinfo = User::getInstance()->getNoCacheUserInfo($uid,['password','salt']);
        $touserinfo = User::getInstance()->getUserinfoByUid($touid);

        if(empty($touserinfo)){
            throw new Exception("", 2001);
        }
        if(floatval($amount)<=0){
            throw new Exception("转账金额不能为0", 2004);
        }

        $walletInfo = WalletNew::getInstance()->getWalletInfo($uid);

        if($walletInfo['balance_vry'] < $amount) {
            throw new Exception("余额不足", 2021);
        }

        if($walletInfo['transfer'] != 0) {
            throw new Exception ( '没有转账权限', 4030 );
        }

        if($this->getWrong($uid)>=5){
            throw new Exception("密码输入错误已达5次，请24小时后重试", 2022);
        }

        //较验支付密码
        if ($userinfo['pay_password'] != md5(md5($paypassword) . $userinfo['pay_salt'])) {
            $this->setWrong($uid);
            throw new Exception("密码输入错误", 2020);
        }

        $insert =  [
            'incomeid'       => $touid,
            'expendid'       => $uid,
            'amount'         => $amount,       //单位VRY
            'income_title'   => '转账-'.$userinfo['nickname'],
            'expend_title'   => '转账-'.$touserinfo['nickname'],
            'remark'         => '',
        ];
        Transfers::getInstance()->transaction_start();
        $data['data']['status'] = 0;
        try{
            Transfers::getInstance()->create($insert);
            $data['data']['status'] = 1;
            Transfers::getInstance()->transaction_commit();
        } catch (Exception $e) {
            Transfers::getInstance()->transaction_rollback();
            throw new Exception("转账失败", 2024);
        }

        $data['data']['status'] = 1;
        $response->setBody($this->formatData($data));
    }

    private function setWrong($uid){
        $wrongKey = 'wrongpaypassword_count';
        $res = SDKs::getRedis()->hget($wrongKey, $uid);
        $wrongcount = 0;
        if($res){
            $res = json_decode($res,true);
            $wrongcount = $res['count'];
        }
        $wrongcount++;
        SDKs::getRedis()->hset($wrongKey, $uid, json_encode(['count' => $wrongcount, 'last_time' => TIMESTAMP]));
    }

    private function getWrong($uid){
        $wrongKey = 'wrongpaypassword_count';
        $res = SDKs::getRedis()->hget($wrongKey, $uid);
        $wrongcount = 0;
        if($res){
            $res = json_decode($res,true);
            //是否超过24小时
            if(TIMESTAMP - $res['last_time']>= 60 * 60 * 24){
                $wrongcount = 0;
                SDKs::getRedis()->hdel($wrongKey, $uid);
            }else{
                $wrongcount = $res['count'];
            }

        }
        return $wrongcount;
    }
}