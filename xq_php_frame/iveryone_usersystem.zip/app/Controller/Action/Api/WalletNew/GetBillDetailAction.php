<?php
/**
 * Created by PhpStorm.
 * User: zhangyuanhao
 * Date: 2018/6/13
 * Time: 17:13
 */

namespace HttpApi\Controller\Action\Api\WalletNew;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\Config;
use HttpApi\Model\WalletNew\Bill;

class GetBillDetailAction extends \HttpApi\Controller\ApiAuthAction
{
    public function execute(Request $request, Response $response)
    {
        $uid = $request->getArg('uid');

        $device_platform = $request->getArg('device_platform');

        $lastDetailId = $request->getArg('last_detail_id');

        $direction_type = $request->getArg('direction_type', 'all');

        $currency_type = $request->getArg('currency_type', 'all');

        $limit = $request->getArg('limit', 20);

        $where = [];

        if ($direction_type == 'income') {
            $where['direction_type'] = 1;
        } elseif ($direction_type == 'expend') {
            $where['direction_type'] = 2;
        } else {

        }

        if ($currency_type == 'all') {
            $detailType = 0;
        } else if ($currency_type == 'v') {
            $detailType = 1;
        } else if ($currency_type == 'vry') {
            $detailType = 2;
        }

        if($lastDetailId) {
            $where['last_detail_id'] = $lastDetailId;
        }

        $isApple = $device_platform == 'ios' ? true : false;

        $billDetail = Bill::getInstance()->getBillDetail($uid, $where, 'desc', 1, $limit, $detailType, $isApple);
        $response->setBody($this->formatData(['data' => $billDetail]));
    }
}