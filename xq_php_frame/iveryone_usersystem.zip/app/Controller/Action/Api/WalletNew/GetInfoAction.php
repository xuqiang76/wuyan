<?php
/**
 * Created by PhpStorm.
 * User: zhangyuanhao
 * Date: 2018/6/13
 * Time: 14:20
 */

namespace HttpApi\Controller\Action\Api\WalletNew;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\Config;

use HttpApi\Model\WalletNew\WalletNew;
use HttpApi\Tool\Format;

class GetInfoAction extends \HttpApi\Controller\ApiAuthAction
{
    public function execute(Request $request, Response $response)
    {
        $uid = $request->getArg ( 'uid' );

        $device_platform = $request->getArg('device_platform');

        $walletInfo = WalletNew::getInstance()->getWalletInfo($uid);

        if($device_platform == 'ios') {
            $v = $walletInfo['balance_apple_v'];
        } else {
            $v = $walletInfo['balance_v'];
        }

        $data['data'] = [
            'wallet_id' => $walletInfo['id'],
            'balance_vry' => Format::amount($walletInfo['balance_vry']),
            'balance_v'   => Format::vryToV($v),
            'balance_coupon' => Format::vryToV($walletInfo['balance_coupon']),
            'old_lock' => Format::amount($walletInfo['old_lock']),
            'old_freeze' => Format::amount($walletInfo['old_freeze']),
            'not_enabled_vry' => Format::amount($walletInfo['old_lock'] + $walletInfo['old_freeze'])
        ];
        $response->setBody($this->formatData($data));
    }
}