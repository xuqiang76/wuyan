<?php
/**
 * Created by PhpStorm.
 * User: zhangyuanhao
 * Date: 2018/6/13
 * Time: 18:05
 */

namespace HttpApi\Controller\Action\Api\WalletNew;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\Config;

use HttpApi\Model\User\User;
use HttpApi\Model\WalletNew\Transfers;
use HttpApi\Model\WalletNew\WalletNew;

class ConvertAction extends \HttpApi\Controller\ApiAuthAction
{
    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     */
    public function execute(Request $request, Response $response)
    {
        $uid = $request->getArg('uid');
        $amount = $request->getArg('amount');

        if(floatval($amount)<=0){
            throw new Exception("兑换金额不能为0", 2004);
        }

        if(floatval($amount) > 2000){
            throw new Exception("单次兑换不能大于2000", 2004);
        }

        $walletInfo = WalletNew::getInstance()->getWalletInfo($uid);

        if($walletInfo['balance_vry'] < $amount) {
            throw new Exception("余额不足", 2021);
        }

        $insert =  [
            'incomeid'       => $uid,
            'expendid'       => $uid,
            'amount'         => $amount,       //单位VRY
            'uniqid'         => uniqid('Convert_'),
        ];
        Convert::getInstance()->transaction_start();
        $data['data']['status'] = 0;
        try{
            Convert::getInstance()->create($uid, $amount, $insert);
            $data['data']['status'] = 1;
            Convert::getInstance()->transaction_commit();
        } catch (Exception $e) {
            Convert::getInstance()->transaction_rollback();
            throw new Exception("兑换失败", 2024);
        }

        $data['data']['status'] = 1;
        $response->setBody($this->formatData($data));
    }
}