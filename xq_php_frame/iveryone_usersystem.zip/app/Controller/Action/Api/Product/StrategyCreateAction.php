<?php

namespace HttpApi\Controller\Action\Api\Product;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use bigcatorm\BitMap;
use HttpApi\Controller\ApiAuthAction;
use HttpApi\Model\Ad;

class StrategyCreateAction extends ApiAuthAction {

	public function execute(Request $request, Response $response) {

		$uid = intval($request->getArg('uid'));
		$title = $request->getArg('title');
		$description = $request->getArg('description');
		$type = $request->getArg('type', 'follow');
		$price = abs(floatval($request->getArg('price', 0.01)));

		$number = intval($request->getArg('number'));
		$plan = intval($request->getArg('plan', 1));
		$privilege = intval($request->getArg('privilege', 0));
		$ad_anonymous = intval($request->getArg('ad_anonymous', 0));

		if (!strlen($description)) {
			throw new Exception('描述不能为空', 5000);
		}

		if (!strlen($title)) {
			throw new Exception('名称不能为空', 5000);
		}

		if (!$number) {
			throw new Exception('人数不能为0', 5000);
		}

		if (!$uid) {
			throw new Exception('uid参数错误', 5000);
		}

		if (!in_array($uid, [1000000])) {
			if ($number > 2000) {
				throw new Exception('人数不能大于2000', 5000);
			}
		}

		if (!$price) {
			throw new Exception('价格不能为0', 5000);
		}

		if ($type == 'follow') {
			if (bccomp(10, $price, 6) == 1 || bccomp($price, 10000, 6) == 1) {
				throw new Exception('价格应在10-10000之间', 5000);
			}
		} else {
			if (bccomp(10, $price, 6) == 1 || bccomp($price, 10000, 6) == 1) {
				throw new Exception('价格应在10-10000之间', 5000);
			}
		}

		if (!in_array($plan, [1, 2, 3])) {
			throw new Exception('注册时间错误', 5001);
		}

		if (!in_array($type, ['feed', 'follow'])) {
			throw new Exception('类型错误', 5001);
		}

		$description = json_encode($description); // 转码 \u
		$title = json_encode($title); // 转码 \u

		$input_strategy = [];
		$input_strategy['plan'] = $plan;
		$input_strategy['privilege'] = $privilege;
		$input_strategy['ad_anonymous'] = $ad_anonymous;
		$strategy_raw_arr = Ad::input2strategy($input_strategy);
		$strategy = implode('_', BitMap::arr2bitmap($strategy_raw_arr));

		Ad::getInstance()->strategy_create([
			'uid' => $uid,
			'title' => $title,
			'description' => $description,
			'type' => $type,
			'price' => $price,
			'number' => $number,
			'strategy' => $strategy,
		]);
		$response->setBody($this->formatData([
			'data' => [],
		]));
	}

}
