<?php

namespace HttpApi\Controller\Action\Api\Product;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use HttpApi\Controller\ApiAuthAction;
use HttpApi\Tool\AdWords;

class PrivilegeAction extends ApiAuthAction {
	public function execute(Request $request, Response $response) {
		$response->setBody($this->formatData([
			'data' => [
				'privilege' => AdWords::privilege($request->getArg('uid')),
			],
		]));
	}
}