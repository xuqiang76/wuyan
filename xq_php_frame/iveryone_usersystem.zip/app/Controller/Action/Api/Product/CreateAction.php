<?php

namespace HttpApi\Controller\Action\Api\Product;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\Config;
use bigcatorm\BitMap;
use HttpApi\Controller\ApiAuthAction;
use HttpApi\Model\Ad;
use HttpApi\Model\Wallet\AdWords;
use HttpApi\Tool\BehaviorLogs;

class CreateAction extends ApiAuthAction {
	/**
	 *
	 * @param Request $request
	 * @param Response $response
	 * @throws \Beahoo\Exception
	 */
	public function execute(Request $request, Response $response) {
		$description = trim($request->getArg('description'));
		if (!strlen($description)) {
			throw new Exception('描述不能为空', 5000);
		}
		$number = abs(intval($request->getArg('number')));

		if (!$number) {
			throw new Exception('人数不能为0', 5000);
		}
		if (!in_array($request->getArg('uid'), [1000000])) {
			if ($number > 2000) {
				throw new Exception('人数不能大于2000', 5000);
			}
		}

		$price = abs(floatval($request->getArg('price', 0.1)));
		if (!$price) {
			throw new Exception('价格不能为0', 5000);
		}

		if ($request->getArg('type', 'follow') == 'follow') {
			if (bccomp(10, $price, 6) == 1 || bccomp($price, 10000, 6) == 1) {
				throw new Exception('价格应在10-10000之间', 5000);
			}
		} else {
			if (bccomp(10, $price, 6) == 1 || bccomp($price, 10000, 6) == 1) {
				throw new Exception('价格应在10-10000之间', 5000);
			}
		}

		$plan = intval($request->getArg('plan'));
		if (!in_array($plan, [1, 2, 3]) && !in_array($plan, [10001, 10002, 10003])) {
			throw new Exception('注册时间错误', 5001);
		}
		$type = $request->getArg('type', 'follow');
		if (!in_array($type, ['feed', 'follow'])) {
			throw new Exception('类型错误', 5001);
		}

		if ($request->getArg('type', 'follow') == 'feed') {
			$assets = $request->getArg('assets');
			if (empty($assets)) {
				throw new Exception('没有图片', 5000);
			}

			$url = $request->getArg('url');
			if (strlen($url) && !preg_match('/^https?:\/\/.*/is', $url)) {
				throw new Exception('链接格式错误', 5000);
			}

			foreach ($assets as $k => $asset) {
				$urlinfo = parse_url($asset);
				if (empty($urlinfo['host']) || !in_array($urlinfo['host'], [
					'image.ivery.one',
					Config::read('imagehost'),
				])) {
					unset($assets[$k]);
				}
			}

			$assets = array_values($assets);
			if (count($assets) > 5) {
				throw new Exception("图片数量超限", 1001);
			}

			$description = json_encode([
				'description' => $description,
				'assets' => $assets,
				'url' => \HttpApi\Tool\AdWords::privilege($request->getArg('uid')) ? $url : '',
			]);

		} else {
			$description = json_encode($description); // 转码 \u
		}

		$input_strategy = [];
		$input_strategy['plan'] = $plan;
		$input_strategy['privilege'] = intval($request->getArg('privilege', 0));
		$input_strategy['ad_anonymous'] = intval($request->getArg('ad_anonymous', 0));
		$strategy_raw_arr = Ad::input2strategy($input_strategy);
		$strategy = implode('_', BitMap::arr2bitmap($strategy_raw_arr));

		Ad::getInstance()->create([
			'description' => $description,
			'uid' => $request->getArg('uid'),
			'number' => $number,
			'price' => $price,
			'type' => $type,

			'plan' => $input_strategy['plan'],
			'privilege' => $input_strategy['ad_anonymous'],

			'strategy' => $strategy,
		]);

		BehaviorLogs::addLogs($request->getArg('uid'), BehaviorLogs::ACT_ADVERTISE, [
			'type' => 1,
			'strategy_raw_str' => implode('_', $strategy_raw_arr),
		], 'create advertise');

		$response->setBody($this->formatData([
			'data' => [],
		]));
	}

}