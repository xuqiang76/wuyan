<?php

namespace HttpApi\Controller\Action\Api\Product;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Controller\ApiAuthAction;
use HttpApi\Model\Ad;

class SchemeDelAction extends ApiAuthAction {

	public function execute(Request $request, Response $response) {

		$uid = intval($request->getArg('uid'));
		$id = intval($request->getArg('id'));

		if (!$uid || !$id) {
			throw new Exception('参数错误' . __LINE__, 5000);
		}

		$result = Ad::getInstance()->scheme_del([
			'uid' => $uid,
			'id' => $id,
		]);
		$response->setBody($this->formatData([
			'data' => $result,
		]));
	}

}
