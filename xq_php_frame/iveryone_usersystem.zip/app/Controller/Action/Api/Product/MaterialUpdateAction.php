<?php

namespace HttpApi\Controller\Action\Api\Product;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\Config;
use HttpApi\Controller\ApiAuthAction;
use HttpApi\Model\Ad;
use HttpApi\Model\Wallet\AdWords;

class MaterialUpdateAction extends ApiAuthAction {

	public function execute(Request $request, Response $response) {

		$id = intval($request->getArg('id'));
		$uid = intval($request->getArg('uid'));
		$title = $request->getArg('title');
		$description = $request->getArg('description');
		$type = $request->getArg('type', 'follow');
		$remark = $request->getArg('remark');
		$assets = $request->getArg('assets', []);
		$url = $request->getArg('url', '');

		if (!strlen($description)) {
			throw new Exception('描述不能为空', 5000);
		}

		if (!strlen($title)) {
			throw new Exception('名称不能为空', 5000);
		}

		if (!$uid || !$id) {
			throw new Exception('参数错误' . __LINE__, 5000);
		}

		if (!in_array($type, ['feed', 'follow'])) {
			throw new Exception('类型错误', 5001);
		}

		if ($type == 'feed') {
			if (empty($assets)) {
				throw new Exception('没有图片', 5000);
			}

			if (strlen($url) && !preg_match('/^https?:\/\/.*/is', $url)) {
				throw new Exception('链接格式错误', 5000);
			}

			foreach ($assets as $k => $asset) {
				$urlinfo = parse_url($asset);
				if (empty($urlinfo['host']) || !in_array($urlinfo['host'], ['image.ivery.one', Config::read('imagehost')])) {
					unset($assets[$k]);
				}
			}

			if (count($assets) > 5) {
				throw new Exception("图片数量超限", 1001);
			}

			$remark = json_encode([
				'remark' => $remark,
				'assets' => $assets,
				'url' => \HttpApi\Tool\AdWords::privilege($request->getArg('uid')) ? $url : '',
			]);

		} else {
			$remark = json_encode($remark); // 转码 \u
		}

		$description = json_encode($description);
		$title = json_encode($title); // 转码 \u

		$result = Ad::getInstance()->material_update([
			'id' => $id,
			'uid' => $uid,
			'description' => $description,
			'title' => $title,
			'type' => $type,
			'remark' => $remark,

		]);
		$response->setBody($this->formatData([
			'data' => $result,
		]));
	}

}
