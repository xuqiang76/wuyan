<?php

namespace HttpApi\Controller\Action\Api\Product;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use HttpApi\Controller\ApiAuthAction;
use HttpApi\Model\Ad;

class QueryAction extends ApiAuthAction {
	public function execute(Request $request, Response $response) {
		if (intval($request->getArg('id'))) {
			$param['id'] = intval($request->getArg('id'));
		}
		$param['advertisers'] = $request->getArg('uid');
		$type = $request->getArg('type');
		if ($type) {
			$param['type'] = $type;
		}

		$param['status'] = $request->getArg('status', []);

		$data = Ad::getInstance()->query($param);

		$response->setBody($this->formatData([
			'data' => $data,
		]));
	}

}