<?php

namespace HttpApi\Controller\Action\Api\Product;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Controller\ApiAuthAction;
use HttpApi\Model\Ad;

class AdQueryNoviceAction extends ApiAuthAction {
	/**
	 *
	 * @param Request $request
	 * @param Response $response
	 * @throws \Beahoo\Exception
	 */
	public function execute(Request $request, Response $response) {

		$userinfo = $request->getArg('userinfo');

		$param = ['uid' => $request->getArg('uid')
			, 'type' => $request->getArg('type', 'novice_gift')
			, 'limit' => 15,

		];

		$re_data = [];
		if (TIMESTAMP - $userinfo['create_timestamp'] < 86400) {
			$re_data = Ad::getInstance()->query_adsense_gift($param);
		}

		$is_click = [];
		$no_click = [];
		foreach ($re_data as $item) {
			if (isset($item['is_click']) && $item['is_click'] == 0) {
				$no_click[] = $item;
			} else {
				$is_click[] = $item;
			}
		}

		$response->setBody($this->formatData([
			'data' => ['is_click' => $is_click, 'no_click' => $no_click],
		]));
	}

}