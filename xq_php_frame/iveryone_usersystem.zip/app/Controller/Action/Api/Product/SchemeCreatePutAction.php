<?php

namespace HttpApi\Controller\Action\Api\Product;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Controller\ApiAuthAction;
use HttpApi\Model\Ad;

class SchemeCreatePutAction extends ApiAuthAction {

	public function execute(Request $request, Response $response) {

		$uid = intval($request->getArg('uid'));
		$description = $request->getArg('description');
		$title = $request->getArg('title');
		$type = $request->getArg('type');
		$material_id = intval($request->getArg('material_id'));
		$strategy_id = intval($request->getArg('strategy_id'));

		if (!$uid) {
			throw new Exception('参数错误' . __LINE__, 5000);
		}

		if (!in_array($type, ['feed', 'follow'])) {
			throw new Exception('类型错误', 5001);
		}

		if (!$description) {
			throw new Exception('描述错误' . __LINE__, 5000);
		}

		if (!$title) {
			throw new Exception('名称错误' . __LINE__, 5000);
		}

		if (!$material_id || !$strategy_id) {
			throw new Exception('参数错误' . __LINE__, 5000);
		}

		Ad::getInstance()->scheme_create_put([
			'uid' => $uid,
			'description' => json_encode($description),
			'title' => json_encode($title),
			'type' => $type,
			'material_id' => $material_id,
			'strategy_id' => $strategy_id,
		]);
		$response->setBody($this->formatData([
			'data' => [],
		]));
	}

}
