<?php

namespace HttpApi\Controller\Action\Api\Product;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Controller\ApiAuthAction;
use HttpApi\Model\Ad;

class SchemeQueryAction extends ApiAuthAction {

	public function execute(Request $request, Response $response) {

		$uid = intval($request->getArg('uid'));
		$status = intval($request->getArg('status'));
		$id = $request->getArg('id', 0);
		$type = $request->getArg('type', '');
		$page = intval($request->getArg('page', 1));
		$order = intval($request->getArg('order', 1));
		$num_per_page = intval($request->getArg('num_per_page', 50));

		if (!$uid) {
			throw new Exception('参数错误' . __LINE__, 5000);
		}

		if (!in_array($status, [0, 1, 4])) {
			throw new Exception('类型错误', 5001);
		}

		if (!$page || !$num_per_page) {
			throw new Exception('参数错误' . __LINE__, 5000);
		}

		if (!in_array($type, ['feed', 'follow', ''])) {
			throw new Exception('类型错误', 5001);
		}

		if (!in_array($order, [1, 0])) {
			throw new Exception('顺序参数错误', 5001);
		}

		$result = Ad::getInstance()->scheme_query([
			'uid' => $uid,
			'type' => $type,
			'status' => $status,
			'page' => $page,
			'num_per_page' => $num_per_page,
			'order' => $order,
			'id' => $id,
			'type_in' => ['feed', 'follow'],
		]);

		$response->setBody($this->formatData([
			'data' => $result,
		]));
	}

}
