<?php

namespace HttpApi\Controller\Action\Api\Product;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Controller\ApiAuthAction;
use HttpApi\Model\Ad;

class GetNoviceInfoAction extends ApiAuthAction {
	/**
	 *
	 * @param Request $request
	 * @param Response $response
	 * @throws \Beahoo\Exception
	 */
	public function execute(Request $request, Response $response) {

		$param = ['uid' => $request->getArg('uid')
			, 'status' => null
			, 'type' => 'novice_gift'
			, 'start_time' => strtotime(date('Y-m-d 00:00:00'))
			, 'end_time' => null,
		];

		$re_data = Ad::getInstance()->get_adwords_info($param);
		unset($re_data['adwords']);
		$response->setBody($this->formatData([
			'data' => $re_data,
		]));
	}

}