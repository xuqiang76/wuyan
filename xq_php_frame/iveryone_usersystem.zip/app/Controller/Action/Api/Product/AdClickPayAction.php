<?php

namespace HttpApi\Controller\Action\Api\Product;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Controller\ApiAuthAction;
use HttpApi\Model\Ad;

class AdClickPayAction extends ApiAuthAction {
	/**
	 *
	 * @param Request $request
	 * @param Response $response
	 * @throws \Beahoo\Exception
	 */
	public function execute(Request $request, Response $response) {

		$param = ['uid' => $request->getArg('uid')
			, 'type' => $request->getArg('type', 'novice_gift')
			, 'adwords_id' => $request->getArg('adwords_id', 0),

		];

		$re_data = Ad::getInstance()->ad_click_pay($param);
		$response->setBody($this->formatData([
			'data' => $re_data,
		]));
	}

}