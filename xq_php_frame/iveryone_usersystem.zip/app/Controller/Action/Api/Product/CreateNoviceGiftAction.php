<?php

namespace HttpApi\Controller\Action\Api\Product;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\Config;
use bigcatorm\BitMap;
use HttpApi\Controller\ApiAuthAction;
use HttpApi\Model\Ad;
use HttpApi\Tool\BehaviorLogs;

class CreateNoviceGiftAction extends ApiAuthAction {
	/**
	 *
	 * @param Request $request
	 * @param Response $response
	 * @throws \Beahoo\Exception
	 */
	public function execute(Request $request, Response $response) {
		$description = trim($request->getArg('description'));
		if (!strlen($description)) {
			throw new Exception('描述不能为空', 5000);
		}

		$number = abs(intval($request->getArg('number')));
		if ($number <= 0 || $number > 10) {
			throw new Exception('数量不对', 5000);
		}

		$free_num = 0;

		$price = abs(floatval($request->getArg('price', 300)));
		if ($price != 300 && $price != 500) {
			throw new Exception('价格不对', 5000);
		}

		$type = $request->getArg('type', 'novice_gift');
		if ($type != 'novice_gift') {
			throw new Exception('类型不对', 5000);
		}

		$assets = $request->getArg('assets', []);

		//$url = $request->getArg('url', '');
		// if (strlen($url) && !preg_match('/^https?:\/\/.*/is', $url)) {
		// 	throw new Exception('链接格式错误', 5000);
		// }

		foreach ($assets as $k => $asset) {
			$urlinfo = parse_url($asset);
			if (empty($urlinfo['host']) || !in_array($urlinfo['host'], ['image.ivery.one', Config::read('imagehost')])) {
				unset($assets[$k]);
			}
		}

		$assets = array_values($assets);
		if (count($assets) > 1) {
			throw new Exception("图片数量超限", 1001);
		}

		if (!$assets) {
			throw new Exception("图片不能为空", 1001);
		}

		$description = json_encode([
			'description' => $description,
			'assets' => $assets,
			//'url' => \HttpApi\Tool\AdWords::privilege($request->getArg('uid')) ? $url : '',
		]);

		$strategy_raw_arr = Ad::input2strategy(['plan' => null, 'privilege' => null, 'ad_anonymous' => null]);
		$strategy = implode('_', BitMap::arr2bitmap($strategy_raw_arr));

		Ad::getInstance()->create([
			'description' => $description,
			'uid' => $request->getArg('uid'),
			'number' => $number,
			'price' => $price,
			'type' => $type,

			'strategy' => $strategy,
			'free_num' => $free_num,
		]);

		BehaviorLogs::addLogs($request->getArg('uid'), BehaviorLogs::ACT_ADVERTISE, [
			'type' => 1,
			'strategy_raw_str' => implode('_', $strategy_raw_arr),
		], 'create advertise');

		$response->setBody($this->formatData([
			'data' => [],
		]));
	}

}