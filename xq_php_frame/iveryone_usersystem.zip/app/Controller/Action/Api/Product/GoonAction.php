<?php

namespace HttpApi\Controller\Action\Api\Product;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Controller\ApiAuthAction;
use HttpApi\Model\Ad;

class GoonAction extends ApiAuthAction {
	public function execute(Request $request, Response $response) {

		$id = intval($request->getArg('id'));
		if (!$id) {
			throw new Exception('参数错误', 5000);
		}

		$uid = intval($request->getArg('uid'));
		if (!$uid) {
			throw new Exception('uid错误', 5000);
		}

		Ad::getInstance()->go_on([
			'uid' => $uid,
			'id' => $id,
		]);
		$response->setBody($this->formatData([
			'data' => [],
		]));
	}
}