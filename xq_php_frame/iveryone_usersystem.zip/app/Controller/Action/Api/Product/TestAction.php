<?php

namespace HttpApi\Controller\Action\Api\Product;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
//use HttpApi\Controller\ApiAuthAction;
use HttpApi\Controller\ApiAction;
use HttpApi\Model\Ad;
use HttpApi\Model\User\Service;
use HttpApi\Tool\BehaviorLogs;

//class CancelAction extends ApiAuthAction {
class TestAction extends ApiAction {

	public function execute(Request $request, Response $response) {
		$data = [];

		//Ad::getInstance()->set_cache();

		$userinfo = Service::GetRichInfo($request->getArg('uid'), false);
		$data = [
			'data' => Ad::getInstance()->set_cache(),
		];
		if (!empty($data['data'])) {
			BehaviorLogs::addLogs($request->getArg('uid'), BehaviorLogs::ACT_WATCHAD, [
				'type' => 1,
			], 'watch advertise');
		}
		$response->setBody($this->formatData($data));
	}
}
