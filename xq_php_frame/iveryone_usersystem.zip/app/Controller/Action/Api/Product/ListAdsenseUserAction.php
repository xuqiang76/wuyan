<?php

namespace HttpApi\Controller\Action\Api\Product;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Controller\ApiAuthAction;
use HttpApi\Model\Ad;

class ListAdsenseUserAction extends ApiAuthAction {

	public function execute(Request $request, Response $response) {

		$id = intval($request->getArg('id', 0));
		if (!$id) {
			throw new Exception('参数错误', 5000);
		}

		$uid = intval($request->getArg('uid', 0));
		if (!$uid) {
			throw new Exception('uid错误', 5000);
		}

		$page = intval($request->getArg('page', 1));
		$order = intval($request->getArg('order', 1));
		$num_per_page = intval($request->getArg('num_per_page', 50));
		if (!$page || !$num_per_page) {
			throw new Exception('参数错误', 5000);
		}

		$result = Ad::getInstance()->adsense_user([
			'uid' => $uid,
			'id' => $id,
			'page' => $page,
			'num_per_page' => $num_per_page,
			'order' => $order,

		]);
		$response->setBody($this->formatData([
			'data' => $result,
		]));
	}

}
