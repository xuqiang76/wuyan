<?php

namespace HttpApi\Controller\Action\Api\Activity;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use HttpApi\Controller\ApiAuthAction;
use HttpApi\Model\Wallet\LotteryActivity;

/**
 *
 * @package \HttpApi\Controller\Action\Api\User
 */
class CollectMissionRewardAction extends ApiAuthAction {
    
    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     * @result void
     */
    public function execute(Request $request, Response $response) {
        $userinfo = $request->getArg ( 'userinfo' );
        $list = LotteryActivity::getInstance()->query($userinfo['id']);
        $data['data']['status'] = 0;
        foreach ($list as $item) {
            if($item['status'] == 0) {
                LotteryActivity::getInstance()->receive($item['id'], $userinfo['id']);
                $data['data']['status'] = 1;
                $data['data']['reward'] = $item['amount'];
                break;
            }
        }
        $response->setBody ( $this->formatData ( $data ) );
    }
}