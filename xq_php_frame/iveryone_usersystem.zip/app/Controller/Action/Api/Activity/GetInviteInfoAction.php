<?php

namespace HttpApi\Controller\Action\Api\Activity;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Tool\ArrayTool;
use Beahoo\Tool\Config;
use HttpApi\Model\Wallet\Balance;
use HttpApi\Model\Wallet\RegisterActivity;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class GetInviteInfoAction extends \HttpApi\Controller\ApiAuthAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     */
    public function execute(Request $request, Response $response)
    {
        $userinfo = $request->getArg('userinfo');
        $type = $request->getArg('type', 0);
        $tree = ArrayTool::list2Map(RegisterActivity::getInstance()->query(['referer' => $userinfo['id'], 'freeze' => 0, 'type' => $type]), 'level');
        $freezetree = ArrayTool::list2Map(RegisterActivity::getInstance()->query(['referer' => $userinfo['id'], 'freeze' => 1, 'type' => $type]), 'level');
        $levels = Config::read('level') [ $type ];

        $reissueInviteUid = 0;
        if(TIMESTAMP - $userinfo['create_timestamp'] < 86400) {
            $superiors = ArrayTool::list2Map(RegisterActivity::getInstance()->query(['uid' => $userinfo['id'], 'type' => $type]), 'level');
            if(empty($superiors[1])) {
                $reissueInviteUid = 1;
            }
        }

        $trees = [];
        $totalnum = $totalfreezenum = $totalamount = $totalfreezeamount = 0;
        foreach ($levels as $level => $candy) {
            if($level == 0) continue;
            $item = [
                'candy' => $candy,
                'level' => $level,
                'amount' => 0
            ];
            if(!empty($tree[$level])) {
                $item['amount'] = $candy*$tree[$level]['total'];
                $totalnum += $item['amount']/$item['candy'];
                $totalamount += $item['amount'];
            }

            if(!empty($freezetree[$level])) {
                $item['freezeamount'] = $candy*$freezetree[$level]['total'];
                $totalfreezenum += $item['freezeamount']/$item['candy'];
                $totalfreezeamount += $item['freezeamount'];
            }
            $trees[] = $item;
        }
        $data['data']['trees'] = $trees;
        $data['data']['totalnum'] = $totalnum;
        $data['data']['totalamount'] = $totalamount;
        $data['data']['totalfreezenum'] = $totalfreezenum;
        $data['data']['totalfreezeamount'] = $totalfreezeamount;
        $data['data']['reissueInviteUid'] = $reissueInviteUid;
        $data['data']['invite_url'] = Config::read('h5_url') . "I/" . $userinfo['id'];

        $response->setBody($this->formatData($data));
    }
}