<?php

namespace HttpApi\Controller\Action\Api\Activity;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Tool\Config;
use HttpApi\Controller\ApiAuthAction;
use HttpApi\Model\Wallet\LotteryActivity;
use HttpApi\Model\Wallet\WorldCup;
use HttpApi\Model\Wallet\WorldCupUserLogs;
use Beahoo\Exception;
use HttpApi\Model\Wallet\Details;
use HttpApi\Model\Wallet\Activity;

/**
 *
 * @package \HttpApi\Controller\Action\Api\Activity
 */
class CreateWorldCupScheAction extends ApiAuthAction {

    public $odds_params = array(
        '1' => 'major_odds',
        '2' => 'tie_odds',
        '3' => 'guest_odds',
    );

    /**
     * 用户投注函数
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     * @result void
     */
    public function execute(Request $request, Response $response) {
        

        $data['data']['status'] = 1;
        
        $sche_id = $request->getArg('sche_id');
        $uid = intval($request->getArg('uid'));
        $victory = $request->getArg('victory'); //123
        $price = (int)$request->getArg('price');
        $time = time();

        //价格验证，防止用户改价格
        $price_group = array(
            5, 10, 20, 50, 100, 200
        );
        if (!in_array($price, $price_group)) {
            throw new Exception('价格非法', 5000);
        }

        $victory_group = array(
            1, 2, 3
        );
        if (!in_array($victory, $victory_group)) {
            throw new Exception('参数非法', 5000);
        }

        $params = array(
            'id' => $sche_id,
        );
        $wc = WorldCup::getInstance()->getSche($params);
        if (!$wc) {
            throw new Exception('没有可投注的场次', 5000);
        }

        //根据胜平负获取赔率
        $victory_key = $this->odds_params[$victory];
        $user_odds = $wc[0][$victory_key];

        $createData = array(
            'sche_id' => $sche_id,
            'uid' => $request->getArg('uid'),
            'victory' => $victory,
            'price' => $price,
            'user_odds' => $user_odds,
            'time' => $time,
        );

        //判断钱包余额
        $wallet = $request->getArg('wallet');
        if ($price > ($wallet['available'] + $wallet['token'])) {
            throw new Exception('可用余额不足', 5000);
        }

        //判断投注的场次是否在可投注时间范围内
        $tomorrow_date = date('Y-m-d', time() + 86400);
        if ($tomorrow_date != $wc[0]['sche_date']) {
            throw new Exception('不在可投注时间范围内', 5000);
        }

        //判断是否已经投注，投注过禁止投注
        $params = array(
            'sche_id' => $sche_id,
            'uid' => $uid,
        );
        $wc_logs = WorldCupUserLogs::getInstance()->getUserLogsById($params);
        if ($wc_logs) {
            throw new Exception('您已经投注过', 5000);
        }

        //sche_id，uid联合唯一索引
        $insert_id = WorldCupUserLogs::getInstance()
            ->create($createData);
        //写钱包

        if ($insert_id) {
            $data['data']['message'] = '投注成功';
        } else {
            $data['data']['message'] = '投注失败';
        }
        
        $response->setBody($this->formatData($data));
    }

    /**
     * 查询用户投注记录
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     */
    public function GetUserLogs(Request $request, Response $response) {
        $uid = intval($request->getArg('uid'));
        $user_log = WorldCupUserLogs::getInstance()->getUserLogs($uid);

        $data = array();
        foreach ($user_log as $key => $value) {
            $value['country_major_name'] = GetWorldCupListAction::$country[$value['country_major']]['country_name'];
            $value['country_guest_name'] = GetWorldCupListAction::$country[$value['country_guest']]['country_name'];
            $value['country_major_flag'] = GetWorldCupListAction::$country[$value['country_major']]['flag_link'];
            $value['country_guest_flag'] = GetWorldCupListAction::$country[$value['country_guest']]['flag_link'];
            $data[$key] = $value;
        }

        $data['data'] = $data;
        $response->setBody($this->formatData($data));
    }

    /**
     * 获取用户分享数据
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     */
    public function ShareUserPic(Request $request, Response $response) {
        $uid = intval($request->getArg('uid'));
        $log_id = intval($request->getArg('log_id'));
        $user_log = WorldCupUserLogs::getInstance()->getUserPic($uid, $log_id);
        
        $data = array();
        foreach ($user_log as $key => $value) {
            $value['country_major_name'] = GetWorldCupListAction::$country[$value['country_major']]['country_name'];
            $value['country_guest_name'] = GetWorldCupListAction::$country[$value['country_guest']]['country_name'];
            $value['country_major_flag'] = GetWorldCupListAction::$country[$value['country_major']]['flag_link'];
            $value['country_guest_flag'] = GetWorldCupListAction::$country[$value['country_guest']]['flag_link'];
            $value['sharelink'] = Config::read('h5_url') . 'I/' . $uid;
            $data[$key] = $value;
        }
        
        $data['data'] = $data;
        $response->setBody($this->formatData($data));
    }

}