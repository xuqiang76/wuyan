<?php

namespace HttpApi\Controller\Action\Api\Activity;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\Config;
use EasyWeChat\Factory;
use HttpApi\Controller\ApiAuthAction;
use HttpApi\Model\User\User;
use HttpApi\Model\Wallet\LotteryActivity;

/**
 *
 * @package \HttpApi\Controller\Action\Api\User
 */
class GetMissionInfoAction extends ApiAuthAction {
    
    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *            @result void
     */
    public function execute(Request $request, Response $response) {
        $userinfo = $request->getArg ( 'userinfo' );

        $collectchance = 0;
        $data['data']['mission'] = [
            'telegram' => 0,
            'wechat' => 0,
            'telegram_url' => "https://t.me/iVeryone",
            'wechat_qrcode' => "https://avatar.ivery.one/qrcode_for_gh_67e706b2fc67_258.jpg",
            'invite_code' => "/checkcode " . $userinfo['id']
        ];
        try {
            $list = LotteryActivity::getInstance()->query($userinfo['id']);
            foreach ($list as $item) {
                if($item['status'] == 0) {
                    $collectchance++;
                }
                switch ($item['category']) {
                    case 5:
                        $data['data']['mission']['telegram'] = 1;
                        break;
                    case 4:
                        $data['data']['mission']['wechat'] = 1;
                        break;
                }
            }
        } catch (Exception $e) {
            //do nothing
        }

        $data['data']['collectchance'] = $collectchance;
        $response->setBody ( $this->formatData ( $data ) );
    }
}