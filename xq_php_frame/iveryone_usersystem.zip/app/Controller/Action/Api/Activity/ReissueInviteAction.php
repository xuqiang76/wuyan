<?php

namespace HttpApi\Controller\Action\Api\Activity;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\ArrayTool;
use Beahoo\Tool\Config;
use EasyWeChat\Factory;
use HttpApi\Controller\ApiAuthAction;
use HttpApi\Model\User\User;
use HttpApi\Model\Wallet\LotteryActivity;
use HttpApi\Model\Wallet\RegisterActivity;

/**
 *
 * @package \HttpApi\Controller\Action\Api\User
 */
class ReissueInviteAction extends ApiAuthAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     * @result void
     * @throws Exception
     */
    public function execute(Request $request, Response $response)
    {
        $userinfo = $request->getArg('userinfo');
        $wallet = $request->getArg('wallet');
        $invite_uid = $request->getArg('invite_uid');

        $invite_userinfo = User::getInstance()->getUserinfoByUid($invite_uid);
        if(empty($invite_userinfo)) {
            throw new Exception("", 2001);
        }

        if(TIMESTAMP - $userinfo['create_timestamp'] > 86400) {
            throw new Exception("", 1008);
        }

        $superiors = ArrayTool::list2Map(RegisterActivity::getInstance()->query(['uid' => $userinfo['id']]), 'level');
        if(!empty($superiors[1])) {
            throw new Exception("", 1008);
        }

        RegisterActivity::getInstance()->Reissueinsert([
            'uid' => $userinfo['id'],
            'referer' => $invite_uid,
            'register' => $userinfo['create_timestamp'],
            'freeze' => $wallet['status'] == 0 ? 0 : 1
        ]);

        $data['data'] = ['status' => 1];
        $response->setBody($this->formatData($data));
    }
}