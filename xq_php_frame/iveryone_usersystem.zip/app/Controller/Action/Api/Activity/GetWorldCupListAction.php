<?php

namespace HttpApi\Controller\Action\Api\Activity;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use HttpApi\Controller\ApiAction;
use HttpApi\Model\Wallet\LotteryActivity;
use HttpApi\Model\Wallet\WorldCup;
use HttpApi\Model\Wallet\WorldCupUserLogs;
use Beahoo\Exception;

/**
 * 世界杯临时活动
 * @package \HttpApi\Controller\Action\Api\User
 */
class GetWorldCupListAction extends ApiAction {

    public static $country = array(
        1 => array(
            'id' => 1,
            'country_name' => '俄罗斯',
            'flag_link' => 'https://iveryone.wuyan.cn/worldcup/%E4%BF%84%E7%BD%97%E6%96%AF%403x.png',
        ),
        2 => array(
            'id' => 2,
            'country_name' => '沙特阿拉伯',
            'flag_link' => 'https://iveryone.wuyan.cn/worldcup/%E6%B2%99%E7%89%B9%E9%98%BF%E6%8B%89%E4%BC%AF%403x.png',
        ),
        3 => array(
            'id' => 3,
            'country_name' => '埃及',
            'flag_link' => 'https://iveryone.wuyan.cn/worldcup/%E5%9F%83%E5%8F%8A%250A%403x.png',
        ),
        4 => array(
            'id' => 4,
            'country_name' => '乌拉圭',
            'flag_link' => 'https://iveryone.wuyan.cn/worldcup/%E4%B9%8C%E6%8B%89%E5%9C%AD%403x.png',
        ),
        5 => array(
            'id' => 5,
            'country_name' => '葡萄牙',
            'flag_link' => 'https://iveryone.wuyan.cn/worldcup/%E8%91%A1%E8%90%84%E7%89%99%403x.png',
        ),
        6 => array(
            'id' => 6,
            'country_name' => '西班牙',
            'flag_link' => 'https://iveryone.wuyan.cn/worldcup/%E8%A5%BF%E7%8F%AD%E7%89%99%403x.png',
        ),
        7 => array(
            'id' => 7,
            'country_name' => '摩洛哥',
            'flag_link' => 'https://iveryone.wuyan.cn/worldcup/%E6%91%A9%E6%B4%9B%E5%93%A5%250A%403x.png',
        ),
        8 => array(
            'id' => 8,
            'country_name' => '伊朗',
            'flag_link' => 'https://iveryone.wuyan.cn/worldcup/%E4%BC%8A%E6%9C%97%403x.png',
        ),
        9 => array(
            'id' => 9,
            'country_name' => '法国',
            'flag_link' => 'https://iveryone.wuyan.cn/worldcup/%E6%B3%95%E5%9B%BD%250A%403x.png',
        ),
        10 => array(
            'id' => 10,
            'country_name' => '澳大利亚',
            'flag_link' => 'https://iveryone.wuyan.cn/worldcup/%E6%BE%B3%E5%A4%A7%E5%88%A9%E4%BA%9A%403x.png',
        ),
        11 => array(
            'id' => 11,
            'country_name' => '秘鲁',
            'flag_link' => 'https://iveryone.wuyan.cn/worldcup/%E7%A7%98%E9%B2%81%403x.png',
        ),
        12 => array(
            'id' => 12,
            'country_name' => '丹麦',
            'flag_link' => 'https://iveryone.wuyan.cn/worldcup/%E4%B8%B9%E9%BA%A6%403x.png',
        ),
        13 => array(
            'id' => 13,
            'country_name' => '阿根廷',
            'flag_link' => 'https://iveryone.wuyan.cn/worldcup/%E9%98%BF%E6%A0%B9%E5%BB%B7%403x.png',
        ),
        14 => array(
            'id' => 14,
            'country_name' => '冰岛',
            'flag_link' => 'https://iveryone.wuyan.cn/worldcup/%E5%86%B0%E5%B2%9B%250A%403x.png',
        ),
        15 => array(
            'id' => 15,
            'country_name' => '克罗地亚',
            'flag_link' => 'https://iveryone.wuyan.cn/worldcup/%E5%85%8B%E7%BD%97%E5%9C%B0%E4%BA%9A%403x.png',
        ),
        16 => array(
            'id' => 16,
            'country_name' => '尼日利亚',
            'flag_link' => 'https://iveryone.wuyan.cn/worldcup/%E5%B0%BC%E6%97%A5%E5%88%A9%E4%BA%9A%403x.png',
        ),
        17 => array(
            'id' => 17,
            'country_name' => '巴西',
            'flag_link' => 'https://iveryone.wuyan.cn/worldcup/%E5%B7%B4%E8%A5%BF%403x.png',
        ),
        18 => array(
            'id' => 18,
            'country_name' => '瑞士',
            'flag_link' => 'https://iveryone.wuyan.cn/worldcup/%E7%91%9E%E5%A3%AB%403x.png',
        ),
        19 => array(
            'id' => 19,
            'country_name' => '哥斯达黎加',
            'flag_link' => 'https://iveryone.wuyan.cn/worldcup/%E5%93%A5%E6%96%AF%E8%BE%BE%E9%BB%8E%E5%8A%A0%403x.png',
        ),
        20 => array(
            'id' => 20,
            'country_name' => '塞尔维亚',
            'flag_link' => 'https://iveryone.wuyan.cn/worldcup/%E5%A1%9E%E5%B0%94%E7%BB%B4%E4%BA%9A%250A%403x.png',
        ),
        21 => array(
            'id' => 21,
            'country_name' => '德国',
            'flag_link' => 'https://iveryone.wuyan.cn/worldcup/%E5%BE%B7%E5%9B%BD%250A%403x.png',
        ),
        22 => array(
            'id' => 22,
            'country_name' => '墨西哥',
            'flag_link' => 'https://iveryone.wuyan.cn/worldcup/%E5%A2%A8%E8%A5%BF%E5%93%A5%250A%403x.png',
        ),
        23 => array(
            'id' => 23,
            'country_name' => '瑞典',
            'flag_link' => 'https://iveryone.wuyan.cn/worldcup/%E7%91%9E%E5%85%B8%250A%403x.png',
        ),
        24 => array(
            'id' => 24,
            'country_name' => '韩国',
            'flag_link' => 'https://iveryone.wuyan.cn/worldcup/%E9%9F%A9%E5%9B%BD%403x.png',
        ),      
        25 => array(
            'id' => 25,
            'country_name' => '比利时',
            'flag_link' => 'https://iveryone.wuyan.cn/worldcup/%E6%AF%94%E5%88%A9%E6%97%B6%250A%403x.png',
        ),
        26 => array(
            'id' => 26,
            'country_name' => '巴拿马',
            'flag_link' => 'https://iveryone.wuyan.cn/worldcup/%E5%B7%B4%E6%8B%BF%E9%A9%AC%250A%403x.png',
        ),  
        27 => array(
            'id' => 27,
            'country_name' => '突尼斯',
            'flag_link' => 'https://iveryone.wuyan.cn/worldcup/%E7%AA%81%E5%B0%BC%E6%96%AF%403x.png',
        ),  
        28 => array(
            'id' => 28,
            'country_name' => '英格兰',
            'flag_link' => 'https://iveryone.wuyan.cn/worldcup/%E8%8B%B1%E6%A0%BC%E5%85%B0%250A%403x.png',
        ),          
        29 => array(
            'id' => 29,
            'country_name' => '波兰',
            'flag_link' => 'https://iveryone.wuyan.cn/worldcup/%E6%B3%A2%E5%85%B0%250A%403x.png',
        ),  
        30 => array(
            'id' => 30,
            'country_name' => '塞内加尔',
            'flag_link' => 'https://iveryone.wuyan.cn/worldcup/%E5%A1%9E%E5%86%85%E5%8A%A0%E5%B0%94%403x.png',
        ),  
        31 => array(
            'id' => 31,
            'country_name' => '哥伦比亚',
            'flag_link' => 'https://iveryone.wuyan.cn/worldcup/%E5%93%A5%E4%BC%A6%E6%AF%94%E4%BA%9A%403x.png',
        ),  
        32 => array(
            'id' => 32,
            'country_name' => '日本',
            'flag_link' => 'https://iveryone.wuyan.cn/worldcup/%E6%97%A5%E6%9C%AC%403x.png',
        ),  
    );

    /**
     * 获取可以投注的列表
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     * @result void
     */
    public function execute(Request $request, Response $response) {

        $uid = intval($request->getArg('uid'));

        //今天取明天可以投注的数据
        $date = date('Y-m-d', time() + 86400);
        //$date = date('Y-m-d', time()); //test
        $params = array(
            'sche_date' => $date,
        );
        
        //根据日期获取比赛场次，与用户无关
        $wc = WorldCup::getInstance()->getSche($params);
        if (!$wc) {
            throw new Exception('没有可投注的场次', 5000);
        }

        //判断是否已经投注 增加参数判断is_use //每个用户返回的数据不一样。
        $data = array();
        foreach ($wc as $key => $value) {
            $value['country_major_name'] = self::$country[$value['country_major']]['country_name'];
            $value['country_guest_name'] = self::$country[$value['country_guest']]['country_name'];
            $value['country_major_flag'] = self::$country[$value['country_major']]['flag_link'];
            $value['country_guest_flag'] = self::$country[$value['country_guest']]['flag_link'];

            $value['is_use'] = 0;
            $sche_id = $value['id'];
            $params = array(
                'sche_id' => $value['id'],
                'uid' => $uid,
            );

            //如果用户没登录，直接展示列别表页，不判断是否参与过
            if (0 != $uid) {
                $wc_logs = WorldCupUserLogs::getInstance()->getUserLogsById($params);
                if ($wc_logs) {
                    $value['is_use'] = 1;
                }
            }
            $data[$key] = $value;
        }

        $data['data'] = $data;

        $response->setBody($this->formatData($data));
    }



}