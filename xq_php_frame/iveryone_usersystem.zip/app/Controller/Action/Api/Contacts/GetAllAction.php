<?php

namespace HttpApi\Controller\Action\Api\Contacts;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Tool\ArrayTool;
use HttpApi\Model\Contacts;
use HttpApi\Model\User\User;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class GetAllAction extends \HttpApi\Controller\ApiAuthAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     */
    public function execute(Request $request, Response $response)
    {
        $userinfo = $request->getArg('userinfo');

        $contacts = Contacts::getInstance()->getAll($userinfo['id']);
        $uids = $list = [];
        foreach ($contacts as $contact) {
            if($contact['uid'] == $userinfo['id']) {
                $uids[] = $contact['contact_uid'];
            } else {
                $uids[] = $contact['uid'];
            }
        }

        $userinfos = ArrayTool::list2Map(User::getInstance()->getUserinfoByUids($uids), 'id');
        foreach ($contacts as $contact) {
            if($contact['uid'] == $userinfo['id']) {
                if(!empty($list[$contact['contact_uid']])) {
                    $list[$contact['contact_uid']]['contact_status'] += 1;
                } else {
                    $list[$contact['contact_uid']]['userinfo'] = $userinfos[$contact['contact_uid']];
                    $list[$contact['contact_uid']]['contact_info'] = $contact;
                    $list[$contact['contact_uid']]['contact_status'] = 1;
                }
            } else {
                if(!empty($list[$contact['uid']])) {
                    $list[$contact['uid']]['contact_status'] += 2;
                } else {
                    $list[$contact['uid']]['userinfo'] = $userinfos[$contact['uid']];
                    $list[$contact['uid']]['contact_info'] = $contact;
                    $list[$contact['uid']]['contact_status'] = 2;
                }
            }
        }

        $data['data']['list'] = $list;
        $response->setBody($this->formatData($data));
    }
}