<?php

namespace HttpApi\Controller\Action\Api\Contacts;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Tool\ArrayTool;
use HttpApi\Model\Contacts;
use HttpApi\Model\User\User;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class GetFollowerAction extends \HttpApi\Controller\ApiAuthAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     */
    public function execute(Request $request, Response $response)
    {
        $uid = $request->getArg('uid');
        $limit = $request->getArg('limit', 50);
        $lastid = $request->getArg('lastid', 0);

        $followers = Contacts::getInstance()->getFollowers($uid, $limit, $lastid);
        $uids = ArrayTool::getFields($followers, 'uid');
        $contacts = ArrayTool::list2Map(Contacts::getInstance()->getItems([
            'uid' => $uid,
            'contact_uid' => $uids,
            'contact_status' => 1
        ]), 'contact_uid');

        $list = [];
        $userinfos = ArrayTool::list2Map(User::getInstance()->getUserinfoByUids($uids), 'id');
        foreach ($followers as $contact) {
            $item = [
                'userinfo' => $userinfos[$contact['uid']],
                'contact_info' => $contact,
                'contact_status' => 2,
            ];
            if(!empty($contacts[$contact['uid']])) {
                $item['contact_status'] = 3;
            }
            $list[] = $item;
        }

        $data['data']['list'] = $list;
        $response->setBody($this->formatData($data));
    }
}