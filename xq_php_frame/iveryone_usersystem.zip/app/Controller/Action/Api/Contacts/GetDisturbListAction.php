<?php

namespace HttpApi\Controller\Action\Api\Contacts;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use HttpApi\Model\Contacts;
use HttpApi\Model\User\User;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class GetDisturbListAction extends \HttpApi\Controller\ApiAuthAction {

	/**
	 * 执行
	 *
	 * @param \Beahoo\Controller\Request\HttpRequest $request
	 * @param \HttpApi\Controller\Response\HttpResponse $response
	 *
	 * @result void
	 */
	public function execute(Request $request, Response $response) {
		$uid = $request->getArg('uid');

		$disturb_list = Contacts::getInstance()->get_disturb_list(['uid' => $uid]);

		$data['data']['disturb_list'] = $disturb_list;
		$response->setBody($this->formatData($data));
	}

}