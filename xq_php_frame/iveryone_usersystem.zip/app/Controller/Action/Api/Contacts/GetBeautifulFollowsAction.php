<?php

namespace HttpApi\Controller\Action\Api\Contacts;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Tool\ArrayTool;
use HttpApi\Model\Contacts;
use HttpApi\Model\User\User;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class GetBeautifulFollowsAction extends \HttpApi\Controller\ApiAuthAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     */
    public function execute(Request $request, Response $response)
    {
        $uid = $request->getArg('uid');
        $start = $request->getArg('start', 0);
        $limit = $request->getArg('limit', 50);

        $separate = $request->getArg('separate', 0);

        $uids = $list = $star_contacts = $bilateral_contacts = $contacts = $userinfos = [];
        if(!$separate) {
            $speicalNumbers = Contacts::getInstance()->getSpecialCounts($uid);
            $speicalCount = array_sum($speicalNumbers);


            if ($start < $speicalCount) {
                if ($start < $speicalNumbers[0]) {
                    $star_contacts = Contacts::getInstance()->getItems([
                        'uid' => $uid,
                        'contact_status' => 1,
                        'star_status' => 1
                    ], $start, $speicalNumbers[0] - $start);
                    $uids = ArrayTool::getFields($star_contacts, 'contact_uid');
                }

                if (count($star_contacts) < $limit) {
                    $bilateral_contacts = Contacts::getInstance()->getItems([
                        'uid' => $uid,
                        'contact_status' => 1,
                        'bilateral' => 1
                    ], 0, $limit - count($star_contacts));
                    $uids = array_merge($uids, ArrayTool::getFields($bilateral_contacts, 'contact_uid'));
                }

                $start = 0;
            } else {
                $start = $start - $speicalCount;
            }

            if ((count($star_contacts) + count($bilateral_contacts)) < $limit) {
                $contacts = Contacts::getInstance()->getBeautifulContacts($uid, $start, $limit - (count($star_contacts) + count($bilateral_contacts)));
                $uids = array_merge($uids, ArrayTool::getFields($contacts, 'contact_uid'));
            }
        } else {
            $contacts = Contacts::getInstance()->getBeautifulContacts($uid, $start, $limit);
            $uids = ArrayTool::getFields($contacts, 'contact_uid');
        }

        if(!empty($uids)) {
            $userinfos = ArrayTool::list2Map(User::getInstance()->getUserinfoByUids($uids), 'id');
        }

        if(!empty($star_contacts)) {

            foreach ($star_contacts as $contact) {
                $item = [
                    'userinfo' => $userinfos[$contact['contact_uid']],
                    'contact_info' => $contact,
                    'contact_status' => 1,
                ];
                $item['initials'] = 2;
                if ($contact['bilateral'] == 1) {
                    $item['contact_status'] = 3;
                }

                if (empty($list[$item['initials']])) {
                    $list[$item['initials']] = [
                        'name' => $item['initials'],
                        'list' => []
                    ];
                }
                $list[$item['initials']]['list'][] = $item;
            }
        }

        if(!empty($bilateral_contacts)) {

            foreach ($bilateral_contacts as $contact) {
                $item = [
                    'userinfo' => $userinfos[$contact['contact_uid']],
                    'contact_info' => $contact,
                    'contact_status' => 3,
                ];
                $item['initials'] = 1;

                if (empty($list[$item['initials']])) {
                    $list[$item['initials']] = [
                        'name' => $item['initials'],
                        'list' => []
                    ];
                }
                $list[$item['initials']]['list'][] = $item;
            }
        }

        if(!empty($contacts)) {

            foreach ($contacts as $contact) {
                $item = [
                    'userinfo' => $userinfos[$contact['contact_uid']],
                    'contact_info' => $contact,
                    'contact_status' => 1,
                ];
                if($contact['bilateral']) {
                    $item['contact_status'] = 3;
                }
                $item['initials'] = $item['userinfo']['nickname_initials'];

                if (empty($list[$item['initials']])) {
                    $list[$item['initials']] = [
                        'name' => $item['initials'],
                        'list' => []
                    ];
                }
                $list[$item['initials']]['list'][] = $item;
            }
        }

        $data['data']['list'] = array_values($list);
        $response->setBody($this->formatData($data));
    }
}