<?php

namespace HttpApi\Controller\Action\Api\Contacts;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use HttpApi\Model\Contacts;
use HttpApi\Model\User\User;
use HttpApi\Controller\ApiAuthAction;
use Beahoo\Exception;

/**
 *
 * @package \HttpApi\Controller\Action\Api\User
 */
class QueryAction extends ApiAuthAction {
    
    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     * @throws Exception
     */
    public function execute(Request $request, Response $response) {
        $userinfo = $request->getArg ( 'userinfo' );
        $contact = $request->getArg ( 'ivoid' );

        if(is_numeric($contact)) {
            $data ['data'] ['userinfo'] = User::getInstance ()->getUserinfoByUid ( $contact );
        }
        if(empty($data ['data'] ['userinfo'])) {
            $data ['data'] ['userinfo'] = User::getInstance ()->getUserinfoByNickname( strip_tags($contact) );
        }

        if ($data ['data'] ['userinfo']) {
            $data ['data'] ['contact_status'] = 0;
            if (Contacts::getInstance ()->getContact ( $userinfo ['id'], $data ['data'] ['userinfo']['id'] ) ['contact_status']) {
                $data ['data'] ['contact_status'] += 1;
            }
            if (Contacts::getInstance ()->getContact ( $data ['data'] ['userinfo']['id'], $userinfo ['id'] ) ['contact_status']) {
                $data ['data'] ['contact_status'] += 2;
            }
        } else {
            throw new Exception ( '', 2001 );
        }
        $response->setBody ( $this->formatData ( $data ) );
    }
}