<?php

namespace HttpApi\Controller\Action\Api\Contacts;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Model\Battery;
use HttpApi\Model\Contacts;
use HttpApi\Model\User\User;
use HttpApi\Tool\BehaviorLogs;
use HttpApi\Tool\iVeryOneApi;

/**
 *
 * @package \HttpApi\Controller\Action\Api\User
 */
class ManageContactAction extends \HttpApi\Controller\ApiAuthAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     * @result void
     * @throws Exception
     */
    public function execute(Request $request, Response $response)
    {
        $userinfo = $request->getArg('userinfo');
        $ivoid = $request->getArg('ivoid');
        $switch = $request->getArg('switch');

        if (empty ($ivoid)) {
            throw new Exception ('', 1001);
        }

        if ($switch == 1) {
            $contact_status = Contacts::getInstance()->follow($userinfo['id'], $ivoid);
        } else {
            $contact_status = Contacts::getInstance()->unfollow($userinfo['id'], $ivoid);
        }

        $data ['data'] = [
            'status' => 1,
            'contact_status' => $contact_status
        ];

        BehaviorLogs::addLogs($userinfo['id'], BehaviorLogs::ACT_FOLLOW, ['uid' => $ivoid, 'switch' => $switch], 'follow');
        $response->setBody($this->formatData($data));
    }
}