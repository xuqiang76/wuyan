<?php

namespace HttpApi\Controller\Action\Api\Contacts;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Model\Contacts;
use HttpApi\Model\User\User;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class ManageStarAction extends \HttpApi\Controller\ApiAuthAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     * @throws Exception
     */
    public function execute(Request $request, Response $response)
    {
        $uid = $request->getArg('uid');
        $ivoid = $request->getArg('ivoid');
        $switch = $request->getArg('switch');

        if (empty($ivoid)) {
            throw new Exception('', 1001);
        }

        $userinfo = User::getInstance()->getUserInfoByUid($ivoid);
        if (empty($userinfo)) {
            throw new Exception('', 2001);
        }

        $contact = Contacts::getInstance()->getContact($uid, $ivoid);
        if ($switch == 1) {
            if (!empty($contact) && $contact['star_status'] == 1) {
                throw new Exception('', 2014);
            }

            $contact = [
                'uid' => $uid,
                'contact_uid' => $ivoid,
                'contact_status' => 1,
                'star_status' => 1
            ];
            Contacts::getInstance()->add($contact, $contact);

            $contact = [
                'uid' => $ivoid,
                'contact_uid' => $uid,
            ];
            Contacts::getInstance()->add($contact, $contact);
        } else {
            if (empty($contact) || $contact['star_status'] != 1) {
                throw new Exception('', 2017);
            }

            Contacts::getInstance()->update([
                'star_status' => 0
            ], [
                'uid' => $uid,
                'contact_uid' => $ivoid
            ]);
        }

        $data['data'] = ['status' => 1];

        $response->setBody($this->formatData($data));
    }
}