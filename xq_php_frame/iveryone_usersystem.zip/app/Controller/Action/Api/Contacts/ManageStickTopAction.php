<?php

namespace HttpApi\Controller\Action\Api\Contacts;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Model\Contacts;
use HttpApi\Model\User\User;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class ManageStickTopAction extends \HttpApi\Controller\ApiAuthAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     * @throws Exception
     */
    public function execute(Request $request, Response $response)
    {
        $uid = $request->getArg('uid');
        $ivoid = $request->getArg('ivoid');
        $switch = $request->getArg('switch');

        if (empty($ivoid)) {
            throw new Exception('', 1001);
        }

        $userinfo = User::getInstance()->getUserInfoByUid($ivoid);
        if (empty($userinfo)) {
            throw new Exception('', 2001);
        }

        $contact = Contacts::getInstance()->getContact($uid, $ivoid);
        if ($switch == 1) {
            if (!empty($contact) && $contact['sticktop'] == 1) {
                throw new Exception('', 2027);
            }

            $contact = [
                'uid' => $uid,
                'contact_uid' => $ivoid,
                'sticktop' => 1
            ];
            Contacts::getInstance()->add($contact, $contact);
        } else {
            if (empty($contact) || $contact['sticktop'] != 1) {
                throw new Exception('', 2028);
            }

            Contacts::getInstance()->update([
                'sticktop' => 0
            ], [
                'uid' => $uid,
                'contact_uid' => $ivoid
            ]);
        }

        $data['data'] = ['status' => 1];

        $response->setBody($this->formatData($data));
    }
}