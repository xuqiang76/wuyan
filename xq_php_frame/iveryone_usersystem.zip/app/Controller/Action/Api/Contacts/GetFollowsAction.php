<?php

namespace HttpApi\Controller\Action\Api\Contacts;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Tool\ArrayTool;
use HttpApi\Model\Contacts;
use HttpApi\Model\User\User;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class GetFollowsAction extends \HttpApi\Controller\ApiAuthAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     */
    public function execute(Request $request, Response $response)
    {
        $uid = $request->getArg('uid');
        $start = $request->getArg('start', 0);
        $limit = $request->getArg('limit', 50);

        $contacts = Contacts::getInstance()->getAllBeautifulContacts($uid, $start, $limit);
        $uids = ArrayTool::getFields($contacts, 'contact_uid');
        $oppositeContacts = ArrayTool::list2Map(Contacts::getInstance()->getItems([
            'uid' => $uids,
            'contact_uid' => $uid,
            'contact_status' => 1
        ]), 'uid');

        $list = [];
        $userinfos = ArrayTool::list2Map(User::getInstance()->getUserinfoByUids($uids), 'id');
        foreach ($contacts as $contact) {
            $item = [
                'userinfo' => $userinfos[$contact['contact_uid']],
                'contact_info' => $contact,
                'contact_status' => 1,
            ];
            if(!empty($oppositeContacts[$contact['contact_uid']])) {
                $item['contact_status'] = 3;
            }
            $list[] = $item;
        }

        $data['data']['list'] = $list;
        $response->setBody($this->formatData($data));
    }
}