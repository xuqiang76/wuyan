<?php

namespace HttpApi\Controller\Action\Api\Contacts;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Model\Contacts;
use HttpApi\Model\User\User;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class SetDisturbAction extends \HttpApi\Controller\ApiAuthAction {

	/**
	 * 执行
	 *
	 * @param \Beahoo\Controller\Request\HttpRequest $request
	 * @param \HttpApi\Controller\Response\HttpResponse $response
	 *
	 * @result void
	 */
	public function execute(Request $request, Response $response) {
		$uid = $request->getArg('uid');
		$contact_uid = $request->getArg('contact_uid');
		$disturb = $request->getArg('disturb');

		if (!in_array($disturb, [0, 1])) {
			throw new Exception('防打扰参数错误', 5001);
		}

		Contacts::getInstance()->set_disturb(['uid' => $uid, 'contact_uid' => $contact_uid, 'disturb' => $disturb]);
		$disturb_list = Contacts::getInstance()->get_disturb_list(['uid' => $uid]);

		$data['data']['disturb_list'] = $disturb_list;
		$response->setBody($this->formatData($data));
	}

}