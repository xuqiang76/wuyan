<?php

namespace HttpApi\Controller\Action\Api\WeChat;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Tool\Config;
use EasyWeChat\Factory;
use HttpApi\Model\Battery;
use HttpApi\Model\User\User;
use HttpApi\Model\Wallet\CommunityActivity;
use HttpApi\Model\Wallet\LotteryActivity;
use HttpApi\Tool\Log;
use unreal4u\TelegramAPI\HttpClientRequestHandler;
use unreal4u\TelegramAPI\Telegram\Methods\SendMessage;
use \unreal4u\TelegramAPI\Telegram\Types\Update;
use unreal4u\TelegramAPI\TgLog;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class DeamonAction extends \HttpApi\Controller\BasicAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     * @throws
     */
    public function execute(Request $request, Response $response)
    {
        $app = Factory::officialAccount(Config::read('iVeryOne_WeChat'));
        $app->server->push(function ($message) {
            if(!empty($message['MsgType'])) {
                if($message['MsgType'] == 'text' && is_numeric($message['Content'])) {
                    $invite_uid = $message['Content'];
                    $usermark = $message['FromUserName'];

                    if(CommunityActivity::getInstance()->query([
                        'community_type' => 1,
                        'community_usermark' => $usermark
                    ])) {
                        return "您的微信号已经绑定过iVeryOne帐号了";
                    }

                    $userinfo = User::getInstance()->getUserinfoByUid($invite_uid);
                    if(empty($userinfo)) {
                        return "id错误";
                    }
                    if(CommunityActivity::getInstance()->query([
                        'uid' => $userinfo['id'],
                        'community_type' => 1
                    ])) {
                        return "您已经绑定过其他微信号了";
                    }

                    CommunityActivity::getInstance()->create($userinfo['id'], 1, $usermark);
                    Battery::getInstance()->increaseCapacity($userinfo['id'], 2);
                    return "任务完成";
                } else if ($message['MsgType'] == 'event' && $message['Event'] == 'CLICK') {
                    switch ($message['EventKey']) {
                        case 'contactus':
                            return "您好，欢迎加入iVeryOne，添加微信号：iveryonelx备注入群加入官方微信群。官方电报群地址：https://t.me/iVeryone";
                            break;
                        case 'business':
                            return "您好，商务合作请联系微信mengxiaozhao1987";
                            break;
                        case 'history':
                            return "暂无历史消息";
                            break;
                        case 'homepage':
                            return "官网地址 https://ivery.one/，请直接复制地址至默认浏览器访问";
                            break;
                        case 'product':
                            return "https://beta.ivery.one/ 请直接复制地址至默认浏览器访问";
                            break;
                    }
                } else if($message['MsgType'] == 'event' && $message['Event'] == 'subscribe') {
                    return "您好，欢迎关注iVeryOne——基于区块链的网络经济体！点击菜单“关注我们”可以加入官方群组/社区，与喜爱iVeryOne的小伙伴畅聊。";
                }
            }
        });

        $response = $app->server->serve();
        $response->send();
    }
}