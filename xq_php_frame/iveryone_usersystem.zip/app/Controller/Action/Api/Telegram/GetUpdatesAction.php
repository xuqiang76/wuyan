<?php

namespace HttpApi\Controller\Action\Api\Telegram;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\Config;
use HttpApi\Model\Battery;
use HttpApi\Model\User\User;
use HttpApi\Model\Wallet\CommunityActivity;
use HttpApi\Model\Wallet\LotteryActivity;
use HttpApi\Tool\Log;
use unreal4u\TelegramAPI\HttpClientRequestHandler;
use unreal4u\TelegramAPI\Telegram\Methods\SendMessage;
use \unreal4u\TelegramAPI\Telegram\Types\Update;
use unreal4u\TelegramAPI\TgLog;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class GetUpdatesAction extends \HttpApi\Controller\BasicAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     * @throws Exception
     */
    public function execute(Request $request, Response $response)
    {
        $updateData = json_decode(file_get_contents('php://input'), true);
        Log::debug($updateData, 'telegrambot');
        $update = new Update($updateData);

        if(!empty($update->message->text) && (substr($update->message->text, 0, 10) == '/checkcode') && ($update->message->chat->id == -308601302 || $update->message->chat->id == -1001325678251)) {
            $uid = substr($update->message->text, 11);
            $usermark = $update->message->from->id;

            $params['uid'] = $uid;
            $params['usermark'] = $usermark;
            $params['secret'] = Config::read('intraapi_secretkey');
            $client = new \GuzzleHttp\Client();
            $data = $client->request('GET', "https://userapi.iveryone.wuyan.cn/Intra/Telegram/Mission", [
                'query' => $params
            ]);
            if ($data->getStatusCode() != 200) {
                throw new Exception("", 1003);
            }
            $data = $data->getBody();
            if (empty($data)) {
                throw new Exception("", 1003);
            }

            $res = json_decode($data, true);

            if($res['data']['status'] == 1) {
                $loop = \React\EventLoop\Factory::create();
                $handler = new HttpClientRequestHandler($loop);
                $tgLog = new TgLog(Config::read('Telegram_Bot_Token'), $handler);
                $sendMessage = new SendMessage();
                $sendMessage->chat_id = $update->message->chat->id;

                if(!empty($update->message->from->username)) {
                    $username = $update->message->from->username;
                } elseif (!empty($update->message->from->first_name)) {
                    $username = $update->message->from->first_name;
                } else {
                    $username = "Hi";
                }

                $sendMessage->text = $username . ': Mission Accomplished!';
                $tgLog->performApiRequest($sendMessage);
                $loop->run();
            }
        }
    }
}