<?php

namespace HttpApi\Controller\Action\Api\User;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Model\Ad;
use HttpApi\Model\Contacts;
use HttpApi\Model\Identity\User as UserIdentity;
use HttpApi\Model\User\PersonalContent;
use HttpApi\Model\User\Service;
use HttpApi\Model\User\User;
use HttpApi\Model\Wallet\Details;
use HttpApi\Tool\Format;
use HttpApi\Tool\OpenApi;
use HttpApi\Tool\Times;
use HttpApi\Tool\Token;

/**
 *
 * @package \HttpApi\Controller\Action\Api\User
 */
class GetInfoAction extends \HttpApi\Controller\ApiAction {

	/**
	 * 执行
	 *
	 * @param \Beahoo\Controller\Request\HttpRequest $request
	 * @param \HttpApi\Controller\Response\HttpResponse $response
	 *
	 * @result void
	 * @throws Exception
	 */
	public function execute(Request $request, Response $response) {
		$uid = $request->getArg('uid');
		$token = $request->getArg('token');
		$bindinfo = $request->getArg('bindinfo', 0);
		$device_platform = $request->getArg('device_platform');

		$data['data']['userinfo'] = [];
		$data['data']['wallet'] = [];
		if (!empty($uid) && !empty($token) && $uid != 'null' && $token != 'null') {
			Token::checkToken($uid, $token, $device_platform);
			$infos = Service::GetRichInfo($uid, false, true);
			$data['data']['userinfo'] = $infos['userinfo'];
			$data['data']['wallet'] = $infos['wallet'];

			// 广告收入从广告系统读取
			if ($re_ad_income = Ad::getInstance()->ad_income(['uid' => $uid])) {
				$data['data']['wallet']['adwords'] = Format::amount($re_ad_income->adwords);
				$data['data']['wallet']['adwords_v'] = Format::amount_k($re_ad_income->adwords_v);
			}

		}
		$data['data']['ivoUserinfo'] = $data['data']['contactInfo'] = [];
		$data['data']['contact_status'] = 0;

		$ivoid = $request->getArg('ivoid', 0);
		if (!empty($ivoid)) {
			$ivouserinfo = User::getInstance()->getUserinfoByUid($ivoid);
			if (!empty($ivouserinfo)) {
				$data['data']['ivoUserinfo'] = $ivouserinfo;
				if (!empty($infos)) {
					$data['data']['contactInfo'] = Contacts::getInstance()->getContact($data['data']['userinfo']['id'], $ivouserinfo['id']);
					$oppositeContactInfo = Contacts::getInstance()->getContact($ivouserinfo['id'], $data['data']['userinfo']['id']);
					$data['data']['contact_status'] = Contacts::getContactStatus($data['data']['contactInfo'], $oppositeContactInfo);
				}
			}
		}

		if (!empty($infos)) {
			// 校验权限
			$data['data']['wallet']['transferPrivillege'] = 0;
			$rss = Details::getInstance()->getOne()->selectOne('users_tasks', '*', [
				'uid' => $data['data']['userinfo']['id'],
				'status' => 3,
				'tid' => 15,
			])['data'];
			if ($data['data']['wallet']['transfer'] == 1 && $rss && $rss['confirm_timestamp']) {
				$day = 24 * 60 * 60;

				$timestamp = $rss['confirm_timestamp'];
				$timestamp = date("Y-m-d", $timestamp);
				$h = strtotime(date("Y-m-d")) - strtotime($timestamp);
				$data['data']['wallet']['confirmDate'] = date("Y-m-d", $rss['confirm_timestamp']);
				$data['data']['wallet']['transferDate'] = date("m月d日", $rss['confirm_timestamp'] + $day);
				if ($h > $day) {
					$data['data']['wallet']['transferPrivillege'] = 1;
				} elseif ($h == $day && date("H") >= 12) {
					$data['data']['wallet']['transferPrivillege'] = 1;
				}
			}
			// 如果为空，重新设置默认值
			$data['data']['userinfo']['ad_feed_minimal'] === '' && $data['data']['userinfo']['ad_feed_minimal'] = 0.01;
			$data['data']['userinfo']['ad_follow_minimal'] === '' && $data['data']['userinfo']['ad_follow_minimal'] = 0.01;

			$user_identity = UserIdentity::getInstance()->getUserIdentity($uid);

			$data['data']['userinfo']['auth_face'] = ($user_identity && $user_identity['auth_face']) ? 1 : 0;
		}

		if ($bindinfo) {
			if (!empty($ivouserinfo)) {
				$buid = $ivouserinfo['id'];
			} else {
				$buid = $uid;
			}
			$authinfos = OpenApi::Request('Intra/User/GetAuthInfo', [
				'uid' => $buid,
			])['data'];

			foreach ($authinfos as $key => $authinfo) {
				unset($authinfos[$key]['accesstoken']);
				if ($authinfo['appname'] != 'PressOne') {
					unset($authinfos[$key]);
					continue;
				}
				if ($authinfo['appname'] == 'PressOne') {
					$authinfos[$key] = [];
					$authinfos[$key]['appname'] = $authinfo['appname'];
					$authinfos[$key]['appuid'] = $authinfo['appuid'];
					$authinfos[$key]['content'] = PersonalContent::getInstance()->getItem(['uid' => $buid]);
					$authinfos[$key]['content']['timestamp'] = Times::format_date($authinfos[$key]['content']['timestamp']);

					try {
                        $client = new \GuzzleHttp\Client();
                        $res = $client->request(
                            'GET',
                            (RUN_ENV == 'test' ? 'http://dev.press.one/api/bind/' : 'https://press.one/api/bind/') . $authinfo['appuid'],
                            ['timeout' => 1]
                        );
                        if ($res->getStatusCode() == 200) {
                            $body = $res->getBody();
                            if (!empty($body)) {
                                $res = json_decode($body, true);
                                if ($res['success']) {
                                    foreach ($res['data'] as $item) {
                                        if ($item['service_name'] == 'ivery.one') {
                                            continue;
                                        }
                                        if (strstr($item['service_name'], '.com')) {
                                            $item['service_name'] = str_replace(".com", "", $item['service_name']);
                                        }
                                        if (strstr($item['service_name'], '.cn')) {
                                            $item['service_name'] = str_replace(".cn", "", $item['service_name']);
                                        }
                                        if ($item['service_name'] == 'qq') {
                                            $item['service_name'] = 'weixin';
                                        }
                                        $authinfos[$item['service_name']] = [
                                            'appname' => $item['service_name'],
                                            'content' => [
                                                'content' => $item['proof'],
                                                'timestamp' => Times::format_date(strtotime($item['createdAt'])),
                                            ],
                                        ];
                                    }
                                }
                            }
                        }
                    } catch (\Exception $e) {
					    //do nothing
                    }
				}
			}

			$data['data']['bindlist'] = array_values($authinfos);
		}

		$response->setBody($this->formatData($data));
	}
}
