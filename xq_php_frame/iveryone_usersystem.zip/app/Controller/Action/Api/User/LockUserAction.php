<?php

namespace HttpApi\Controller\Action\Api\User;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\ArrayTool;
use Beahoo\Tool\Config;
use HttpApi\Model\User\LockUserInfo;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class LockUserAction extends \HttpApi\Controller\ApiAuthAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     */
    public function execute(Request $request, Response $response)
    {
        $uid = $request->getArg('uid');
        //find if the user is bigR
        $result = LockUserInfo::getInstance()->getSum($uid);
        $data['data']['userinfo'] = array(
            'lock_amount' => floatval($result[0]['amount']/1000000)
        );
        $response->setBody($this->formatData($data));
    }

}