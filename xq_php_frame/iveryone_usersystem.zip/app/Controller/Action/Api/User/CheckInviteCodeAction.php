<?php

namespace HttpApi\Controller\Action\Api\User;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use HttpApi\Model\User\InviteCode;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class CheckInviteCodeAction extends \HttpApi\Controller\ApiAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     */
    public function execute(Request $request, Response $response)
    {
        $invite_code = $request->getArg('invite_code');
        if($invite_code == '81DDA25FB7466CD21022CAAEBA3B9F94' || InviteCode::getInstance()->get($invite_code)) {
            $data['data']['status'] = 1;
        } else {
            $data['data']['status'] = 0;
        }

        $response->setBody($this->formatData($data));
    }
}