<?php

namespace HttpApi\Controller\Action\Api\User;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Model\User\User;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class UpdateFieldsAction extends \HttpApi\Controller\ApiAuthAction {

	/**
	 * 执行
	 *
	 * @param \Beahoo\Controller\Request\HttpRequest $request
	 * @param \HttpApi\Controller\Response\HttpResponse $response
	 *
	 * @result void
	 * @throws Exception
	 */
	public function execute(Request $request, Response $response) {
		$userinfo = $request->getArg('userinfo');
		$menuunread = $request->getArg('menuunread');
		$beginnerguide = $request->getArg('beginnerguide');
		$favguide = $request->getArg('favguide');

		$nickname = isset($request->getGPArgs()['nickname']) ? urldecode($request->getArg('nickname')) : null;
		$oldpassword = $request->getArg('oldpassword');
		$password = $request->getArg('password');
		$ad_feed_switch = $request->getArg('ad_feed_switch');
		$ad_feed_minimal = '' . (floatval($request->getArg('ad_feed_minimal')) / 1000);
		$ad_follow_switch = $request->getArg('ad_follow_switch');
		$ad_follow_minimal = '' . (floatval($request->getArg('ad_follow_minimal')) / 1000);
		$ad_anonymous = $request->getArg('ad_anonymous', 0);
		$push = $request->getArg('push');
		$pushdetail = $request->getArg('pushdetail');
		$profile = $request->getArg('profile');

		$setarr = [];
		if (isset($nickname) && $nickname != $userinfo['nickname']) {
			if (User::getInstance()->getUserinfoByNickname($nickname)) {
				throw new Exception("", 2014);
			}
			$setarr['nickname'] = $nickname;
		}
		if (isset($menuunread)) {
			$setarr['menuunread'] = intval($menuunread);
		}
		if (isset($beginnerguide)) {
			$setarr['beginnerguide'] = intval($beginnerguide);
		}
		if (isset($favguide)) {
			$setarr['favguide'] = intval($favguide);
		}
		if (isset($password)) {
			if ($userinfo['create_timestamp'] == $userinfo['last_login_timestamp'] && ($userinfo['create_timestamp'] + 86400 > TIMESTAMP || $userinfo['nickname'] == $userinfo['phone'])) {
				throw new Exception("", 1007);
			}
			if (!empty($userinfo['setpass'])) {
				User::getInstance()->checkpassword($userinfo['id'], $oldpassword, PHP_INT_MAX);
			}
			User::getInstance()->changePassword($userinfo['id'], $password);
		}

		// $setarr = [];
		// if(isset($nickname) && $nickname != $userinfo['nickname']) {
		//     if(User::getInstance()->getUserinfoByNickname($nickname)) {
		//         throw new Exception("", 2014);
		//     }
		//     $setarr['nickname'] = $nickname;
		// }
		// if(isset($menuunread)) {
		//     $setarr['menuunread'] = intval($menuunread);
		// }
		// if(isset($beginnerguide)) {
		//     $setarr['beginnerguide'] = intval($beginnerguide);
		// }
		// if(isset($favguide)) {
		//     $setarr['favguide'] = intval($favguide);
		// }
		// if(isset($password)) {
		//     if(!empty($userinfo['setpass'])) {
		//         User::getInstance()->checkpassword($userinfo['id'], $oldpassword, PHP_INT_MAX);
		//     }
		//     User::getInstance()->changePassword($userinfo['id'], $password);
		// }

		if (isset($ad_feed_switch)) {
			$setarr['ad_feed_switch'] = $ad_feed_switch;
		}
		if (isset($ad_feed_minimal)) {
			$setarr['ad_feed_minimal'] = $ad_feed_minimal;
		}
		if (isset($ad_follow_switch)) {
			$setarr['ad_follow_switch'] = $ad_follow_switch;
		}
		if (isset($ad_follow_minimal)) {
			$setarr['ad_follow_minimal'] = $ad_follow_minimal;
		}
		if (isset($ad_anonymous)) {
			$setarr['ad_anonymous'] = $ad_anonymous;
		}

		if (isset($push)) {
			$setarr['push'] = intval($push);
		}
		if (isset($pushdetail)) {
			$setarr['pushdetail'] = $pushdetail;
		}
		if (isset($profile)) {
			$setarr['profile'] = $profile;
		}

		if (!empty($setarr)) {
			User::getInstance()->updateFields($setarr, ['id' => $userinfo['id']]);
		}

		$data['data']['status'] = 1;
		$response->setBody($this->formatData($data));
	}

}