<?php

namespace HttpApi\Controller\Action\Api\User;

use afs\Request\V20180112\AuthenticateSigRequest;
use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Model\Battery;
use HttpApi\Model\Contacts;
use HttpApi\Model\User\User;
use HttpApi\Tool\Log;
use HttpApi\Tool\Team;
use HttpApi\Tool\Token;
use HttpApi\Utility;
use HttpApi\Tool\SDKs;

require_once "/download/WuyanLibs/sms/SMS.php";
require_once ROOT . '/libs/aliyun-php-sdk-core/Config.php';

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class PayPasswordAction extends \HttpApi\Controller\ApiAuthAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     * @throws Exception
     */
    public function execute(Request $request, Response $response)
    {
        $uid = $request->getArg('uid');
        $action = $request->getArg('action');
        $smscode = $request->getArg('smscode');
        $password = $request->getArg("password");
        $oldpaypassword = $request->getArg("oldpaypassword");
        $touid = $request->getArg('touid');
        $ip = Utility::getIP();
        switch ($action) {
            case 'checkCaptcha':
                $userinfo = User::getInstance()->getNoCacheUserInfo($uid, ['password', 'pay_password', 'salt']);
                $transPhoneInfo = Team::transformPhoneNum($userinfo['country_code'], $userinfo['phone']);
                $res = \SMS::verifyCaptcha([
                    'country_code' => $transPhoneInfo[0],
                    'tel' => $transPhoneInfo[1],
                    'template_code' => 4,
                    'msg' => $smscode,
                    'doexpire' => 0
                ]);
                if ($res['code'] == 0) {
                    $data['data']['status'] = 1;
                } else {
                    throw new Exception($res['msg'], 2011);
                }
                break;
            case 'setPass':
                $userinfo = User::getInstance()->getNoCacheUserInfo($uid, ['password', 'pay_password', 'salt']);
                $transPhoneInfo = Team::transformPhoneNum($userinfo['country_code'], $userinfo['phone']);
                $res = \SMS::verifyCaptcha([
                    'country_code' => $transPhoneInfo[0],
                    'tel' => $transPhoneInfo[1],
                    'template_code' => 4,
                    'msg' => $smscode,
                    'doexpire' => 1
                ]);
                if ($res['code'] == 0) {
                    User::getInstance()->setPayPassword($uid, $password);
                    $data['data']['status'] = 1;
                    $this->clearWrong($uid);
                } else {
                    throw new Exception($res['msg'], 2011);
                }
                break;
            case 'changePass':
                if ($this->getWrong($uid) >= 5) {
                    throw new Exception("密码输入错误已达5次，请24小时后重试", 2022);
                }
                $userinfo = User::getInstance()->getNoCacheUserInfo($uid, ['password', 'salt']);
                if ($userinfo['pay_password'] == md5(md5($oldpaypassword) . $userinfo['pay_salt'])) {
                    $res = User::getInstance()->setPayPassword($uid,$password);
                    $data['data']['status'] = 1;
                    $this->clearWrong($uid);
                }else{
                    throw new Exception("", 1001);
                }
                
                break;
            case 'checkPass':
                if ($this->getWrong($uid) >= 5) {
                    throw new Exception("密码输入错误已达5次，请24小时后重试", 2022);
                }

                $userinfo = User::getInstance()->getNoCacheUserInfo($uid, ['password', 'salt']);
                if ($userinfo['pay_password'] != md5(md5($oldpaypassword) . $userinfo['pay_salt'])) {
                    $this->setWrong($uid);
                    $data['data']['errno'] = 2020;
                    $data['data']['wrongcount'] = $this->getWrong($uid);
                    $data['data']['errmsg'] = "密码输入错误";
                    //throw new Exception("", 2020);
                } else {
                    $data['data']['errno'] = 0;
                }

                break;
            case 'checkToUser':
                $userinfo = User::getInstance()->getNoCacheUserInfo($touid);
                if (empty($userinfo)) {
                    throw new Exception("请输入正确的ID", 2023);
                }
                $data['data']['touserinfo'] = $userinfo;
                break;
            case 'getWrongPayTimes':
                $count = $this->getWrong($uid);
                $data['data']['wrongcount'] = $count;
                break;
        }
        $response->setBody($this->formatData($data));
    }

    private function setWrong($uid)
    {
        $wrongKey = 'wrongpaypassword_count';
        $res = SDKs::getRedis()->hget($wrongKey, $uid);
        $wrongcount = 0;
        if ($res) {
            $res = json_decode($res, true);
            $wrongcount = $res['count'];
        }
        $wrongcount++;
        SDKs::getRedis()->hset($wrongKey, $uid, json_encode(['count' => $wrongcount, 'last_time' => TIMESTAMP]));
    }

    private function getWrong($uid)
    {
        $wrongKey = 'wrongpaypassword_count';
        $res = SDKs::getRedis()->hget($wrongKey, $uid);
        $wrongcount = 0;
        if ($res) {
            $res = json_decode($res, true);
            //是否超过24小时
            if (TIMESTAMP - $res['last_time'] >= 60 * 60 * 24) {
                $wrongcount = 0;
                SDKs::getRedis()->hdel($wrongKey, $uid);
            } else {
                $wrongcount = $res['count'];
            }

        }
        return $wrongcount;
    }

    private function clearWrong($uid)
    {
        $wrongKey = 'wrongpaypassword_count';
        $res = SDKs::getRedis()->hdel($wrongKey, $uid);
    }
}