<?php

namespace HttpApi\Controller\Action\Api\User;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Model\Contacts;
use HttpApi\Model\User\User;
use HttpApi\Model\Wallet\Activity;
use HttpApi\Model\Wallet\Wallet;
use HttpApi\Tool\BehaviorLogs;
use HttpApi\Tool\Cache;
use HttpApi\Tool\Team;
use HttpApi\Tool\Token;
use HttpApi\Utility;
use HttpApi\Tool\SDKs;
use Beahoo\Tool\Config;
use HttpApi\Tool\IMInterface;
use HttpApi\Tool\Log;

require_once "/download/WuyanLibs/sms/SMS.php";

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class RegisterAction extends \HttpApi\Controller\ApiAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     * @throws Exception
     * @throws \Exception
     */
    public function execute(Request $request, Response $response)
    {
        $country_code = strtoupper($request->getArg('country_code'));
        $phone = $request->getArg('phone');
        $code = $request->getArg('code');
        $nickname = urldecode($request->getArg('nickname'));
        $avatar_url = $request->getArg('avatar_url');
        $invite_uid = $request->getArg('invite_uid', 0);
        $device_platform = $request->getArg('device_platform');
        $ip = Utility::getIP();

        if (empty($country_code) || empty($phone) || empty($code)) {
            throw new Exception("", 1001);
        }

        if(in_array($device_platform, ['ios', 'android'])) {
            if(empty($nickname)) {
                $nickname = uniqid();
            }
        } else {
            if(empty($nickname) || empty($avatar_url)) {
                throw new Exception("", 1001);
            }
        }

        if (!is_numeric($code) && strlen($code) != 6) {
            throw new Exception("", 2011);
        }

        if(User::getInstance()->getUserinfoByPhone($country_code, $phone)) {
            throw new Exception("", 2004);
        }

        if(User::getInstance()->getUserinfoByNickname($nickname)) {
            throw new Exception("", 2014);
        }

        $transPhoneInfo = Team::transformPhoneNum($country_code, $phone);

        if(!in_array(RUN_ENV, ['test', 'development','local', 'aliyun_huabei2_sandbox'])) {
            $cache = Cache::GetCache('register_' . $transPhoneInfo[0] . $transPhoneInfo[1]);
            if(empty($cache) || $cache['ip'] != $ip || $cache['stopatreg'] == 1) {
                throw new Exception("", 1005);
            }
        }

        $res = \SMS::verifyCaptcha([
            'country_code' => $transPhoneInfo[0],
            'tel' => $transPhoneInfo[1],
            'template_code' => '1',
            'msg' => $code,
            'doexpire' => 1
        ]);
        if ($res['code'] != 0) {
            if(!in_array(RUN_ENV, ['test', 'development','local', 'aliyun_huabei2_sandbox'])) {
                throw new Exception($res['msg'], 2011);
            }
        }

        if(!empty($invite_uid)) {
            $invite_user = User::getInstance()->getUserinfoByUid($invite_uid);
            if(empty($invite_user)) {
                throw new Exception('推荐人ID不存在', 1);
            }
        }

        if(!in_array(RUN_ENV, ['test', 'development','local', 'aliyun_huabei2_sandbox'])) {
            if(!Cache::CheckFrequncy('register', $ip, 180)) {
                throw new Exception("", 1004);
            }
        }

        $uid = User::getInstance()->newuser($country_code, $phone, $nickname, $avatar_url, $invite_uid);
        $sets[] = [$invite_uid, BehaviorLogs::ACT_INVITE, ['uid' => $uid], 'invited'];
        $iveryone_office_uid=Config::read('iveryone_office_uid');
        $iveryone_helper_uid=Config::read('iveryone_helper_uid');
        Contacts::getInstance()->follow($uid, $iveryone_office_uid);
        // 小v助手账户
        Contacts::getInstance()->follow($uid, $iveryone_helper_uid);
        
        $sets[] = [$iveryone_office_uid, BehaviorLogs::ACT_FOLLOW, ['uid' => $uid, 'switch' => 1], 'follow'];

        if(RUN_ENV != 'aliyun_huabei2_sandbox') {
            Contacts::getInstance()->follow($uid, 1000000);
            $sets[] = [1000000, BehaviorLogs::ACT_FOLLOW, ['uid' => $uid, 'switch' => 1], 'follow'];
        }

        if(!empty($invite_uid)) {
            Contacts::getInstance()->follow($uid, $invite_uid);
            $sets[] = [$invite_uid, BehaviorLogs::ACT_INVITE, ['uid' => $uid], 'invited'];
            $sets[] = [$invite_uid, BehaviorLogs::ACT_FOLLOW, ['uid' => $uid, 'switch' => 1], 'follow'];
        }
        try{
            $content='欢迎来到iveryone,常见问题请点击查看。'.Config::read('h5_url').'Problem';
            $msgbody=['msg'=>$content];
            IMInterface::send($iveryone_helper_uid,0,$uid,0,$msgbody,IMInterface::makeExt($uid, 0, json_encode($msgbody), 0));
        }catch(Exception $e){
            Log::debug('IM Exception:'.PHP_EOL.$e->getMessage(), "push.everyone");
        }
        $data['data']['uid'] = $uid;
        $data['data']['token'] = Token::create($uid, $device_platform, 0, 1);
        $data['data']['identity_notice'] = 1;
        $data['data']['identity_reward'] = "10";

        try{
            // 标识已经弹过人脸认证提示
            SDKs::getRedis()->hset('user_face_identity_notice',$uid,1);
        }catch(Exception $e){

        }

        $sets[] = [$uid, BehaviorLogs::ACT_REGISTER, [], "register"];
        BehaviorLogs::addMulti($sets);

        if(RUN_ENV == 'aliyun_huabei2_sandbox') {
            $data['data']['identity_notice'] = 0;
            Wallet::getInstance()->status($uid, 0);
            Activity::getInstance ()->create ( [
                'uid' => $uid,
                'amount' => 500,
                'category' => Activity::WorldCup
            ] );
        }

        $response->setBody($this->formatData($data));
    }
}