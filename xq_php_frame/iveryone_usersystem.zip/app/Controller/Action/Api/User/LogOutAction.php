<?php

namespace HttpApi\Controller\Action\Api\User;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Tool\Token;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class LogOutAction extends \HttpApi\Controller\ApiAuthAction
{

    public $no_wallet_status_check = true;
    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     * @throws Exception
     */
    public function execute(Request $request, Response $response)
    {
        $userinfo = $request->getArg('userinfo');
        $device_platform = $request->getArg('device_platform');

        Token::clear($userinfo['id'], $device_platform);

        $data['data']['status'] = 1;
        $response->setBody($this->formatData($data));
    }
}