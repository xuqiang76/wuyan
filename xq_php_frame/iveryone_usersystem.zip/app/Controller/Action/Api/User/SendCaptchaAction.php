<?php

namespace HttpApi\Controller\Action\Api\User;

use afs\Request\V20180112\AuthenticateSigRequest;
use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\Config;
use HttpApi\Encrypt\Rsa;
use HttpApi\Model\User\User;
use HttpApi\Tool\Cache;
use HttpApi\Tool\GeetestLib;
use HttpApi\Tool\Log;
use HttpApi\Tool\Team;
use HttpApi\Tool\WmReg;
use HttpApi\Utility;

require_once "/download/WuyanLibs/sms/SMS.php";
require_once ROOT . '/libs/aliyun-php-sdk-core/Config.php';

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class SendCaptchaAction extends \HttpApi\Controller\ApiAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     * @throws Exception
     */
    public function execute(Request $request, Response $response)
    {
        $country_code = strtoupper($request->getArg('country_code'));
        $phone = $request->getArg('phone');
        $act = $request->getArg('act');
        $device_platform = $request->getArg('device_platform');
        $invite_uid = $request->getArg('invite_uid', 0);
        $ip = Utility::getIP();

        if (empty($country_code) || empty($phone) || !in_array($act, ['login', 'register'])) {
            throw new Exception("", 1001);
        }

        $risk = $stopatreg = 0;
        $userinfo = User::getInstance()->getUserinfoByPhone($country_code, $phone);
        if ($act == 'login') {
            if (empty($userinfo)) {
                throw new Exception("", 2001);
            }
            if($userinfo['blocked'] == 3) {
                $risk = 1;
            }
        } else {
            if (!empty($userinfo)) {
                throw new Exception("", 2004);
            }
        }

        if (!in_array($device_platform, ['ios', 'android'])) {
            if ($act == 'register') {
                $sessionid = $request->getArg('sessionid');
                $geetest_challenge = $request->getArg('geetest_challenge');
                $geetest_validate = $request->getArg('geetest_validate');
                $geetest_seccode = $request->getArg('geetest_seccode');
                $params = array(
                    "user_id" => $sessionid,
                    "client_type" => $device_platform,
                    "ip_address" => $ip
                );
                $GtSdk = new GeetestLib(Config::read('CAPTCHA_ID'), Config::read('CAPTCHA_PRIVATE_KEY'));
                $cache = Cache::GetCache($sessionid);
                if (empty($cache) || empty($cache['status'])) {
                    throw new Exception("", 1005);
                }
                if ($cache['status'] == 1) {   //服务器正常
                    $result = $GtSdk->success_validate($geetest_challenge, $geetest_validate, $geetest_seccode, $params);
                    if (!$result) {
                        throw new Exception("", 1005);
                    }
                } else {  //服务器宕机,走failback模式
                    if ($GtSdk->fail_validate($geetest_challenge, $geetest_validate, $geetest_seccode)) {
                        throw new Exception("", 1005);
                    }
                }

                if (!Cache::CheckFrequncy('sendcaptcha', $ip, 30)) {
                    throw new Exception("", 1004);
                }

                $wmtoken = $request->getArg('wmtoken');

                $params = [];
                $params['businessId'] = Config::read('WM_REG');
                $params['token'] = $wmtoken;
                $params['account'] = $phone;
                $params['ip'] = $ip;
                $params['runEnv'] = WmReg::$runEnv[$device_platform];
                $params['operatingTime'] = TIMESTAMP;
                $params['phone'] = $phone;
                $params["target"] = $invite_uid;
                $params['referrer'] = $_SERVER['HTTP_REFERER'];
                $params['userAgent'] = $_SERVER['HTTP_USER_AGENT'];
                $wmcheckres = WmReg::check($params);
                if ($wmcheckres["code"] == 200) {
                    $action = $wmcheckres["result"]["action"];
                    if ($action == 20) {
                        $stopatreg = 1;
                    } else if ($action == 10) {
                        $risk = 1;
                    }
                }
            } else {
                $sc_sessionid = $request->getArg('sc_sessionid');
                $sc_sig = $request->getArg('sc_sig');
                $sc_token = $request->getArg('sc_token');
                $sc_sence = "ic_" . $act . ($device_platform == "h5" ? "_h5" : "");

                $iClientProfile = \DefaultProfile::getProfile("cn-beijing", "LTAIgqlgNpdOi1H6", "SbbBjxAroCcHnvxQgA5gZ8GlQ7DqcG");
                $client = new \DefaultAcsClient($iClientProfile);
                \DefaultProfile::addEndpoint("cn-beijing", "cn-beijing", "afs", "afs.aliyuncs.com");

                $screquest = new AuthenticateSigRequest();
                $screquest->setSessionId($sc_sessionid);
                $screquest->setToken($sc_token);
                $screquest->setSig($sc_sig);
                $screquest->setScene($sc_sence);
                $screquest->setAppKey("FFFF00000000017A87BB");
                $screquest->setRemoteIp($ip);

                $scresponse = $client->getAcsResponse($screquest);
                if (!in_array($scresponse->RiskLevel, ['low', ""]) || $scresponse->Code != 100) {
                    Log::debug($scresponse, $act . 'risk');
                    throw new Exception("", 1005);
                }
            }
        } else {
            $captchakey = $request->getArg('captchaKey');
            if (strstr($captchakey, '%')) {
                $captchakey = urldecode($captchakey);
            }
            $timestamp = Rsa::decrypt($captchakey);
            if (strlen($timestamp) == 13) {
                $timestamp = substr($timestamp, 0, 10);
            }
            if (abs(TIMESTAMP - $timestamp) > 60) {
                throw new Exception("", 1005);
            }
        }

        $data['data']['status'] = 1;

        $transPhoneInfo = Team::transformPhoneNum($country_code, $phone);
        $whitelist = [
            18609099586,
            15862312979,
            15837025015,
            18825207227,
            18918092478,
            13577671428,
            13793311451,
            13481019441
        ];
        if(in_array($phone, $whitelist) || in_array($transPhoneInfo[1], $whitelist)) {
            $risk = 0;
        } else if ($transPhoneInfo[1] != $phone) {
            $risk = 0;
        }

        Cache::SetCache('register_' . $transPhoneInfo[0] . $transPhoneInfo[1], [
            'phone' => $phone,
            'ip' => $ip,
            'stopatreg' => $stopatreg
        ]);
        $data['data']['risk'] = $risk;

        if(!in_array(RUN_ENV, ['test', 'development'])) {
            $res = \SMS::sendCaptcha([
                'country_code' => $transPhoneInfo[0],
                'tel' => $transPhoneInfo[1],
                'template_code' => $act == 'login' ? 5 : 1,
                'product_name' => "iVeryOne社区",
                'risk' => $risk
            ]);
            if ($res['code'] != 0) {
                throw new Exception($res['msg'], 2008);
            }
        }

        $response->setBody($this->formatData($data));
    }

    /**
     * @param $phone
     * @return mixed
     * @throws Exception
     */
    private function phonegeo($phone)
    {
        $ch = curl_init();
        $url = "http://api04.aliyun.venuscn.com/mobile?mobile={$phone}";
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization:APPCODE 7b9240c5140649dba0de036294ce846b']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_URL, $url);
        $res = curl_exec($ch);
        $res = json_decode($res, true);
        if (empty($res)) {
            return;
        }
        if ($res['ret'] != 200) {
            throw new Exception($res['msg'], 4132);
        }
        $res['data']['prov'] = str_replace([
            "省", "市", "自治区", "特别行政区", "维吾尔", "回族", "壮族"
        ], "", $res['data']['prov']);
        return $res['data'];
    }

    /**
     * @param $ip
     * @return mixed
     * @throws Exception
     */
    private function ipgeo($ip)
    {
        $ch = curl_init();
        $url = "https://dm-81.data.aliyun.com/rest/160601/ip/getIpInfo.json?ip={$ip}";
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization:APPCODE 7b9240c5140649dba0de036294ce846b']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_URL, $url);
        $res = curl_exec($ch);
        $res = json_decode($res, true);
        if (empty($res)) {
            return;
        }
        if ($res['code'] != 0) {
            throw new Exception($res['data'], 4132);
        }
        $res['data']['region'] = str_replace([
            "省", "市", "自治区", "特别行政区", "维吾尔", "回族", "壮族"
        ], "", $res['data']['region']);
        return $res['data'];
    }
}