<?php

namespace HttpApi\Controller\Action\Api\User;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\ArrayTool;
use Beahoo\Tool\Config;
use HttpApi\Model\User\LockUserFlows;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class LockUserFlowsAction extends \HttpApi\Controller\ApiAuthAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     */
    public function execute(Request $request, Response $response)
    {
        
        $uid = $request->getArg('uid');
        $referer = $request->getArg("referer");
        $start = $request->getArg('start', 0);
        $limit = $request->getArg('limit', 10);

        //find if the user is bigR
        $list = LockUserFlows::getInstance()->getDetail($uid,$referer);
        if($list){
            $tids = [];
            foreach ($list as $key => $value) {
                $value['remark'] && $tids[] = $value['remark'];
            }
            // article IDs
            if($tids){

            }
        }
        if($list){
            foreach ($list as $key => $value) {
                $list[$key]['amount'] = floatval($value['amount']/1000000);
            }
            $data['data']['list'] = $list;
        }
        
        $response->setBody($this->formatData($data));
    }
}