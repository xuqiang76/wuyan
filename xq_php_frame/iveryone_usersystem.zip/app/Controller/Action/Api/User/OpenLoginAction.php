<?php

namespace HttpApi\Controller\Action\Api\User;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\Config;
use GuzzleHttp\Client;
use HttpApi\Model\Wallet\Balance;
use HttpApi\Tool\Token;


/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class OpenLoginAction extends \HttpApi\Controller\ApiAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     * @throws Exception
     */
    public function execute(Request $request, Response $response)
    {
        $code = $request->getArg('code');
        $platform = $request->getArg('platform');
        $device_platform = $request->getArg('device_platform');
        $redirect_uri = urldecode($request->getArg('redirect_uri'));

        if (empty($code) || empty($platform)) {
            throw new Exception("", 1001);
        }

        $client = new Client();
        $res = $client->request('GET', Config::read('iveryone_openapi_url') . 'Oauth2/AccessToken', [
            'query' => [
                'appkey' => Config::read('open_app_maps.' . $platform . ".appkey"),
                'appsecret' => Config::read('open_app_maps.' . $platform . ".appsecret"),
                'redirect_uri' => $redirect_uri,
                'code' => $code
            ]
        ]);

        if ($res->getStatusCode() != 200) {
            throw new Exception("", 1003);
        }
        $res = $res->getBody();
        if (empty($res)) {
            throw new Exception("", 1003);
        }

        $res = json_decode($res, true);
        
        if($res['errno'] == 0) {
            $data['data']['uid'] = $res['data']['uid'];
            $data['data']['token'] = Token::create($res['data']['uid'], $device_platform, 0);
        } else {
            throw new Exception($res['errmsg'], 1003);
        }

        $response->setBody($this->formatData($data));
    }

}