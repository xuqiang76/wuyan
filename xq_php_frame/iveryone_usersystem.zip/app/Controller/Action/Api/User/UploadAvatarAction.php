<?php

namespace HttpApi\Controller\Action\Api\User;

use Aws\S3\S3Client;
use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Model\User\User;
use HttpApi\Tool\Token;
use OSS\Core\OssException;
use OSS\OssClient;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class UploadAvatarAction extends \HttpApi\Controller\ApiAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     * @throws Exception
     * @throws OssException
     */
    public function execute(Request $request, Response $response)
    {
        $uid = $request->getArg('uid');
        $token = $request->getArg('token');
        $device_platform = $request->getArg('device_platform');

        if(!empty($uid) && !empty($token) && !empty($device_platform)) {
            Token::checkToken($uid, $token, $device_platform);
        }

        $avatar = $request->getFileArg('avatar');
        if(empty($avatar)) {
            throw new Exception("", 1001);
        }

        if(!in_array($avatar['type'], ['image/png', 'image/jpg', 'image/jpeg', 'image/gif', 'audio/mpegurl'])) {
            throw new Exception("", 1001);
        }

        if($avatar['size'] > 1024*1024*2) {
            throw new Exception("", 2006);
        }

        $key = md5_file($avatar['tmp_name']) . "." . str_replace(["image/", "audio/mpegurl"], ["", "m3u8"], $avatar['type']);

        try {
            $accessKeyId = "LTAIgqlgNpdOi1H6";
            $accessKeySecret = "SbbBjxAroCcHnvxQgA5gZ8GlQ7DqcG";
            $endpoint = RUN_ENV=='aliyun_huabei2'?"oss-cn-beijing-internal.aliyuncs.com":"oss-cn-beijing.aliyuncs.com";
            $ossClient = new OssClient($accessKeyId, $accessKeySecret, $endpoint);
            $ossClient->uploadFile('iveryone-avatar', $key, $avatar['tmp_name']);
            $data['data']['avatar_url'] = "http://avatar.iveryone.wuyan.cn/" . $key;
        } catch (OssException $e) {
            throw new Exception("", 2005);
        }

        if(!empty($uid)) {
            User::getInstance()->updateFields(['avatar' => $data['data']['avatar_url']], ['id' => $uid]);
        }

        $data['data']['avatar_url'] .= "/avatar";
        $response->setBody($this->formatData($data));
    }
}