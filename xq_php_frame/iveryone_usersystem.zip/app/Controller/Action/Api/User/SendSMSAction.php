<?php

namespace HttpApi\Controller\Action\Api\User;

use afs\Request\V20180112\AuthenticateSigRequest;
use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\Config;
use HttpApi\Encrypt\Rsa;
use HttpApi\Model\User\User;
use HttpApi\Tool\Cache;
use HttpApi\Tool\Log;
use HttpApi\Tool\Team;
use HttpApi\Utility;

require_once "/download/WuyanLibs/sms/SMS.php";
require_once ROOT . '/libs/aliyun-php-sdk-core/Config.php';

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class SendSMSAction extends \HttpApi\Controller\ApiAuthAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     * @throws Exception
     */
    public function execute(Request $request, Response $response)
    {
        $uid = $request->getArg('uid');
        $userinfo = User::getInstance()->getNoCacheUserInfo($uid, ['password', 'pay_password', 'salt']);
        $transPhoneInfo = Team::transformPhoneNum($userinfo['country_code'], $userinfo['phone']);

        $params = [
            'country_code' => $transPhoneInfo[0],
            'tel' => $transPhoneInfo[1],
            'template_code' => 4,
            'product_name' => "iVeryOne社区",
            'risk' => 0
        ];
        $res = \SMS::sendCaptcha($params);
        if ($res['code'] != 0) {
            if (!in_array(RUN_ENV, ['test', 'development'])) {
                throw new Exception($res['msg'], 2008);
            }
        }
        $data['data']['status'] = 1;
        $response->setBody($this->formatData($data));
    }
}