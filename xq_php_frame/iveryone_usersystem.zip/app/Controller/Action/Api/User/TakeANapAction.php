<?php

namespace HttpApi\Controller\Action\Api\User;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Model\User\User;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class TakeANapAction extends \HttpApi\Controller\ApiAuthAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     * @throws Exception
     */
    public function execute(Request $request, Response $response)
    {
        $act = $request->getArg('act');
        $nap_last = $request->getArg('nap_last');

        if(!in_array($act, ['rest', 'getup'])) {
            throw new Exception("", 1001);
        }

        $userinfo = $request->getArg('userinfo');
        if($act == 'rest') {
            if($nap_last == '1hour') {
                $userinfo['nap_end_timestamp'] = TIMESTAMP + 3600;
            } else if ($nap_last == 'next7am') {
                if(date("H") < 7) {
                    $userinfo['nap_end_timestamp'] = strtotime(date("Y-m-d") . " 07:00:00");
                } else {
                    $userinfo['nap_end_timestamp'] = strtotime(date("Y-m-d", strtotime("+1 day")) . " 07:00:00");
                }
            } else {
                throw new Exception("", 1001);
            }
            $userinfo['nap_status'] = 1;
        } else {
            $userinfo['nap_status'] = 0;
            $userinfo['nap_end_timestamp'] = 0;
        }
        
        User::getInstance()->updateFields([
            'nap_end_timestamp' => $userinfo['nap_end_timestamp']
        ], ['id' => $userinfo['id']]);

        $data['data'] = [
            'status' => 1,
            'userinfo' => User::getInstance()->dataFormat($userinfo)
        ];

        $response->setBody($this->formatData($data));
    }
}