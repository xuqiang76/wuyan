<?php

namespace HttpApi\Controller\Action\Api\User;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Tool\ArrayTool;
use HttpApi\Controller\ApiAction;
use HttpApi\Model\Contacts;
use HttpApi\Model\User\User;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class GetInfosAction extends ApiAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     */
    public function execute(Request $request, Response $response)
    {
        $uid = $request->getArg('uid');
        $uids = $request->getArg('uids');
        $listmap = $request->getArg('listmap', 0);
        $getcontactstatus = $request->getArg('getcontactstatus', 0);
        $userinfos = User::getInstance()->getUserinfoByUids($uids);

        if($listmap) {
            $userinfos = ArrayTool::list2Map($userinfos, 'id');
            if(empty($userinfos)) {
                $userinfos = new \StdClass();
            }
        }

        if(!empty($userinfos) && $getcontactstatus && $uid) {
            $contactInfos = ArrayTool::list2Map(Contacts::getInstance()->getItems([
                'uid' => $uid,
                'contact_uid' => $uids,
                'contact_status' => 1
            ]), 'contact_uid');
            foreach ($userinfos as $key => $userinfo) {
                $userinfos[$key]['contact_status'] = 0;
                if(!empty($contactInfos[$userinfos['id']])) {
                    $userinfos[$key]['contact_status'] = 1;
                }
            }
        }

        $data['data']['list'] = array_values($userinfos);
        $response->setBody($this->formatData($data));
    }
}