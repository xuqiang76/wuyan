<?php

namespace HttpApi\Controller\Action\Api\User;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Tool\ArrayTool;
use HttpApi\Controller\ApiAction;
use HttpApi\Model\User\User;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class GetInfosAction extends ApiAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     */
    public function execute(Request $request, Response $response)
    {
        $uids = $request->getArg('uids');
        $listmap = $request->getArg('listmap', 0);
        $userinfos = User::getInstance()->getUserinfoByUids($uids);

        if($listmap) {
            $userinfos = ArrayTool::list2Map($userinfos, 'id');
            if(empty($userinfos)) {
                $userinfos = new \StdClass();
            }
        }

        $data['data']['list'] = $userinfos;
        $response->setBody($this->formatData($data));
    }
}