<?php

namespace HttpApi\Controller\Action\Api\User;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Model\Contacts;
use HttpApi\Model\User\User;
use HttpApi\Tool\BehaviorLogs;
use HttpApi\Utility;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class ReportAction extends \HttpApi\Controller\ApiAuthAction
{

    /**
     * 获取报告设置
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     */
    public function execute(Request $request, Response $response){
        
        $userinfo = $request->getArg('userinfo');
        
        $data=[
            'report_push_everyone'=>intval($userinfo['report_push_everyone']),
            'report_push_statistic'=>intval($userinfo['report_push_statistic'])
        ];

        $response->setBody($this->formatData(['data'=>$data]));
    }

    /**
     * 设置报告推送
     * @param  Request  $request  
     * @param  Response $response 
     * @return 
     */
    public function setting(Request $request, Response $response){

        $uid=$request->getArg('uid');

        try{

            if(isset($_REQUEST['report_push_everyone'])){
                
                User::getInstance()->updateFields(['report_push_everyone'=>intval($_REQUEST['report_push_everyone'])],['id'=>$uid]);
            }else if(isset($_REQUEST['report_push_statistic'])){

                User::getInstance()->updateFields(['report_push_statistic'=>intval($_REQUEST['report_push_statistic'])],['id'=>$uid]);
            }

            $response->setBody($this->formatData([]));
        }catch(Exception $e){

            throw new Exception('系统异常,请重试',1);
        }
    }
}