<?php

namespace HttpApi\Controller\Action\Api\User;

use afs\Request\V20180112\AuthenticateSigRequest;
use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\Config;
use HttpApi\Model\Battery;
use HttpApi\Model\Contacts;
use HttpApi\Model\User\User;
use HttpApi\Model\Wallet\Balance;
use HttpApi\Model\Wallet\Wallet;
use HttpApi\Tool\GeeGuardLib;
use HttpApi\Tool\IMInterface;
use HttpApi\Tool\Log;
use HttpApi\Tool\Team;
use HttpApi\Tool\Token;
use HttpApi\Utility;
use HttpApi\Tool\SDKs;

require_once "/download/WuyanLibs/sms/SMS.php";
require_once ROOT . '/libs/aliyun-php-sdk-core/Config.php';

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class LoginAction extends \HttpApi\Controller\ApiAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     * @throws Exception
     */
    public function execute(Request $request, Response $response)
    {
        $country_code = strtoupper($request->getArg('country_code'));
        $phone = $request->getArg('phone');
        $code = $request->getArg('code');
        $password = $request->getArg('password');
        $invite_uid = $request->getArg('invite_uid', 0);
        $device_platform = $request->getArg('device_platform');

        if (empty($country_code) || empty($phone) || (empty($code) && empty($password))) {
            throw new Exception("", 1001);
        }

        if(!empty($code)) {
            if (!is_numeric($code) && strlen($code) != 6) {
                throw new Exception("", 2011);
            }
        }

        $userinfo = User::getInstance()->getUserinfoByPhone($country_code, $phone);
        if(empty($userinfo)) {
            throw new Exception("", 2001);
        }

        if(!empty($password)) {
            if(!$userinfo['setpass']) {
                throw new Exception("", 2018);
            }
            if($userinfo['blocked'] == 3 || $userinfo['blocked'] == 4) {
                throw new Exception("您的帐号异常，请用验证码登录", 1001);
            }
            try {
                User::getInstance ()->checkpassword ( $userinfo ['id'], $password );
            } catch ( Exception $e) {
                if($e->getCode() == 2002){
                    throw new Exception('', 2019);
                } else {
                    throw new Exception($e->getMessage(), $e->getCode());
                }
            }
        } else {
            $transPhoneInfo = Team::transformPhoneNum($country_code, $phone);
            $res = \SMS::verifyCaptcha([
                'country_code' => $transPhoneInfo[0],
                'tel' => $transPhoneInfo[1],
                'template_code' => '5',
                'msg' => $code,
                'doexpire' => 1
            ]);
            if ($res['code'] != 0) {
                if(!in_array(RUN_ENV, ['test', 'development','local', 'aliyun_huabei2_sandbox'])) {
                    throw new Exception($res['msg'], 2011);
                }
            }
        }

        $data['data']['uid'] = $userinfo['id'];
        $data['data']['token'] = Token::create($userinfo['id'], $device_platform, $userinfo['init_im_user']);
        $wallet = Balance::getInstance()->query(['uid' => $userinfo['id']]);

        $data['data']['identity_notice'] = 0;
        $data['data']['identity_reward'] = "10";
        // 只针对初始化未认证的用户,只提示一次
        ($wallet['status']==1016 && $this->_should_popup_face_identity($userinfo['id'])) && $data['data']['identity_notice']=1;

        $iveryone_official_uid = Config::read('iveryone_official_uid');
        try {
            $content = '欢迎来到iveryone,常见问题请点击查看。';
            $msgbody = [
                'msgType' => 23,
                'data' => [
                    'title' => $content,
                    'img' => 'https://static.wuyan.cn/iveryone/logo.png',
                    'url' => Config::read('h5_url') . 'Problem'
                ]
            ];
            IMInterface::send($iveryone_official_uid, 0, $userinfo['id'], 100, $msgbody, IMInterface::makeExt($userinfo['id'], 0, json_encode($msgbody), 0));
        } catch (Exception $e) {
            Log::debug('IM Exception:' . PHP_EOL . $e->getMessage(), "push.everyone");
        }

        if(!empty($invite_uid)) {
            try {
                Contacts::getInstance()->follow($userinfo['id'], $invite_uid);
            } catch (Exception $e) {

            }
        }

        $response->setBody($this->formatData($data));
    }

    /**
     * 是否应该弹人脸认证的提示框
     * 首次登录时只提示一次
     * @return boolean
     */
    private function _should_popup_face_identity($uid){
        
        $redis=SDKs::getRedis();
        
        $key_string='user_face_identity_notice';

        $exists=$redis->hexists($key_string,$uid);

        if(!$exists) $redis->hset($key_string,$uid,1);

        return !$exists;
    }
}