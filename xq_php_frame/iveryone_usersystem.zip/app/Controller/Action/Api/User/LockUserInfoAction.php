<?php

namespace HttpApi\Controller\Action\Api\User;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\ArrayTool;
use HttpApi\Model\User\LockUserInfo;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class LockUserInfoAction extends \HttpApi\Controller\ApiAuthAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     */
    public function execute(Request $request, Response $response)
    {
        
        #$data['data']['userinfo'] = $request->getArg('userinfo');
        $uid = $request->getArg('uid');
        $lastid = $request->getArg('lastid', 0);
        $limit = $request->getArg('limit', 10);
        //find if the user is bigR
        $result = LockUserInfo::getInstance()->get($uid,$lastid,$limit);
        if($result){
            foreach ($result as $key => $value) {
                $result[$key]['amount'] = floatval($value['lock_amount']/1000000);
                //when islock=='Y'
            }
        }
        $data['data'] = $result ? $result:[];
        $response->setBody($this->formatData($data));
    }
    
}