<?php

namespace HttpApi\Controller\Action\Api\User;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\Config;
use HttpApi\Tool\iVeryOneApi;
use HttpApi\Tool\OpenApi;


/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class GetOpenCodeAction extends \HttpApi\Controller\ApiAuthAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     * @throws Exception
     */
    public function execute(Request $request, Response $response)
    {
        $userinfo = $request->getArg('userinfo');
        $platform = $request->getArg('platform');

        if (empty($platform)) {
            throw new Exception("", 1001);
        }

        $res = OpenApi::Request('Intra/User/GetCode', [
            'uid' => $userinfo['id'],
            'appkey' => Config::read('open_app_maps.' . $platform . ".appkey"),
            'redirect_uri' => Config::read('open_app_maps.' . $platform . ".redirect_uri")
        ]);

        if($res['errno'] === 0) {
            $data['data']['code'] = $res['data']['code'];
        } else {
            throw new Exception($res['errmsg'], 1003);
        }

        $response->setBody($this->formatData($data));
    }

}