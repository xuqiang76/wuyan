<?php

namespace HttpApi\Controller\Action\Api\User;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Model\User\PersonalContent;
use HttpApi\Model\User\Service;
use HttpApi\Tool\OpenApi;
use HttpApi\Tool\Times;
use HttpApi\Tool\Token;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class GetAuthInfoAction extends \HttpApi\Controller\ApiAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     * @throws Exception
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function execute(Request $request, Response $response)
    {
        $uid = $request->getArg('uid');
        $token = $request->getArg('token');
        $device_platform = $request->getArg('device_platform');
        $ivoid = $request->getArg('ivoid', 0);
        $appname = $request->getArg('appname');

        if(!empty($uid) && !empty($token) && $uid != 'null' && $token != 'null') {
            Token::checkToken($uid, $token, $device_platform);
        }

        if(empty($uid) && empty($ivoid)) {
            throw new Exception("", 1001);
        }

        if(!empty($ivoid)) {
            $uid = $ivoid;
        }
        $authinfos = OpenApi::Request('Intra/User/GetAuthInfo', [
            'uid' => $uid
        ])['data'];

        if(!empty($appname)) {
            foreach ($authinfos as $key => $authinfo) {
                unset($authinfos[$key]['accesstoken']);
                if($authinfo['appname'] != $appname) {
                    unset($authinfos[$key]);
                    continue;
                }
                if($authinfo['appname'] == 'PressOne') {
                    $authinfos[$key] = [];
                    $authinfos[$key]['appname'] = $authinfo['appname'];
                    $authinfos[$key]['appuid'] = $authinfo['appuid'];
                    $authinfos[$key]['content'] = PersonalContent::getInstance()->getItem(['uid' => $uid]);
                    $authinfos[$key]['content']['timestamp'] = Times::format_date($authinfos[$key]['content']['timestamp']);

                    $client = new \GuzzleHttp\Client();
                    $res = $client->request('GET', 'https://press.one/api/bind/' . $authinfo['appuid']);
                    if ($res->getStatusCode() == 200) {
                        $body = $res->getBody();
                        if (!empty($body)) {
                            $res = json_decode($body, true);
                            if($res['success']) {
                                foreach ($res['data'] as $item) {
                                    if($item['service_name'] == 'ivery.one') {
                                        continue;
                                    }
                                    if(strstr($item['service_name'], '.com')) {
                                        $item['service_name'] = str_replace(".com", "", $item['service_name']);
                                    }
                                    if(strstr($item['service_name'], '.cn')) {
                                        $item['service_name'] = str_replace(".cn", "", $item['service_name']);
                                    }
                                    if($item['service_name'] == 'qq') {
                                        $item['service_name'] = 'weixin';
                                    }
                                    $authinfos[$item['service_name']] = [
                                        'appname' => $item['service_name'],
                                        'content' => [
                                            'content' => $item['proof'],
                                            'timestamp' => Times::format_date(strtotime($item['createdAt']))
                                        ]
                                    ];
                                }
                            }
                        }
                    }
                }
            }
        }

        $data['data']['list'] = array_values($authinfos);
        $response->setBody($this->formatData($data));
    }
}