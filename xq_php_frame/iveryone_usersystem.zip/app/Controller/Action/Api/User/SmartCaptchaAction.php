<?php

namespace HttpApi\Controller\Action\Api\User;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Tool\Config;
use HttpApi\Tool\Cache;
use HttpApi\Tool\GeetestLib;
use HttpApi\Utility;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class SmartCaptchaAction extends \HttpApi\Controller\ApiAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     */
    public function execute(Request $request, Response $response)
    {
        $device_platform = $request->getArg('device_platform');
        $GtSdk = new GeetestLib(Config::read('CAPTCHA_ID'), Config::read('CAPTCHA_PRIVATE_KEY'));

        $user_id = uniqid();
        $params = array(
            "user_id" => $user_id, # 网站用户id
            "client_type" => $device_platform, #web:电脑上的浏览器；h5:手机上的浏览器，包括移动应用内完全内置的web_view；native：通过原生SDK植入APP应用的方式
            "ip_address" => Utility::getIP() # 请在此处传输用户请求验证时所携带的IP
        );

        $cache['status'] = $GtSdk->pre_process($params, 1);
        $data['data'] = $GtSdk->get_response();
        $cache['sessionid'] = $data['data']['sessionid'] = $user_id;

        Cache::SetCache($user_id, $cache);

        $response->setBody($this->formatData($data));
    }
}