<?php

namespace HttpApi\Controller\Action\Api\Identity;

include_once ROOT.'/libs/linkface/autoload.php';

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Linkface\Ocr;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class IdcardAction extends \HttpApi\Controller\ApiAuthAction
{
    public $no_wallet_status_check = true;

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     */
    public function execute(Request $request, Response $response)
    {
        $image=@$_FILES['idcard']['tmp_name'];
        $uid = $request->getArg('uid');
        $side = strtolower($request->getArg('side','front'));

        if(empty($image) || empty($side) || ($side!='front' && $side!='back')) throw new Exception('', 1001);
        
        $ocr=new Ocr(\Beahoo\Tool\Config::read('linkface.api_id'),\Beahoo\Tool\Config::read('linkface.api_secret'));

        $data=$ocr->idcard($image,$side);

        if($side=='front' && $data['errno']==0)
            $data['data']=['name'=>$data['data']['name'],'number'=>$data['data']['number']];
        
        $response->setBody($this->formatData($data));
    }
}