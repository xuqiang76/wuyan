<?php

namespace HttpApi\Controller\Action\Api\Identity;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Model\Identity\{Face,User};

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class FaceAction extends \HttpApi\Controller\ApiAuthAction
{
    public $no_wallet_status_check = true;
    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     */
    public function execute(Request $request, Response $response)
    {
        $uid = $request->getArg('uid');
        $name = $request->getArg('name');
        $number = $request->getArg('number');
        $code = $request->getArg('code');
        $image=@$_FILES['image']['tmp_name'];
        $protobuf=@$_FILES['protobuf']['tmp_name']; //移动端SDK返回的protobuf文件
        $wallet = $request->getArg('wallet');
        // 是否是高危用户
        $is_risk=($wallet['status']==1014 || $wallet['status']==1015)?1:0;
        
        if(empty($number) || empty($name) || empty($image)) throw new Exception('参数不全', 1001);

        $number_regex="/^([1-9]\d{5}(18|19|([23]\d))\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$)|(^[1-9]\d{5}\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{2}$)/";

        if(!preg_match($number_regex, $number)) throw new Exception('身份证号不正确', 2150);
        // 校验图片md5是否一致
        if(md5_file($image)!=$code) throw new Exception('', 2152);
        // 校验是否上传视频文件
        if(empty($protobuf) || !file_exists($protobuf)) throw new Exception('',2152);
        
        $result=(new Face())->verify($uid,$number,$name,$image,$protobuf,$is_risk);
        
        if($result===true) $result=['data'=>['status'=>1]];
        
        $response->setBody($this->formatData($result));
    }

    /**
     * 获取人脸认证状态
     * @param  Request  $request  
     * @param  Response $response 
     * @return array
     */
    public function status(Request $request, Response $response){

        $uid = $request->getArg('uid');

        $user_identity=User::getInstance()->getUserIdentity($uid);

        $is_auth=0; // 是否已完成人脸认证

        if($user_identity && $user_identity['auth_face']) $is_auth=1;

        $data=['status'=>$is_auth];

        $response->setBody($this->formatData(['data'=>$data]));
    }

    /**
     * 再次人脸认证
     * @param  Request  $request  [description]
     * @param  Response $response [description]
     * @return [type]             [description]
     */
    public function again(Request $request, Response $response){

        $code = $request->getArg('code');
        $image=@$_FILES['image']['tmp_name'];
        $uid = $request->getArg('uid');

        if(empty($image)) throw new Exception('', 1001);

        if(md5_file($image)!=$code) throw new Exception('6666', 2152);

        $result=(new Face())->verifyAgain($uid,$image);

        if($result===true) $result=['data'=>['status'=>1]];
        
        $response->setBody($this->formatData($result));
    }
} 