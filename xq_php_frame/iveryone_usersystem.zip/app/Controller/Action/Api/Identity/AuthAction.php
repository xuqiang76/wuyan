<?php

namespace HttpApi\Controller\Action\Api\Identity;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Model\Identity\{Face,User};

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class AuthAction extends \HttpApi\Controller\ApiAuthAction
{
    public $no_wallet_status_check = true;

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     */
    public function execute(Request $request, Response $response)
    {
        $uid = $request->getArg('uid');
        // 默认为人脸认证
        $auth='face';

        $user_identity=User::getInstance()->getUserIdentity($uid);
            
        // 如果人脸及支付宝都完成认证
        if($user_identity['auth_face'] && $user_identity['auth_alipay']){

            $authes=['face','alipay'];

            $auth=$authes[rand(0,count($authes)-1)];

        }elseif($user_identity['auth_face']){

            $auth='alipay';
        }else{

            $auth='face';
        }

        $response->setBody($this->formatData(['data'=>['auth'=>$auth]]));
    }
} 