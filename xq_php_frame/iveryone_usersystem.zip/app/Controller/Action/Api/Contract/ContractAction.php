<?php

namespace HttpApi\Controller\Action\Api\Contract;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Model\Contract\Contract;
use HttpApi\Model\Contacts;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class ContractAction extends \HttpApi\Controller\ApiAuthAction
{

    /**
     * 获取用户合约列表.有层级结构
     * @param  Request  $request  
     * @param  Response $response 
     * @return 
     */
    public function execute(Request $request, Response $response)
    {
        // 如果是父类的话,则传递contract_id获取相应的子合约
        $contract_id=$request->getArg('contract_id',0);
        $uid=$request->getArg('uid');

        $contracts=Contract::getInstance()->getContracts(['status'=>1,'parent_id'=>$contract_id],['id','name','type','contract_no','is_parent']);    

        $result=[];

        foreach ($contracts as $contract) {

            $result[]=[
                'id'=>$contract['id'],
                'name'=>$contract['name'],
                'contract_no'=>$contract['type']==Contract::CONSTRACT_TYPE_NEWS_TRANSFER?str_replace('0000',$uid, $contract['contract_no']):$contract['contract_no'],
                'jump_type'=>$contract['type']==Contract::CONSTRACT_TYPE_MESSAGE?
                    Contract::JUMP_TYPE_MESSAGE:
                    ($contract['is_parent']?Contract::JUMP_TYPE_NEXT_LEVEL:Contract::JUMP_TYPE_DETAIL),
            ];
        }

        $data=['contracts'=>$result];

        $response->setBody($this->formatData(['data'=>$data]));
    }

    /**
     * 获取某个合约的详情
     * @param  Request  $request  
     * @param  Response $response 
     * @return array
     */
    public function detail(Request $request, Response $response){

        $uid=$request->getArg('uid');
        $contract_id=$request->getArg('id',0);

        $contract=Contract::getInstance()->getContract(
            ['id'=>$contract_id,'status'=>1],
            ['id','name','contract_no','partya','partyb','remark','content','type','detail_url']
        );

        if(empty($contract))  throw new Exception('合约不存在', -1);
        // 如果是内容转发合约
        $contract['type']==Contract::CONSTRACT_TYPE_NEWS_TRANSFER && $contract['contract_no']=str_replace('0000',$uid, $contract['contract_no']);

        $response->setBody($this->formatData(['data'=>$contract]));
    }
}