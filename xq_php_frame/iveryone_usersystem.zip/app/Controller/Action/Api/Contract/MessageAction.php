<?php

namespace HttpApi\Controller\Action\Api\Contract;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\Config;
use HttpApi\Model\Contract\Contract;
use HttpApi\Model\Contract\User as UserContract;
use HttpApi\Model\Contract\Message as MessageContract;
use HttpApi\Model\Contacts;
use HttpApi\Model\User\User;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class MessageAction extends \HttpApi\Controller\ApiAuthAction
{

    public function __construct(){
        // 限定json_encode时浮点精度为3位数
        @ini_set('serialize_precision',3);
    }

    /**
     * 获取用户消息合约列表
     * @param  Request  $request  
     * @param  Response $response 
     * @return 
     */
    public function execute(Request $request, Response $response)
    {
        $uid=$request->getArg('uid');
        $page = $request->getArg('page', 1);
        $page_size=20;

        $where=['uid'=>$uid,'status'=>1];

        // 判断是否存在默认合约
        $exist_default_message_contract=UserContract::getInstance()->existDefaultMessageContract($uid);
        // 不存在则直接创建
        if(!$exist_default_message_contract){
            // 创建默认合约和免费合约
            UserContract::getInstance()->createUserDefaultMessageContract($uid);
            UserContract::getInstance()->createUserFreeMessageContract($uid);
        }

        $message_contracts=MessageContract::getInstance()->getMessageContracts(
            $where,
            ['id','name','contract_no','message_price','audio_price','video_price','audio_status','video_status','is_default'],
            ($page-1)*$page_size,
            $page_size
        );

        $total=MessageContract::getInstance()->getCount($where);

        $page_count=ceil($total/$page_size);

        $data=['message_contracts'=>$message_contracts,'total'=>$total,'page_count'=>ceil($total/$page_size)];

        $response->setBody($this->formatData(['data'=>$data]));
    }

    /**
     * 获取某个消息合约的详情
     * @param  Request  $request  
     * @param  Response $response 
     * @return array
     */
    public function detail(Request $request, Response $response){

        $uid=$request->getArg('uid');
        $message_contract_id=$request->getArg('id',0);
        $userinfo=$request->getArg('userinfo');

        $message_contract=MessageContract::getInstance()->getMessageContract(
            ['id'=>$message_contract_id,'status'=>1],
            ['id','name','contract_no','message_price','audio_price','video_price','audio_status','video_status','is_default']
        );

        if(empty($message_contract))  throw new Exception('合约不存在', -1);

        $contract=Contract::getInstance()->getContract(['type'=>Contract::CONSTRACT_TYPE_MESSAGE,'status'=>1]);
        // 合约简介
        $message_contract['remark']=$contract['remark'];
        // 甲方
        $message_contract['partya']=$userinfo['nickname'];
        // 默认合约写死
        if($message_contract['is_default']){

            $message_contract['partyb']=[];
        }else{
            // 获取绑定的联系人账户
            $contact_arr=Contacts::getInstance()->getUserContacts(['uid'=>$uid,'message_contract_id'=>$message_contract_id],['contact_uid']);

            $contact_uid_arr=[];

            foreach ($contact_arr as $contact) $contact_uid_arr[]=$contact['contact_uid'];

            $users=User::getInstance()->getUsers(['id'=>$contact_uid_arr],['id','nickname','avatar']);

            $message_contract['partyb']=$users;
        }
        
        $message_contract['detail_url']=Config::read('appwv_url') . "Contract5?id=" . $message_contract_id;

        $response->setBody($this->formatData(['data'=>$message_contract]));
    }

    /**
     * 新增新的用户消息合约，同时绑定联系人合约
     * @param Request  $request  
     * @param Response $response 
     */
    public function add(Request $request, Response $response){
        $uid=$request->getArg('uid');
        $name=$request->getArg('name');
        $message_price=$request->getArg('message_price',0.0);
        $audio_price=$request->getArg('audio_price',0.0);
        $video_price=$request->getArg('video_price',0.0);
        $audio_status=$request->getArg('audio_status',0);
        $video_status=$request->getArg('video_status',0);
        $contacts=$request->getArg('contacts');

        if(empty($name)) throw new Exception('名称不能为空',-1);
        elseif(mb_strlen($name)>22) throw new Exception('名称限定22个字符以内',-1);

        if(!is_numeric($message_price) || $message_price<0 || !is_numeric($audio_price) || $audio_price<0 || !is_numeric($video_price) || $video_price<0 || $message_price>2000 || $audio_price>2000 || $video_price>2000)
            throw new Exception('收费价格应限定在0-2000',-1);

        $audio_price==='' && $audio_status=0;
        $video_price==='' && $video_status=0;
        $audio_status==0 && $audio_price=0;
        $video_status==0 && $video_price=0;
        $audio_price>0 && $audio_price=floatval(number_format($audio_price,3));
        $video_price>0 && $video_price=floatval(number_format($video_price,3));
        // 记录是否已自增suffix值
        $suffix_incr=false;

        try{

            MessageContract::getInstance()->transaction_start();

            $contract_no_suffix = UserContract::getInstance()->getLatestContractNoSuffix($uid);

            $suffix_incr=true;

            $message_contract_data=[
                'uid'=>$uid,
                'name'=>$name,
                'message_price'=>(string)$message_price,
                'audio_price'=>(string)$audio_price,
                'video_price'=>(string)$video_price,
                'audio_status'=>$audio_status,
                'video_status'=>$video_status,
                'contract_no'=>'IM-'.$uid.'-'.$contract_no_suffix,
                'status'=>1,
                'is_default'=>0
            ];

            $message_contract_id=MessageContract::getInstance()->add($message_contract_data);

            if($contacts && is_array($contacts)){

                foreach ($contacts as $contact_uid) {
                    // 绑定合约
                    Contacts::getInstance()->update(['message_contract_id'=>$message_contract_id],['uid'=>$uid,'contact_uid'=>$contact_uid]);
                }
            }

            MessageContract::getInstance()->transaction_commit();

            $message_contract_data['id']=(string)$message_contract_id;

            $response->setBody($this->formatData(['data'=>$message_contract_data]));

        }catch(Exception $e){
            
            MessageContract::getInstance()->transaction_rollback(); 

            if($suffix_incr) UserContract::getInstance()->rollbackContractNoSuffix($uid);

            throw new Exception('系统异常,请重试', -1);
        }
    }

    /**
     * 编辑用户指定消息合约
     * @param  Request  $request  
     * @param  Response $response 
     * @return 
     */
    public function edit(Request $request, Response $response){

        $uid=$request->getArg('uid');
        $message_contract_id=$request->getArg('id',0);
        $name=$request->getArg('name');
        $message_price=$request->getArg('message_price',0.0);
        $audio_price=$request->getArg('audio_price',0.0);
        $video_price=$request->getArg('video_price',0.0);
        $audio_status=$request->getArg('audio_status',0);
        $video_status=$request->getArg('video_status',0);
        $contacts=$request->getArg('contacts');

        if(empty($name)) throw new Exception('名称不能为空',-1);
        elseif(mb_strlen($name)>22) throw new Exception('名称限定22个字符以内',-1);

        if(!is_numeric($message_price) || $message_price<0 || !is_numeric($audio_price) || $audio_price<0 || !is_numeric($video_price) || $video_price<0 || $message_price>2000 || $audio_price>2000 || $video_price>2000)
            throw new Exception('收费价格应限定在0-2000',-1);

        $audio_price==='' && $audio_status=0;
        $video_price==='' && $video_status=0;
        $audio_status==0 && $audio_price=0;
        $video_status==0 && $video_price=0;
        $audio_price>0 && $audio_price=floatval(number_format($audio_price,3));
        $video_price>0 && $video_price=floatval(number_format($video_price,3));

        if(empty($message_contract_id)) throw new Exception('未指定消息合约',-1);

        $message_contract=MessageContract::getInstance()->getMessageContract(['id'=>$message_contract_id,'uid'=>$uid,'status'=>1]);

        if(empty($message_contract)) throw new Exception('消息合约不存在',-1);

        try{
            MessageContract::getInstance()->transaction_start();

            $message_contract_data=[
                'uid'=>$uid,
                'name'=>$name,
                'message_price'=>(string)$message_price,
                'audio_price'=>(string)$audio_price,
                'video_price'=>(string)$video_price,
                'audio_status'=>$audio_status,
                'video_status'=>$video_status,
            ];

            MessageContract::getInstance()->update($message_contract_data,['id'=>$message_contract_id,'uid'=>$uid,'status'=>1]);
            // 先将之前用户绑定的合约置为0
            Contacts::getInstance()->update(['message_contract_id'=>0],['uid'=>$uid,'message_contract_id'=>$message_contract_id]);

            if($contacts && is_array($contacts)){

                foreach ($contacts as $contact_uid) {
                    // 重新绑定合约
                    Contacts::getInstance()->update(['message_contract_id'=>$message_contract_id],['uid'=>$uid,'contact_uid'=>$contact_uid]);
                }
            }

            MessageContract::getInstance()->transaction_commit();

            $message_contract_data['contract_no']=$message_contract['contract_no'];
            $message_contract_data['id']=$message_contract_id;
            $message_contract_data['is_default']=$message_contract['is_default'];

            $response->setBody($this->formatData(['data'=>$message_contract_data]));
        }catch(Exception $e){
            
            MessageContract::getInstance()->transaction_rollback(); 

            throw new Exception('系统异常,请重试', -1);
        }
    }

    /**
     * 删除用户消息合约，同时将之前绑定的联系人合约清空
     * @param  Request  $request  
     * @param  Response $response 
     * @return 
     */
    public function del(Request $request, Response $response){

        $uid=$request->getArg('uid');
        $contract=$request->getArg('contract');

        if(empty($contract)) throw new Exception('', 1001);

        is_numeric($contract) && $contract=[$contract];

        try{
            MessageContract::getInstance()->transaction_start();

            foreach ($contract as $message_contract_id) {
                
                MessageContract::getInstance()->del(['uid'=>$uid,'id'=>$message_contract_id]);
                
                Contacts::getInstance()->update(['message_contract_id'=>0],['uid'=>$uid,'message_contract_id'=>$message_contract_id]);
            }

           MessageContract::getInstance()->transaction_commit();

            $data=['status'=>1];

            $response->setBody($this->formatData(['data'=>$data]));
        }catch(Exception $e){
            
            MessageContract::getInstance()->transaction_rollback(); 

            throw new Exception('系统异常,请重试', -1);
        }
    }

    /**
     * 给某个联系人绑定消息合约
     * @param  Request  $request  
     * @param  Response $response 
     * @return 
     */
    public function bind(Request $request, Response $response){

        $uid=$request->getArg('uid');
        $contact_uid=$request->getArg('contact_uid');
        $message_contract_id=$request->getArg('message_contract_id');

        if(empty($uid) || empty($contact_uid) || empty($message_contract_id)) throw new Exception('',1001);

        $status=UserContract::getInstance()->setContractMessageContract($uid,$contact_uid,$message_contract_id);

        $response->setBody($this->formatData(['data'=>['status'=>$status]]));
    }

    public function test(){

        $contracts=UserContract::getInstance()->getBothContactMssageContract(111,10);
        // $contracts=UserContract::getInstance()->getUserDefaultMessageContract(10);
        // $contracts=UserContract::getInstance()->getContactMessageContract(10,111);
        // $contracts=UserContract::getInstance()->getContactMessageContract(111,10);
        print_r($contracts);
    }

    /**
     * 获取消息合约简介
     * @param  Request  $request  [description]
     * @param  Response $response [description]
     * @return 
     */
    public function remark(Request $request, Response $response){

        $contract=Contract::getInstance()->getContract(
            ['type'=>Contract::CONSTRACT_TYPE_MESSAGE,'status'=>1],
            ['remark','detail_url']
        );

        $contract['detail_url']=Config::read('appwv_url') . "Contract5?id=";

        $response->setBody($this->formatData(['data'=>$contract]));
    }
}