<?php

namespace HttpApi\Controller\Action\Api\Wallet;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use HttpApi\Controller\ApiAuthAction;
use HttpApi\Model\User\User;
use HttpApi\Model\Wallet\Details;

class DetailsAction extends ApiAuthAction {
    public function execute(Request $request, Response $response) {
        $categorys = [ 
            1 => [ 
                'title' => '注册iVeryOne',
                'detail' => false 
            ],
            2 => [ 
                'title' => '邀请激励',
                'detail' => false 
            ],
            3 => [ 
                'title' => '关注',
                'detail' => false 
            ],
            4 => [ 
                'title' => '关注公众号',
                'detail' => false 
            ],
            5 => [ 
                'title' => '关注电邮',
                'detail' => false 
            ],
            6 => [ 
                'title' => [ 
                    '内容售出',
                    '购买付费' 
                ],
                'detail' => true 
            ],
            7 => [ 
                'title' => [ 
                    '转发分成',
                    '售出分成' 
                ],
                'detail' => true 
            ],
            8 => [ 
                'title' => '手续费',
                'detail' => false 
            ],
            9 => [ 
                'title' => '投放广告',
                'detail' => false 
            ],
            10 => [ 
                'title' => '查看广告',
                'detail' => false 
            ],
            11 => [ 
                'title' => '消费补贴发放',
                'detail' => false 
            ],
            12 => [ 
                'title' => '语音通话',
                'detail' => true 
            ],
            13 => [ 
                'title' => '聊天',
                'detail' => true 
            ],
            14 => [ 
                'title' => '视频通话',
                'detail' => true 
            ],
            15 => [ 
                'title' => '中止投放广告',
                'detail' => false 
            ],
            16 => [ 
                'title' => '活动奖励',
                'detail' => false 
            ],
            17 => [ 
                'title' => '预约游戏',
                'detail' => false 
            ],
            18 => [ 
                'title' => '游戏推广分成',
                'detail' => false 
            ],
            19 => [ 
                'title' => '游戏消费',
                'detail' => false 
            ],
            20 => [ 
                'title' => '游戏推广分成',
                'detail' => false 
            ],
            21 => [ 
                'title' => '清空补贴',
                'detail' => false 
            ],
            22 => [ 
                'title' => '转账',
                'detail' => true 
            ],
            23 => [ 
                'title' => '文章打赏',
                'detail' => true 
            ],
            24 => [ 
                'title' => '举报',
                'detail' => true 
            ],
            25 => [ 
                'title' => '申诉',
                'detail' => true 
            ],
            26 => [ 
                'title' => '人脸认证奖励',
                'detail' => true 
            ],
            27 => [ 
                'title' => '审核工资',
                'detail' => false 
            ],
            28 => [ 
                'title' => '举报失败',
                'detail' => true 
            ],
            29 => [ 
                'title' => '举报奖励',
                'detail' => true 
            ],
            30 => [ 
                'title' => '购买道具',
                'detail' => true 
            ],
            31 => [ 
                'title' => '道具销售分成',
                'detail' => true 
            ],
            32 => [ 
                'title' => '道具游戏厂商分成',
                'detail' => true 
            ] 
        ];
        
        $activity = [ 
            1 => 'bug、建议提交',
            2 => '母亲节活动奖励',
            3 => '群管奖励',
            4 => '星球提建议奖励',
            5 => '内容发布规则变更补贴',
            6 => [ 
                '活动奖励',
                '参加活动' 
            ],
            7 => '活动返还',
            8 => '活动奖励' 
        ];
        $auditor = [ 
            1 => '举报',
            2 => '申诉' 
        ];
        
        $lastid = intval ( $request->getArg ( 'lastid' ) );
        $userinfo = $request->getArg ( 'userinfo' );
        if ($lastid == 0) {
            User::getInstance ()->updateFields ( [ 
                'lastview_bill_timestamp' => TIMESTAMP 
            ], [ 
                'id' => $userinfo ['id'] 
            ] );
        }
        
        $params = [ 
            'recorder' => $request->getArg ( 'uid' ),
            'offset' => $lastid,
            'limit' => $request->getArg ( 'limit', 50 ) 
        ];
        if ($filter = $request->getArg ( 'filter' )) {
            switch ($filter) {
                case 2 :
                    $params ['direction'] = 'outlay';
                    break;
                case 1 :
                    $params ['direction'] = 'income';
                    break;
            }
        }
        if ($category = $request->getArg ( 'category' )) {
            $params ['category'] = $category;
        }
        $response->setBody ( $this->formatData ( [ 
            'data' => array_reduce ( Details::getInstance ()->query ( $params ), function ($details, $detail) use ($categorys, $activity, $auditor) {
                if ($detail ['receiver'] != 'system_token' && $detail ['receiver'] != 'system_balance') {
                    switch ($detail ['category']) {
                        case 16 :
                            switch (intval ( $detail ['uniqid'] )) {
                                case 6 :
                                    array_push ( $details, [ 
                                        'id' => $detail ['id'],
                                        'timestamp' => $detail ['create_timestamp'],
                                        'amount' => $detail ['amount'],
                                        'category' => $activity [6] [intval ( $detail ['amount'] < 0 )],
                                        'detail' => $categorys [$detail ['category']] ['detail'] 
                                    ] );
                                    break;
                                case 7 :
                                    array_push ( $details, [ 
                                        'id' => $detail ['id'],
                                        'timestamp' => $detail ['create_timestamp'],
                                        'amount' => $detail ['amount'],
                                        'category' => $activity [7],
                                        'detail' => $categorys [$detail ['category']] ['detail'] 
                                    ] );
                                    break;
                                case 8 :
                                    array_push ( $details, [ 
                                        'id' => $detail ['id'],
                                        'timestamp' => $detail ['create_timestamp'],
                                        'amount' => $detail ['amount'],
                                        'category' => $activity [8],
                                        'detail' => $categorys [$detail ['category']] ['detail'] 
                                    ] );
                                    break;
                                default :
                                    array_push ( $details, [ 
                                        'id' => $detail ['id'],
                                        'timestamp' => $detail ['create_timestamp'],
                                        'amount' => $detail ['amount'],
                                        'category' => $categorys [$detail ['category']] ['title'] . ' - ' . $activity [intval ( $detail ['uniqid'] )],
                                        'detail' => $categorys [$detail ['category']] ['detail'] 
                                    ] );
                            }
                            break;
                        case 27 :
                            array_push ( $details, [ 
                                'id' => $detail ['id'],
                                'timestamp' => $detail ['create_timestamp'],
                                'amount' => $detail ['amount'],
                                'category' => $categorys [$detail ['category']] ['title'] . ' - ' . $auditor [intval ( $detail ['uniqid'] )],
                                'detail' => $categorys [$detail ['category']] ['detail'] 
                            ] );
                            break;
                        default :
                            array_push ( $details, [ 
                                'id' => $detail ['id'],
                                'timestamp' => $detail ['create_timestamp'],
                                'amount' => $detail ['amount'],
                                'category' => is_array ( $categorys [$detail ['category']] ['title'] ) ? $categorys [$detail ['category']] ['title'] [intval ( $detail ['amount'] < 0 )] : $categorys [$detail ['category']] ['title'],
                                'detail' => $categorys [$detail ['category']] ['detail'] 
                            ] );
                    }
                }
                return $details;
            }, [ ] ) 
        ] ) );
    }
}