<?php

namespace HttpApi\Controller\Action\Api\Wallet;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\Config;
use HttpApi\Model\Battery;
use HttpApi\Model\Wallet\Balance;
use HttpApi\Model\Wallet\Details;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class GetInfoAction extends \HttpApi\Controller\ApiAuthAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     */
    public function execute(Request $request, Response $response)
    {
        $device_platform = $request->getArg('device_platform');
        $data['data']['userinfo'] = $request->getArg('userinfo');
        $data['data']['wallet'] = $request->getArg('wallet');
        $data['data']['battery'] = $request->getArg('battery');
        $data['data']['next_recharge'] = "";
        $data['data']['telegram_url'] = "https://t.me/iVeryone";
        $data['data']['wechat_qrcode'] = "http://avatar.ivery.one/qrcode_for_gh_67e706b2fc67_258.jpg";
        $data['data']['batterywidth'] = "1px";
        $data['data']['battery_expired'] = $request->getArg('battery_expired');
        $data['data']['freeze_onlinetime'] = Config::read('freeze_onlinetime');
        $data['data']['freeze_notice'] = "";
        $data['data']['lock_notice'] = "";
        if($data['data']['wallet']['status'] > 0 && $data['data']['userinfo']['create_timestamp'] > $data['data']['freeze_onlinetime']) {
            $data['data']['lock_notice'] = '注册奖励50VRY,将在完成账号验证后发放';
        } else if ($data['data']['wallet']['status'] > 0) {
            $data['data']['lock_notice'] = '请先完成账户验证，激活VRY使用';
        } else if ($data['data']['wallet']['freeze'] > 0) {
            $data['data']['freeze_notice'] = '锁定余额：'. $data['data']['wallet']['freeze'] . 'VRY';
        }

        if($data['data']['battery_expired']) {
            $data['data']['next_recharge'] = "00:00:00";
        } else if($data['data']['wallet']['token'] < $data['data']['battery']['capacity']) {
            $count_down = 3600 - (TIMESTAMP - $data['data']['battery']['last_charge_timestamp']);
            $minutes = sprintf("%02d", floor($count_down/60));
            $seconds = sprintf("%02d", $count_down%60);
            if($minutes == 60) {
                $minutes = 59;
                $seconds = 59;
            }
            $data['data']['next_recharge'] = "00:" . $minutes . ":" . $seconds;
            $data['data']['batterywidth'] = ceil(($data['data']['wallet']['token']/$data['data']['battery']['capacity'])*115) . "px";
        }

        if(in_array($device_platform, ['ios', 'android'])) {
            $data['data']['wallet']['balance'] = strval($data['data']['wallet']['balance']);
            $data['data']['wallet']['token'] = strval($data['data']['wallet']['token']);
            $data['data']['wallet']['freeze'] = strval($data['data']['wallet']['freeze']);
        }
        //校验权限
        $data['data']['wallet']['transferPrivillege'] = 0;
        $rss = Details::getInstance()->getOne()->selectOne('users_tasks','*',['uid'=>$data['data']['userinfo']['id'],'status'=>3,'tid'=>15])['data'];
        if($data['data']['wallet']['transfer']== 1 && $rss && $rss['confirm_timestamp']){
            $day = 24 * 60 * 60;

            $timestamp = $rss['confirm_timestamp'];
            $timestamp = date("Y-m-d",$timestamp);
            $h = strtotime(date("Y-m-d")) - strtotime($timestamp);
            $data['data']['wallet']['confirmDate'] = date("Y-m-d",$rss['confirm_timestamp']);
            $data['data']['wallet']['transferDate'] = date("m月d日",$rss['confirm_timestamp']+$day);
            if($h > $day){
                $data['data']['wallet']['transferPrivillege'] = 1;
            }elseif($h == $day && date("H")>=12){
                $data['data']['wallet']['transferPrivillege'] = 1;
            }
        } 
        // 如果为空，重新设置默认值
        $data['data']['userinfo']['ad_feed_minimal']==='' && $data['data']['userinfo']['ad_feed_minimal']=0.01;
        $data['data']['userinfo']['ad_follow_minimal']==='' && $data['data']['userinfo']['ad_follow_minimal']=0.01;

        $response->setBody($this->formatData($data));
    }
}