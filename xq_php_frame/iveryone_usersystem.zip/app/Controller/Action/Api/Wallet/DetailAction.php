<?php

namespace HttpApi\Controller\Action\Api\Wallet;

use HttpApi\Controller\ApiAuthAction;
use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Model\Wallet\Details;
use HttpApi\Tool\iVeryOneApi;
use HttpApi\Model\User\User;

class DetailAction extends ApiAuthAction {
    public function execute(Request $request, Response $response) {
        $data ['data'] = [ ];
        $detail = Details::getInstance ()->query ( [ 
            'recorder' => $request->getArg ( 'uid' ),
            'id' => array_unique ( $request->getArg ( 'id' ) ),
            'limit' => count ( $request->getArg ( 'id' ) ) * 3,
            'category' => [ 
                6,
                7,
                12,
                13,
                14,
                22,
                23,
                24,
                25,
                26,
                28,
                29,
                30,
                31,
                32 
            ] 
        ] );
        // 文章处理逻辑
        $id = array_reduce ( $detail, function ($sum, $item) {
            if (in_array ( $item ['category'], [ 
                6,
                7,
                23 
            ] )) {
                $sum [$item ['id']] = intval ( $item ['uniqid'] );
            }
            return $sum;
        }, [ ] );
        // 申诉处理逻辑
        $appeal = array_reduce ( $detail, function ($sum, $item) {
            if (in_array ( $item ['category'], [ 
                25 
            ] )) {
                $sum [$item ['id']] = intval ( $item ['uniqid'] );
            }
            return $sum;
        }, [ ] );
        
        if (! empty ( $appeal )) {
            $feedback = array_reduce ( iVeryOneApi::Request ( 'Intra/Feedback/Appeal', [ 
                'id' => array_unique ( array_values ( $appeal ) ) 
            ] ) ['data'], function ($sum, $item) use ($appeal) {
                foreach ( $appeal as $k => $v ) {
                    if ($item ['id'] == $v) {
                        $sum [$k] = $item ['tid'];
                    }
                }
                return $sum;
            }, [ ] );
        }
        // 举报处理逻辑
        $feedback = array_reduce ( $detail, function ($sum, $item) {
            if (in_array ( $item ['category'], [ 
                24,
                28,
                29 
            ] )) {
                $sum [$item ['id']] = intval ( $item ['uniqid'] );
            }
            return $sum;
        }, $feedback ?? [ ]);
        
        if ($feedback) {
            $id = array_reduce ( iVeryOneApi::Request ( 'Intra/Feedback/Feedback', [ 
                'id' => array_unique ( array_values ( $feedback ) ) 
            ] ) ['data'], function ($sum, $item) use ($feedback) {
                foreach ( $feedback as $k => $v ) {
                    if ($v == $item ['id']) {
                        $sum [$k] = $item ['tid'];
                    }
                }
                return $sum;
            }, $id );
        }
        
        if (! empty ( $id )) {
            $result = iVeryOneApi::Request ( 'Intra/Thread/Detail', [ 
                'id' => array_unique ( array_values ( $id ) ) 
            ] );
            if ($result ['errno']) {
                throw new Exception ( $result ['errmsg'], $result ['errno'] );
            } else {
                foreach ( $id as $k => $v ) {
                    array_push ( $data ['data'], [ 
                        'id' => $k,
                        'title' => $result ['data'] [$v] ?? ''
                    ] );
                }
            }
        }
        // 转账处理逻辑
        $id = array_reduce ( $detail, function ($sum, $item) {
            if (in_array ( $item ['category'], [ 
                22,
                12,
                13,
                14 
            ] )) {
                $sum [$item ['id']] = [ 
                    'receiver' => $item ['receiver'],
                    'category' => $item ['category'] 
                ];
            }
            return $sum;
        }, [ ] );
        if (! empty ( $id )) {
            $result = User::getInstance ()->getUserinfoByUids ( array_column ( $id, 'receiver' ) );
            if (! empty ( $result )) {
                foreach ( $result as $user ) {
                    foreach ( $id as $k => $v ) {
                        if ($v ['receiver'] == $user ['id']) {
                            if ($v ['category'] == 22) {
                                array_push ( $data ['data'], [ 
                                    'id' => $k,
                                    'title' => "ID:{$v['receiver']} - {$user['nickname']}" 
                                ] );
                            } else {
                                array_push ( $data ['data'], [ 
                                    'id' => $k,
                                    'title' => $user ['nickname'] 
                                ] );
                            }
                            unset ( $id [$k] );
                        }
                    }
                }
            }
            foreach ( $id as $k => $v ) {
                array_push ( $data ['data'], [ 
                    'id' => $k,
                    'title' => "ID:{$v}" 
                ] );
            }
        }
        
        // 道具处理逻辑
        $assets = array_reduce ( $detail, function ($sum, $item) {
            if (in_array ( $item ['category'], [ 
                30,
                31,
                32 
            ] )) {
                $sum [$item ['id']] = intval ( $item ['uniqid'] );
            }
            return $sum;
        }, $assets ?? [ ]);
        
        if ($assets) {
            $result = iVeryOneApi::Request ( 'Intra/Assets/Query', [ 
                'id' => array_unique ( array_values ( $assets ) ) 
            ] );
            if ($result ['errno']) {
                throw new Exception ( $result ['errmsg'], $result ['errno'] );
            } else {
                foreach ( $assets as $k => $v ) {
                    array_push ( $data ['data'], [ 
                        'id' => $k,
                        'title' => $result ['data'] [$v] ?? ''
                    ] );
                }
            }
        }
        $response->setBody ( $this->formatData ( $data ) );
    }
}