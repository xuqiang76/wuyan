<?php

namespace HttpApi\Controller\Action\Api\Shadow;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Controller\ApiQueryAuthAction;
use HttpApi\Model\Ad;
use HttpApi\Tool\BehaviorLogs;

class QueryAction extends ApiQueryAuthAction {
	/**
	 *
	 * @param Request $request
	 * @param Response $response
	 * @throws \Beahoo\Exception
	 */
	public function execute(Request $request, Response $response) {
		$userinfo = $request->getArg('userinfo');
		$adtype = $request->getArg('type', 'follow');
		$wallet = $request->getArg('wallet');

		$re_data = Ad::getInstance()->query_adsense([
			'userinfo' => $userinfo,
			'limit' => $request->getArg('limit') > 3 ? 3 : $request->getArg('limit'),
			'type' => $adtype,
			'privilege' => $wallet['status'],
		]);

		if (!$re_data) {
			//空内容
			throw new Exception('', 4000);
		}

		$data = [
			'data' => $re_data,
		];
		if (!empty($data['data'])) {
			BehaviorLogs::addLogs($request->getArg('uid'), BehaviorLogs::ACT_WATCHAD, [
				'type' => 1,
			], 'watch advertise');
		}

		$response->setBody($this->formatData($data));
	}
}