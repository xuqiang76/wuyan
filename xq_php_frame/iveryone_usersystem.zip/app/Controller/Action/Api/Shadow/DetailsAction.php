<?php

namespace HttpApi\Controller\Action\Api\Shadow;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use HttpApi\Controller\ApiAuthAction;
use HttpApi\Model\Ad;

class DetailsAction extends ApiAuthAction {
	/**
	 *
	 * @param Request $request
	 * @param Response $response
	 * @throws \Beahoo\Exception
	 */
	public function execute(Request $request, Response $response) {
		$uid = $request->getArg('uid');
		$lastid = $request->getArg('lastid', 0);

		$list = Ad::getInstance()->details([
			'uid' => $uid,
			'lastid' => $lastid,
		]);

		$data['data']['list'] = $list;
		$response->setBody($this->formatData($data));
	}
}