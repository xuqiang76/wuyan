<?php

namespace HttpApi\Controller\Action\Api\Task;

use HttpApi\Controller\ApiAuthAction;
use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use HttpApi\Model\TaskPool\Task;

class QueryAction extends ApiAuthAction {
    /**
     *
     * @param Request $request
     * @param Response $response
     * @throws \Beahoo\Exception
     */
    public function execute(Request $request, Response $response) {
        $response->setBody ( $this->formatData ( [ 
            'data' => [ 
                'task' => Task::getInstance()->process($request->getArg ( 'userinfo' ) ['id']),
                'list' => Task::getInstance()->query_user_tasks($request->getArg ( 'userinfo' ))
            ] 
        ] ) );
    }
}