<?php

namespace HttpApi\Controller\Action\Api\Task;

use HttpApi\Controller\ApiAuthAction;
use Beahoo\Controller\Request;
use Beahoo\Controller\Response;

class ListAction extends ApiAuthAction {
    /**
     *
     * @param Request $request
     * @param Response $response
     * @throws \Beahoo\Exception
     */
    public function execute(Request $request, Response $response) {
        $response->setBody ( $this->formatData ( [ 
            'data' => [ 
                [ 
                    'id' => "2608761",
                    'status' => "1",
                    'task' => "AuthorReward",
                    'title' => "新手礼包",
                    'icon' => 'http://www.baidu.com',
                    'app_webview_url' => '' 
                ],
                [ 
                    'id' => "2608761",
                    'status' => "2",
                    'task' => "AuthorReward",
                    'title' => "Pressone",
                    'icon' => 'http://www.baidu.com',
                    'app_webview_url' => '' 
                ],
                [ 
                    'id' => "2608761",
                    'status' => "3",
                    'task' => "VPoint",
                    'title' => "V点",
                    'icon' => 'http://www.baidu.com',
                    'app_webview_url' => '' 
                ] 
            ] 
        ] ) );
    }
}