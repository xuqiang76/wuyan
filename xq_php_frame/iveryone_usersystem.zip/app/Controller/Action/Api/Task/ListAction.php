<?php

namespace HttpApi\Controller\Action\Api\Task;

use HttpApi\Controller\ApiAuthAction;
use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use HttpApi\Model\TaskPool\Task;
use Beahoo\Tool\Config;
use HttpApi\Model\TaskPool\TaskBase;
use Beahoo\Tool\ArrayTool;

class ListAction extends ApiAuthAction {
    /**
     *
     * @param Request $request
     * @param Response $response
     * @throws \Beahoo\Exception
     */
    public function execute(Request $request, Response $response) {
        $list = array_map ( function ($item) {
            preg_match ( '/([a-z0-9]*?)task$/i', $item ['script'], $script );
            $item ['script'] = $script [1];
            return $item;
        }, Task::getInstance ()->init () [0] ['slave'] );
        usort ( $list, function ($prev, $next) {
            return $prev ['weight'] <=> $next ['weight'];
        } );
        $user_task = TaskBase::getInstance ()->query_user_tasks ( [ 
            'uid' => $request->getArg ( 'uid' ),
            'script' => array_column ( $list, 'script' ) 
        ] ) ['data'];
        $user_task = ArrayTool::list2Map ( $user_task, 'script' );
        
        $tasks = [ ];
        
        while ( $task = array_pop ( $list ) ) {
            switch ($task ['script']) {
                case 'NewGift' :
                    if ($request->getArg ( 'userinfo' ) ['create_timestamp'] + 86400 >= TIMESTAMP) {
                        $utask = TaskBase::getInstance ()->query_user_tasks ( [ 
                            'uid' => $request->getArg ( 'uid' ),
                            'script' => 'ReceiveGift' 
                        ] ) ['data'] [0] ?? [ ];
                    } else {
                        $utask = TaskBase::getInstance ()->query_user_tasks ( [ 
                            'uid' => $request->getArg ( 'uid' ),
                            'script' => 'NoviceGift' 
                        ] ) ['data'] [0] ?? [ ];
                    }
                    $task = [ 
                        'id' => $utask ['id'] ?? 0,
                        'status' => $utask ['status'] ?? 1,
                        'task' => $utask ['script'],
                        'title' => $task ['name'],
                        'icon' => $task ['icon'],
                        'icon_active' => $task ['icon_active'],
                        'app_webview_url' => Config::read ( 'appwv_url' ) . $task ['url'],
                        'router' => $task ['url'] 
                    ];
                    break;
                default :
                    $task = [ 
                        'id' => $user_task [$task ['script']] ['id'] ?? 0,
                        'status' => $user_task [$task ['script']] ['status'] ?? 1,
                        'task' => $task ['script'],
                        'title' => $task ['name'],
                        'icon' => $task ['icon'],
                        'icon_active' => $task ['icon_active'],
                        'app_webview_url' => Config::read ( 'appwv_url' ) . $task ['url'],
                        'router' => $task ['url'] 
                    ];
            }
            
            $task ['status'] == 3 ? array_push ( $tasks, $task ) : array_unshift ( $tasks, $task );
        }
        
        $response->setBody ( $this->formatData ( [ 
            'data' => $tasks 
        ] ) );
    }
}