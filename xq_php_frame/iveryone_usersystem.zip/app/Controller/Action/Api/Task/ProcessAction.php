<?php

namespace HttpApi\Controller\Action\Api\Task;

use HttpApi\Controller\ApiAuthAction;
use Beahoo\Controller\Request;
use Beahoo\Controller\Response;

class ProcessAction extends ApiAuthAction {
    public function execute(Request $request, Response $response) {
        $task = 'HttpApi\\Model\\TaskPool\\' . $request->getArg ( 'task' ) . 'Task';
        $response->setBody ( $this->formatData ( [ 
            'data' => [ 
                'task' => $task::getInstance ()->status ( $request->getArg ( 'uid' ), $request->getArg ( 'tid' ) ) 
            ] 
        ] ) );
    }
}