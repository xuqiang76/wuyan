<?php

namespace HttpApi\Controller\Action\Api\Task;

use Beahoo\Exception;
use HttpApi\Controller\ApiAuthAction;
use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use HttpApi\Model\TaskPool\Task;

class ReceiveAction extends ApiAuthAction {
    /**
     *
     * @param Request $request
     * @param Response $response
     * @throws \Beahoo\Exception
     */
    public function execute(Request $request, Response $response) {
        $wallet = $request->getArg('wallet');
        if($wallet['status'] != 0) {
            throw new Exception("", $wallet['status']);
        }
        $response->setBody ( $this->formatData ( [ 
            'data' => [ 
                'reward' => Task::getInstance ()->receive ( [ 
                    'id' => $request->getArg ( 'id' ),
                    'uid' => $request->getArg ( 'uid' ) 
                ] ) 
            ] 
        ] ) );
    }
}