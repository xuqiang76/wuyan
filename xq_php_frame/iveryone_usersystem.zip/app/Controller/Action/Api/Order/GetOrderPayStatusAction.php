<?php
/**
 * Created by PhpStorm.
 * User: zhangyuanhao
 * Date: 2018/6/20
 * Time: 20:06
 */

namespace HttpApi\Controller\Action\Api\Order;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\Config;

use HttpApi\Model\Orders\Orders;

class GetOrderPayStatusAction extends \HttpApi\Controller\ApiAuthAction
{
    public function execute(Request $request, Response $response)
    {
        $tradeNoId = $request->getArg('trade_no_id');

        $orderInfo = Orders::getInstance()->getOrderInfoByTradeNo($tradeNoId);

        if(!$orderInfo) {
            throw new Exception("订单不存在", 4415);
        }

        $returnData = [
            'status' => $orderInfo['status'] == 3 ? 'pay_success' : 'not_pay'
        ];
        $response->setBody($this->formatData(['data' => $returnData]));
    }
}