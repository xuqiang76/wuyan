<?php
/**
 * Created by PhpStorm.
 * User: zhangyuanhao
 * Date: 2018/6/20
 * Time: 14:26
 */

namespace HttpApi\Controller\Action\Api\Order;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\Config;
use HttpApi\Model\Orders\Orders;

class UpdateOrderAction extends \HttpApi\Controller\ApiAuthAction
{
    public function execute(Request $request, Response $response)
    {
        $tradeNoId = $request->getArg('trade_no_id');

        $status = $request->getArg('status');

        // 获取订单ID
        $orderInfo = Orders::getInstance()->getOrderInfoByTradeNo($tradeNoId);

        if(!$orderInfo)
            throw new Exception('订单不存在', 4416);

        if($orderInfo['status'] == 1) {
            if($status == 'success') {
                Orders::getInstance()->updateOrderStatus($tradeNoId, 2);
            } else {
                Orders::getInstance()->updateOrderStatus($tradeNoId, 4);
            }
        }
        $response->setBody($this->formatData(['data' => ['status' => 1]]));
    }
}