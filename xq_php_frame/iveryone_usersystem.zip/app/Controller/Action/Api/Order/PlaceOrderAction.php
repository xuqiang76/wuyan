<?php
/**
 * Created by PhpStorm.
 * User: zhangyuanhao
 * Date: 2018/6/20
 * Time: 10:34
 */

namespace HttpApi\Controller\Action\Api\Order;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\Config;
use HttpApi\Model\Goods\Goods;
use HttpApi\Model\Orders\Orders;

require_once ROOT . DS . 'libs/alipay/aop/AopClient.php';
require_once ROOT . DS . 'libs/alipay/aop/request/AlipayTradeAppPayRequest.php';

class PlaceOrderAction extends \HttpApi\Controller\ApiAuthAction
{
    public function execute(Request $request, Response $response)
    {
        $device_platform = $request->getArg('device_platform');
        $goodsId = $request->getArg('goods_id');
        $uid = $request->getArg('uid');
        $payType = $request->getArg('pay_type');

        // 获取商品详情
        $goodsInfo = Goods::getInstance()->getGoodsInfo($goodsId);
        if(!$goodsInfo) {
            throw new Exception('没有此商品', 4415);
        }

        $ortherData = [
            'order_title' => $goodsInfo['goods_title']. ' - ' .$goodsInfo['goods_desc'],
            'goods_id'    => $goodsInfo['goods_id'],
            'platform'    => $device_platform == 'ios' ? 1 : 2,
            'pay_type'    => $payType,
        ];
        // 生成订单
        $orderId = Orders::getInstance()->placeOrder($uid, $goodsInfo['amount'], $ortherData);

        $orderInfo = Orders::getInstance()->getOrderInfo($orderId);

        $returnData = [
            "trade_no_id" => $orderInfo['trade_no_id'],
            "alipay_string" => ""
        ];

        if($payType == 1) {
            $content = [
                "body" => $orderInfo['order_title'],
                "subject" => $orderInfo['order_title'] .' - '.$orderInfo['trade_no_id'],
                "out_trade_no" => $orderInfo['trade_no_id'],
                "total_amount" => $orderInfo['amount'],
                "product_code" => "QUICK_MSECURITY_PAY",
                "timeout_express" => "5m"
            ];
            $returnData['alipay_string'] = $this->alipay($content);
        }

        $response->setBody($this->formatData(['data' => $returnData]));
    }

    /**
     * 支付宝支付
     */
    public function alipay($content)
    {
        $config = Config::read('iVeryOne_Alipay');
        $aop = new \AopClient();
        $aop->gatewayUrl = $config['gatewayUrl'];
        $aop->appId = $config['app_id'];
        $aop->rsaPrivateKey = $config['merchant_private_key'];
        $aop->format = "json";
        $aop->charset = $config['charset'];
        $aop->signType = $config['sign_type'];
        $aop->alipayrsaPublicKey = $config['alipay_public_key'];


        $request = new \AlipayTradeAppPayRequest();
        //SDK已经封装掉了公共参数，这里只需要传入业务参数
        $bizcontent = json_encode($content);
        $request->setNotifyUrl(BASE_URL . "Order/Alipay/PayNotify");
        $request->setBizContent($bizcontent);
        //这里和普通的接口调用不同，使用的是sdkExecute
        $response = $aop->sdkExecute($request);

        //htmlspecialchars是为了输出到页面时防止被浏览器将关键参数html转义，实际打印到日志以及http传输不会有这个问题
        return $response;
//        return htmlspecialchars($response);//就是orderString 可以直接给客户端请求，无需再做处理。
    }
}