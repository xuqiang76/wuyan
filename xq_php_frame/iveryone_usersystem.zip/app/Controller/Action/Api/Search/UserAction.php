<?php

namespace HttpApi\Controller\Action\Api\Search;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use HttpApi\Model\Contacts;
use HttpApi\Model\User\User;
use HttpApi\Controller\ApiAuthAction;
use Beahoo\Exception;

/**
 *
 * @package \HttpApi\Controller\Action\Api\User
 */
class UserAction extends ApiAuthAction {
    
    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     * @throws Exception
     */
    public function execute(Request $request, Response $response) {
        $userinfo = $request->getArg ( 'userinfo' );
        $kw = $request->getArg ( 'kw' );

        if(empty($kw)) {
            throw new Exception("", 1001);
        }

        $data['data'] = [];
        if(is_numeric($kw)) {
            $searchinfo = User::getInstance ()->getUserinfoByUid ( $kw );
            if(!empty($searchinfo)) {
                $contactInfo = Contacts::getInstance ()->getContact ( $userinfo ['id'], $searchinfo['id'] );
                $oppositeContactInfo = Contacts::getInstance ()->getContact ( $searchinfo['id'], $userinfo ['id'] );

                $data ['data']['list'][] = [
                    'userinfo' => $searchinfo,
                    'contact_status' => Contacts::getContactStatus($contactInfo, $oppositeContactInfo)
                ];
            }
        }

        $searchinfo = User::getInstance ()->getUserinfoByNickname( $kw );
        if(!empty($searchinfo)) {
            $contactInfo = Contacts::getInstance ()->getContact ( $userinfo ['id'], $searchinfo['id'] );
            $oppositeContactInfo = Contacts::getInstance ()->getContact ( $searchinfo['id'], $userinfo ['id'] );

            $data ['data']['list'][] = [
                'userinfo' => $searchinfo,
                'contact_status' => Contacts::getContactStatus($contactInfo, $oppositeContactInfo)
            ];
        }

        $response->setBody ( $this->formatData ( $data ) );
    }

    /**
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     * @throws Exception
     */
    public function contacts(Request $request, Response $response)
    {
        $userinfo = $request->getArg ( 'userinfo' );
        $kw = strip_tags($request->getArg ( 'kw' ));
        $start = $request->getArg('start', 0);
        $limit = $request->getArg('limit', 50);

        $db = Contacts::getInstance()->getDb();

        $sql = "SELECT count(*) as num FROM userinfo u LEFT JOIN contacts c ON u.id = c.contact_uid
                WHERE c.uid = " . $userinfo['id'] . " AND c.contact_status = 1 AND u.nickname LIKE '%".$kw."%'";
        $query = $db->query($sql);
        $res = $query->fetch(\PDO::FETCH_ASSOC);
        $number1 = $res['num'];

        $userinfos = [];
        if($start < $number1) {
            $sql = "SELECT u.* FROM userinfo u LEFT JOIN contacts c ON u.id = c.contact_uid WHERE c.uid = " . $userinfo['id'] . " 
                    AND c.contact_status = 1 AND u.nickname LIKE '%".$kw."%' LIMIT " . $start . "," . $limit;
            $query = $db->query($sql);
            $userinfos = $query->fetchAll(\PDO::FETCH_ASSOC);

            $start = 0;
        } else {
            $start = $start - $number1;
        }

        if(count($userinfos) < $limit) {
            $sql = "SELECT u.* FROM userinfo u LEFT JOIN contacts c ON u.id = c.uid WHERE c.contact_uid = " . $userinfo['id'] . " 
                    AND c.contact_status = 1 AND c.bilateral = 0 AND u.nickname LIKE '%".$kw."%' LIMIT " . $start . "," . ($limit - count($userinfos));
            $query = $db->query($sql);
            $userinfos = array_merge($userinfos, $query->fetchAll(\PDO::FETCH_ASSOC));
        }

        $list = [];
        foreach ($userinfos as $item) {
            $list[] = [
                'userinfo' => $item
            ];
        }

        $data['data']['list'] = $list;

        $response->setBody ( $this->formatData ( $data ) );
    }
}