<?php

namespace HttpApi\Controller\Action\Api\Password;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Model\User\User;

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class ResetAction extends \HttpApi\Controller\ApiAuthAction
{

    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     * @throws Exception
     * @throws \Exception
     */
    public function execute(Request $request, Response $response)
    {
        $uid = $request->getArg('uid');
        $old_password = urldecode($request->getArg('old_password'));
        $new_password = urldecode($request->getArg('new_password'));
        $new_password_repeat = urldecode($request->getArg('new_password_repeat'));

        if (empty($old_password) || empty($new_password) || empty($new_password_repeat)) throw new Exception("", 1001);

        if($new_password!==$new_password_repeat) throw new Exception('密码不一致',1);
        // 6-12位
        if(strlen($new_password)<6 || strlen($new_password)>12) throw new Exception('密码长度为6-12位', 1);

        // 至少包含数字/字母/字符两种
        if(preg_match('/^\d+$/', $new_password) || preg_match('/^[a-zA-Z]+$/', $new_password) || preg_match('/^[^\da-zA-Z]+$/',$new_password)) 
            throw new Exception('密码至少包含字母/数字/字符两种组合', 1);

        // 校验旧密码正确性
        try {
            User::getInstance ()->checkpassword($uid, $old_password);
        } catch ( Exception $e) {
            if($e->getCode() == 2002){
                throw new Exception('', 2019);
            } else {
                throw new Exception($e->getMessage(), $e->getCode());
            }
        }

        $salt=uniqid('',false);

        $password=md5(md5($new_password).$salt);

        try{
            User::getInstance()->updateFields([
                'salt' => $salt,
                'password' => $password,
            ], ['id' => $uid]);
        }catch(Exception $e){

            throw new Exception('系统异常,请重试',1);
        }

        $response->setBody($this->formatData([]));
    }
}