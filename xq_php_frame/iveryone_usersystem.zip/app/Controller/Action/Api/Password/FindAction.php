<?php

namespace HttpApi\Controller\Action\Api\Password;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use HttpApi\Model\User\User;
use HttpApi\Tool\Team;
use HttpApi\Tool\SDKs;

require_once "/download/WuyanLibs/sms/SMS.php";

/**
 * @package \HttpApi\Controller\Action\Api\User
 */
class FindAction extends \HttpApi\Controller\ApiAuthAction
{

    /**
     * 重置密码的校验key
     * @var string
     */
    private $prefix_reset_password_key_string='reset_password_key_';

    public function execute(Request $request, Response $response)
    {
        
    }
    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request\HttpRequest $request
     * @param \HttpApi\Controller\Response\HttpResponse $response
     *
     * @result void
     * @throws Exception
     * @throws \Exception
     */
    public function newpwd(Request $request, Response $response)
    {
        $uid = $request->getArg('uid');
        $key = $request->getArg('key');
        $new_password = urldecode($request->getArg('new_password'));
        $new_password_repeat = urldecode($request->getArg('new_password_repeat'));
        $device_platform = $request->getArg('device_platform');

        if (empty($key) || empty($new_password) || empty($new_password_repeat)) throw new Exception("", 1001);

        if($new_password!==$new_password_repeat) throw new Exception('密码不一致',1);
        // 6-12位
        if(strlen($new_password)<6 || strlen($new_password)>12) throw new Exception('密码长度为6-12位', 1);

        // 至少包含数字/字母/字符两种
        if(preg_match('/^\d+$/', $new_password) || preg_match('/^[a-zA-Z]+$/', $new_password) || preg_match('/^[^\da-zA-Z]+$/',$new_password)) 
            throw new Exception('密码至少包含字母/数字/字符两种组合', 1);

        $redis=SDKs::getRedis();

        $key_string=$this->prefix_reset_password_key_string.$uid;

        $saved_key=$redis->get($key_string);

        if($saved_key!=$key) throw new Exception('验证超时,请返回重试', 1);

        $salt=uniqid('',false);

        $password=md5(md5($new_password) . $salt);

        try{

            User::getInstance()->updateFields([
                'salt' => $salt,
                'password' => $password,
            ], ['id' => $uid]);
        }catch(Exception $e){

            throw new Exception('系统异常,请重试',1);
        }

        $redis->del($key_string);

        $response->setBody($this->formatData([]));
    }

    /**
     * 校验短信验证码
     * @param  Request  $request  
     * @param  Response $response 
     * @return 
     */
    public function checkCode(Request $request, Response $response){

        $uid = $request->getArg('uid');
        $code = $request->getArg('code');

        $userinfo = User::getInstance()->getNoCacheUserInfo($uid, ['password', 'pay_password', 'salt']);
        $transPhoneInfo = Team::transformPhoneNum($userinfo['country_code'], $userinfo['phone']);

        if(empty($code) || empty($userinfo)) throw new Exception('', 1001);
        // 校验短信验证码为6位数
        if (!is_numeric($code) && strlen($code) != 6) throw new Exception("", 2011);

        $res = \SMS::verifyCaptcha([
            'country_code' => $transPhoneInfo[0],
            'tel' => $transPhoneInfo[1],
            'template_code' => 4,
            'msg' => $code,
            'doexpire' => 1
        ]);
        
        if ($res['code'] != 0) {
            if(!in_array(RUN_ENV, ['test', 'development','local'])) {
                throw new Exception($res['msg'], 2011);
            }
        }

        $random_key=uniqid('FP');
        // 设置的校验字符串
        SDKs::getRedis()->setex($this->prefix_reset_password_key_string.$uid,180,$random_key);

        $response->setBody($this->formatData(['data'=>['key'=>$random_key]]));
    }

    /**
     * 找回密码之发送短信验证码
     * @param  Request  $request  
     * @param  Response $response 
     * @return 
     */
    public function sendSms(Request $request, Response $response){

        $uid = $request->getArg('uid');
        $userinfo = User::getInstance()->getNoCacheUserInfo($uid, ['password', 'pay_password', 'salt']);
        $transPhoneInfo = Team::transformPhoneNum($userinfo['country_code'], $userinfo['phone']);

        $params = [
            'country_code' => $transPhoneInfo[0],
            'tel' => $transPhoneInfo[1],
            'template_code' => 4,
            'product_name' => "iVeryOne社区",
            'risk' => 0
        ];
        
        $res = \SMS::sendCaptcha($params);
        
        if ($res['code'] != 0) {
            if (!in_array(RUN_ENV, ['test', 'development','local'])) {
                throw new Exception($res['msg'], 2008);
            }
        }

        $response->setBody($this->formatData([]));
    }
}