<?php
/**
 * Created by PhpStorm.
 * User: zhangyuanhao
 * Date: 2018/6/20
 * Time: 10:09
 */

namespace HttpApi\Controller\Action\Api\Goods;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Exception;
use Beahoo\Tool\Config;

use HttpApi\Model\Goods\Goods;

class GetGoodsListAction extends \HttpApi\Controller\ApiAuthAction
{

    public function execute(Request $request, Response $response)
    {
        $data['data'] = Goods::getInstance()->getGoodsList(false);
        $response->setBody($this->formatData($data));
    }

}