<?php
namespace HttpApi\Controller;
use Beahoo\Controller\ApiActionTrait;

/**
 * 所有不需要验证相关Action的父类
 *
 * @package HttpApi\Controller
 * @property \HttpApi\Controller\Decorator\ErrorDecorator $error
 * @property \HttpApi\Controller\Decorator\SignDecorator $sign
 * @property \HttpApi\Controller\Decorator\AuthDecorator $auth
 */
abstract class ApiAuthAction extends \Beahoo\Controller\Action {
	use ApiActionTrait;

	protected $decorators = array(
		'HttpApi\Controller\Decorator\ErrorDecorator' => 'error',
		'HttpApi\Controller\Decorator\BusErrorDecorator' => 'buserror',
		'HttpApi\Controller\Decorator\InputDecorator' => 'input',
		'HttpApi\Controller\Decorator\AuthDecorator' => 'auth',
	);

	public $no_wallet_status_check = false;
}
