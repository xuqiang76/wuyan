<?php

namespace HttpApi\Controller\Response;

use HttpApi\Encrypt\Des;
use HttpApi\Tool\Log;

class HttpResponse extends \Beahoo\Controller\Response\HttpResponse
{
    private $deskey;

    public function setDesKey($deskey)
    {
        $this->deskey = $deskey;
    }

    public function send()
    {
        $this->setHeader('Access-Control-Allow-Origin', '*');
        $this->setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
        foreach ($this->headers as $name => $values) {
            foreach ($values as $key => $value) {
                header("{$name}: {$value}", $key == 0);
            }
        }

        if (is_array($this->body)) {
            $this->body = json_encode($this->body);
        }

        if(!empty($this->deskey) && empty($_REQUEST['debug']))
        {
            $this->body = Des::encrypt($this->body, $this->deskey);
        }

        $request = \App::getRequest();
        $uid = $request->getArg('uid');
        if(in_array($uid, [1,2,3,35,1000006])) {
            Log::debug($this->body, 'request');
        }

        echo $this->body;
    }
}
