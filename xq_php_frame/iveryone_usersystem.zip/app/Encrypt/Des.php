<?php

namespace HttpApi\Encrypt;

class Des
{

    public static function decrypt($encrypt_str, $key)
    {
        $iv = sprintf("%c%c%c%c%c%c%c%c", 0x12, 0x34, 0x56, 0x78, 0x90, 0xAB, 0xCD, 0xEF);
        $str_decrypt = openssl_decrypt($encrypt_str, "DES-CBC", $key, 0, $iv);
        return $str_decrypt;
    }

    public static function encrypt($input, $key)
    {
        $iv = sprintf("%c%c%c%c%c%c%c%c", 0x12, 0x34, 0x56, 0x78, 0x90, 0xAB, 0xCD, 0xEF);
        $encrypted_data = openssl_encrypt($input, "DES-CBC", $key, null, $iv);
        return $encrypted_data;
    }
}
