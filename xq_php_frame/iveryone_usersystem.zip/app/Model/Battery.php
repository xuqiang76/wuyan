<?php

namespace HttpApi\Model;

use Beahoo\Model\Base;
use HttpApi\Model\User\User;
use HttpApi\Model\Wallet\Balance;
use HttpApi\Model\Wallet\Details;
use HttpApi\Tool\BehaviorLogs;

class Battery extends Base
{
    private static $batterycaches = [];

    private static $instance;

    private $tableName = 'batteryinfo';

    public static function getInstance()
    {
        if (empty(self::$instance)) {
            self::$instance = new Battery();
        }
        return self::$instance;
    }

    public function initBattery($uid)
    {
        return $this->getOne()->insert($this->tableName, [
            'uid' => $uid,
            'capacity' => TIMESTAMP > NEW_INVITE_TIMESTAMP ? 10000000 : 30000000,
        ]);
    }

    public function getBatteryInfo($uid)
    {
        if(empty(self::$batterycaches[$uid])) {
            $res = $this->getOne()->selectOne($this->tableName, '*', ['uid' => $uid]);
            $batteryinfo = $res['data'];
            $batteryinfo['capacity'] /= 1000000;
            self::$batterycaches[$uid] = $batteryinfo;
        }
        return self::$batterycaches[$uid];
    }

    /**
     * @param $uid
     * @param $missionid
     * @throws \Beahoo\Exception
     */
    public function increaseCapacity($uid, $missionid)
    {
        $batteryinfo = $this->getBatteryInfo($uid);
        $setarr = [];
        switch ($missionid) {
            case 1:
                if ($batteryinfo['mission1_finish']) {
                    return;
                }
                $setarr = [
                    'mission1_finish' => 1,
                    'mission1_finishtimestamp' => TIMESTAMP
                ];
                break;
            case 2:
                if ($batteryinfo['mission2_finish']) {
                    return;
                }
                $setarr = [
                    'mission2_finish' => 1,
                    'mission2_finishtimestamp' => TIMESTAMP
                ];
                break;
            case 3:
                if ($batteryinfo['mission3_finish']) {
                    return;
                }
                $setarr = [
                    'mission3_finish' => 1,
                    'mission3_finishtimestamp' => TIMESTAMP
                ];
                break;
            case 4:
                if ($batteryinfo['mission4_finish']) {
                    return;
                }
                $setarr = [
                    'mission4_finish' => 1,
                    'mission4_finishtimestamp' => TIMESTAMP
                ];
                break;
        }

        if (!empty($setarr)) {
            BehaviorLogs::addLogs($uid, BehaviorLogs::ACT_BATTERY_MISSION, ['missionid' => $missionid], 'battery mission');
            $this->getOne()->update($this->tableName, $setarr, [
                'capacity' => 2500000,
            ], ['uid' => $uid]);
            if(!empty(self::$batterycaches[$uid])) {
                $setarr['capacity'] = $batteryinfo['capacity'] + 2500000;
                self::$batterycaches[$uid] = array_merge(self::$batterycaches[$uid], $setarr);
            }
        }
    }

    public function UpdateLastChargeTimestamp($uid)
    {
        if(!empty(self::$batterycaches[$uid])) {
            self::$batterycaches[$uid]['last_charge_timestamp'] = TIMESTAMP;
        }
        return $this->getOne()->update($this->tableName, ['last_charge_timestamp' => TIMESTAMP], [], ['uid' => $uid]);
    }
}