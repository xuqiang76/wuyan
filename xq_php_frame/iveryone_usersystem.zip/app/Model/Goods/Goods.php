<?php
/**
 * Created by PhpStorm.
 * User: zhangyuanhao
 * Date: 2018/6/20
 * Time: 10:38
 */

namespace HttpApi\Model\Goods;

use Beahoo\Exception;
use HttpApi\Tool\Format;

class Goods extends \HttpApi\Model\BaseModel
{
    // 商品一旦加上，不能删掉，不能注释
    private $goodsList = [
        [
            'goods_id'    => 1,
            'goods_title' => '6元',
            'goods_desc'  => '6000V点',
            'amount'      => 6,
            'value'       => 6000,
            'is_show'     => true
        ],
        [
            'goods_id'    => 2,
            'goods_title' => '30元',
            'goods_desc'  => '30000V点',
            'amount'      => 30,
            'value'       => 30000,
            'is_show'     => true
        ],
        [
            'goods_id'    => 3,
            'goods_title' => '128元',
            'goods_desc'  => '128000V点',
            'amount'      => 128,
            'value'       => 128000,
            'is_show'     => true
        ],
        [
            'goods_id'    => 4,
            'goods_title' => '198元',
            'goods_desc'  => '198000V点',
            'amount'      => 198,
            'value'       => 198000,
            'is_show'     => true
        ],
        [
            'goods_id'    => 5,
            'goods_title' => '324元',
            'goods_desc'  => '324000V点',
            'amount'      => 324,
            'value'       => 324000,
            'is_show'     => true
        ],
        [
            'goods_id'    => 6,
            'goods_title' => '648元',
            'goods_desc'  => '648000V点',
            'amount'      => 648,
            'value'       => 648000,
            'is_show'     => true
        ],
        [
            'goods_id'    => 16,
            'goods_title' => '6元',
            'goods_desc'  => '3000V点',
            'amount'      => 6,
            'value'       => 3000,
            'is_show'     => false
        ],
        [
            'goods_id'    => 17,
            'goods_title' => '30元',
            'goods_desc'  => '15000V点',
            'amount'      => 30,
            'value'       => 15000,
            'is_show'     => false
        ],
        [
            'goods_id'    => 18,
            'goods_title' => '128元',
            'goods_desc'  => '64000V点',
            'amount'      => 128,
            'value'       => 64000,
            'is_show'     => false
        ],[
            'goods_id'    => 19,
            'goods_title' => '198元',
            'goods_desc'  => '99000V点',
            'amount'      => 198,
            'value'       => 99000,
            'is_show'     => false
        ],
        [
            'goods_id'    => 20,
            'goods_title' => '324元',
            'goods_desc'  => '162000V点',
            'amount'      => 324,
            'value'       => 162000,
            'is_show'     => false
        ],
        [
            'goods_id'    => 21,
            'goods_title' => '648元',
            'goods_desc'  => '324000V点',
            'amount'      => 648,
            'value'       => 324000,
            'is_show'     => false
        ],
        [
            'goods_id'    => 26,
            'goods_title' => '999元',
            'goods_desc'  => '1V点',
            'amount'      => 999,
            'value'       => 1,
            'is_show'     => false
        ],
    ];

//    protected $tableName = 'wallet_new';
    protected static $instance = [ ];

    public static function getInstance() {
        $class = get_called_class ();
        if (! isset ( self::$instance [$class] )) {
            self::$instance [$class] = new $class ();
        }
        return self::$instance [$class];
    }

    public function getGoodsList($isAll = true)
    {
        if($isAll) {
            return $this->goodsList;
        }  else {
            return array_reduce($this->goodsList, function($iteration, $item) {
                if($item['is_show']) {
                    unset($item['is_show']);
                    $iteration[] = $item ;
                }
                return $iteration;
            });
        }

    }

    public function getGoodsInfo($goodsId)
    {
        $newGoodsList = Format::arrayChangeKey($this->goodsList, 'goods_id');
        if(isset($newGoodsList[$goodsId])) {
            return $newGoodsList[$goodsId];
        } else {
            return [];
        }
    }
}