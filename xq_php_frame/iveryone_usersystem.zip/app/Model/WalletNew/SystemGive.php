<?php
namespace HttpApi\Model\WalletNew;

use Beahoo\Exception;
use HttpApi\Model\Wallet\WalletBase;
use HttpApi\Model\WalletNew\Bill;
/**
 * 系统赠送类的钱包操作入口
 *
 *
 * Class Assets
 * @package HttpApi\Model\WalletNew|
 */
class SystemGive extends WalletBase
{
    /**
     *
     * 执行操作  系统赠送类的  注册iVeryOne、邀请激励、关注、关注公众号、关注电邮、消费补贴发放、活动奖励、人脸认证奖励
     * @param $data  ['income_id', 'category', 'remark', 'title', 'uniqid', 'amount']
     * @return mixed
     */
    public function create($data)
    {
        try{
            $orderid  = Bill::getInstance()->giveVCoupon(
                $data['income_id'],
                $data['amount'],
                ['uniqid' => $data['uniqid'], 'title' => $data['title'], 'remark' => $data['remark'], 'scene_category' => $data['category']]);
            return $orderid;
        } catch(\Exception $e) {
            throw  new Exception($e->getMessage(), $e->getCode());
        }
    }
}