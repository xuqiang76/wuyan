<?php
/**
 * Created by PhpStorm.
 * User: zhangyuanhao
 * Date: 2018/6/11
 * Time: 19:28
 */

namespace HttpApi\Model\WalletNew;

use Beahoo\Exception;

class BillDetail extends \HttpApi\Model\BaseModel
{
    protected $conf = [
        'currency_type' => [
            'v' => 1,
            'coupon' => 2,
            'vry' => 3
        ],
        'origin' => [
            'general' => 1,
            'apple' => 2,
            'not_apple' => 3
        ]
    ];

    protected $tableName = 'bill_detail';
    protected static $instance = [ ];

    public static function getInstance() {
        $class = get_called_class ();
        if (! isset ( self::$instance [$class] )) {
            self::$instance [$class] = new $class ();
        }
        return self::$instance [$class];
    }

    /**
     * 批量/单条 创建账单明细
     * @param $billData
     * $param $createDetail  是否生成账单
     */
    public function create($billId, $detailData, $createDetail = true)
    {
        if(!$createDetail) {
            return;
        }
        if(!isset($detailData[0])) {
            $batchData = [$detailData];
        } else {
            $batchData = $detailData;
        }
        $batchSaveData = [];
        foreach ($batchData as $k => $v) {
            $batchSaveData[$k] = [
                'create_timestamp' => $v['create_timestamp'],
                'bill_id' => $billId,
                'direction_type' => $v['direction_type']
            ];
            if(!isset($v['currency_type']) || !isset($this->conf['currency_type'][$v['currency_type']])) {
                throw new Exception('账单明细生成失败1', 4414);
            } else {
                $batchSaveData[$k]['currency_type'] = $this->conf['currency_type'][$v['currency_type']];
            }
            if(!isset($v['amount'])) {
                throw new Exception('账单明细生成失败2', 4414);
            } else {
                $batchSaveData[$k]['amount'] = $v['amount'];
            }
            if(!isset($v['belong_role'])) {
                throw new Exception('账单明细生成失败3', 4414);
            } else {
                $batchSaveData[$k]['belong_role'] = $v['belong_role'];
            }
            if(!isset($v['belong_id'])) {
                throw new Exception('账单明细生成失败4', 4414);
            } else {
                $batchSaveData[$k]['belong_id'] = $v['belong_id'];
            }
            if(!isset($v['origin']) || !isset($this->conf['origin'][$v['origin']])) {
                $batchSaveData[$k]['origin'] = $this->conf['origin']['general'];
            } else {
                $batchSaveData[$k]['origin'] = $this->conf['origin'][$v['origin']];
            }
        }

        $result = $this->getOne ()->batchInsert ( $this->tableName, $batchSaveData );
    }

    /**
     * 获取账单明细
     * @param $uid 用户ID
     * @param array $where [
     *          'start_timestamp' => '', // 开始时间戳
     *          'end_timestamp' => '', // 结束时间戳
     *          'direction_type' => '', // 收入还是支出
     * ]
     * @param string $orderby 排序 asc时间正序   desc时间倒序
     * @param int $page
     * @param int $limit
     * @param $detailType 0 全部  1 V点和代金券  2 Vry
     * @param $isApple 是否为苹果
     */
    public function detail($uid, $where = [], $orderby = 'desc', $page = 1, $limit = 20, $detailType = 0, $isApple = false)
    {

        $offset = ($page - 1) * $limit;
        $orderby = 'order by id '.$orderby;

        $whereFeild = [
            'belong_id' => $uid,
            'belong_role' => 1,
        ];
        if($detailType == 1) {
            $whereFeild['currency_type'] = [
                $this->conf['currency_type']['v'], $this->conf['currency_type']['coupon']
            ];
        } elseif ($detailType == 2) {
            $whereFeild['currency_type'] = $this->conf['currency_type']['vry'];
        } else {

        }

        if(isset($where['start_timestamp'])) {
            $whereFeild['create_timestamp']['$gte'] = $where['start_timestamp'];
        }

        if(isset($where['direction_type'])) {
            $whereFeild['direction_type'] = $where['direction_type'];
        }

        if(isset($where['last_detail_id']) && $where['last_detail_id']) {
            $whereFeild['id'] = [
                '$lt' => $where['last_detail_id']
            ];
        }

        if($isApple) {
            $whereFeild['origin'] = [1, 2];
        } else {
            $whereFeild['origin'] = [1, 3];
        }

        $details = $this->getOne()->select($this->tableName, '*', $whereFeild, $orderby, $offset, $limit);
        if(0 == $details['rownum'])
            throw new Exception ('没有结果', 4000);

        return $details['data'];
    }

    /**
     * 根据账单ID获取账单明细
     * @param $billId
     */
    public function getDetailByBillId($billId)
    {
        $details = $this->getOne()->select($this->tableName, '*', [
            'bill_id' => $billId
        ]);

        if(0 == $details['rownum'])
            throw new Exception ('没有结果', 4000);

        return $details['data'];
    }

    public function getCurrencyType($billId)
    {
        $data = $this->getOne()->selectOne($this->tableName, '*', [
            'bill_id' => $billId
        ])['data'];
        if (empty ( $data )) {
            throw new Exception ( '没有结果', 4000 );
        }
        $currencyType = $data['currency_type'] == 1 ? 'V' : 'VRY';
        return $currencyType;

    }
}