<?php
namespace HttpApi\Model\WalletNew;

use Beahoo\Exception;

/**
 * VRY 转账
 *
 * Class
 * @package HttpApi\Model\WalletNew
 */
class Transfers extends \HttpApi\Model\BaseModel
{
    /**
     *
     * 转账操作执行入口  VRY   系统内转账、游戏内钓VRY
     * @param $data  [incomeid, expendid, amount, uniqid, income_title, expend_title, remark, category]
     * @return mixed
     */
    public function create($data)
    {
        $this->transaction_start();
        try{
            $external = [
                'uniqid'         => isset($data['uniqid']) ? isset($data['uniqid']) :uniqid ( 'transfer_' ),
                'income_title'   => $data['income_title'],
                'expend_title'   => $data['expend_title'],
                'remark'         => $data['remark'],
                'scene_category' => $data['category'] ? $data['category'] : 'Transfer'
            ];

            $orderid = Bill::getInstance()->transferVry($data['incomeid'], $data['expendid'], $data['amount'], $external);
            return $orderid;
            $this->transaction_commit();
        } catch(Exception $e) {
            $this->transaction_rollback();
           throw new Exception('向用户转账失败', '3004');
        }
    }


    /**
     * 打赏形式的转账   支出单位V点，收入是VRY
     * @param $data  [incomeid, expendid, amount, uniqid, income_title, expend_title, remark, category]
     * @return mixed
     */
    public function TipsTrans($data)
    {
        $isApple = false;

        if(\App::getGlobal('device_platform') == 'ios') {
            $isApple = true;
        }
        $this->transaction_start();
        try {
            $external = [
                'uniqid'         => uniqid ( 'transferTips_' ),
                'income_title'   => $data['income_title'],    //来自谁的打赏
                'expend_title'   => $data['expend_title'],    //打赏谁的
                'remark'         => $data['remark'],
                'scene_category' => $data['category']
            ];

            $orderid = Bill::getInstance()->expendVToIncomeVry($data['incomeid'], $data['expendid'], $data['amount'], $external, $isApple);
            $this->transaction_commit();
            return $orderid;
        } catch (Exception $e) {
            $this->transaction_rollback();
            throw new Exception('打赏失败', '3004');
        }

    }
}