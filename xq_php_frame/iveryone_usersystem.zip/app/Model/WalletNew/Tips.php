<?php

namespace HttpApi\Model\WalletNew;

use Beahoo\Exception;

class Tips extends \HttpApi\Model\BaseModel
{

    /**
     * 打赏 支出V券 V点，收入的是VRY

     * @param Array $data
     *            $data['uid'] 打赏的用户id
     *            $data['tid'] 接受打赏的文章id
     *            $data['title'] 文章的标题
     *            $data['author'] 接受转账的用户id
     *            $data['amount'] 转账金额，不可为0，仅为正数，负数会自动转换成正数
     * @throws Exception
     */
    public function create($data) {
        $this->transaction_start();
        try{
            $data ['amount'] = abs ( $data ['amount'] );
            if ($data ['amount'] === 0) {
                throw new Exception ( '打赏金额为0', 4031 );
            }
            $tipData = [
                'incomeid' => $data['author'],  //文章作者
                'expendid' => $data['uid'],     //打赏者
                'amount'   => $data['amount'],
                'uniqid'   => $data['tid'],
                'income_title' => '打赏-'.$data['title'],
                'expend_title' => '打赏-'.$data['title'],
                'remark'       => '',
                'category'     => 'Tips'
            ];

            Transfers::getInstance()->TipsTrans($tipData);
            $this->transaction_commit();
        }catch(Exception $e){
            $this->transaction_rollback();
            throw new Exception($e->getMessage(), $e->getCode());
        }


    }
}