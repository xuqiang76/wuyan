<?php
/**
 * Created by PhpStorm.
 * User: zhangyuanhao
 * Date: 2018/6/11
 * Time: 18:25
 */

namespace HttpApi\Model\WalletNew;

use Beahoo\Exception;
use HttpApi\Model\Wallet\Balance;
use HttpApi\Tool\Format;

class WalletNew extends \HttpApi\Model\BaseModel {
	protected $tableName = 'wallet_new';
	protected static $instance = [];

	public static function getInstance() {
		$class = get_called_class();
		if (!isset(self::$instance[$class])) {
			self::$instance[$class] = new $class();
		}
		return self::$instance[$class];
	}

	/**
	 * 初始化/创建钱包
	 * @param $data
	 * @return mixed
	 */
	public function create($data) {
		// 如果新钱包有的话，则不进行创建
		$newOldresult = $this->getOne()->selectOne($this->tableName, '*', [
			'uid' => $data['uid'],
		]);
		if ($newOldresult['data']) {
			return $newOldresult['data']['id'];
		}
		// @todo 因为要处理老数据，所以需要迁移老数据
		$oldWallet = Balance::getInstance()->query([
			'uid' => $data['uid'],
		]);
		if ($oldWallet) {
		    $coupon = Format::vryExchangeV(Format::amount($oldWallet['token']));
			$data = [
				'uid' => $data['uid'],
				'balance_vry' => Format::formatVry($oldWallet['available']),
				'balance_coupon' => Format::encodeV($coupon),
				'old_freeze' => Format::formatVry($oldWallet['freeze']),
				'old_lock' => Format::formatVry($oldWallet['lock']),
				'status' => $oldWallet['status'],
				'transfer' => $oldWallet['transfer'],
			];
		}
		$result = $this->getOne()->insert($this->tableName, $data);
		if (!$result['insertid']) {
			throw new Exception('钱包生成失败', 4412);
		}
		return $result['insertid'];
	}

	/**
	 * 获取用户钱包各种货币余额
	 * @param $uid
	 * @return array
	 */
	public function getWalletInfo($uid) {
		do {
			$result = $this->getOne()->selectOne($this->tableName, '*', [
				'uid' => $uid,
			]);
		} while (empty($result['data']) && $this->create([
			'uid' => $uid,
		]));
		return [
			'id' => $result['data']['id'], // 钱包ID
			'balance_vry' => $result['data']['balance_vry'], // 余额VRY
			'balance_v' => $result['data']['balance_v'], // 非苹果V点
			'balance_apple_v' => $result['data']['balance_apple_v'], // 苹果V点
			'balance_coupon' => $result['data']['balance_coupon'], // V点代金卷
			'lock' => $result['data']['lock'], // 锁定VRY
			'unconfirmed' => $result['data']['unconfirmed'], // 未确认VRY
			'transfer' => $result['data']['transfer'], // 转账状态
			'status' => $result['data']['status'], // 钱包状态
			'adwords' => $result['data']['adwords'], // 广告收益
			'old_lock' => $result['data']['old_lock'], // 老钱包的锁定余额
			'old_freeze' => $result['data']['old_freeze'], // 老钱包的冻结余额
		];
	}

	/**
	 * 锁定钱包
	 * @param $uid
	 * @return mixed
	 */
	public function lockWallet($uid, $status) {
		return $this->getOne()->update($this->tableName, [
			'status' => $status,
		], [], [
			'uid' => $uid,
		]);
	}

	/**
	 * 解锁钱包
	 * @param $uid
	 * @return mixed
	 */
	public function unlockWallet($uid) {
		return $this->getOne()->update($this->tableName, [
			'status' => 0,
		], [], [
			'uid' => $uid,
		]);
	}

	/**
	 * 修改转账权限
	 * @param $uid
	 * @return mixed
	 */
	public function updateTransfer($uid, $status) {
		return $this->getOne()->update($this->tableName, [
			'transfer' => $status,
		], [], [
			'uid' => $uid,
		]);
	}

	/**
	 * 更新vry余额
	 * @param $uid
	 * @param $amount
	 * @param $type add 增加 less 减少
	 * @return mixed
	 */
	public function updateBalanceVry($uid, $amount, $type) {
		if ($type == 'add') {
			$amount = '+ ' . $amount;
			return $this->getOne()->exec("UPDATE {$this->tableName} SET balance_vry = balance_vry {$amount} WHERE uid = '{$uid}'");
		} else {
			$checkAmount = abs($amount);
			$amount = '- ' . $amount;
			if($checkAmount) {
                $result = $this->getOne()->exec("UPDATE {$this->tableName} SET balance_vry = balance_vry {$amount} WHERE uid = '{$uid}' AND balance_vry >= {$checkAmount}");
                if (!$result['affectedrows']) {
                    throw new Exception('钱包更新失败', 42125);
                }
                return $result;
            }

		}
	}

	/**
	 * 更新通用V点余额
	 * @param $uid
	 * @param $amount
	 * @param $type add 增加 less 减少
	 * @return mixed
	 */
	public function updateBalanceV($uid, $amount, $type) {
		if ($type == 'add') {
			$amount = '+ ' . $amount;
			return $this->getOne()->exec("UPDATE {$this->tableName} SET balance_v = balance_v {$amount} WHERE uid = '{$uid}'");
		} else {
			$checkAmount = abs($amount);
			$amount = '- ' . $amount;
			if($checkAmount) {
                $result = $this->getOne()->exec("UPDATE {$this->tableName} SET balance_v = balance_v {$amount} WHERE uid = '{$uid}' AND balance_v >= {$checkAmount}");
                if (!$result['affectedrows']) {
                    throw new Exception('钱包更新失败', 42225);
                }
                return $result;
            }
		}
	}

	/**
	 * 更新苹果V点余额
	 * @param $uid
	 * @param $amount
	 * @param $type add 增加 less 减少
	 * @return mixed
	 */
	public function updateBalanceAppleV($uid, $amount, $type) {
		if ($type == 'add') {
			$amount = '+ ' . $amount;
			return $this->getOne()->exec("UPDATE {$this->tableName} SET balance_apple_v = balance_apple_v {$amount} WHERE uid = '{$uid}'");
		} else {
			$checkAmount = abs($amount);
			$amount = '- ' . $amount;
            if($checkAmount) {
                $result = $this->getOne()->exec("UPDATE {$this->tableName} SET balance_apple_v = balance_apple_v {$amount} WHERE uid = '{$uid}' AND balance_apple_v >= {$checkAmount}");
                if (!$result['affectedrows']) {
                    throw new Exception('钱包更新失败', 4225);
                }
                return $result;
            }
		}
	}

	/**
	 * 更新V卷余额
	 * @param $uid
	 * @param $amount
	 * @param $type add 增加 less 减少
	 * @return mixed
	 */
	public function updateBalanceCoupon($uid, $amount, $type) {
		if ($type == 'add') {
			$amount = '+ ' . $amount;
			return $this->getOne()->exec("UPDATE {$this->tableName} SET balance_coupon = balance_coupon {$amount} WHERE uid = '{$uid}'");
		} else {
			$checkAmount = abs($amount);
			$amount = '- ' . $amount;
			if($checkAmount) {
                $result = $this->getOne()->exec("UPDATE {$this->tableName} SET balance_coupon = balance_coupon {$amount} WHERE uid = '{$uid}' AND balance_coupon >= {$checkAmount}");
                if (!$result['affectedrows']) {
                    throw new Exception('钱包更新失败', 4225);
                }
                return $result;
            }
		}
	}

	/**
	 * 更新锁定余额
	 * @param $uid
	 * @param $amount
	 * @param $type add 增加 less 减少
	 * @return mixed
	 */
	public function updateLock($uid, $amount, $type) {
		if ($type == 'add') {
			$amount = '+ ' . $amount;
			return $this->getOne()->exec("UPDATE {$this->tableName} SET lock = lock {$amount} WHERE uid = '{$uid}'");
		} else {
			$checkAmount = abs($amount);
			$amount = '- ' . $amount;
			if($checkAmount) {
                $result = $this->getOne()->exec("UPDATE {$this->tableName} SET lock = lock {$amount} WHERE uid = '{$uid}' AND lock >= {$checkAmount}");
                if (!$result['affectedrows']) {
                    throw new Exception('钱包更新失败', 4225);
                }
                return $result;
            }
		}
	}

	/**
	 * 锁定VRY \ 解锁VRY
	 *
	 * @param $uid
	 * @param $amount
	 * @return \Beahoo\Tool\Dbresult|bool
	 * @throws Exception
	 */
	public function lockHandle($uid, $amount) {
		if ($amount > 0) {
			//锁定 从vry 钱包转移到锁定钱包
			$result = $this->getOne()->exec("UPDATE {$this->tableName} SET lock = lock + {$amount},balance_vry = balance_vry - {$amount}  WHERE uid = '{$uid}' AND balance_vry >= {$amount}");
		} else if ($amount < 0) {
			//锁定 从锁定钱包转移到vry 钱包
			$result = $this->getOne()->exec("UPDATE {$this->tableName} SET lock = lock + {$amount},balance_vry = balance_vry - {$amount}  WHERE uid = '{$uid}' AND lock + {$amount} >=0 ");
		} else {
			return false;
		}

		if (!$result['affectedrows']) {
			if ($amount > 0) {
				throw new Exception('锁定失败', 4224);
			} else {
				throw new Exception('解锁失败', 4225);
			}
		}
		return $result;
	}

	/**
	 * 更新未确认余额
	 * @param $uid
	 * @param $amount
	 * @param $type add 增加 less 减少
	 * @return mixed
	 */
	public function updateUnconfirmed($uid, $amount, $type) {
		if ($type == 'add') {
			$amount = '+ ' . $amount;
			return $this->getOne()->exec("UPDATE {$this->tableName} SET unconfirmed = unconfirmed {$amount} WHERE uid = '{$uid}'");
		} else {
			$checkAmount = abs($amount);
			$amount = '- ' . $amount;
			if($checkAmount) {
                $result = $this->getOne()->exec("UPDATE {$this->tableName} SET unconfirmed = unconfirmed {$amount} WHERE uid = '{$uid}' AND unconfirmed >= {$checkAmount}");
                if (!$result['affectedrows']) {
                    throw new Exception('钱包更新失败', 4225);
                }
                return $result;
            }
		}
	}

    /**
     * 看广告增加 钱包
     * @param $incomeId
     * @param $amount  V点
     */
    public function adSense($incomeId, $amount)
    {
        //转换为VRY
        $amount = Format::formatVry(Format::vExchangeVry($amount));
        return $this->getOne()->exec("UPDATE {$this->tableName} SET adwords = adwords  + {$amount} WHERE uid = '{$incomeId}'");
    }

	/**
	 * 判断余额是否足够
	 */
	public function isBalance($uid, $amount, $balanceType) {
		if (!is_array($balanceType)) {
			$balanceType = [$balanceType];
		}

		$walletInfo = $this->getWalletInfo($uid);
		$balance = 0;
		foreach ($balanceType as $v) {
			if (isset($walletInfo[$v])) {
				$balance += $walletInfo[$v];
			}
		}
		if ($balance >= $amount) {
			return true;
		} else {
			return false;
		}
	}
}