<?php
/**
 * Created by PhpStorm.
 * User: zhangyuanhao
 * Date: 2018/6/11
 * Time: 19:07
 */

namespace HttpApi\Model\WalletNew;

use Beahoo\Exception;
use HttpApi\Tool\Format;

class Bill extends \HttpApi\Model\BaseModel
{
    private $conf = [
        'bill_type' => [
            'system' => 1, // 系统
            'not_system' => 2 // 非系统
        ],
        'trading_type' => [
            'consume' => 1, // 消费
            'transfer' => 2, // 转账
            'recharge' => 3, // 充值
            'withdraw' => 4, // 提现
            'refund'   => 5, // 退还
        ],
        'direction_type' => [
            'income' => 1, // 收入
            'expend' => 2, // 支出
        ],
        'income_role' => [
            'user'   => 1, // 用户
            'system' => 2, // 系统
        ],
        'expend_role' => [
            'user'   => 1, // 用户
            'system' => 2, // 系统
        ],
        'belong_role' => [
            'user'   => 1, // 用户
            'system' => 2, // 系统
        ],
        'status' => [
            'ing' => 1, // 交易中
            'finish' => 2, // 交易完成
            'fail' => 3 // 交易失败
        ],
        'combine_currency_type' => [
            'v' => 1, // V点或者V券
            'vry' => 5, // VRY
        ],
        'scene_category' => [
            'Candy_Register' => 1,
            'Candy_Level' => 2,
            'Candy_Follow' => 3,
            'Candy_WeChat' => 4,
            'Candy_Telegram' => 5,
            'Thread_Buy' => 6,
            'Thread_Spread' => 7,
            'System_Fee' => 8,
            'AdWords' => 9,
            'AdSense' => 10,
            'Battery' => 11,
            'Audio'   => 12,
            'Chat'    => 13,
            'Video'   => 14,
            'AdWords_Cancel'   => 15,
            'Activity'   => 16,
            'Game_Booking'   => 17,
            'Game_Booking_Spread'   => 18,
            'Game_Purchase'   => 19,
            'Game_Purchase_Spread'   => 20,
            'Battery_Clean'   => 21,
            'Transfer'   => 22,
            'Tips'   => 23,
            'Feedback'   => 24,
            'Appeal'   => 25,
            'Feedback_Cancel'   => 28,
            'Verification' => 26,
            'Power_Auditor'   => 27,
            'Feedback_Reward' => 29,
            'Assets_Purchase'    => 30,
            'Assets_Spread'      => 31,
            'Assets_App_Fee'     => 32,
            'World_Cup_Back'     => 33,  //世界杯精彩返还
            'Apple_Recharge'     => 34,
            'Not_Apple_Recharge' => 35,
            'Game_Reward'        => 36,
            'VRY_Convert_V'      => 37,  //VRY  兑换V券
        ]
    ];

    protected $tableName = 'bill';
    protected static $instance = [ ];

    public static function getInstance() {
        $class = get_called_class ();
        if (! isset ( self::$instance [$class] )) {
            self::$instance [$class] = new $class ();
        }
        return self::$instance [$class];
    }

    /**
     * 创建账单
     * @param $billData
     */
    public function create($billData, $otherData = [])
    {
        // @todo 因为涉及到导数据，多进行一次钱包的查询
        if($billData['belong_role'] == $this->conf['belong_role']['user']) {
            WalletNew::getInstance()->create([
                'uid' => $billData['belong_id']
            ]);
        }

        if(isset($otherData['title']))
            $billData['title'] = $otherData['title'];

        if(isset($otherData['uniqid']))
            $billData['uniqid'] = $otherData['uniqid'];

        if(isset($otherData['remark']))
            $billData['remark'] = $otherData['remark'];

        if(isset($otherData['scene_category']))
            $billData['scene_category'] = $this->conf['scene_category'][$otherData['scene_category']];

        if(isset($otherData['scene_category_value']))
            $billData['scene_category'] = $otherData['scene_category_value'];

        $billData['status'] = $this->conf['status']['ing'];

        if(isset($otherData['status'])) {
            $billData['status'] = $otherData['status'];
        }

        $result = $this->getOne ()->insert ( $this->tableName, $billData );
        return $result ['insertid'];
    }

    /**
     * 获取账单明细
     * @param $uid 用户ID
     * @param array $where [
     *          'start_timestamp' => '', // 开始时间戳
     *          'end_timestamp' => '', // 结束时间戳
     *          'direction_type' => '', // 收入还是支出
     * ]
     * @param string $orderby 排序 asc时间正序   desc时间倒序
     * @param int $page
     * @param int $limit
     * @param $detailType 0 全部  1 V点和代金券  2 Vry
     * @param $isApple 是否为苹果
     */
    public function getBillDetail($uid, $where = [], $orderby = 'desc', $page = 1, $limit = 20, $detailType = 0, $isApple = false)
    {
        $billDetailData = BillDetail::getInstance()->detail($uid, $where, $orderby, $page, $limit, $detailType, $isApple);

        $billIds = array_unique(array_column($billDetailData, 'bill_id'));
        // 获取账单
        $billData = $this->getOne()->select($this->tableName, '*', [
            'id' => $billIds
        ]);
        if(0 == $billData['rownum'])
            throw new Exception ('没有结果', 4000);

        $billNewData = Format::arrayChangeKey($billData['data'], 'id');
        $returnData = [];
        foreach ($billDetailData as $k => $v) {
            $returnData[$k] = [
                'bill_detail_id' => $v['id'],
                'bill_id' => $v['bill_id'],
                'title' => $billNewData[$v['bill_id']]['title'],
                'create_timestamp' => $billNewData[$v['bill_id']]['create_timestamp'],
                'direction_type' => $v['direction_type']
            ];
            if(in_array($v['currency_type'], [1, 2])) {
                $returnData[$k]['currency_type'] = $v['currency_type'];
                $returnData[$k]['amount'] = Format::decodeV($v['amount']);
            } elseif($v['currency_type'] == 3) {
                $returnData[$k]['currency_type'] = $v['currency_type'];
                $returnData[$k]['amount'] = Format::amount($v['amount']);
            } else {

            }
        }

        return $returnData;
    }

    public function queryBill($data, $orderby = null)
    {
        $limit = 100;
        $offset = 0;
        foreach (explode(',', 'offset,limit,begin,end') as $key) {
            if (isset($data[$key])) {
                $$key = $data[$key];
                unset($data[$key]);
            }
        }
        $orderby = $orderby ?? ($offset ? (empty($data) ? "" : "and ") . "id < {$offset} " : "");
        $details = $this->getOne()->select($this->tableName, '*', $data, $orderby . 'order by id desc', 0, $limit);
        if (empty($details['data'])) {
            throw new Exception('没有结果', 4000);
        } else {
            $details = $details['data'];
            foreach($details as $key => $detail) {
                $type = BillDetail::getInstance()->getCurrencyType($detail['id']);
                $details[$key]['amount'] = $type == 'V' ? Format::decodeV($detail['amount']) : Format::amount($detail['amount']);
//                $details[$key]['amount'] = $detail['combine_currency_type'] == $this->conf['combine_currency_type']['v'] ? Format::decodeV($detail['amount']) : Format::amount($detail['amount']);
            }
        }
        return $details;
    }

    public function getBillCount($params, $orderby = null) {
        $orderby = $orderby ?? '';
        return $this->getOne()->select($this->tableName, 'count(1) as num', $params, $orderby)['data'][0]['num'];
    }

    /**
     * 获取账单列表的总金额
     * @param $params
     * @return mixed
     */
    public function getBillSumAmount($params, $orderBy) {
        if(isset($params['scene_category']) && isset($this->conf['scene_category'][$params['scene_category']]))
            $params['scene_category'] = $this->conf['scene_category'][$params['scene_category']];
        $amount = $this->getOne()->selectOne($this->tableName, 'sum(amount) as sum', $params, $orderBy);
        return $amount['data']['sum'] ? $amount['data']['sum'] : 0;
    }

    /**
     * 通过账单ids获取账单列表
     * @param $ids
     */
    public function getBillListByIds($ids)
    {
        $data = $this->getOne()->select($this->tableName, '*', [
            'id' => $ids
        ]);

        if(0 == $data['rownum'])
            return [];

        return $data['data'];
    }

    /**
     * 获取账单信息
     * @param $uid
     * @return array
     */
    public function getBillInfo($billId)
    {
        $result = $this->getOne()->selectOne($this->tableName, '*', [
            'id' => $billId
        ]);
        if(!$result['affectedrows']) {
            throw new Exception('获取账单信息失败', 4413);
        }
        return $result['data'];
    }

    /**
     * 操作交易完成
     * @param $billId
     */
    public function tradingFinish($billId)
    {
        return $this->getOne()->update($this->tableName, [
            'status' => $this->conf['status']['finish'],
            'finish_timestamp' => time()
        ], [], [
            'id' => $billId
        ]);
    }

    /**
     * 操作交易失败
     * @param $billId
     */
    public function tradingFail($billId)
    {
        return $this->getOne()->update($this->tableName, [
            'status' => $this->conf['status']['fail'],
            'fail_timestamp' => time()
        ], [], [
            'id' => $billId
        ]);
    }

    /**
     * 充值V点（苹果和非苹果）
     * @param $incomeUid 用户ID
     * @param $amount 金额 V点  请传给我v点
     * @param $data [
     *         'uniqid' => '', // 第三方ID
     *         'title'  => '', // 标题
     *         'remark'  => '', // 备注（可为空）
     * ]
     * @param bool $isApple 是否是苹果
     */
    public function rechargeV($incomeUid, $amount, $data, $isApple = false)
    {
        $amount = Format::encodeV($amount);
        $currTime = time();
        $billData = [
            'bill_type' => $this->conf['bill_type']['system'], // 系统交易
            'trading_type' => $this->conf['trading_type']['recharge'], // 充值
            'direction_type' => $this->conf['direction_type']['income'], // 收入
            'income_role'  => $this->conf['income_role']['user'], // 收入角色是用户
            'expend_role' => $this->conf['expend_role']['system'], // 支出角色是系统
            'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
            'belong_id' => $incomeUid,
            'income_id' => $incomeUid,
            'combine_currency_type' => $this->conf['combine_currency_type']['v'],
            'amount'   => $amount,
            'create_timestamp' => $currTime
        ];

        if($isApple) {
            $data['scene_category'] = 'Apple_Recharge';
        } else {
            $data['scene_category'] = 'Not_Apple_Recharge';

        }
        try {
            // 先生成总账单
            $billId = $this->create($billData, $data);
            // 再生成明细
            BillDetail::getInstance()->create($billId, [
                [
                    'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
                    'belong_id' => $incomeUid,
                    'currency_type' => 'v',
                    'amount' => $amount,
                    'origin' => $isApple ? 'apple' : 'not_apple',
                    'create_timestamp' => $currTime,
                    'direction_type' => $this->conf['direction_type']['income'] // 收入
                ]
            ]);

            // 修改余额
            if($isApple) {
                WalletNew::getInstance()->updateBalanceAppleV($incomeUid, $amount, 'add');
            } else {
                WalletNew::getInstance()->updateBalanceV($incomeUid, $amount, 'add');
            }

            // 操作交易完成
            $this->tradingFinish($billId);
            return $billId;
        } catch (Exception $e) {
            throw new Exception($e->getMessage(), $e->getCode());
        }

    }

    /**
     * 赠送V券
     * @param $incomeUid 用户ID
     * @param $amount 金额 V券 请传给我v点
     * @param $data [
     *         'uniqid' => '', // 第三方ID
     *         'title'  => '', // 标题
     *         'remark'  => '', // 备注（可为空）
     *         'scene_category'  => '', // 业务场景
     * ]
     */
    public function giveVCoupon($incomeUid, $amount, $data)
    {
        $amount = Format::encodeV($amount);
        $currTime = time();
        $billData = [
            'bill_type' => $this->conf['bill_type']['system'], // 系统交易
            'trading_type' => $this->conf['trading_type']['recharge'], // 充值
            'direction_type' => $this->conf['direction_type']['income'], // 收入
            'income_role'  => $this->conf['income_role']['user'], // 收入角色是用户
            'expend_role' => $this->conf['expend_role']['system'], // 支出角色是系统
            'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
            'belong_id' => $incomeUid,
            'income_id' => $incomeUid,
            'combine_currency_type' => $this->conf['combine_currency_type']['v'],
            'amount'   => $amount,
            'title'    => $data['title'],
            'create_timestamp' => $currTime
        ];

        try {
            // 先生成总账单
            $billId = $this->create($billData, $data);
            // 再生成明细
            BillDetail::getInstance()->create($billId, [
                [
                    'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
                    'belong_id' => $incomeUid,
                    'currency_type' => 'coupon',
                    'amount' => $amount,
                    'origin' => 'general',
                    'create_timestamp' => $currTime,
                    'direction_type' => $this->conf['direction_type']['income'] // 收入
                ]
            ]);

            // 修改余额
            WalletNew::getInstance()->updateBalanceCoupon($incomeUid, $amount, 'add');

            // 操作交易完成
            $this->tradingFinish($billId);
            return $billId;
        } catch (Exception $e) {
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }

    /**
     * 消费V点和V券 收入VRY
     * @param $incomeUid 收入用户ID
     * @param $expendUid 支出用户ID
     * @param $amount 金额 V点 请传给我V点
     * @param $data [
     *         'uniqid' => '', // 第三方ID
     *         'income_title'  => '', // 收入账单标题
     *         'expend_title'  => '', // 支出账单标题
     *         'remark'  => '', // 备注（可为空）
     *         'scene_category'  => '', // 业务场景
     * ]
     * @param bool $isApple 是否是苹果
     */
    public function expendVToIncomeVry($incomeUid, $expendUid, $amount, $data, $isApple = false)
    {
        $currTime = time();
        $createDetail = true;
        if($amount == 0) {
            $createDetail = false;
        }
        // 账单基础数据
        $billData = [
            'bill_type' => $this->conf['bill_type']['not_system'], // 非系统交易
            'trading_type' => $this->conf['trading_type']['consume'], // 消费
            'income_role'  => $this->conf['income_role']['user'], // 收入角色是用户
            'expend_role' => $this->conf['expend_role']['user'], // 支出角色是用户
            'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
            'income_id' => $incomeUid,
            'expend_id' => $expendUid,
            'create_timestamp' => $currTime
        ];

        // 收入者账单数据
        $incomeAmount = Format::formatVry(Format::vExchangeVry($amount)); // 先把V点兑换成VRY
        $incomeBillData = [
            'direction_type' => $this->conf['direction_type']['income'], // 收入
            'belong_id' => $incomeUid,
            'combine_currency_type' => $this->conf['combine_currency_type']['vry'],
            'amount' => $incomeAmount
        ];
        if(isset($data['income_title']))
            $incomeBillData['title'] = $data['income_title'];

        // 支出者账单数据
        $expendAmount = Format::encodeV($amount); // 格式化成数据库存储的格式
        $expendBillData = [
            'direction_type' => $this->conf['direction_type']['expend'], // 支出
            'belong_id' => $expendUid,
            'combine_currency_type' => $this->conf['combine_currency_type']['v'],
            'amount' => $expendAmount
        ];

        if(isset($data['expend_title']))
            $expendBillData['title'] = $data['expend_title'];

        // 获取支出人余额
        $walletInfo = WalletNew::getInstance()->getWalletInfo($expendUid);
        // 判断支出人是否余额充足
        $balance = $isApple ? $walletInfo['balance_apple_v']+$walletInfo['balance_coupon'] : $walletInfo['balance_v']+$walletInfo['balance_coupon'];
        if($balance < $expendAmount) {
            throw new Exception ('可用余额不足', 4222);
        }

        try {
            // 先生成支出者总账单
            $expendBillId = $this->create(array_merge($billData, $expendBillData), $data);
            // 再生成支出者明细
            $expendBillDetail = [];
            $couponAmount = 0;
            // 如果v卷有余额
            if(0 < $walletInfo['balance_coupon']) {
                if($walletInfo['balance_coupon'] >= $expendAmount) {
                    // 余额足够直接扣
                    $couponAmount = $expendAmount;
                } else {
                    $couponAmount = $walletInfo['balance_coupon'];
                }
                $expendBillDetail[] = [
                    'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
                    'belong_id' => $expendUid,
                    'currency_type' => 'coupon',
                    'amount' => $couponAmount,
                    'origin' => 'general',
                    'create_timestamp' => $currTime,
                    'direction_type' => $this->conf['direction_type']['expend'] // 支出
                ];
            }
            // 如果V券扣完还不够，则从V点扣
            $vAmount = $expendAmount - $couponAmount;
            if($vAmount) {
                $expendBillDetail[] = [
                    'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
                    'belong_id' => $expendUid,
                    'currency_type' => 'v',
                    'amount' => $vAmount,
                    'origin' => $isApple ? 'apple' : 'not_apple',
                    'create_timestamp' => $currTime,
                    'direction_type' => $this->conf['direction_type']['expend'] // 支出
                ];
            }
            BillDetail::getInstance()->create($expendBillId, $expendBillDetail, $createDetail);

            // 先扣除支出者余额
            if($couponAmount) {
                WalletNew::getInstance()->updateBalanceCoupon($expendUid, $couponAmount, 'less');
            }
            if($vAmount) {
                if($isApple) {
                    WalletNew::getInstance()->updateBalanceAppleV($expendUid, $vAmount, 'less');
                } else {
                    WalletNew::getInstance()->updateBalanceV($expendUid, $vAmount, 'less');
                }
            }

            // 先生成收入者总账单
            $incomeBillId = $this->create(array_merge($billData, $incomeBillData), $data);
            // 再生成收入者明细
            BillDetail::getInstance()->create($incomeBillId, [
                [
                    'belong_role' => $this->conf['belong_role']['user'],
                    'belong_id' => $incomeUid,
                    'currency_type' => 'vry',
                    'amount' => $incomeAmount,
                    'origin' => 'general',
                    'create_timestamp' => $currTime,
                    'direction_type' => $this->conf['direction_type']['income'] // 收入
                ]
            ], $createDetail);
            // 修改余额
            WalletNew::getInstance()->updateBalanceVry($incomeUid, $incomeAmount, 'add');

            // 操作交易完成
            $this->tradingFinish($expendBillId);
            // 操作交易完成
            $this->tradingFinish($incomeBillId);

            return true;
        } catch (Exception $e) {
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }

    /**
     * 未确认款项，消费V点，收入V券
     * @param $incomeUid 收入用户ID
     * @param $expendUid 支出用户ID
     * @param $amount 金额 V点 传给我V点
     * @param $data [
     *         'uniqid' => '', // 第三方ID
     *         'title'  => '', // 收入账单标题
     *         'remark'  => '', // 备注（可为空）
     *         'scene_category' => '' // 业务场景
     * ]
     */
    public function unconfirmedVToCoupon($incomeUid, $expendUid, $amount, $data)
    {
        //0.9.8 广告场景更换 收入改为VRY 计算VRY的获得数量
        $vryAmount = Format::formatVry( Format::vExchangeVry($amount) );
        // 格式化V点为数据库存储格式
        $amount = Format::encodeV($amount);
        $currTime = time();

        // 账单基础数据
        $billData = [
            'bill_type' => $this->conf['bill_type']['not_system'], // 非系统交易
            'trading_type' => $this->conf['trading_type']['consume'], // 消费
            'income_role'  => $this->conf['income_role']['user'], // 收入角色是用户
            'expend_role' => $this->conf['expend_role']['user'], // 支出角色是用户
            'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
            'income_id' => $incomeUid,
            'expend_id' => $expendUid,
            'combine_currency_type' => $this->conf['combine_currency_type']['vry'],
            'amount'   => $vryAmount,
            'create_timestamp' => $currTime,
            'direction_type' => $this->conf['direction_type']['income'], // 收入
            'belong_id' => $incomeUid
        ];

        // 获取支出人余额
        $walletInfo = WalletNew::getInstance()->getWalletInfo($expendUid);
        // 判断支出人是否余额充足
        if($walletInfo['unconfirmed'] < $amount) {
            throw new Exception ('可用余额不足', 4222);
        }

        try {
            // 先扣除支出者余额
            WalletNew::getInstance()->updateUnconfirmed($expendUid, $amount, 'less');

            // 先生成收入者总账单
            $incomeBillId = $this->create($billData, $data);
            // 再生成收入者明细
            BillDetail::getInstance()->create($incomeBillId, [
                [
                    'belong_role' => $this->conf['belong_role']['user'],
                    'belong_id' => $incomeUid,
                    'currency_type' => 'vry',
                    'amount' => $vryAmount,
                    'origin' => 'general',
                    'create_timestamp' => $currTime,
                    'direction_type' => $this->conf['direction_type']['income'] // 收入
                ]
            ]);
            // 修改余额
            //WalletNew::getInstance()->updateBalanceCoupon($incomeUid, $amount, 'add');
            //0.9.8 广告场景更换 收入改为VRY
            WalletNew::getInstance()->updateBalanceVry($incomeUid, $vryAmount, 'add');
            // 操作交易完成
            $this->tradingFinish($incomeBillId);

            return [
                'orderID' => $incomeBillId,
                'currencyType'  => 'vry',
                'amount'        => Format::amount($vryAmount),
            ];
        } catch (Exception $e) {
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }

    /**
     * 锁定VRY（暂时只有选票用） 锁定VRY 单纯的从一个钱包转移到另一个钱包
     * @param $expendUid 支出用户ID
     * @param $amount 金额 Vry
     * @param $data [
     *         'uniqid' => '', // 第三方ID
     *         'title'  => '', // 标题
     *         'remark'  => '', // 备注（可为空）
     * ],
     * @param $action  默认为锁定，非0为解锁
     */
    public function lockVry($expendUid, $amount, $data, $action =0)
    {
        $amount = Format::formatVry($amount);
        $create_time = time();

        $billData = [
            'bill_type' => $this->conf['bill_type']['not_system'], // 锁定属于用户行为
            'trading_type' => $this->conf['trading_type']['transfer'], // 转账流程
            'direction_type' => $action == 0 ? $this->conf['direction_type']['expend'] : $this->conf['direction_type']['income'], // 收入
            'income_role'  => $action == 0 ? $this->conf['income_role']['system'] : $this->conf['income_role']['user'], // 收入角色是用户
            'expend_role' => $action == 0 ? $this->conf['expend_role']['user'] : $this->conf['expend_role']['system'] , // 支出角色是系统
            'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
            'belong_id' => $expendUid,
            'income_id' => $action == 0 ? 0 :$expendUid,
            'expend_id' => $action == 0 ? $expendUid : 0,
            'combine_currency_type' => $this->conf['combine_currency_type']['vry'],
            'amount'   => $amount,
            'create_timestamp' => $create_time
        ];
        try{
            //总账单生成
            $billId = $this->create($billData, $data);
            // 再生成明细
            BillDetail::getInstance()->create($billId, [
                [
                    'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
                    'belong_id' => $expendUid,
                    'currency_type' => 'vry',
                    'amount' => $amount,
                    'origin' => 'general',
                    'create_timestamp' => $create_time,
                    'direction_type' => $this->conf['direction_type']['expend'] // 支出
                ]
            ]);
            // 修改余额
            if($action == 0) {
                WalletNew::getInstance()->lockHandle($expendUid, $amount);
            } else {
                WalletNew::getInstance()->lockHandle($expendUid, $amount * -1);
            }
            // 操作交易完成
            $this->tradingFinish($billId);

            return true;
        } catch(\Exception $e) {
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }

    /**
     * 将VRY转入未确认钱包
     * @param $expendUid 支出用户ID
     * @param $amount 金额 Vry 请传给我vry
     * @param $data [
     *         'uniqid' => '', // 第三方ID
     *         'title'  => '', // 标题
     *         'remark'  => '', // 备注（可为空）
     * ]
     * @return $billId  账单ID
     */
    public function unconfirmedVry($expendUid, $amount, $data)
    {
        // 因为业务的调整，VRY不能直接打进待支付钱包
        exit;
        $currTime = time();
        $amount = Format::formatVry($amount);
        // 账单基础数据
        $billData = [
            'bill_type' => $this->conf['bill_type']['system'], // 系统交易
            'trading_type' => $this->conf['trading_type']['consume'], // 消费
            'income_role'  => $this->conf['income_role']['system'], // 收入角色是系统
            'expend_role' => $this->conf['expend_role']['user'], // 支出角色是用户
            'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
            'expend_id' => $expendUid,
            'amount'   => $amount,
            'create_timestamp' => $currTime,
            'direction_type' => $this->conf['direction_type']['expend'], // 支出
            'belong_id' => $expendUid
        ];

        // 获取支出人余额
        $walletInfo = WalletNew::getInstance()->getWalletInfo($expendUid);
        // 判断支出人是否余额充足
        if($walletInfo['balance_vry'] < $amount) {
            throw new Exception ('可用余额不足', 4222);
        }

        try {
            // 先生成支出者总账单
            $expendBillId = $this->create($billData, $data);

            $expendBillDetail[] = [
                'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
                'belong_id' => $expendUid,
                'currency_type' => 'vry',
                'amount' => $amount,
                'origin' => 'general',
                'create_timestamp' => $currTime,
                'direction_type' => $this->conf['direction_type']['expend'] // 支出
            ];
            BillDetail::getInstance()->create($expendBillId, $expendBillDetail);

            // 先扣除支出者余额
            WalletNew::getInstance()->updateBalanceVry($expendUid, $amount, 'less');

            // 增加收入者余额
            WalletNew::getInstance()->updateUnconfirmed($expendUid, $amount, 'add');

            // 操作交易完成
            $this->tradingFinish($expendBillId);

            return $expendBillId;
        } catch (Exception $e) {
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }

    /**
     * 将V点和V券转入未确认钱包
     * @param $expendUid 支出用户ID
     * @param $amount 金额 V点 请传给我v点
     * @param $data [
     *         'uniqid' => '', // 第三方ID
     *         'title'  => '', // 标题
     *         'remark'  => '', // 备注（可为空）
     * ]
     * @param $isApple
     * @return $billId  账单ID
     */
    public function unconfirmedV($expendUid, $amount, $data, $isApple = false)
    {
        // 格式化V点成VRY
        $amount = Format::encodeV($amount);
        $currTime = time();

        // 账单基础数据
        $billData = [
            'bill_type' => $this->conf['bill_type']['system'], // 系统交易
            'trading_type' => $this->conf['trading_type']['consume'], // 消费
            'income_role'  => $this->conf['income_role']['system'], // 收入角色是系统
            'expend_role' => $this->conf['expend_role']['user'], // 支出角色是用户
            'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
            'expend_id' => $expendUid,
            'combine_currency_type' => $this->conf['combine_currency_type']['v'],
            'amount'   => $amount,
            'create_timestamp' => $currTime,
            'direction_type' => $this->conf['direction_type']['expend'], // 支出
            'belong_id' => $expendUid
        ];

        // 获取支出人余额
        $walletInfo = WalletNew::getInstance()->getWalletInfo($expendUid);
        // 判断支出人是否余额充足
        $balance = $isApple ? $walletInfo['balance_apple_v']+$walletInfo['balance_coupon'] : $walletInfo['balance_v']+$walletInfo['balance_coupon'];
        if($balance < $amount) {
            throw new Exception ('可用余额不足', 4222);
        }

        try {
            // 先生成支出者总账单
            $expendBillId = $this->create($billData, $data);
            // 再生成支出者明细
            $expendBillDetail = [];
            $couponAmount = 0;
            // 如果v卷有余额
            if(0 < $walletInfo['balance_coupon']) {
                if($walletInfo['balance_coupon'] >= $amount) {
                    // 余额足够直接扣
                    $couponAmount = $amount;
                } else {
                    $couponAmount = $walletInfo['balance_coupon'];
                }
                $expendBillDetail[] = [
                    'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
                    'belong_id' => $expendUid,
                    'currency_type' => 'coupon',
                    'amount' => $couponAmount,
                    'origin' => 'general',
                    'create_timestamp' => $currTime,
                    'direction_type' => $this->conf['direction_type']['expend'] // 支出
                ];
            }
            // 如果V券扣完还不够，则从V点扣
            $vAmount = $amount - $couponAmount;
            if($vAmount) {
                $expendBillDetail[] = [
                    'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
                    'belong_id' => $expendUid,
                    'currency_type' => 'v',
                    'amount' => $vAmount,
                    'origin' => $isApple ? 'apple' : 'not_apple',
                    'create_timestamp' => $currTime,
                    'direction_type' => $this->conf['direction_type']['expend'] // 支出
                ];
            }
            BillDetail::getInstance()->create($expendBillId, $expendBillDetail);

            // 先扣除支出者余额
            if($couponAmount) {
                WalletNew::getInstance()->updateBalanceCoupon($expendUid, $couponAmount, 'less');
            }
            if($vAmount) {
                if($isApple) {
                    WalletNew::getInstance()->updateBalanceAppleV($expendUid, $vAmount, 'less');
                } else {
                    WalletNew::getInstance()->updateBalanceV($expendUid, $vAmount, 'less');
                }
            }

            // 增加收入者余额
            WalletNew::getInstance()->updateUnconfirmed($expendUid, $amount, 'add');

            // 操作交易完成
            $this->tradingFinish($expendBillId);

            return $expendBillId;
        } catch (Exception $e) {
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }

    /**
     * 将V点和V券从未确认钱包原路返回
     * @param $uidid 用户ID
     * $param $billId  操作V点进未确认钱包时返回的账单编号
     * @param $expendAmount  已消费了的金额 V点
     * @param $data [
     *         'uniqid' => '', // 第三方ID
     *         'title'  => '', // 标题
     *         'remark'  => '', // 备注（可为空）
     *         'scene_category' => '' // 业务场景
     * ]
     */
    public function refundUnconfirmedV($billId, $expendAmount, $data)
    {
        $expendAmount = Format::encodeV($expendAmount);
        $currTime = time();
        // 获取账单信息
        $billData = $this->getBillInfo($billId);
        // 判断余额是否超出
        if($billData['amount'] <= $expendAmount) {
            throw new Exception('无法退回', 4100);
        }

        $billDetail = BillDetail::getInstance()->getDetailByBillId($billId);

        // 退还总计
        $countRefundAmount = $billData['amount'] - $expendAmount;
        // 明细V点余额
        $detailVAmount = 0;
        // 明细V卷余额
        $detailCouponAmount = 0;
        // 是否苹果
        $isApple = false;

        // 先统计明细里面V点和V券的余额
        foreach ($billDetail as $k => $v) {
            if($v['currency_type'] == 1) {
                $detailVAmount += $v['amount'];
                if($v['origin'] == 2)
                    $isApple = true;
            }
            if($v['currency_type'] == 2) {
                $detailCouponAmount += $v['amount'];
            }
        }

        // 需要退还V卷多少给用户
        $returnCouponAmount = 0;
        // 需要退还V点多少给用户
        $returnVAmount = 0;

        if($detailCouponAmount > $expendAmount ) { // 如果V卷够，退V券和V点
            $returnCouponAmount = $detailCouponAmount - $expendAmount;
            $returnVAmount = $detailVAmount;
        } else if($detailCouponAmount == $expendAmount) { // 如果刚刚V卷没了，则只退V点
            $returnVAmount = $detailVAmount;
        } else if($detailCouponAmount < $expendAmount) { // 如果v卷不够，则计算只退V点
            $returnVAmount = $detailVAmount - ($expendAmount - $detailCouponAmount);
        }

        // 账单基础数据
        $newBillData = [
            'bill_type' => $this->conf['bill_type']['system'], // 系统交易
            'trading_type' => $this->conf['trading_type']['refund'], // 退还
            'income_role'  => $this->conf['income_role']['user'], // 收入角色是用户
            'expend_role' => $this->conf['expend_role']['system'], // 支出角色是系统
            'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
            'income_id' => $billData['belong_id'],
            'combine_currency_type' => $this->conf['combine_currency_type']['v'],
            'amount'   => $countRefundAmount,
            'create_timestamp' => $currTime,
            'direction_type' => $this->conf['direction_type']['income'], // 收入
            'belong_id' => $billData['belong_id']
        ];

        try {
            // 先生成收入者总账单
            $newBillId = $this->create($newBillData, $data);

            if($returnCouponAmount) {
                $newBillDetailData[] = [
                    'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
                    'belong_id' => $billData['belong_id'],
                    'currency_type' => 'coupon',
                    'amount' => $returnCouponAmount,
                    'origin' => 'general',
                    'create_timestamp' => $currTime,
                    'direction_type' => $this->conf['direction_type']['income'] // 收入
                ];
            }

            if($returnVAmount) {
                $newBillDetailData[] = [
                    'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
                    'belong_id' => $billData['belong_id'],
                    'currency_type' => 'v',
                    'amount' => $returnVAmount,
                    'origin' => $isApple ? 'apple' : 'not_apple',
                    'create_timestamp' => $currTime,
                    'direction_type' => $this->conf['direction_type']['income'] // 收入
                ];
            }

            BillDetail::getInstance()->create($newBillId, $newBillDetailData);

            // 减少余额
            WalletNew::getInstance()->updateUnconfirmed($billData['belong_id'], $countRefundAmount, 'less');

            // 增加余额V券
            if($returnCouponAmount) {
                WalletNew::getInstance()->updateBalanceCoupon($billData['belong_id'], $returnCouponAmount, 'add');
            }
            // 增加V点余额
            if($returnVAmount) {
                if(!$isApple) {
                    WalletNew::getInstance()->updateBalanceV($billData['belong_id'], $returnVAmount, 'add');
                } else {
                    WalletNew::getInstance()->updateBalanceAppleV($billData['belong_id'], $returnVAmount, 'add');
                }
            }

            // 操作交易完成
            $this->tradingFinish($newBillId);

            return true;
        } catch (Exception $e) {
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }

    /**
     * 将Vry从未确认钱包原路返回
     * @param $billId 账单ID
     * @param $expendAmount  已消费了的金额 Vry 传给我VRY
     * @param $data [
     *         'uniqid' => '', // 第三方ID
     *         'title'  => '', // 标题
     *         'remark'  => '', // 备注（可为空）
     *         'scene_category' => '' // 业务场景
     * ]
     */
    public function refundUnconfirmedVry($billId, $expendAmount, $data)
    {
        // 因为业务的调整，VRY不能直接打进待支付钱包
        exit;
        $amount = Format::formatVry($expendAmount);
        $create_time = time();
        // 获取账单信息
        $billData = $this->getBillInfo($billId);
        // 判断余额是否超出
        if($billData['amount'] <= $amount) {
            throw new Exception('无法退回', 4100);
        }
        // 退还总计
        $refundAmount = $billData['amount'] - $amount;
        $resData = [
            'bill_type' => $this->conf['bill_type']['system'], // 系统交易
            'trading_type' => $this->conf['trading_type']['refund'], // 退还
            'income_role'  => $this->conf['income_role']['user'], // 收入角色是系统
            'expend_role' => $this->conf['expend_role']['system'], // 支出角色是用户
            'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
            'income_id'   => $billData['belong_id'],
            'amount'   => $refundAmount,
            'create_timestamp' => $create_time,
            'direction_type' => $this->conf['direction_type']['income'], // 算到收入
            'belong_id' => $billData['belong_id']
        ];

        // 获取支出人余额
        $walletInfo = WalletNew::getInstance()->getWalletInfo($billData['belong_id']);
        // 判断支出人是否余额充足
        if($walletInfo['unconfirmed'] < $amount) {
            throw new Exception ('退还余额错误，或者可退余额不足', 4222);
        }

        try {
            $billId = $this->create($resData, $data);
            $billDetail[] = [
                'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
                'belong_id' => $billData['belong_id'],
                'currency_type' => 'vry',
                'amount' => $amount,
                'origin' => 'general',
                'create_timestamp' => $create_time,
                'direction_type' => $this->conf['direction_type']['income'] // 算到收入
            ];
            BillDetail::getInstance()->create($billId, $billDetail);
            //未确认钱包余额减少
            WalletNew::getInstance()->updateUnconfirmed($billData['belong_id'], $amount, 'less');
            //VRY 钱包余额增加
            WalletNew::getInstance()->updateBalanceVry($billData['belong_id'], $amount, 'add');

            // 操作交易完成
            $this->tradingFinish($billId);

            return $billId;
        } catch (Exception $e) {
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }

    /**
     * 临时方法，广告不存在订单ID 按VRY退回
     *
     * @param $uid
     * @param $amount
     * @param $data
     */
    public function refundAdVry($uid, $amount, $data)
    {
        exit;
        $amount = Format::formatVry($amount);
        $create_time = time();
        // 获取支出人余额
        $walletInfo = WalletNew::getInstance()->getWalletInfo($uid);
        // 判断支出人是否余额充足
        if($walletInfo['unconfirmed'] < $amount) {
            throw new Exception ('退还余额错误，或者可退余额不足', 4222);
        }

        $resData = [
            'bill_type' => $this->conf['bill_type']['system'], // 系统交易
            'trading_type' => $this->conf['trading_type']['refund'], // 退还
            'income_role'  => $this->conf['income_role']['user'], // 收入角色是系统
            'expend_role' => $this->conf['expend_role']['system'], // 支出角色是用户
            'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
            'income_id'   => $uid,
            'amount'       => $amount,
            'create_timestamp' => $create_time,
            'direction_type' => $this->conf['direction_type']['income'], // 算到收入
            'belong_id' => $uid
        ];
        try {
            $billId = $this->create($resData, $data);
            $billDetail[] = [
                'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
                'belong_id' => $uid,
                'currency_type' => 'vry',
                'amount' => $amount,
                'origin' => 'general',
                'create_timestamp' => $create_time,
                'direction_type' => $this->conf['direction_type']['income'] // 算到收入
            ];
            BillDetail::getInstance()->create($billId, $billDetail);
            //未确认钱包余额减少
            WalletNew::getInstance()->updateUnconfirmed($uid, $amount, 'less');
            //VRY 钱包余额增加
            WalletNew::getInstance()->updateBalanceVry($uid, $amount, 'add');

            // 操作交易完成
            $this->tradingFinish($billId);

            return $billId;
        } catch (Exception $e) {
            throw new Exception($e->getMessage(), $e->getCode());
        }


    }

    /**
     * VRY 转账
     *
     * @param $income_id  接收人id
     * @param $expend_id  发送人id
     * @param $amount     发送金额
     * @param $data [
     *         'uniqid' => '', // 第三方ID
     *         'income_title'  => '', // 收入者标题
     *         'expend_title'  => '', // 支出者标题
     *         'remark'  => '', // 备注（可为空）
     *         'scene_category' => '' // 业务场景
     */
    public function transferVry($income_id, $expend_id, $amount, $data)
    {
        $amount = Format::formatVry($amount);
        $create_time = time();

        $checkAamount = abs ($amount );
        if ($checkAamount === 0) {
            throw new Exception ( '转账金额为0', 4031 );
        }

        //判断支出人是否余额充足
        $walletInfo = WalletNew::getInstance()->getWalletInfo($expend_id);
        if($walletInfo['balance_vry'] < $amount) {
            throw new Exception ('钱包金额不足，不能完成转账', 4222);
        }
        try{
            //先扣除支出人的
            foreach(['expend', 'income'] as $value) {
                $transferData = [
                    'bill_type' => $this->conf['bill_type']['not_system'], // 非系统交易
                    'trading_type' => $this->conf['trading_type']['transfer'], // 转账
                    'income_role'  => $this->conf['income_role']['user'], // 收入角色是系统
                    'expend_role' => $this->conf['expend_role']['user'], // 支出角色是用户
                    'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
                    'income_id'   => $income_id,
                    'expend_id'   => $expend_id,
                    'combine_currency_type' => $this->conf['combine_currency_type']['vry'],
                    'amount'      => $amount,
                    'create_timestamp' => $create_time,
                    'direction_type' => $value == 'expend' ? $this->conf['direction_type']['expend'] : $this->conf['direction_type']['income'], // 支出
                    'belong_id' => $value == 'expend' ? $expend_id : $income_id
                ];
                if(isset($data['expend_title']) || isset($data['expend_title'])) {
                    $data['title'] = $value == 'expend' ? $data['expend_title'] : $data['income_title'];
                }
                $billId = $this->create($transferData, $data);
                $billDetail = [
                    'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
                    'belong_id' => $value == 'expend' ? $expend_id : $income_id,
                    'currency_type' => 'vry',
                    'amount' => $amount,
                    'origin' => 'general',
                    'create_timestamp' => $create_time,
                    'direction_type' => $value == 'expend' ? $this->conf['direction_type']['expend'] : $this->conf['direction_type']['income']// 支出
                ];
                BillDetail::getInstance()->create($billId, $billDetail);
                if($value == 'expend') {
                    WalletNew::getInstance()->updateBalanceVry($expend_id, $amount, 'less');
                } else {
                    WalletNew::getInstance()->updateBalanceVry($income_id, $amount, 'add');
                }
                $this->tradingFinish($billId);
            }

            return $billId;
        } catch(\Exception $e) {
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }

    /**
     * VRY 转换为V券
     * @param $uid
     * @param $amount
     * @param $data
     */
    public function VryToCoupon($uid, $amount, $data)
    {
        $expendAmount = Format::formatVry($amount);
        $incomeAmount = Format::encodeV(Format::vryExchangeV($amount));
        $create_time = time();
        // 获取支出人余额
        $walletInfo = WalletNew::getInstance()->getWalletInfo($uid);
        // 判断支出人是否余额充足
        if($walletInfo['balance_vry'] < $expendAmount) {
            throw new Exception ('余额不足，不能发起兑换', 4222);
        }

        try{
            //先扣除支出VRY 然后增加收入V点
            foreach(['expend', 'income'] as $value) {
                $transferData = [
                    'bill_type' => $this->conf['bill_type']['not_system'], // 非系统交易
                    'trading_type' => $this->conf['trading_type']['transfer'], // 转账
                    'income_role'  => $this->conf['income_role']['user'], // 收入角色是系统
                    'expend_role' => $this->conf['expend_role']['user'], // 支出角色是用户
                    'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
                    'income_id'   => $uid,
                    'expend_id'   => $uid,
                    'combine_currency_type' => $value == 'expend' ? $this->conf['combine_currency_type']['vry'] : $this->conf['combine_currency_type']['v'],
                    'amount'      => $value == 'expend' ? $expendAmount : $incomeAmount,
                    'create_timestamp' => $create_time,
                    'direction_type' => $value == 'expend' ? $this->conf['direction_type']['expend'] : $this->conf['direction_type']['income'], // 支出
                    'belong_id' => $uid
                ];
                if(isset($data['expend_title']) || isset($data['expend_title'])) {
                    $data['title'] = $value == 'expend' ? $data['expend_title'] : $data['income_title'];
                }

                $billId = $this->create($transferData, $data);
                $billDetail = [
                    'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
                    'belong_id' => $uid,
                    'currency_type' => $value == 'expend' ? 'vry' : 'v',
                    'amount' => $value == 'expend' ? $expendAmount : $incomeAmount,
                    'origin' => 'general',
                    'create_timestamp' => $create_time,
                    'direction_type' => $value == 'expend' ? $this->conf['direction_type']['expend'] : $this->conf['direction_type']['income']// 支出
                ];
                BillDetail::getInstance()->create($billId, $billDetail);
                if($value == 'expend') {
                    WalletNew::getInstance()->updateBalanceVry($uid, $expendAmount, 'less');
                } else {
                    WalletNew::getInstance()->updateBalanceCoupon($uid, $incomeAmount, 'add');
                }
                $this->tradingFinish($billId);
            }

            return $billId;
        } catch(\Exception $e) {
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }


    /**
     * 扣款订单原路返回 只支持系统扣款类的订单
     *
     * @param $orderid
     * @param $amount
     * @param $data
     */
    public  function refund($incomeUid, $amount, $data, $billId)
    {
        $amount = Format::encodeV($amount);
        $currTime = time();

        $orderDetail = $this->getOne()->select('bill_detail', '*', ['bill_id' => $billId])['data'];

        // 账单基础数据
        $newBillData = [
            'bill_type' => $this->conf['bill_type']['system'], // 系统交易
            'trading_type' => $this->conf['trading_type']['refund'], // 退还
            'income_role'  => $this->conf['income_role']['user'], // 收入角色是用户
            'expend_role' => $this->conf['expend_role']['system'], // 支出角色是系统
            'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
            'income_id' => $incomeUid,
            'combine_currency_type' => $this->conf['combine_currency_type']['v'],
            'amount'   => $amount,
            'create_timestamp' => $currTime,
            'direction_type' => $this->conf['direction_type']['income'], // 收入
            'belong_id' => $incomeUid
        ];

        try {
            // 先生成收入者总账单
            $newBillId = $this->create($newBillData, $data);
            foreach($orderDetail as $detail) {
                $billDetail = [
                    'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
                    'belong_id' => $incomeUid,
                    'currency_type' => 'v',
                    'amount' => $detail['amount'],
                    'origin' => 'general',
                    'create_timestamp' => $currTime,
                    'direction_type' => $this->conf['direction_type']['income']// 支出
                ];

                BillDetail::getInstance()->create($newBillId, $billDetail);
                if($detail['currency_type'] == 2) {
                    WalletNew::getInstance()->updateBalanceCoupon($incomeUid, $detail['amount'], 'add');
                }
                if($detail['currency_type'] == 1) {
                    if($detail['origin'] == 2) {
                        //苹果点
                        WalletNew::getInstance()->updateBalanceAppleV($incomeUid, $detail['amount'], 'add');
                    }
                    if($detail['origin'] == 3) {
                        //非苹果点
                        WalletNew::getInstance()->updateBalanceV($incomeUid, $detail['amount'], 'add');
                    }
                }
            }

            // 操作交易完成
            $this->tradingFinish($newBillId);
            return $newBillId;
        } catch (Exception $e) {
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }

    /**
     * 扣除V点 到系统
     *
     * @param $uid
     * @param $amount
     * @param $data
     */
    public function consumeVtoSystem($uid, $amount, $data, $isApple = false)
    {
        $amount = Format::encodeV($amount);
        $create_time = time();
        $resData = [
            'bill_type' => $this->conf['bill_type']['system'], // 系统交易
            'trading_type' => $this->conf['trading_type']['consume'], // 退还
            'income_role'  => $this->conf['income_role']['system'], // 收入角色是系统
            'expend_role' => $this->conf['expend_role']['user'], // 支出角色是用户
            'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
            'expend_id'   => $uid,
            'combine_currency_type' => $this->conf['combine_currency_type']['v'],
            'amount'       => $amount,
            'create_timestamp' => $create_time,
            'direction_type' => $this->conf['direction_type']['expend'], // 算到收入
            'belong_id' => $uid
        ];

        // 获取支出人余额
        $walletInfo = WalletNew::getInstance()->getWalletInfo($uid);
        // 判断支出人是否余额充足
        $balance = $isApple ? $walletInfo['balance_apple_v']+$walletInfo['balance_coupon'] : $walletInfo['balance_v']+$walletInfo['balance_coupon'];
        if($balance < $amount) {
            throw new Exception ('可用余额不足', 4222);
        }

        try {
            $billId = $this->create($resData, $data);
            // 再生成支出者明细
            $expendBillDetail = [];
            $couponAmount = 0;
            // 如果v卷有余额
            if(0 < $walletInfo['balance_coupon']) {
                if($walletInfo['balance_coupon'] >= $amount) {
                    // 余额足够直接扣
                    $couponAmount = $amount;
                } else {
                    $couponAmount = $walletInfo['balance_coupon'];
                }
                $expendBillDetail[] = [
                    'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
                    'belong_id' => $uid,
                    'currency_type' => 'coupon',
                    'amount' => $couponAmount,
                    'origin' => 'general',
                    'create_timestamp' => $create_time,
                    'direction_type' => $this->conf['direction_type']['expend'] // 支出
                ];
            }
            // 如果V券扣完还不够，则从V点扣
            $vAmount = $amount - $couponAmount;
            if($vAmount) {
                $expendBillDetail[] = [
                    'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
                    'belong_id' => $uid,
                    'currency_type' => 'v',
                    'amount' => $vAmount,
                    'origin' => $isApple ? 'apple' : 'not_apple',
                    'create_timestamp' => $create_time,
                    'direction_type' => $this->conf['direction_type']['expend'] // 支出
                ];
            }
            BillDetail::getInstance()->create($billId, $expendBillDetail);

            // 先扣除支出者余额
            if($couponAmount) {
                WalletNew::getInstance()->updateBalanceCoupon($uid, $couponAmount, 'less');
            }
            if($vAmount) {
                if($isApple) {
                    WalletNew::getInstance()->updateBalanceAppleV($uid, $vAmount, 'less');
                } else {
                    WalletNew::getInstance()->updateBalanceV($uid, $vAmount, 'less');
                }
            }
            // 操作交易完成
            $this->tradingFinish($billId);

            return $billId;
        } catch (Exception $e) {
            throw new Exception($e->getMessage(), $e->getCode());
        }

    }

    /**
     * 系统赠送VRY  举报奖励 审核工资
     *
     * @param $uid
     * @param $amount
     * @param $data
     */
    public function SystemToVry($uid, $amount, $data)
    {
        $amount = Format::formatVry($amount);
        $create_time = time();
        $resData = [
            'bill_type' => $this->conf['bill_type']['system'], // 系统交易
            'trading_type' => $this->conf['trading_type']['recharge'], // 退还
            'income_role'  => $this->conf['income_role']['system'], // 收入角色是系统
            'expend_role' => $this->conf['expend_role']['user'], // 支出角色是用户
            'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
            'income_id'   => $uid,
            'combine_currency_type' => $this->conf['combine_currency_type']['vry'],
            'amount'       => $amount,
            'create_timestamp' => $create_time,
            'direction_type' => $this->conf['direction_type']['income'], // 算到收入
            'belong_id' => $uid
        ];

        try {
            $billId = $this->create($resData, $data);

            $expendBillDetail[] = [
                'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
                'belong_id' => $uid,
                'currency_type' => 'vry',
                'amount' => $amount,
                'origin' => 'general',
                'create_timestamp' => $create_time,
                'direction_type' => $this->conf['direction_type']['income'] // 支出
            ];

            WalletNew::getInstance()->updateBalanceVry($uid, $amount, 'add');
            // 操作交易完成
            $this->tradingFinish($billId);

            return $billId;
        } catch (Exception $e) {
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }

    /**
     * 系统费用， 手续费  目前只支持VRY 扣除
     *
     * @param $uid
     * @param $amount
     * @param $data
     * @param string $type
     */
    public function SystemCharge($uid, $amount, $data,$type = 'VRY')
    {
//        if($type == 'VRY') {
        $amount = Format::formatVry($amount);
//        } else {
//            $amount = Format::encodeV($amount);
//        }
        $create_time = time();

        $resData = [
            'bill_type' => $this->conf['bill_type']['system'], // 系统交易
            'trading_type' => $this->conf['trading_type']['consume'], // 退还
            'income_role'  => $this->conf['income_role']['system'], // 收入角色是系统
            'expend_role' => $this->conf['expend_role']['user'], // 支出角色是用户
            'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
            'expend_id'   => $uid,
            'combine_currency_type' => $this->conf['combine_currency_type']['vry'],
            'amount'       => $amount,
            'create_timestamp' => $create_time,
            'direction_type' => $this->conf['direction_type']['expend'], // 算到收入
            'belong_id' => $uid
        ];

        try {
            $billId = $this->create($resData, $data);
            $billDetail[] = [
                'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
                'belong_id' => $uid,
                'currency_type' => 'vry',
                'amount' => $amount,
                'origin' => 'general',
                'create_timestamp' => $create_time,
                'direction_type' => $this->conf['direction_type']['expend'] // 算到收入
            ];
            BillDetail::getInstance()->create($billId, $billDetail);
            //VRY 钱包减少
            WalletNew::getInstance()->updateBalanceVry($uid, $amount, 'less');

            // 操作交易完成
            $this->tradingFinish($billId);

            return $billId;
        } catch (Exception $e) {
            throw new Exception($e->getMessage(), $e->getCode());
        }

    }

    /**
     * 扣除支出者待确认钱包V点 余额 到用户的VRY
     *
     * @param $incomeId
     * @param $expendId
     * @param $amount
     * @param $external
     */
    public function unconfirmedVToVry($incomeId, $expendId, $amount, $external)
    {
        $expendAmount = Format::encodeV($amount);
        $incomeAmount = Format::formatVry(Format::vExchangeVry($amount));
        $currTime = time();
        try{
            // 账单基础数据
            $newBillData = [
                'bill_type' => $this->conf['bill_type']['system'], // 系统交易
                'trading_type' => $this->conf['trading_type']['consume'], // 退还
                'income_role'  => $this->conf['income_role']['user'], // 收入角色是用户
                'expend_role' => $this->conf['expend_role']['system'], // 支出角色是系统
                'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
                'income_id' => $incomeId,
                'expend_id' => $expendId,
                'create_timestamp' => $currTime,
            ];
            foreach(['expend', 'income'] as $value) {
                $newBillData['direction_type'] = $value == 'expend' ? $this->conf['direction_type']['expend'] : $this->conf['direction_type']['income'];
                $newBillData['belong_id'] = $value == 'expend' ? $expendId : $incomeId;
                if(isset($external['expend_title']) || isset($external['expend_title'])) {
                    $external['title'] = $value == 'expend' ? $external['expend_title'] : $external['income_title'];
                }
                if($value == 'expend') {
                    $newBillData['combine_currency_type'] = $this->conf['combine_currency_type']['v'];
                    $newBillData['amount'] = $expendAmount;
                } else {
                    $newBillData['combine_currency_type'] = $this->conf['combine_currency_type']['vry'];
                    $newBillData['amount'] = $incomeAmount;
                }

                $newBillId = $this->create($newBillData, $external);
                if($value == 'expend') {
                    $billDetail = [
                        'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
                        'belong_id' => $expendId,
                        'create_timestamp' => $currTime,
                        'direction_type' => $this->conf['direction_type']['expend']// 支出
                    ];
                    foreach($external['billDetail'] as $origin => $originAmount){
                        $billDetail['origin'] = $origin;
                        $billDetail['currency_type'] = $origin == 'general' ? 'coupon' : 'v';
                        $billDetail['amount'] = $originAmount;
                        BillDetail::getInstance()->create($newBillId, $billDetail);
                    }

                } else {
                    $billDetail = [
                        'belong_role' => $this->conf['belong_role']['user'], // 所属角色是用户
                        'belong_id' => $incomeId,
                        'currency_type' => 'vry',
                        'amount' => $incomeAmount,
                        'origin' => 'general',
                        'create_timestamp' => $currTime,
                        'direction_type' => $this->conf['direction_type']['income'] // 算到收入
                    ];
                    BillDetail::getInstance()->create($newBillId, $billDetail);
                }
            }

            //未确认钱包余额减少
            WalletNew::getInstance()->updateUnconfirmed($expendId, $expendAmount, 'less');
            //VRY 钱包余额增加
            WalletNew::getInstance()->updateBalanceVry($incomeId, $incomeAmount, 'add');
            return $newBillId;
        } catch (Exception $e) {
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }
}