<?php
namespace HttpApi\Model\WalletNew;

use Beahoo\Exception;
use HttpApi\Model\Wallet\WalletBase;
use HttpApi\Model\WalletNew\Bill;

/**
 * 文章购买相关
 *
 * Class Assets
 * @package HttpApi\Model\WalletNew|
 */
class Thread extends WalletBase
{
    private $isApple = false;

    /**
     * 文章购买订单生成  先扣除购买者的钱，打入文章作者的钱包， 然后逐级从你作者钱包分成给转发者
     *
     * @param $data
     */
    public function create($data)
    {
        $data ['plan'] = intval ( $data ['plan'] ?? 0);
        //读取配置
        $thread = Config::read ( 'thread' );
        if($data['device_platform'] == 'ios') {
            $this->isApple = true;
        }
        $this->transaction_start ();
        try{
            //扣除购买者费用 增加作者收入
            $external = [
                'uniqid' => $data['tid'],
                'income_title'  => $data['income_title'],
                'expend_title'  => $data['expend_title'],
                'remark' => $data['remark'],
                'scene_category' => 'Thread_Buy'
            ];
            Bill::getInstance()->expendVToIncomeVry($data ['income_id'], $data['expend_id'], $data['amount'], $external, $this->isApple);
            //扣除手续费
            /*  TODO
            if ($thread ['system_fee']) {
                $param = [
                    'expend_id' => $data ['income_id'],
                    'amount' => $data['amount'] * $thread ['system_fee'],
                    'category' => 'System_Fee',
                    'title'    => '系统手续费',
                    'uniqid' => $data ['tid'] . '-' . $data ['income_id']
                ];
                Bill::getInstance()->SystemCharge($data ['income_id'], $param['amount'], $param);
            }
            */
            //统计用户当日收入 Redis Key
            /*
            $redis = SDKs::getRedis();
            $dateformat=date('ymd');
            $expireat=strtotime('+1 day',strtotime(date('Y-m-d')))-1;
            $user_all_key_string='user_'.$dateformat.'_all_amount';
            */
            //发放转发分成
            if ($data ['plan'] && $data ['channel']) {
                foreach ( $data ['channel'] as $level => $channel ) {
                    if ($thread ['channel'] [$data ['plan']] [$level]) {
                        $planParam = [
                            'scene_category' => 'Thread_Spread',
                            'income_title'   =>  $data['income_title'],
                             'expend_title'  => $data['income_title'], // 支出者标题
                             'remark'        => $data, // 备注（可为空）
                            'uniqid' => "{$data['tid']}-{$channel}-{$level}-{$data['income_id']}"
                        ];
                        $amount = $data ['amount']  * $thread ['channel'] [$data ['plan']] [$level];
                        Bill::getInstance()->transferVry($channel, $data['income_id'], $amount, $planParam);
                        // 今日收益
                        //$redis->hincrbyfloat($user_all_key_string,$channel, $amount/1000000);
                        //$redis->expireat($user_all_key_string,$expireat);
                    }
                }
            }


        } catch (Exception $e) {
            throw new Exception($e->getMessage(), $e->getCode());
        }




    }
}