<?php
namespace HttpApi\Model\WalletNew;

use Beahoo\Exception;
use HttpApi\Model\Wallet\Details;
use HttpApi\Tool\Format;
use HttpApi\Model\User\User;
/**
 * IM 相关钱包操作  消费V点/V券 获得VRY
 *
 * Class Assets
 * @package HttpApi\Model\WalletNew|
 */
class IM extends Bill
{
    protected $tableName = 'redpack_detail';

    /**
     *  预付款 先放入待确认钱包 只进行款项的转移
     *
     * @param $data  [expendid, amount, chatid, isApple]
     * @return mixed
     */
    public function imprest($expendid, $incomeid, $amount, $chatid, $uniqid, $category, $isApple = false)
    {
        //获取钱包余额
        $amount = abs($amount);
        $walletInfo = WalletNew::getInstance()->getWalletInfo($expendid);
        $balance = $isApple ? $walletInfo['balance_apple_v']+$walletInfo['balance_coupon'] : $walletInfo['balance_v']+$walletInfo['balance_coupon'];
        if($balance < $amount) {
            throw new Exception ('可用余额不足', 4222);
        }
        $couponAmount = 0;
        if(0 < $walletInfo['balance_coupon']) {
            if($walletInfo['balance_coupon'] >= $amount) {
                // 余额足够直接扣
                $couponAmount = $amount;
            } else {
                $couponAmount = $walletInfo['balance_coupon'];
            }
        }

        $save = [
            'belong_id' => $expendid,
            'income_id' => $incomeid,
            'uniqid'    => $uniqid,
            'chatid'    => $chatid,
            'category'  => $category,
            'create_timestamp' => time()
        ];
        // 如果V券扣完还不够，则从V点扣
        $vAmount = $amount - $couponAmount;
        // 先扣除支出者余额

        if($couponAmount) {
            $save['amount'] = Format::encodeV($couponAmount);
            $save['origin'] = 3;
            WalletNew::getInstance()->updateBalanceCoupon($expendid, Format::encodeV($couponAmount), 'less');
            $insertid =  $this->getOne()->insert($this->tableName, $save)['insertid'];
        }
        if($vAmount > 0) {
            if($isApple) {
                $save['amount'] = Format::encodeV($vAmount);
                $save['origin'] = $isApple ? 1 : 2;
                WalletNew::getInstance()->updateBalanceAppleV($expendid, Format::encodeV($vAmount), 'less');
                $insertid = $this->getOne()->insert($this->tableName, $save)['insertid'];
            } else {
                $save['amount'] = Format::encodeV($vAmount);
                $save['origin'] = $isApple ? 1 : 2;
                WalletNew::getInstance()->updateBalanceV($expendid, Format::encodeV($vAmount), 'less');
                $insertid =  $this->getOne()->insert($this->tableName, $save)['insertid'];
            }
        }
        WalletNew::getInstance()->updateUnconfirmed($expendid, Format::encodeV($amount), 'add');
        return $insertid;
    }
    //生成最终账单

    /**
     * @param $incomeId
     * @param $expendId
     * @param $amount   //V点
     * @param $chatid
     * @param $data
     * @return mixed
     * @throws Exception
     */
    public function createBill($incomeId, $expendId, $amount, $chatid, $data)
    {
        $external = [];
        try{
            $incomeInfo = User::getInstance()->getOne()->selectOne('userinfo', ['nickname'], ['id' => $incomeId])['data'];
            $expendInfo = User::getInstance()->getOne()->selectOne('userinfo', ['nickname'], ['id' => $expendId])['data'];
            if($data['category'] == Details::Chat) {
                $category = 'Chat';
                $external['income_title'] = '图文语音信息-'.$incomeInfo['nickname'] ;
                $external['expend_title'] = '图文语音信息-'.$expendInfo['nickname'];
            }
            if($data['category'] == Details::Audio) {
                $category = 'Audio';
                $external['income_title'] = '语音通话-'.$incomeInfo['nickname'] ;
                $external['expend_title'] = '语音通话-'.$expendInfo['nickname'];
            }
            if($data['category'] == Details::Video) {
                $category = 'Video';
                $external['income_title'] = '视频通话-'.$incomeInfo['nickname'] ;
                $external['expend_title'] = '视频通话-'.$expendInfo['nickname'];
            }
            $external['uniqid'] = $chatid;
            $external['remark'] = $data['remark'];
            $external['scene_category'] = $category;

            $imDetail = $this->getOne()->select(
                $this->tableName,
                '*',
                ['chatid' => $chatid, 'status' => 2, 'belong_id' => $expendId, 'income_id' => $incomeId])['data'];
            if($imDetail) {
                $billDetail = [];
                foreach($imDetail as $detail) {
                    if($detail['origin'] == 1) {
                        if(!isset($billDetail['apple'])) {
                            $billDetail['apple'] = 0;
                        }
                        $billDetail['apple'] += $detail['amount'];
                    }
                    if($detail['origin'] == 2) {
                        if(!isset($billDetail['not_apple'])) {
                            $billDetail['not_apple'] = 0;
                        }
                        $billDetail['not_apple'] += $detail['amount'];
                    }
                    if($detail['origin'] == 3) {
                        if(!isset($billDetail['general'])) {
                            $billDetail['general'] = 0;
                        }
                        $billDetail['general'] += $detail['amount'];
                    }
                }
            }
            $external['billDetail'] = $billDetail;
            $orderid = Bill::getInstance()->unconfirmedVToVry($incomeId, $expendId, $amount, $external);
            return $orderid;

        } catch(\Exception $e) {
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }
    // 退还  减少支出者的待确认钱包余额  增加收入者对应的钱包余额
    public function recall($incomeId, $expendId, $amount, $origin)
    {
        //转换为数据库支持的V点格式
        $amount = Format::encodeV($amount);
        try{
            if($origin == 1) {
                WalletNew::getInstance()->updateBalanceAppleV($incomeId, $amount, 'add');
            } else if($origin == 2) {
                WalletNew::getInstance()->updateBalanceV($incomeId, $amount, 'add');
            } else {
                WalletNew::getInstance()->updateBalanceCoupon($incomeId, $amount, 'add');
            }
            WalletNew::getInstance()->updateUnconfirmed($expendId, $amount, 'less');
        }catch(Exception $e){
            throw new Exception('退还失败', 3001);
        }
    }

    public function queryDetail($data)
    {
        $limit = 100;
        $offset = 0;
        foreach (explode(',', 'offset,limit,begin,end') as $key) {
            if (isset($data[$key])) {
                $$key = $data[$key];
                unset($data[$key]);
            }
        }
        //新老钱包映射
        $fields = ['recorder' => 'belong_id','receiver' => 'income_id'];
        if(isset($data['recorder']) && !is_int($data['recorder'])) {
            $data['recorder'] = 0;
        }
        if(isset($data['receiver']) && !is_int($data['receiver'])) {
            $data['recorder'] = 0;
        }
        if(isset($data['direction'])) {
            $data['direction'] = $data['direction'] == 'income' ? 1 : 2;
        }
        foreach($fields as $key => $field) {
            if(isset($data[$key])) {
                $data[$field] = $data[$key];
                unset($data[$key]);
            }
        }
        $details = $this->getOne()->select($this->tableName, '*', $data, ($offset ? (empty($data) ? "" : "and ") . "id < {$offset} " : '') . 'order by id desc', 0, $limit);
        if (empty($details['data'])) {
            throw new Exception('没有结果', 4000);
        } else {
            $detail = $details['data'];
            foreach ($detail as $key =>  $v) {
                $detail[$key]['amount'] = Format::decodeV($v['amount']);
            }
        }
        return $detail;
    }
}