<?php
namespace HttpApi\Model\WalletNew;

use Beahoo\Exception;
use HttpApi\Model\Wallet\WalletBase;

/**
 * 广告相关的钱包操作
 *
 * Class Assets
 * @package HttpApi\Model\WalletNew|
 */
class AdWords extends WalletBase
{
    /**
     * 新建广告，创建广告  将用户的V点和V券转移至未确认的钱包
     *
     * @param $uid
     * @param $amount
     * @param $data
     * @return mixed
     * @throws Exception
     */
    public function create($uid, $amount, $data)
    {
        /*
         * 用户打广告
         */

        $isApple = false;
        try{
            $external = [
                'uniqid' => $data['uniqid'],
                'title'  => $data['title'],
                'remark' => $data['remark'],
                'scene_category' => 'AdWords'
            ];
            if($data['device_platform'] == 'ios') {
                $isApple = true;
            }
            //此处消费的是V点 单位是V点
            if($data['type'] == 'VRY') {
                //通过VRY 打广告
                $orderid = Bill::getInstance()->unconfirmedVry($uid, $amount, $external);
            } else {
                //通过V点打广告
                $orderid = Bill::getInstance()->unconfirmedV($uid, $amount, $external, $isApple);
            }


            return $orderid;

        } catch(\Exception $e) {
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }

    /**
     * @param $uid   浏览广告者ID
     * @param $adsId  广告商ID
     * @param $amount  获得金额   单位V点
     * @param $data    其他
     * @return mixed
     * @throws Exception
     */
    public function look($uid, $adsId,$amount, $data)
    {
        try{
            $external = [
                'uniqid' => $data['uniqid'],
                'title'  => $data['title'],
                'remark' => $data['remark'],
                'scene_category' => 'AdSense'
            ];

            //此处消费的是V点 单位是V点
            $orderid = Bill::getInstance()->unconfirmedVToCoupon($uid, $adsId, $amount, $external);

            return $orderid;

        } catch(\Exception $e) {
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }

    /**
     * 广告终止，费用退还  @TODO
     *
     * @param $amount  需退还金额
     * @param
     *       $data = [
     *         'uniqid' => '', // 第三方ID
     *         'title'  => '', // 标题
     *         'remark'  => '', // 备注（可为空）
     *         'scene_category' => '' // 业务场景
     *          'type'    =>    'VRY / V'
     *          'uid'     =>     '' //广告商ID
     *           'orderId'  =>    ''   //广告订单支付ID
     */
    public function refund($useAmount, $restAmount,  $data)
    {
        //通过uniqid 和 scene_category  定位打广告时的orderid  @TODO
        //$orderinfo = Bill::getInstance()->select('bill', '*', ['uniqid' => $data['uniqid'], 'scene_category' => 9, 'belong_id' => $data['uid']])['data'];
        //$data['orderId'] = $orderinfo['id'];
        try{
            $external = [
                'uniqid' => $data['uniqid'],
                'title'  => $data['title'],
                'remark' => $data['remark'],
                'scene_category' => 'AdWords_Cancel'
            ];
            if($data['uniqid'] <= 0000 && empty($data['orderId'])) {  //广告数据迁移的时候记录ID 节点
                $orderid = Bill::getInstance()->refundAdVry($data['uid'], $restAmount, $external);
            } else {
                $orderid = Bill::getInstance()->refundUnconfirmedV($data['orderId'] , $useAmount, $external);
            }

            if(empty($data['orderId'])) {
                throw new  Exception('无法定位发布广告时的订单ID', 4001);
            }

            return $orderid;

        } catch(\Exception $e) {
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }
}