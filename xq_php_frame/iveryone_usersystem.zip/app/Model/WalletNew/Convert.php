<?php
namespace HttpApi\Model\WalletNew;

use Beahoo\Exception;
use HttpApi\Model\Wallet\WalletBase;
use HttpApi\Model\WalletNew\Bill;
use HttpApi\Tool\Format;

/**
 * VRY 转换为V点
 *
 * Class Assets
 * @package HttpApi\Model\WalletNew|
 */
class Convert extends \HttpApi\Model\BaseModel
{


    protected $tableName = 'convert';
    /**
     * VRY 转换为V点
     *
     * @param $uid
     * @param $amount
     * @param $data
     */
    public function create($uid, $amount, $data)
    {
        $this->transaction_start();
        try{
            $external = [
                'uniqid' => $data['uniqid'],
                'expend_title'  => $data['expend_title'] ? $data['expend_title'] : '发起VRY到V点代金券的兑换',
                'income_title'  => $data['income_title'] ? $data['expend_title'] : 'VRY兑换所得',
                'remark' => $data['remark'],
                'scene_category' => 'VRY_Convert_V'
            ];

            $orderid = Bill::getInstance()->VryToCoupon($uid, $amount, $external);
            $this->getOne()->insert($this->tableName, ['uid' => $uid, 'amount' => Format::formatVry($amount), 'orderid' => $orderid, '	create_time' => time()]);
            $this->transaction_commit();
            return $orderid;

        } catch(\Exception $e) {
            $this->transaction_rollback();
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }
}