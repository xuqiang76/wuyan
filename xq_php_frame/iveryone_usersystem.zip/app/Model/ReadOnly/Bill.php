<?php
/**
 * Created by PhpStorm.
 * User: zhangyuanhao
 * Date: 2018/6/15
 * Time: 18:11
 */

namespace HttpApi\Model\ReadOnly;

class Bill extends BaseModel
{
    protected $tableName = 'bill';
    protected static $instance = [ ];

    public static function getInstance() {
        $class = get_called_class ();
        if (! isset ( self::$instance [$class] )) {
            self::$instance [$class] = new $class ();
        }
        return self::$instance [$class];
    }
}