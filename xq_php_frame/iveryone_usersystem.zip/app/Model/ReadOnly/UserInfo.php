<?php
/**
 * Created by PhpStorm.
 * User: zhangyuanhao
 * Date: 2018/6/15
 * Time: 18:17
 */

namespace HttpApi\Model\ReadOnly;


class UserInfo extends BaseModel
{
    protected $tableName = 'userinfo';
    protected static $instance = [ ];

    public static function getInstance() {
        $class = get_called_class ();
        if (! isset ( self::$instance [$class] )) {
            self::$instance [$class] = new $class ();
        }
        return self::$instance [$class];
    }
}