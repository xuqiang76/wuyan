<?php
/**
 * Created by PhpStorm.
 * User: zhangyuanhao
 * Date: 2018/6/20
 * Time: 10:56
 */

namespace HttpApi\Model\Orders;

use Beahoo\Exception;

class Orders extends \HttpApi\Model\BaseModel
{
    protected $tableName = 'orders';
    protected static $instance = [ ];

    private $payType = [
        1 => 'alipay',
        2 => 'wechat',
        3 => 'apple'
    ];

    private $status = [
        1 => '等待用户付款',
        2 => '付款处理中',
        3 => '支付成功',
        4 => '支付失败'
    ];

    private $platform = [
        1 => 'ios',
        2 => 'android',
        3 => 'h5',
        4 => 'web'
    ];

    public static function getInstance() {
        $class = get_called_class ();
        if (! isset ( self::$instance [$class] )) {
            self::$instance [$class] = new $class ();
        }
        return self::$instance [$class];
    }

    /**
     * 下单
     * @param $uid 用户ID
     * @param $amount 用户金额
     * @param $ortherData 其他数据
     */
    public function placeOrder($uid, $amount, $ortherData)
    {
        $saveData = [
            'uid' => $uid,
            'amount' => $amount,
            'trade_no_id' => date('YmdHis').mt_rand(10000,99999).mt_rand(1, 9),
            'create_timestamp' => time()
        ];
        if(isset($ortherData['goods_id']))
            $saveData['goods_id'] = $ortherData['goods_id'];

        if(isset($ortherData['order_title']))
            $saveData['order_title'] = $ortherData['order_title'];

        if(isset($ortherData['pay_type']) && $this->payType[$ortherData['pay_type']])
            $saveData['pay_type'] = $ortherData['pay_type'];

        if(isset($ortherData['platform']) && $this->platform[$ortherData['platform']])
            $saveData['platform'] = $ortherData['platform'];

        $result = $this->getOne ()->insert ( $this->tableName, $saveData );
        return $result ['insertid'];
    }

    /**
     * 获取订单详情
     * @param $orderIds
     */
    public function getOrderInfo($orderIds)
    {
        $result = $this->getOne()->selectOne($this->tableName, '*', [
            'id' => $orderIds
        ]);
        if(empty ($result ['data']))
            return [];

        return $result ['data'];
    }

    /**
     * 获取订单详情
     * @param $orderIds
     */
    public function getOrderInfoByTradeNo($tradeNoId)
    {
        $result = $this->getOne()->selectOne($this->tableName, '*', [
            'trade_no_id' => $tradeNoId
        ]);
        if(empty ($result ['data']))
            return [];

        return $result ['data'];
    }

    /**
     * 更新订单状态
     * @param $tradeNoId
     * @param $status
     */
    public function updateOrderStatus($tradeNoId, $status, $otherData = [])
    {
        $otherData['status'] = $status;

        return $this->getOne()->update($this->tableName, $otherData, [], [
            'trade_no_id' => $tradeNoId
        ]);
    }
}