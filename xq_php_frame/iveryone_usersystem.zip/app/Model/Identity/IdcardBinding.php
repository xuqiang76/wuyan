<?php

namespace HttpApi\Model\Identity;

use Beahoo\Model\Base;

class IdcardBinding extends Base
{
    private static $instance;

    private $tableName = 'user_idcard_binding';

    public static function getInstance()
    {
        if(empty(self::$instance))
        {
            self::$instance = new IdcardBinding();
        }
        return self::$instance;
    }

    public function update($setarr, $where)
    {
        $setarr['update_timestamp'] = time();
        return $this->getOne()->update($this->tableName, $setarr, [], $where);
    }
    /**
     * 获取用户身份认证信息
     * @param  int $user_id 用户id
     * @return array
     */
    public function getUserIdcardBinding($idcard_md5)
    {
        $res = $this->getOne()->selectOne($this->tableName, '*', ['idcard_md5' => $idcard_md5]);
        return $res['data'];
    }

    public function add($setarr)
    {
        $setarr['create_timestamp']=time();
        $res = $this->getOne()->insert($this->tableName, $setarr);
        return $res['insertid'];
    }
}