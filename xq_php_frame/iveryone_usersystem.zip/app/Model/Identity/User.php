<?php

namespace HttpApi\Model\Identity;

use Beahoo\Model\Base;

class User extends Base
{
    private static $instance;

    private $tableName = 'user_identity';

    public static function getInstance()
    {
        if(empty(self::$instance))
        {
            self::$instance = new User();
        }
        return self::$instance;
    }

    public function update($setarr, $where)
    {
        $setarr['update_timestamp'] = time();
        return $this->getOne()->update($this->tableName, $setarr, [], $where);
    }
    /**
     * 获取用户身份认证信息
     * @param  int $user_id 用户id
     * @return array
     */
    public function getUserIdentity($user_id)
    {
        $res = $this->getOne()->selectOne($this->tableName, '*', ['uid' => $user_id]);
        return $res['data'];
    }

    public function add($setarr)
    {
        $setarr['create_timestamp']=time();
        $res = $this->getOne()->insert($this->tableName, $setarr);
        return $res['insertid'];
    }
}