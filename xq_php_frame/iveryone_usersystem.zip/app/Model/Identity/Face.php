<?php

namespace HttpApi\Model\Identity;

include_once ROOT.'/libs/linkface/autoload.php';

use Beahoo\Model\Base;
use HttpApi\Model\Identity\{User,IdcardBinding};
use Linkface\{Identity,Liveness};
use OSS\OssClient;
use Beahoo\Tool\Config;
use HttpApi\Model\WalletNew\WalletNew;

class Face extends Base
{

    /**
     * 针对老用户，允许身份证最多的绑定次数
     * @var integer
     */
    protected $max_binding_count=3;

    /**
     * 保存user_identity对象
     * @var object
     */
    protected $user_identity=null;

    /**
     * 保存user_idcard_binding对象
     * @var object
     */
    protected $user_idcard_binding=null;

    /**
     * link face app_id
     * @var string
     */
    protected $linkface_app_id='';

    /**
     * app_secret
     * @var string
     */
    protected $linkface_app_secret='';

    public function __construct(){

        parent::__construct();

        $this->linkface_app_id=\Beahoo\Tool\Config::read('linkface.api_id');
        $this->linkface_app_secret=\Beahoo\Tool\Config::read('linkface.api_secret');
    }

    /**
     * 人脸认证的真正逻辑处理
     * @param  int $uid       用户id
     * @param  string $idcard    身份证号
     * @param  string $realname  姓名
     * @param  string $imagepath 人像图片位置
     * @param  string $protobuf 移动端SDK返回的protobuf文件
     * @param  string $is_risk 是否是高危用户
     * @return 
     */
    public function verify($uid,$idcard, $realname,$imagepath,$protobuf)
    {   

        $idcard=strtoupper($idcard);

        if($this->has_face_verify($uid)) return true;

        // 如果允许绑定
        if(($binding_status=$this->can_binding_idcard($uid,$idcard))===true){
            // echo 'binding_status:'.$binding_status.PHP_EOL;
            // 防hack判断
            if(($hack_status=$this->check_hack($imagepath,$protobuf))!==true){

                return ['errno'=>1051,'errmsg'=>$hack_status];
            }
            // 如果之前绑定过
            $face_status=($this->user_identity && $this->user_identity['auth_face_image'])?
                $this->check_face_with_face($imagepath,'http://'.$this->user_identity['auth_face_image']):
                $this->check_face_with_gongan($idcard,$realname,$imagepath);
            // echo 'face_status:'.$face_status.PHP_EOL;
            // 如果验证成功
            if($face_status===true){

                $new_image_name = $this->get_new_image_name($imagepath,$uid);

                $face_image_url=$this->upload_oss($imagepath,$new_image_name);

                // 请重新上传图片
                if($face_image_url===false) return ['errno'=>1050,'errmsg'=>'认证失败,无法核实您的账户真实性'];

                User::getInstance()->transaction_start();

                try{
                    $idcard_md5=md5($idcard);

                    $first_face_auth=true;

                    $user_identity_data=[
                        'uid'=>$uid,
                        'auth_face'=>1,
                        'auth_face_image'=>$face_image_url,
                        'realname'=>$realname,
                        'idcard'=>$idcard,
                        'idcard_md5'=>$idcard_md5,
                    ];
                    // print_r($user_identity_data);
                    if(empty($this->user_identity)){

                        User::getInstance()->add($user_identity_data);

                        $first_binding_new=true;
                    }else{

                        $first_binding_new=!$this->user_identity['is_old'];

                        $first_face_auth=!($this->user_identity['auth_face'] && $this->user_identity['auth_face_image']);

                        User::getInstance()->update($user_identity_data,['uid'=>$uid]);
                    }

                    if($this->user_idcard_binding===null){

                        $this->getUserIdcardBinding($idcard_md5);
                    }
                    // print_r($this->user_idcard_binding);
                    if(empty($this->user_idcard_binding)){

                        IdcardBinding::getInstance()->add([
                            'idcard_md5'=>$idcard_md5,
                            'first_binding_new'=>$first_binding_new,
                            'binding_count'=>1,
                        ]);
                    }else{

                        $binding_data=['binding_count'=>intval($this->user_idcard_binding['binding_count'])+1];
                        // 如果是首次绑定,同时更新该值
                        $this->user_idcard_binding['binding_count']==0 && $binding_data['first_binding_new']=$first_binding_new;
                        // print_r($binding_data);
                        IdcardBinding::getInstance()->update($binding_data,['idcard_md5'=>$idcard_md5]);
                    }
                    //不管是否是高危用户,认证成功后更改钱包状态
                    WalletNew::getInstance()->unlockWallet($uid);

                    User::getInstance()->transaction_commit();

                    return true;

                }catch(Exception $e){
                    // print_r($e->getMessage());
                    User::getInstance()->transaction_rollback(); 

                    return ['errno'=>1000,'errmsg'=>'系统错误,请重试'];              
                }
            }

            return ['errno'=>1051,'errmsg'=>$face_status];
        }

        return ['errno'=>1052,'errmsg'=>$binding_status];
    }

    /**
     * 已经通过人脸认证的用户标记为高危用户时，再次进行人脸认证时
     * @param  int $uid       
     * @param  string $imagepath 
     * @return true|array
     */
    public function verifyAgain($uid,$imagepath){

        $this->getUserIdentity($uid);

        if(!$this->user_identity || $this->user_identity['auth_face']==0 || !$this->user_identity['auth_face_image']) 
            return ['errno'=>1055,'errmsg'=>'不允许调用该接口'];
        
        $face_status=$this->check_face_with_face($imagepath,'http://'.$this->user_identity['auth_face_image']);

        if($face_status===true){

            WalletNew::getInstance()->unlockWallet($uid);

            return true;
        }

        return ['errno'=>1051,'errmsg'=>$face_status];
    }

    private function get_new_image_name($tmpname,$uid){

        $image_info=getimagesize($tmpname);

        switch ($image_info[2]) {
            case IMAGETYPE_JPEG:$ext='.jpeg';break;
            case IMAGETYPE_JPEG2000:$ext='.jpg';break;
            case IMAGETYPE_BMP:$ext='.bmp';break;
            case IMAGETYPE_PNG:$ext='.png';break;
            case IMAGETYPE_GIF:$ext='.gif';break;
            case IMAGETYPE_TIFF_II:$ext='.tiff';break;
            case IMAGETYPE_TIFF_MM:$ext='.tiff';break;
            default: $ext='';
        }

        return 'if'.date('Ymdhis').'_'.$uid.$ext;
    }

    private function upload_oss($tmp_name,$new_name){

        try {
            $endpoint = RUN_ENV=='aliyun_huabei2'?"oss-cn-beijing-internal.aliyuncs.com":"oss-cn-beijing.aliyuncs.com";
            $ossClient = new OssClient(
                \Beahoo\Tool\Config::read('aliyun.oss.accessKeyId'),
                \Beahoo\Tool\Config::read('aliyun.oss.accessKeySecret'),
                $endpoint);

            $ossClient->uploadFile('iveryone-face', $new_name, $tmp_name);

            return "iveryone-face.oss-cn-beijing.aliyuncs.com/" . $new_name;
        } catch (OssException $e) {

            return false;
        }
    }

    private function getUserIdentity($uid){

        $this->user_identity=User::getInstance()->getUserIdentity($uid);
    }

    private function getUserIdcardBinding($idcard_md5){

        $this->user_idcard_binding=IdcardBinding::getInstance()->getUserIdcardBinding($idcard_md5);
    }

    /**
     * 判断用户是否已完成人脸认证
     * @param  int  $uid 
     * @return boolean
     */
    public function has_face_verify($uid){

        $this->getUserIdentity($uid);
        
        if($this->user_identity && $this->user_identity['auth_face']==1) return true;

        return false;
    }

    /**
     * 是否允许用户绑定身份证
     * @param  int $uid 
     * @return string|boolean string代表错误信息
     */
    public function can_binding_idcard($uid,$idcard){

        $idcard=strtoupper($idcard);

        $idcard_md5=md5($idcard);
        // echo $idcard_md5;
        $this->getUserIdentity($uid);
        $this->getUserIdcardBinding($idcard_md5);
        // $this->user_idcard_binding=IdcardBinding::getInstance()->getUserIdcardBinding($idcard_md5);
        // 如果未找到对应的身份证绑定，则直接返回true
        if(empty($this->user_idcard_binding)) return true;
        // 如果当前用户是新账户且存在绑定的身份证号
        if(empty($this->user_identity) || $this->user_identity['is_old']==0) return '认证失败,该身份信息已经存在';

        $binding_count=$this->user_idcard_binding['binding_count'];
        // 如果发现身份证已经绑定到新用户上,则直接返回错误信息
        if($this->user_idcard_binding['first_binding_new']) return '认证失败,该身份信息已经存在';
        // 如果首次绑定老用户且被绑定起过3次,则直接返回错误信息
        elseif($binding_count>=$this->max_binding_count)  return '认证失败,该身份信息已经存在';

        return true;
    }

    /**
     * 跟公安部留的底图进行对比
     * @return
     */
    public function check_face_with_gongan($idcard,$realname,$image){

        $identity=new Identity($this->linkface_app_id,$this->linkface_app_secret,0.7);

        $result=$identity->selfie_idnumber_verification($idcard,$realname,$image);
        // print_r($result);
        if($result['errno']==0) return true;

        return $result['errmsg'];
    }

    /**
     * 前后两次人像对比
     * @param  string $image           
     * @param  string $last_face_image 上次验证的人像
     * @return string|boolean
     */
    public function check_face_with_face($image,$last_face_image){

        $identity=new Identity($this->linkface_app_id,$this->linkface_app_secret,0.7);

        $result=$identity->historical_selfie_verification_v2($image,$last_face_image);
        // print_r($result);
        if($result['errno']==0) return true;

        return $result['errmsg'];
    }

    public function check_hack($image,$protobuf){

        $liveness=new Liveness($this->linkface_app_id,$this->linkface_app_secret,0.98);

        $result=$liveness->liveness_selfie_verification($image,$protobuf);

        if($result['errno']==0) return true;

        return $result['errmsg']; 
    }
}