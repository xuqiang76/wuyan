<?php

namespace HttpApi\Model;

use Beahoo\Exception;
use Beahoo\Model\Base;
use Beahoo\Tool\Config;
use bigcatorm\BaseFunction;
use bigcatorm\CatRedis;
use bigcatorm\ListCommonFactory;
use HttpApi\Model\User\User;
use HttpApi\Model\Wallet\AdWords;
use HttpApi\puremodel\Contacts as ModelContacts;
use HttpApi\puremodel\ContactsFactory;
use HttpApi\Tool\iVeryOneApi;
use HttpApi\Tool\SDKs;
use HttpApi\Tool\IMInterface;

class Contacts extends Base {
	public $field_maps = [
		'id' => 0,
		'contact_status' => 0,
		'indb' => 1,
		'message_contract_id' => 0,
		'suggest_set_contract' => 1,
	];

	private static $instance;

	private $tableName = 'contacts';

	protected $cache_handler = null;
	protected $db_handler = null;

	public static function getInstance() {
		if (empty(self::$instance)) {
			self::$instance = new Contacts();
		}
		return self::$instance;
	}

	public function __construct() {
		//缓存服务器 redis
		if (empty($this->cache_handler)) {
			$config_redis = Config::read('redis');

			$redis_options['scheme'] = $config_redis['Parameters']['scheme'];
			$redis_options['host'] = $config_redis['Parameters']['host'];
			$redis_options['port'] = $config_redis['Parameters']['port'];
			$redis_options['password'] = $config_redis['Parameters']['password'];
			$redis_options['db'] = $config_redis['db'];
			$redis_options['cachedb'] = $config_redis['cachedb'];

			$this->cache_handler = CatRedis::get_instance($redis_options);
			if (!$this->cache_handler) {
				throw new Exception('Redis 连接失败', 4990);
			}
		}

		//数据库配置
		BaseFunction::set_db($this->getDb()); //兼容 Beahoo\Model\Base 的数据库连接
		//BaseFunction::set_db_options(Config::read('mysql'));

		$this->db_handler = BaseFunction::get_db();
		if (!$this->db_handler) {
			throw new Exception(__CLASS__ . __LINE__, 1002);
		}
	}

	public function add($setarr, $updateField = []) {
		$updateField = array_keys($updateField);
		$updateField[] = 'update_timestamp';
		$setarr['create_timestamp'] = $setarr['update_timestamp'] = TIMESTAMP;
		if (!empty($setarr['contact_status'])) {
			$setarr['contact_timestamp'] = TIMESTAMP;
		}
		$res = $this->getOne()->insert($this->tableName, $setarr, $updateField);

		$setarr['id'] = $res['insertid'];
		return array_merge($this->field_maps, $setarr);
	}

	public function update($setarr, $where) {
		$setarr['update_timestamp'] = TIMESTAMP;
		return $this->getOne()->update($this->tableName, $setarr, [], $where);
	}

	public function delete($where) {
		if (empty($where)) {
			throw new Exception("delete no where condition!", 1000);
		}

		return $this->getOne()->delete($this->tableName, $where);
	}

	public function getContact($uid, $contact_uid) {
		$res = $this->getOne()->selectOne($this->tableName, '*', ['uid' => $uid, 'contact_uid' => $contact_uid])['data'];
		if (empty($res)) {
			$res['indb'] = 0;
		} else {
			$res['contact_status'] = intval($res['contact_status']);
		}
		return array_merge($this->field_maps, $res);
	}

	public function getContacts($uid, $limit = 0, $lastid = 0) {
		if (!empty($lastid)) {
			$where = "uid = " . $uid . " AND contact_status = 1 AND contact_timestamp < " . $lastid;
		} else {
			$where = [
				'uid' => $uid,
				'contact_status' => 1,
			];
		}

		$res = $this->getOne()->select($this->tableName, '*', $where, 'ORDER BY contact_timestamp DESC', 0, $limit);
		return $res['data'];
	}

	public function getStarContacts($uid, $limit = 0, $lastid = 0) {
		$where = [
			'uid' => $uid,
			'contact_status' => 1,
			'star_status' => 1,
		];

		$order = ' ORDER BY contact_timestamp DESC';
		if (!empty($lastid)) {
			$order = "contact_timestamp < " . $lastid . $order;
		}

		$res = $this->getOne()->select($this->tableName, '*', $where, $order, 0, $limit);
		return $res['data'];
	}

	public function getBilateralContacts($uid, $limit = 0, $lastid = 0) {
		$where = [
			'uid' => $uid,
			'contact_status' => 1,
			'bilateral' => 1,
		];

		$order = ' ORDER BY contact_timestamp DESC';
		if (!empty($lastid)) {
			$order = "contact_timestamp < " . $lastid . $order;
		}

		$res = $this->getOne()->select($this->tableName, '*', $where, $order, 0, $limit);
		return $res['data'];
	}

	public function getBeautifulContacts($uid, $start = 0, $limit = 50) {
		$sql = "SELECT c.* FROM userinfo u LEFT JOIN contacts c ON u.id = c.contact_uid WHERE c.uid = " . $uid .
			" AND c.contact_status = 1 AND c.star_status = 0 AND c.bilateral = 0 ORDER BY u.nickname_initials ASC LIMIT " . $start . ", " . $limit;

		$query = $this->getDb()->query($sql);
		return $query->fetchAll(\PDO::FETCH_ASSOC);
	}

	public function getAllBeautifulContacts($uid, $start = 0, $limit = 50) {
		$sql = "SELECT c.* FROM userinfo u LEFT JOIN contacts c ON u.id = c.contact_uid WHERE c.uid = " . $uid .
			" AND c.contact_status = 1 ORDER BY u.nickname_initials ASC LIMIT " . $start . ", " . $limit;

		$query = $this->getDb()->query($sql);
		return $query->fetchAll(\PDO::FETCH_ASSOC);
	}

	public function getSpecialCounts($uid) {
		$starnum = $this->getOne()->selectOne($this->tableName, 'count(*) as num', ['uid' => $uid, 'contact_status' => 1, 'star_status' => 1])['data']['num'];
		$bilateralnum = $this->getOne()->selectOne($this->tableName, 'count(*) as num', ['uid' => $uid, 'contact_status' => 1, 'bilateral' => 1])['data']['num'];
		return [$starnum, $bilateralnum];
	}

	public function getFollowers($uid, $limit = 0, $lastid = 0) {
		if (!empty($lastid)) {
			$where = "contact_uid = " . $uid . " AND contact_status = 1 AND contact_timestamp < " . $lastid;
		} else {
			$where = [
				'contact_uid' => $uid,
				'contact_status' => 1,
			];
		}

		$res = $this->getOne()->select($this->tableName, '*', $where, 'ORDER BY contact_timestamp DESC', 0, $limit);
		return $res['data'];
	}

	public function getAll($uid) {
		$where = "(uid = " . $uid . " OR contact_uid = " . $uid . ") AND contact_status = 1";
		$res = $this->getOne()->select($this->tableName, '*', $where);
		return $res['data'];
	}

	public function getCount($where) {
		$res = $this->getOne()->selectOne($this->tableName, 'count(*) as num', $where);
		return $res['data']['num'];
	}

	public function getItems($where, $start = 0, $limit = 0) {
		$res = $this->getOne()->select($this->tableName, '*', $where, 'ORDER BY contact_timestamp DESC', $start, $limit);
		return $res['data'];
	}

	public function getUserContacts($where, $fields = '*', $start = 0, $limit = 0) {
		$res = $this->getOne()->select($this->tableName, $fields, $where, 'ORDER BY contact_timestamp DESC', $start, $limit);
		return $res['data'];
	}

	/**
	 * @param $uid
	 * @param $contact_uid
	 * @throws Exception
	 */
	public function follow($uid, $contact_uid) {
		$userinfo = User::getInstance()->getUserinfoByUid($uid);
		$oppositeUserinfo = User::getInstance()->getUserinfoByUid($contact_uid);
		if (empty($oppositeUserinfo)) {
			throw new Exception('', 2001);
		}

		if ($userinfo['id'] == $contact_uid) {
			throw new Exception("", 1001);
		}

		$contactInfo = Contacts::getInstance()->getContact($userinfo['id'], $contact_uid);
		$oppositeContactInfo = Contacts::getInstance()->getContact($contact_uid, $userinfo['id']);
		$contact_status = 0;
		if ($oppositeContactInfo['contact_status'] == 1) {
			$contact_status += 2;
		}

		if (!empty($contactInfo) && $contactInfo['contact_status'] == 1) {
			throw new Exception('', 2012);
		}

		$contact_status += 1;
		$bilateral = $contact_status == 3 ? 1 : 0;

		$setarr = [
			'uid' => $userinfo['id'],
			'contact_uid' => $contact_uid,
			'contact_status' => 1,
			'contact_timestamp' => TIMESTAMP,
			'bilateral' => $bilateral,
		];
		Contacts::getInstance()->add($setarr, $setarr);
		if ($bilateral) {
			Contacts::getInstance()->update(['bilateral' => 1], ['id' => $oppositeContactInfo['id']]);
		}

		if ($userinfo['follow_num'] > 14) {
			$batteryinfo = Battery::getInstance()->getBatteryInfo($userinfo['id']);
			if (empty($batteryinfo['mission3_finish'])) {
				Battery::getInstance()->increaseCapacity($userinfo['id'], 3);
			}
		}
		iVeryOneApi::Request('Intra/Feed/Follow', [
			'uid' => $userinfo['id'],
			'wyid' => $contact_uid,
		]);

		User::getInstance()->updateFields(['id' => $userinfo['id']], ['id' => $userinfo['id']], ['follow_num' => 1]);
		AdWords::getInstance()->redis()->zadd('adwords_follow_', $userinfo['id'], 0, $contact_uid);
		User::getInstance()->updateFields(['id' => $oppositeUserinfo['id']], ['id' => $oppositeUserinfo['id']], ['fans_num' => 1]);
        try{
            if($oppositeUserinfo['report_push_everyone']){
                $iveryone_helper_uid=Config::read('iveryone_helper_uid');
                $content=$userinfo['nickname'].'关注了你';
                $daychat_res = IMInterface::send($iveryone_helper_uid,0,$contact_uid,0,['msg'=>$content],'');
            }
            if($oppositeUserinfo['report_push_statistic']){
                $redis = SDKs::getRedis();
                $redis->hincrby('report_push_follow_'.date('ymd'),$contact_uid,1);
            }
        }catch(Exception $e){
            Log::debug('IM Exception:'.PHP_EOL.var_export($detail,true).PHP_EOL.$e->getMessage(), "push.everyone");
        }
		$this->save_today_follow($contact_uid, true);
		return $contact_status;
	}

	/**
	 * @param $uid
	 * @param $contact_uid
	 * @return int
	 * @throws Exception
	 */
	public function unfollow($uid, $contact_uid) {
		$userinfo = User::getInstance()->getUserinfoByUid($uid);
		$oppositeUserinfo = User::getInstance()->getUserinfoByUid($contact_uid);
		if (empty($oppositeUserinfo)) {
			throw new Exception('', 2001);
		}

		if ($userinfo['id'] == $contact_uid) {
			throw new Exception("", 1001);
		}

		$contactInfo = Contacts::getInstance()->getContact($userinfo['id'], $contact_uid);
		$oppositeContactInfo = Contacts::getInstance()->getContact($contact_uid, $userinfo['id']);
		$contact_status = 0;

		if (empty($contactInfo) || $contactInfo['contact_status'] != 1) {
			throw new Exception('', 2013);
		}

		Contacts::getInstance()->update([
			'contact_status' => 0,
			'bilateral' => 0,
		], [
			'uid' => $userinfo['id'],
			'contact_uid' => $contact_uid,
		]);

		if ($oppositeContactInfo['contact_status'] == 1) {
			$contact_status += 2;
			Contacts::getInstance()->update(['bilateral' => 0], ['id' => $oppositeContactInfo['id']]);
		}

		iVeryOneApi::Request('Intra/Feed/Unfollow', [
			'uid' => $userinfo['id'],
			'wyid' => $contact_uid,
		]);
		User::getInstance()->updateFields(['id' => $userinfo['id']], ['id' => $userinfo['id']], ['follow_num' => -1]);
		AdWords::getInstance()->redis()->zDelete('adwords_follow_', $userinfo['id'], $contact_uid);
		User::getInstance()->updateFields(['id' => $oppositeUserinfo['id']], ['id' => $oppositeUserinfo['id']], ['fans_num' => -1]);
        if($oppositeUserinfo['report_push_statistic']){
            $redis = SDKs::getRedis();
            $redis->hincrby('report_push_follow_'.date('ymd'),$contact_uid,-1);
        }
		$this->save_today_follow($contact_uid, false);
		return $contact_status;
	}

	public static function getContactStatus($contactInfo, $oppositeContactInfo) {
		$contact_status = 0;
		if (!empty($contactInfo['contact_status'])) {
			$contact_status += 1;
		}
		if (!empty($oppositeContactInfo['contact_status'])) {
			$contact_status += 2;
		}
		return $contact_status;
	}

	public function save_today_follow($uid, $follow = true) {

		$redis = SDKs::getRedis();

		$dateformat = date('ymd');
		$expireat = strtotime('+1 day', strtotime(date('Y-m-d'))) - 1;
		// 今日关注用户
		$user_tips_key_string = 'user_' . $dateformat . '_followed_contacts';
		if ($follow) {
			$redis->hincrby($user_tips_key_string, $uid, 1);
		} else {
			$redis->hincrby($user_tips_key_string, $uid, -1);
		}

		$redis->expireat($user_tips_key_string, $expireat);
	}

	//设置一个用户免打扰
	public function set_disturb($data = ['uid' => 0, 'contact_uid' => 0, 'disturb' => 0]) {
		if (empty($data['uid'])
			|| empty($data['contact_uid'])
		) {
			throw new Exception(__CLASS__ . __LINE__, 4003);
		}

		$obj_contacts_list_factory = new ListCommonFactory($this->cache_handler, null
			, [" select `id` from `contacts`  where uid=? and contact_uid=? ", [$data['uid'], $data['contact_uid']]]);
		if ($obj_contacts_list_factory->initialize() && $obj_contacts_list = $obj_contacts_list_factory->get()) {
			$id = $obj_contacts_list[0];
			$obj_contacts_factory = new ContactsFactory($this->cache_handler, $id);
			if ($obj_contacts_factory->initialize() && $obj_contacts = $obj_contacts_factory->get()) {
				$obj_contacts->disturb = $data['disturb'];
				$obj_contacts->update_timestamp = TIMESTAMP;

				if (!BaseFunction::execute_one($this->db_handler, $obj_contacts->getUpdateSql())) {
					throw new Exception(__CLASS__ . __LINE__, 1002);
				}
				$obj_contacts_list_factory->writeback();
			}

		} else {
			$obj_contacts_list_factory->clear();
			$obj_contacts = new ModelContacts();

			$obj_contacts->uid = $data['uid'];
			$obj_contacts->contact_uid = $data['contact_uid'];
			$obj_contacts->disturb = $data['disturb'];
			$obj_contacts->create_timestamp = TIMESTAMP;
			$obj_contacts->update_timestamp = TIMESTAMP;
			$obj_contacts->contact_timestamp = TIMESTAMP;

			if (!BaseFunction::execute_one($this->db_handler, $obj_contacts->getInsertSql())) {
				throw new Exception(__CLASS__ . __LINE__, 1002);
			}

		}
		return true;
	}

	//获取免打扰列表
	public function get_disturb_list($data = ['uid' => 0]) {
		if (empty($data['uid'])) {
			throw new Exception(__CLASS__ . __LINE__, 4003);
		}

		$obj_contacts_list_factory = new ListCommonFactory($this->cache_handler, null
			, [" select `contact_uid` from `contacts`  where uid=? and disturb=1 ", [$data['uid']]]);
		if ($obj_contacts_list_factory->initialize() && $obj_contacts_list = $obj_contacts_list_factory->get()) {
			return $obj_contacts_list;
		} else {
			$obj_contacts_list_factory->clear();
			return [];
		}
	}
}