<?php

namespace HttpApi\Mode\TaskPool;

use HttpApi\Model\TaskPool\TaskBase;
use HttpApi\Model\Wallet\Details;
use Beahoo\Exception;

class AdWordsTask extends TaskBase {
    public function finished($data, $task, $user_task) {
        if (! $this->redis ()->get ( 'task_adwords_' . $data ['id'] )) {
            try {
                $stat = Details::getInstance ()->query ( [ 
                    'recorder' => $data ['id'],
                    'receiver' => 'system',
                    'category' => Details::AdWords,
                    'limit' => 1 
                ] );
            } catch ( Exception $e ) {
                if ($e->getCode () == 4000) {
                    $stat = [ ];
                }
            }
            if (! empty ( $stat )) {
                parent::finished ( $data, $task, $user_task );
                $this->redis ()->set ( 'task_adwords_' . $data ['id'], 1, strtotime ( date ( 'Y-m-d 23:59:59' ) ) - TIMESTAMP );
                return true;
            }
            return false;
        }
        return true;
    }
}