<?php

namespace HttpApi\Model\TaskPool;

use HttpApi\Model\Identity\User;

class IdentityTask extends TaskBase {
    public function finished($data, $task, $user_task) {
        if ($this->disabeCache || ! $this->redis ()->get ( 'task_identity_' . $data ['id'] )) {
            $identity = User::getInstance()->getUserIdentity($data['id']);
            if (! empty ( $identity ) && $identity['auth_face'] == 1) {
                $taskStat = $this->getOne ()->selectOne ( 'users_tasks', '*', [
                    'uid' => $data['id'],
                    'tid' => $task ['id']
                ] );
                if ($taskStat ['rownum']) {
                    if ($taskStat ['data'] ['status'] == 1) {
                        parent::finished ( $data, $task, $taskStat ['data'] );
                    }
                }
                $this->redis ()->set ( 'task_identity_' . $data ['id'], 1, self::ONCE - TIMESTAMP );
                Task::getInstance()->receive([
                    'id' => $user_task['id'],
                    'uid' => $data['id']
                ]);
                return true;
            }
            return false;
        }
        return true;
    }
}