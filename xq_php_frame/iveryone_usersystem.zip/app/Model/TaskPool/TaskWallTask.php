<?php

namespace HttpApi\Model\TaskPool;

class TaskWallTask extends TaskBase {
    public function finished($data, $task, $user_task) {
    }
}