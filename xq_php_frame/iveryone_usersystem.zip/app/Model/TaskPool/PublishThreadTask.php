<?php

namespace HttpApi\Model\TaskPool;

class PublishThreadTask extends TaskBase {
    public function finished($userinfo, $task, $user_task) {
        if ($this->disabeCache || ! $this->redis ()->get ( 'task_publish_thread_' . $userinfo ['id'] )) {
            $stat = $this->getOne ()->exec ( "select count(1) num from threads where uid = '{$userinfo['id']}' and status = 2");
            if ($stat ['rownum']) {
                $this->getOne ()->update ( 'users_tasks', [ 
                    'current' => $stat ['data'] [0] ['num'] >= $task ['number'] ? $task ['number'] : $stat ['data'] [0] ['num'] 
                ], [ ], [ 
                    'id' => $user_task ['id'] 
                ] );
                if ($stat ['data'] [0] ['num'] >= $task ['number']) {
                    parent::finished ( $userinfo, $task, $user_task );
                    $this->redis ()->set ( 'task_publish_thread_' . $userinfo ['id'], 1, self::DAILY - TIMESTAMP );
                    return true;
                }
            }
            return false;
        }
        return true;
    }
}