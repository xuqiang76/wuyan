<?php

namespace HttpApi\Model\TaskPool;

class AuthorRewardTask extends TaskBase {
    public function finished($userinfo, $task, $user_task) {
        if ($this->disabeCache || ! $this->redis ()->get ( 'task_auth_reward_' . $userinfo ['id'] )) {
            if ($userinfo['create_timestamp'] < 1528128000 && time() < 1528473600) {
                parent::finished ( $userinfo, $task, $user_task );
                $this->redis ()->set ( 'task_auth_reward_' . $userinfo ['id'], 1, self::ONCE - TIMESTAMP );
                return true;
            }
            return false;
        }
        return true;
    }
}