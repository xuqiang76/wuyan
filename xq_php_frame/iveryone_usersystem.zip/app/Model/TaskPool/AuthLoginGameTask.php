<?php

namespace HttpApi\Model\TaskPool;

class AuthLoginGameTask extends TaskBase {
    public function finished($userinfo, $task, $user_task) {
        if ($this->disabeCache || ! $this->redis ()->get ( 'task_auth_login_game_' . $userinfo ['id'] )) {
            $stat = $this->getOne ()->selectOne ( 'user_openapi', 'max(expired_timestamp) timestamp', [ 
                'uid' => $userinfo ['id'],
                'appkey' => '' 
            ] );
            if ($stat ['rownum'] && $stat ['data'] ['timestamp'] - 86400 * 30 >= self::DAYTIME) {
                parent::finished ( $userinfo, $task, $user_task );
                $this->redis ()->set ( 'task_auth_login_game_' . $userinfo ['id'], 1, self::ONCE - TIMESTAMP );
                return true;
            }
            return false;
        }
        return true;
    }
}