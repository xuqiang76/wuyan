<?php

namespace HttpApi\Model\TaskPool;

use HttpApi\Model\Wallet\Details;

class PurchaseThreadTask extends TaskBase {
    public function finished($data, $task, $user_task) {
        if ($this->disabeCache || ! $this->redis ()->get ( 'task_purchase_thread_' . $data ['id'] )) {
            
            $stat = $this->getOne ()->exec ( "select count(1) num from wallet_details where recorder = '{$data['id']}' and receiver > 0 and category=" . Details::Thread_Buy . " and direction='outlay' and create_timestamp >=" . self::DAYTIME . " and status = 1" );
            
            if ($stat ['rownum']) {
                $this->getOne ()->update ( 'users_tasks', [ 
                    'current' => $stat ['data'] [0] ['num'] >= $task ['number'] ? $task ['number'] : $stat ['data'] [0] ['num'] 
                ], [ ], [ 
                    'id' => $user_task ['id'] 
                ] );
                if ($stat ['data'] [0] ['num'] >= $task ['number']) {
                    parent::finished ( $data, $task, $user_task );
                    $this->redis ()->set ( 'task_login_' . $data ['id'], 1, self::DAILY - TIMESTAMP );
                    return true;
                }
            }
            return false;
        }
        return true;
    }
}