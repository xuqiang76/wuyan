<?php

namespace HttpApi\Model\TaskPool;

class TaskSystemTask extends TaskBase {
}