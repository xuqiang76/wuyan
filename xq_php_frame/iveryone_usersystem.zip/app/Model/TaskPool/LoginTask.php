<?php

namespace HttpApi\Model\TaskPool;

use Beahoo\Exception;

class LoginTask extends TaskBase {
    protected $tableName = 'task_login';
    public function finished($userinfo, $task, $user_task) {
        if ($this->disabeCache || ! $this->redis ()->get ( 'task_login_' . $userinfo ['id'] )) {
            $loginStat = $this->getOne ()->selectOne ( $this->tableName, '*', [ 
                'uid' => $userinfo ['id'] 
            ] );
            
            if (! $loginStat ['rownum'] || TASK_DAYTIME != $loginStat ['data'] ['timestamp'] || $user_task ['status'] == 1) {
                $length = floor ( (TASK_DAYTIME - strtotime ( date ( 'Y-m-d 00:00:00', $userinfo ['create_timestamp'] ) )) / 86400 );
                $stat = '1';
                if ($loginStat ['rownum']) {
                    $stat = substr ( str_pad ( $loginStat ['data'] ['stat'], $length, '0' ), 0, $length ) . $stat;
                    $this->getOne ()->update ( $this->tableName, [ 
                        'stat' => $stat,
                        'timestamp' => TIMESTAMP 
                    ], [ ], [ 
                        'uid' => $userinfo ['id'] 
                    ] );
                } else {
                    $stat = str_pad ( '', $length, '0' ) . $stat;
                    $this->getOne ()->insert ( $this->tableName, [ 
                        'uid' => $userinfo ['id'],
                        'stat' => $stat,
                        'timestamp' => TIMESTAMP 
                    ] );
                }
                preg_match_all ( '/(1{1,})$/', $stat, $match );
                $this->getOne ()->update ( 'users_tasks', [ 
                    'current' => strlen ( $match [1] [0] ) 
                ], [ ], [ 
                    'id' => $user_task ['id'] 
                ] );
                parent::finished ( $userinfo, $task, $user_task );
            }
            $this->redis ()->set ( 'task_login_' . $userinfo ['id'], 1, self::DAILY - TIMESTAMP );
        }
        return true;
    }
    public function check($userinfo) {
        if ($this->disabeCache || ! $this->redis ()->get ( 'task_login_' . $userinfo ['id'] )) {
            $task = $this->getOne ()->selectOne ( 'tasks', '*', [ 
                'script' => __CLASS__ 
            ] ) ['data'];
            if (empty ( $task )) {
                return;
            }
            $user_task = $this->getOne ()->selectOne ( 'users_tasks', '*', [ 
                'uid' => $userinfo ['id'],
                'tid' => $task ['id'] 
            ], 'order by id desc' ) ['data'];
            if (empty ( $user_task )) {
                return;
            }
            $this->finished ( $userinfo, $task, $user_task );
        }
    }
    public function status($uid, $tid) {
        $status = parent::status ( $uid, $tid );
        $status ['reward'] = min ( $status ['total'], $status ['current'] );
        $utask = $this->getOne ()->select ( 'users_tasks', '*', [ 
            'script' => $status ['task'],
            'uid' => $uid 
        ], 'order by id desc', 0, $status ['current'] ) ['data'] ?? [ ];
        if (empty ( $utask )) {
            throw new Exception ( '', 4000 );
        }
        $status = [ 
            $status 
        ];
        array_shift ( $utask );
        foreach ( $utask as $task ) {
            array_push ( $status, [ 
                'id' => $task ['id'],
                'total' => $task ['total'],
                'current' => end ( $status ) ['current'] - 1,
                'status' => $task ['status'],
                'task' => $task ['script'],
                'reward' => end ( $status ) ['reward'] - 1 
            ] );
        }
        $reward = range ( 0, 10 );
        unset ( $reward [0] );
        
        return [ 
            'total' => ( string ) reset ( $status ) ['current'],
            'task' => array_reverse ( $status ),
            'reward' => $reward,
            'nextReward' => $reward [count ( $status ) + 1] ?? end ( $reward )
        ];
    }
    public function receive($data, $utask = [], $task = []) {
        $data = parent::receive ( $data );
        $data ['reward'] = min ( $utask ['current'], $task ['reward'] );
        return $data;
    }
}