<?php

namespace HttpApi\Model\TaskPool;

use HttpApi\Model\Ad;
use HttpApi\Model\User\User;

class NoviceGiftTask extends TaskBase {
    public function finished($userinfo, $task, $user_task) {
        if ($this->disabeCache || ! $this->redis ()->get ( 'task_novice_gift_' . $userinfo ['id'] )) {
            $param = [ 
                'uid' => $userinfo ['id'],
                'status' => null,
                'type' => 'novice_gift',
                'start_time' => strtotime ( date ( 'Y-m-d 00:00:00' ) ),
                'end_time' => null 
            ];
            $re_data = Ad::getInstance ()->get_adwords_info ( $param );
            
            $this->getOne ()->update ( 'users_tasks', [ 
                'current' => $re_data ['quota_all'] >= $task ['number'] ? $task ['number'] : $re_data ['quota_all'] 
            ], [ ], [ 
                'id' => $user_task ['id'] 
            ] );
            
            if ($re_data ['quota_all'] >= $task ['number']) {
                parent::finished ( $userinfo, $task, $user_task );
                $this->redis ()->set ( 'task_novice_gift_' . $userinfo ['id'], 1, self::ONCE - TIMESTAMP );
                return true;
            }
            return false;
        }
        return true;
    }
    public function finish($uid) {
        $task = $this->getOne ()->selectOne ( $this->tableName, '*', [ 
            'enable' => 1,
            'script' => get_called_class () 
        ] ) ['data'];
        $userinfo = User::getInstance ()->getUserinfoByUid ( $uid );
        $user_task = $this->query_user_tasks ( [ 
            'uid' => $uid,
            'tid' => $task ['id'] 
        ] ) ['data'] [0];
        $this->getOne ()->update ( 'users_tasks', [ ], [ 
            'current' => 1 
        ], [ 
            'id' => $user_task ['id'],
            'uid' => $uid 
        ] );
        $this->finished ( $userinfo, $task, $user_task );
    }
    public function create($data) {
        $data ['create_timestamp'] = User::getInstance ()->getUserinfoByUid ( $data ['uid'] ) ['create_timestamp'] + 86400;
        return parent::create ( $data );
    }
}