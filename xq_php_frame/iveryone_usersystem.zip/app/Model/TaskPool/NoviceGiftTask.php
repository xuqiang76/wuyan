<?php

namespace HttpApi\Model\TaskPool;

use HttpApi\Model\Ad;

class NoviceGiftTask extends TaskBase {
	public function finished($userinfo, $task, $user_task) {
		if ($this->disabeCache || !$this->redis()->get('task_novice_gift_' . $userinfo['id'])) {

			$param = ['uid' => $userinfo['id']
				, 'status' => null
				, 'type' => 'novice_gift'
				, 'start_time' => strtotime(date('Y-m-d 00:00:00'))
				, 'end_time' => null,
			];
			$re_data = Ad::getInstance()->get_adwords_info($param);

			$this->getOne()->update('users_tasks', [
				'current' => $re_data['quota_all'] >= $task['number'] ? $task['number'] : $re_data['quota_all'],
			], [], [
				'id' => $user_task['id'],
			]);

			if ($re_data['quota_all'] >= $task['number']) {
				parent::finished($userinfo, $task, $user_task);
				$this->redis()->set('task_novice_gift_' . $userinfo['id'], 1, self::ONCE - TIMESTAMP);
				return true;
			}
			return false;
		}
		return true;
	}
}