<?php

namespace HttpApi\Model\TaskPool;

class UnFollowTask extends TaskBase {
    public function finished($userinfo, $task, $user_task) {
        if ($this->disabeCache || ! $this->redis ()->get ( 'task_unfollow_' . $userinfo ['id'] )) {
            $stat = $this->getOne ()->exec ( "select count(id) unfollow from contacts where uid = {$userinfo['id']} and contact_status = 0 and update_timestamp >= " . self::DAYTIME );
            if ($stat ['rownum']) {
                $this->getOne ()->update ( 'users_tasks', [ 
                    'current' => $stat ['data'] [0] ['unfollow'] >= $task ['number'] ? $task ['number'] : $stat ['data'] [0] ['unfollow'] 
                ], [ ], [ 
                    'id' => $user_task ['id'] 
                ] );
                if ($stat ['data'] [0] ['unfollow'] >= $task ['number']) {
                    parent::finished ( $userinfo, $task, $user_task );
                    $this->redis ()->set ( 'task_unfollow_' . $userinfo ['id'], 1, self::ONCE - TIMESTAMP );
                    return true;
                }
            }
            return false;
        }
        return true;
    }
}