<?php

namespace HttpApi\Model\TaskPool;

class VPointTask extends TaskBase
{
    public function expired($data, $task)
    {
        $taskStat = $this->getOne()->selectOne('users_tasks', '*', [
            'uid' => $data ['id'],
            'tid' => $task ['id']
        ]);
        if ($taskStat ['rownum']) {
            if ($taskStat ['data'] ['status'] >= 2) {
                $this->user_task_set_expired($taskStat ['data']);
                return true;
            }
        }
        return false;
    }

    function finished($data, $task, $user_task)
    {
        if (!is_array($task['include'])) {
            $task['include'] = json_decode($task['include'], true);
        }
        $slave_tasks = $this->getOne()->select($this->tableName, '*', [
            'id' => $task['include']
        ])['data'];

        foreach ($slave_tasks as $slave_task) {
            if ($slave_task['script'] == 'HttpApi\Model\TaskPool\LoginTask') {
                unset($task['include'][array_search($slave_task['id'], $task['include'])]);
            }
        }

        $users_tasks = $this->getOne()->select('users_tasks', '*', [
            'uid' => $data['id'],
            'tid' => $task['include']
        ])['data'];
        $finished_num = 0;
        foreach ($users_tasks as $users_task) {
            if ($users_task['status'] >= 2) {
                $finished_num++;
            }
        }
        if ($finished_num == 2) {
            parent::finished($data, $task, $user_task);
            return true;
        }
        return false;
    }
}