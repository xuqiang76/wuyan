<?php

namespace HttpApi\Model\TaskPool;

class SpreadThreadTask extends TaskBase {
    public function finished($userinfo, $task, $user_task) {
        if ($this->disabeCache || ! $this->redis ()->get ( 'task_spread_thread_' . $userinfo ['id'] )) {
            $total = $this->getOne ()->exec ( "select count(1) total from user_feed where uid = {$userinfo['id']} and content_type = 0 and create_timestamp >=" . self::DAYTIME . ' group by content_id' );
            if ($total ['rownum']) {
                $spread = array_reduce ( $total ['data'], function ($sum, $item) {
                    return $sum + $item ['total'];
                }, 0 );
                $self = $this->getOne ()->exec ( "select count(1) self from user_feed where uid = {$userinfo['id']} and content_type = 0 and create_timestamp >=" . self::DAYTIME . " and content_id in (select id from threads where uid = {$userinfo['id']}) group by content_id" );
                if ($self ['rownum']) {
                    $spread -= array_reduce ( $self ['data'], function ($sum, $item) {
                        return $sum + $item ['self'];
                    }, 0 );
                }
                $this->getOne ()->update ( 'users_tasks', [ 
                    'current' => $spread > $task ['number'] ? $task ['number'] : $spread 
                ], [ ], [ 
                    'id' => $user_task ['id'] 
                ] );
                if ($spread >= $task ['number']) {
                    parent::finished ( $userinfo, $task, $user_task );
                    $this->redis ()->set ( 'task_spread_thread_' . $userinfo ['id'], 1, self::DAILY - TIMESTAMP );
                    return true;
                }
            }
            return false;
        }
        return true;
    }
}