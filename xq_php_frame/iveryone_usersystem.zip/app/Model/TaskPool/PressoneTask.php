<?php

namespace HttpApi\Model\TaskPool;

use HttpApi\Model\Wallet\CommunityActivity;
use HttpApi\Model\User\User;

class PressoneTask extends TaskBase {
    public function finished($userinfo, $task, $user_task) {
        if ($this->disabeCache || ! $this->redis ()->get ( 'task_pressone_' . $userinfo ['id'] )) {
            $community = CommunityActivity::getInstance ()->query ( [ 
                'uid' => $userinfo ['id'],
                'community_type' => 3 
            ] );
            if (! empty ( $community )) {
                $taskStat = $this->getOne ()->selectOne ( 'users_tasks', '*', [ 
                    'uid' => $userinfo ['id'],
                    'tid' => $task ['id'] 
                ] );
                if ($taskStat ['rownum']) {
                    if ($taskStat ['data'] ['status'] == 1) {
                        parent::finished ( $userinfo, $task, $taskStat ['data'] );
                    }
                }
                $this->redis ()->set ( 'task_pressone_' . $userinfo ['id'], 1, self::ONCE - TIMESTAMP );
                return true;
            }
            return false;
        }
        return true;
    }
    public function finish($uid) {
        $task = $this->getOne ()->selectOne ( $this->tableName, '*', [ 
            'enable' => 1,
            'script' => get_called_class () 
        ] ) ['data'];
        $userinfo = User::getInstance ()->getUserinfoByUid ( $uid );
        $user_task = $this->query_user_tasks ( [ 
            'uid' => $uid,
            'tid' => $task ['id'] 
        ] ) ['data'] [0];
        $this->getOne ()->update ( 'users_tasks', [ ], [ 
            'current' => 1 
        ], [ 
            'id' => $user_task ['id'],
            'uid' => $uid 
        ] );
        $this->finished ( $userinfo, $task, $user_task );
    }
}