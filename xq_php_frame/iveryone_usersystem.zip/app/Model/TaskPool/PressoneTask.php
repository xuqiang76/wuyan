<?php

namespace HttpApi\Model\TaskPool;

use HttpApi\Model\Wallet\CommunityActivity;

class PressoneTask extends TaskBase {
    public function finished($userinfo, $task, $user_task) {
        if ($this->disabeCache || ! $this->redis ()->get ( 'task_pressone_' . $userinfo ['id'] )) {
            $community = CommunityActivity::getInstance ()->query ( [ 
                'uid' => $userinfo ['id'],
                'community_type' => 3 
            ] );
            if (! empty ( $community )) {
                $taskStat = $this->getOne ()->selectOne ( 'users_tasks', '*', [ 
                    'uid' => $userinfo ['id'],
                    'tid' => $task ['id'] 
                ] );
                if ($taskStat ['rownum']) {
                    if ($taskStat ['data'] ['status'] == 1) {
                        parent::finished ( $userinfo, $task, $taskStat ['data'] );
                    }
                }
                $this->redis ()->set ( 'task_pressone_' . $userinfo ['id'], 1, self::ONCE - TIMESTAMP );
                return true;
            }
            return false;
        }
        return true;
    }
}