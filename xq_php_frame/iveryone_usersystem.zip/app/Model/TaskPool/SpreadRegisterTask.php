<?php

namespace HttpApi\Model\TaskPool;

class SpreadRegisterTask extends TaskBase {
    public function finished($userinfo, $task, $user_task) {
        if ($this->disabeCache || ! $this->redis ()->get ( 'task_spread_register_' . $userinfo ['id'] )) {
            $stat = $this->getOne ()->exec ( "select count(1) num from genealogy where referer = '{$userinfo['id']}' and level between 1 and 6 and freeze = 0 and register >=" . strtotime ( date ( '2018-03-25 00:00:00' ) ) );
            
            if ($stat ['rownum']) {
                $this->getOne ()->update ( 'users_tasks', [ 
                    'current' => $stat ['data'] [0] ['num'] >= $task ['number'] ? $task ['number'] : $stat ['data'] [0] ['num'] 
                ], [ ], [ 
                    'id' => $user_task ['id'] 
                ] );
                if ($stat ['data'] [0] ['num'] >= $task ['number']) {
                    parent::finished ( $userinfo, $task, $user_task );
                    $this->redis ()->set ( 'task_spread_register_' . $userinfo ['id'], 1, self::DAILY - TIMESTAMP );
                    return true;
                }
            }
            return false;
        }
        return true;
    }
}