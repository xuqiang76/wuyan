<?php

namespace HttpApi\Model\TaskPool;

use HttpApi\Model\User\User;

class UpdateFieldsNicknameTask extends TaskBase {
    protected $notify = false;
    public function finished($data, $task, $user_task) {
        if (! $this->redis ()->get ( 'task_nickname_edit_' . $data ['id'] )) {
            $stat = $this->getOne ()->selectOne ( 'users_tasks', '*', [ 
                'id' => $user_task ['id'] 
            ] ) ['data'];
            if ($stat ['current'] == $stat ['total']) {
                parent::finished ( $data, $task, $user_task );
                $this->redis ()->set ( 'task_nickname_edit_' . $data ['id'], 1 );
                return true;
            }
            return false;
        }
        return true;
    }
    public function finish($uid) {
        $task = $this->getOne ()->selectOne ( $this->tableName, '*', [ 
            'enable' => 1,
            'script' => get_called_class () 
        ] ) ['data'];
        $userinfo = User::getInstance ()->getUserinfoByUid ( $uid );
        $user_task = $this->query_user_tasks ( [ 
            'uid' => $uid,
            'tid' => $task ['id'] 
        ] ) ['data'] [0];
        $this->getOne ()->update ( 'users_tasks', [ ], [ 
            'current' => 1 
        ], [ 
            'id' => $user_task ['id'],
            'uid' => $uid 
        ] );
        $this->finished ( $userinfo, $task, $user_task );
    }
}