<?php

namespace HttpApi\Model\TaskPool;

use Beahoo\Exception;
use HttpApi\Model\Wallet\Details;
use HttpApi\Tool\Format;

class Task extends TaskBase {
    protected $class = 'Task';
    public function task($userinfo) {
        if ($this->disabeCache || ! $this->redis ()->get ( 'task_init' . $userinfo ['id'] )) {
            $this->transaction_start ();
            $taskPool = $this->init ();
            $process = $this->process ( $userinfo ['id'], false, false );
            if (! in_array ( $process, array_column ( $taskPool, 'script' ) )) {
                $process = '';
            }
            while ( $task = array_shift ( $taskPool ) ) {
                if ($process && $task ['script'] != $process) {
                    continue;
                }
                if (! $task ['script']::getInstance ()->complete ( $userinfo, $task )) {
                    $this->process ( $userinfo ['id'], $task ['script'] );
                    $task ['script']::getInstance ()->execute ( $userinfo, $task );
                    break;
                } else if ($taskPool) {
                    $process = $taskPool [0] ['script'];
                }
            }
            $this->transaction_commit ();
            $this->redis ()->set ( 'task_init_' . $userinfo ['id'], 1, self::DAILY - TIMESTAMP );
        }
    }
    public function query_user_tasks($userinfo) {
        $this->transaction_start ();
        $utasks = [ ];
        $taskid = [ ];
        foreach ( parent::query_user_tasks ( [ 
            'uid' => $userinfo ['id'],
            'status' => 1 
        ] ) ['data'] as $task ) {
            $task ['slave'] = [ ];
            $utasks [$task ['id']] = $task;
            $taskid [] = $task ['tid'];
        }
        foreach ( $utasks as $key => $task ) {
            $task ['master'] = json_decode ( $task ['master'], true );
            foreach ( $task ['master'] as $master ) {
                if (isset ( $utasks [$master] )) {
                    $utasks [$master] ['slave'] [$task ['id']] = $task ['id'];
                }
            }
        }
        $tasks = [ ];
        foreach ( $this->getOne ()->select ( 'tasks', '*', [ 
            'id' => $taskid,
            'enable' => 1 
        ] ) ['data'] as $task ) {
            $tasks [$task ['id']] = $task;
        }
        do {
            foreach ( $utasks as $index => $task ) {
                if (empty ( $task ['slave'] )) {
                    if (isset ( $tasks [$task ['tid']] )) {
                        $tasks [$task ['tid']] ['script']::getInstance ()->finished ( $userinfo, $tasks [$task ['tid']], $task );
                    } else {
                        $this->getOne ()->update ( 'users_tasks', [ 
                            'status' => 4 
                        ], [ ], [ 
                            'id' => $task ['id'] 
                        ] );
                    }
                    unset ( $utasks [$index] );
                    $task ['master'] = json_decode ( $task ['master'], true );
                    foreach ( $task ['master'] as $master ) {
                        unset ( $utasks [$master] ['slave'] [$task ['id']] );
                    }
                    break;
                }
            }
        } while ( ! empty ( $utasks ) );
        $utasks = [ ];
        foreach ( parent::query_user_tasks ( [ 
            'uid' => $userinfo ['id'],
            'status' => [ 
                1,
                2,
                3 
            ] 
        ] ) ['data'] as $task ) {
            $tasks [$task ['tid']] = $tasks [$task ['tid']] ?? $this->getOne ()->selectOne ( 'tasks', '*', [ 
                'id' => $task ['tid'] 
            ] ) ['data'];
            preg_match ( '/([a-z0-9]*?)task$/i', $tasks [$task ['tid']] ['script'], $script );
            $utasks [$script [1]] = [ 
                'id' => $task ['id'],
                'total' => $task ['total'],
                'current' => $task ['current'],
                'status' => $task ['status'],
                'task' => $script [1],
                'reward' => $tasks [$task ['tid']] ['reward'] 
            ];
            switch ($script [1]) {
                case 'Daily' :
                    $utasks [$script [1]] ['current'] = DailyTask::getInstance ()->stat ( $task ['uid'] );
                    break;
                case 'Login' :
                    $utasks [$script [1]] ['reward'] = $task ['current'] > $tasks [$task ['tid']] ['reward'] ? $tasks [$task ['tid']] ['reward'] : $task ['current'];
                    if (TIMESTAMP >= NEW_INVITE_TIMESTAMP) {
                        $utasks [$script [1]] ['reward'] = Format::amount ( bcmul ( $utasks [$script [1]] ['reward'], 500000, 6 ) );
                    }
                    break;
                case 'TransferAccount' :
                    $utasks [$script [1]] ['daily'] = TransferAccountTask::getInstance ()->daily ( $task ['uid'] );
                    if ($utasks [$script [1]] ['daily'] ['total'] != $utasks [$script [1]] ['daily'] ['current']) {
                        $utasks [$script [1]] ['status'] = '1';
                    }
                    break;
                default :
            }
        }
        $this->transaction_commit ();
        return $utasks;
    }
    public function receive($data) {
        $data ['status'] = 2;
        $task = $this->getOne ()->selectOne ( 'users_tasks', '*', $data ) ['data'];
        if (empty ( $task )) {
            throw new Exception ( '', 4000 );
        }
        $Task = $this->getOne ()->selectOne ( 'tasks', '*', [ 
            'id' => $task ['tid'] 
        ] ) ['data'];
        if (empty ( $Task )) {
            throw new Exception ( '', 4000 );
        }
        $data ['reward'] = $Task ['reward'];
        $this->transaction_start ();
        $data = $Task ['script']::getInstance ()->receive ( $data, $task, $Task );
        Details::getInstance ()->create ( [ 
            'recorder' => $data ['uid'],
            'receiver' => 'system',
            'category' => Details::Battery,
            'amount' => $data ['reward'],
            'uniqid' => 'user_task_' . $task ['id'],
            'remark' => $Task ['name'] 
        ] );
        $this->getOne ()->update ( 'users_tasks', [ 
            'status' => 3,
            'confirm_timestamp' => TIMESTAMP 
        ], [ ], [ 
            'id' => $task ['id'],
            'status' => 2 
        ] );
        $this->transaction_commit ();
        return [ 
            'reward' => $data ['reward'] 
        ];
    }
}