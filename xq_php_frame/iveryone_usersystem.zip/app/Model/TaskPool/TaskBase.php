<?php

namespace HttpApi\Model\TaskPool;

define ( 'TASK_ONCE', 2000000000 );
define ( 'TASK_DAILY', strtotime ( date ( 'Y-m-d 23:59:59' ) ) );
define ( 'TASK_DAYTIME', strtotime ( date ( 'Y-m-d 00:00:00' ) ) );

use HttpApi\Model\Wallet\WalletBase;

class TaskBase extends WalletBase {
    protected $tableName = 'tasks';
    protected $disabeCache = true;
    const ONCE = TASK_ONCE;
    const DAILY = TASK_DAILY;
    const DAYTIME = TASK_DAYTIME;
    public function init() {
        foreach ( $this->getOne ()->select ( $this->tableName, '*', [ 
            'enable' => 1 
        ] ) ['data'] as $task ) {
            if ($task ['start'] <= TIMESTAMP && TIMESTAMP < $task ['end']) {
                $tasks [$task ['id']] = $task;
            }
        }
        foreach ( $tasks as $key => &$task ) {
            if (! $key) {
                continue;
            }
            if (is_string ( $tasks [$key] ['include'] )) {
                $tasks [$key] ['include'] = json_decode ( $task ['include'], true );
            }
            if (isset ( $tasks [$key] ['slave'] )) {
                $tasks [$key] ['slave'] = [ ];
            }
            if ($task ['type'] == 'mainline') {
                $tasks [0] [$task ['prev']] = &$tasks [$key];
                foreach ( $task ['include'] as $id ) {
                    if (isset ( $tasks [$id] )) {
                        $task ['slave'] [] = &$tasks [$id];
                    }
                }
            } else if (! empty ( $task ['include'] )) {
                foreach ( $task ['include'] as $id ) {
                    if (isset ( $tasks [$id] )) {
                        $tasks [$key] ['slave'] [] = &$tasks [$id];
                    }
                }
            }
        }
        if (count ( $tasks [0] ) < 2) {
            return $tasks [0];
        }
        $mainline = [ 
            array_pop ( $tasks [0] ) 
        ];
        do {
            $length = count ( $tasks [0] );
            foreach ( $tasks as $k => $task ) {
                if ($mainline [0] ['prev'] == $task ['id']) {
                    array_unshift ( $mainline, $task );
                    unset ( $tasks [0] [$k] );
                    continue;
                }
                if ($mainline [count ( $mainline ) - 1] ['id'] == $task ['prev']) {
                    array_push ( $mainline, $task );
                    unset ( $tasks [0] [$k] );
                    continue;
                }
            }
        } while ( $length != count ( $tasks [0] ) );
        return $mainline;
    }
    public function expired($data, $task) {
        return false;
    }
    public function finished($data, $task, $user_task) {
        $affectedrows = $this->getOne ()->update ( 'users_tasks', [ 
            'status' => 2,
            'finish_timestamp' => TIMESTAMP 
        ], [ ], [ 
            'id' => $user_task ['id'],
            'status' => 1 
        ] );
        if ($affectedrows ['affectedrows'] && strlen ( $user_task ['master'] ) > 2) {
            foreach ( json_decode ( $user_task ['master'], true ) as $id ) {
                $this->getOne ()->update ( 'users_tasks', [ ], [ 
                    'current' => 1 
                ], [ 
                    'id' => $id,
                    'status' => 1 
                ] );
                $master = $this->getOne ()->selectOne ( 'users_tasks', '*', [ 
                    'id' => $id 
                ] ) ['data'];
                if ($master ['current'] == $master ['current']) {
                    $task = $this->getOne ()->selectOne ( 'tasks', '*', [ 
                        'id' => $master ['tid'] 
                    ] ) ['data'];
                    $task ['script']::getInstance ()->finished ( $data, $task, $master );
                }
            }
        }
        return false;
    }
    public function execute($data, $task) {
        $task ['master'] = [ ];
        $tasks [$task ['id']] = $task;
        do {
            $loop = false;
            foreach ( $tasks as $key => $task ) {
                $tasks [$key] ['prev'] = [ ];
                if (isset ( $task ['slave'] )) {
                    foreach ( $task ['slave'] as $v ) {
                        if (! isset ( $tasks [$v ['id']] )) {
                            $tasks [$v ['id']] = $v;
                            $tasks [$v ['id']] ['master'] [$key] = $key;
                        }
                        $tasks [$v ['id']] ['master'] [$key] = $key;
                        $loop = ! empty ( $v ['slave'] ) || $loop;
                    }
                    $tasks [$key] ['slave'] = [ ];
                }
            }
        } while ( $loop );
        do {
            foreach ( $tasks as $key => $task ) {
                if (empty ( $task ['master'] )) {
                    $insertid = $this->create ( [ 
                        'uid' => $data ['id'],
                        'tid' => $task ['id'],
                        'create_timestamp' => TIMESTAMP,
                        'expired_timestamp' => $task ['cycle'] == 'daily' ? self::DAILY : self::ONCE,
                        'total' => empty ( $task ['include'] ) ? $task ['number'] : count ( $task ['include'] ),
                        'master' => json_encode ( $task ['prev'] ) 
                    ] );
                    
                    unset ( $tasks [$key] );
                    foreach ( $tasks as $k => $tmp ) {
                        if (isset ( $tasks [$k] ['master'] [$key] )) {
                            if (is_string ( $tasks [$k] ['prev'] )) {
                                $tasks [$k] ['prev'] = [ ];
                            }
                            $tasks [$k] ['prev'] [] = $insertid;
                            unset ( $tasks [$k] ['master'] [$key] );
                        }
                    }
                    break;
                }
            }
        } while ( count ( $tasks ) );
    }
    public function create($data) {
        if ($data ['tid'] == 12 || $data ['tid'] == 19) {
            $result = $this->getOne ()->selectOne ( 'users_tasks', "*", [ 
                'uid' => $data ['uid'],
                'tid' => $data ['tid']
            ] );
        } else {
            $result = $this->getOne ()->selectOne ( 'users_tasks', "*", [ 
                'uid' => $data ['uid'],
                'tid' => $data ['tid'],
                'expired_timestamp' => $data ['expired_timestamp'] 
            ] );
        }
        if ($result ['rownum']) {
            return $result ['data'] ['id'];
        }
        return $this->getOne ()->insert ( 'users_tasks', $data ) ['insertid'];
    }
    public function query_user_tasks($data) {
        return $this->getOne ()->select ( 'users_tasks', '*', $data, ' and expired_timestamp >= ' . TIMESTAMP );
    }
    public function user_task_set_expired($data) {
        $this->getOne ()->update ( 'users_tasks', [ 
            'status' => 0 
        ], [ ], [ 
            'uid' => $data ['uid'],
            'tid' => $data ['tid'],
            'status' => 1 
        ] );
    }
    public function process($uid, $task = false, $short = true) {
        if ($task) {
            $this->redis ()->hSet ( 'task_process', 'mainline_' . $uid, $task );
        } else {
            $current = $this->redis ()->hGet ( 'task_process', 'mainline_' . $uid );
            if ($short) {
                preg_match ( '/([a-z0-9]*?)task$/i', $current, $match );
                return $match ? $match [1] : '';
            }
            return $current;
        }
    }
    public function receive($data) {
    }
}