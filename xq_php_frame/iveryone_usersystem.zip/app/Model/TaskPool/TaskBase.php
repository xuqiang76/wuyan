<?php

namespace HttpApi\Model\TaskPool;

define ( 'TASK_ONCE', 2000000000 );
define ( 'TASK_DAILY', strtotime ( date ( 'Y-m-d 23:59:59' ) ) );
define ( 'TASK_DAYTIME', strtotime ( date ( 'Y-m-d 00:00:00' ) ) );

use HttpApi\Model\Wallet\WalletBase;
use Beahoo\Exception;

class TaskBase extends WalletBase {
    protected $tableName = 'tasks';
    protected $disabeCache = true;
    protected $class = 'TaskBase';
    protected $notify = true;
    const ONCE = TASK_ONCE;
    const DAILY = TASK_DAILY;
    const DAYTIME = TASK_DAYTIME;
    public static function getInstance(): TaskBase {
        $instance = parent::getInstance ();
        preg_match ( '/([a-z0-9]*?)task$/i', get_called_class (), $class );
        $instance->class = $class [1] ?? $instance->class;
        return $instance;
    }
    public function init() {
        $mainline = [ ];
        foreach ( $this->getOne ()->select ( $this->tableName, '*', [ 
            'enable' => 1 
        ] ) ['data'] as $task ) {
            if ($task ['start'] <= TIMESTAMP && TIMESTAMP < $task ['end']) {
                $tasks [$task ['id']] = $task;
            }
        }
        foreach ( $tasks as &$task ) {
            $task ['include'] = json_decode ( $task ['include'], true );
            $task ['slave'] = [ ];
            foreach ( $task ['include'] as $id ) {
                if (isset ( $tasks [$id] )) {
                    $task ['slave'] [] = &$tasks [$id];
                }
            }
            if ($task ['type'] == 'mainline') {
                $mainline [$task ['prev']] = $task;
            }
        }
        return $this->table ( $mainline );
    }
    public function table(Array $mainline) {
        if (empty ( $mainline )) {
            return [ ];
        }
        $mainlines = [ 
            array_pop ( $mainline ) 
        ];
        while ( $mainline ) {
            foreach ( $mainline as $key => $task ) {
                if (reset ( $mainlines ) ['prev'] == $task ['id']) {
                    array_unshift ( $mainlines, $task );
                    unset ( $mainline [$key] );
                    continue;
                }
                if (end ( $mainlines ) ['id'] == $task ['prev']) {
                    array_push ( $mainlines, $task );
                    unset ( $mainline [$key] );
                    continue;
                }
            }
        }
        foreach ( $mainlines as &$mainline ) {
            foreach ( $mainline ['slave'] as &$task ) {
                if ($task ['type'] == 'branch') {
                    $task ['slave'] = $this->table ( $task ['slave'] );
                }
            }
        }
        return $mainlines;
    }
    public function expired($data, $task) {
        return false;
    }
    public function finished($data, $task, $user_task) {
        $this->notify ( $user_task );
        $affectedrows = $this->getOne ()->update ( 'users_tasks', [ 
            'status' => 2,
            'finish_timestamp' => TIMESTAMP 
        ], [ ], [ 
            'id' => $user_task ['id'],
            'status' => 1 
        ] );
        if ($affectedrows ['affectedrows'] && strlen ( $user_task ['master'] ) > 2) {
            foreach ( json_decode ( $user_task ['master'], true ) as $id ) {
                $this->getOne ()->update ( 'users_tasks', [ ], [ 
                    'current' => 1 
                ], [ 
                    'id' => $id,
                    'status' => 1 
                ] );
                $master = $this->getOne ()->selectOne ( 'users_tasks', '*', [ 
                    'id' => $id 
                ] ) ['data'];
                if ($master ['current'] == $master ['current']) {
                    $task = $this->getOne ()->selectOne ( 'tasks', '*', [ 
                        'id' => $master ['tid'] 
                    ] ) ['data'];
                    $task ['script']::getInstance ()->finished ( $data, $task, $master );
                }
            }
        }
        return false;
    }
    public function execute($data, $task) {
        $task ['master'] = [ ];
        $tasks [$task ['id']] = $task;
        do {
            $loop = false;
            foreach ( $tasks as $key => $task ) {
                $tasks [$key] ['prev'] = [ ];
                if (isset ( $task ['slave'] )) {
                    foreach ( $task ['slave'] as $v ) {
                        if ($v ['type'] == 'activity') {
                            continue;
                        }
                        if (! isset ( $tasks [$v ['id']] )) {
                            $tasks [$v ['id']] = $v;
                            $tasks [$v ['id']] ['master'] [$key] = $key;
                        }
                        $tasks [$v ['id']] ['master'] [$key] = $key;
                        $loop = ! empty ( $v ['slave'] ) || $loop;
                    }
                    $tasks [$key] ['slave'] = [ ];
                }
            }
        } while ( $loop );
        do {
            foreach ( $tasks as $key => $task ) {
                if (empty ( $task ['master'] )) {
                    $insertid = $task ['script']::getInstance ()->create ( [ 
                        'uid' => $data ['id'],
                        'tid' => $task ['id'],
                        'create_timestamp' => TIMESTAMP,
                        'expired_timestamp' => $task ['cycle'] == 'daily' ? self::DAILY : self::ONCE,
                        'total' => empty ( $task ['include'] ) ? $task ['number'] : count ( $task ['include'] ),
                        'master' => json_encode ( $task ['prev'] ) 
                    ] );
                    
                    unset ( $tasks [$key] );
                    foreach ( $tasks as $k => $tmp ) {
                        if (isset ( $tasks [$k] ['master'] [$key] )) {
                            if (is_string ( $tasks [$k] ['prev'] )) {
                                $tasks [$k] ['prev'] = [ ];
                            }
                            $tasks [$k] ['prev'] [] = $insertid;
                            unset ( $tasks [$k] ['master'] [$key] );
                        }
                    }
                    break;
                }
            }
        } while ( count ( $tasks ) );
    }
    public function create($data) {
        preg_match ( '/([a-z0-9]*?)task$/i', get_called_class (), $script );
        $result = $this->getOne ()->selectOne ( 'users_tasks', "*", [ 
            'uid' => $data ['uid'],
            'tid' => $data ['tid'],
            'expired_timestamp' => $data ['expired_timestamp'],
            'script' => $script [1] 
        ] );
        if ($result ['rownum']) {
            return $result ['data'] ['id'];
        }
        $data ['script'] = $script [1];
        return $this->getOne ()->insert ( 'users_tasks', $data ) ['insertid'];
    }
    public function query_user_tasks($data) {
        return $this->getOne ()->select ( 'users_tasks', '*', $data, ' and expired_timestamp >= ' . TIMESTAMP );
    }
    public function user_task_set_expired($data) {
        $this->getOne ()->update ( 'users_tasks', [ 
            'status' => 0 
        ], [ ], [ 
            'uid' => $data ['uid'],
            'tid' => $data ['tid'],
            'status' => 1 
        ] );
    }
    public function process($uid, $task = false, $short = true) {
        if ($task) {
            $this->redis ()->hSet ( 'task_process', 'mainline_' . $uid, $task );
        } else {
            $current = $this->redis ()->hGet ( 'task_process', 'mainline_' . $uid );
            if ($short) {
                preg_match ( '/([a-z0-9]*?)task$/i', $current, $match );
                return $match ? $match [1] : '';
            }
            return $current;
        }
    }
    public function receive($data) {
        $this->notify($data, 'delete');
        return $data;
    }
    public function complete($userinfo, $task) {
        return false;
    }
    public function status($uid, $tid) {
        $utask = $this->query_user_tasks ( [ 
            'id' => $tid,
            'uid' => $uid,
            'status' => [ 
                1,
                2,
                3 
            ] 
        ] ) ['data'] [0] ?? [ ];
        if (empty ( $utask )) {
            throw new Exception ( '', 4000 );
        }
        $task = $this->getOne ()->selectOne ( 'tasks', '*', [ 
            'id' => $utask ['tid'] 
        ] ) ['data'];
        if (empty ( $task )) {
            throw new Exception ( '', 4000 );
        }
        return [ 
            'id' => $utask ['id'],
            'total' => $utask ['total'],
            'current' => $utask ['current'],
            'status' => $utask ['status'],
            'task' => $utask ['script'],
            'reward' => $task ['reward'] 
        ];
    }
    public function notify($data, $op = 'set') {
        if ($this->notify && isset ( $data ['expired_timestamp'] )) {
            $this->redis ()->set ( "task_notify_{$data['uid']}_{$this->class}", $data ['expired_timestamp'], $data ['expired_timestamp'] - TIMESTAMP );
        } else if ($op == 'set') {
            return count ( $this->redis ()->keys ( "task_notify_{$data['uid']}_*" ) );
        } else {
            $this->redis ()->delete ( "task_notify_{$data['uid']}_{$this->class}" );
        }
    }
}