<?php

namespace HttpApi\Model\TaskPool;

class StayTimeTask extends TaskBase {
    public function finished($userinfo, $task, $user_task) {
        if ($this->disabeCache || ! $this->redis ()->get ( 'task_stay_time_' . $userinfo ['id'] )) {
            $stay = $this->getOne ()->selectOne ( 'task_online', 'stat', [ 
                'uid' => $userinfo ['id'],
                'month' => date ( 'Ym' ) 
            ] );
            if ($stay ['rownum']) {
                $stay = json_decode ( $stay ['data'] ['stat'], true );
                $today = date ( 'Ymd' );
                if (isset ( $stay [$today] )) {
                    $this->getOne ()->update ( 'users_tasks', [ 
                        'current' => $stay [$today] > $task ['number'] ? $task ['number'] : $stay [$today] 
                    ], [ ], [ 
                        'id' => $user_task ['id'] 
                    ] );
                    if ($stay [$today] >= $task ['number']) {
                        parent::finished ( $userinfo, $task, $user_task );
                        $this->redis ()->set ( 'task_stay_time_' . $userinfo ['id'], 1, self::DAILY - TIMESTAMP );
                        return true;
                    }
                }
            }
            return false;
        }
        return true;
    }
}