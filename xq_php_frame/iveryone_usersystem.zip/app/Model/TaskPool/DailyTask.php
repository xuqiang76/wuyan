<?php

namespace HttpApi\Model\TaskPool;

class DailyTask extends TaskBase {
    protected $tableName = 'task_daily';
    public function finished($userinfo, $task, $user_task) {
        if ($user_task ['total'] != $user_task ['current']) {
            return;
        }
        if ($this->disabeCache || ! $this->redis ()->get ( 'task_daily_' . $userinfo ['id'] )) {
            $loginStat = $this->getOne ()->selectOne ( $this->tableName, '*', [ 
                'uid' => $userinfo ['id'] 
            ] );
            
            if (! $loginStat ['rownum'] || TASK_DAYTIME != $loginStat ['data'] ['timestamp']) {
                $length = floor ( (TASK_DAYTIME - strtotime ( date ( 'Y-m-d 00:00:00', $userinfo ['create_timestamp'] ) )) / 86400 );
                $stat = '1';
                if ($loginStat ['rownum']) {
                    $stat = substr ( str_pad ( $loginStat ['data'] ['stat'], $length, '0' ), 0, $length ) . $stat;
                    $this->getOne ()->update ( $this->tableName, [ 
                        'stat' => $stat,
                        'timestamp' => TIMESTAMP 
                    ], [ ], [ 
                        'uid' => $userinfo ['id'] 
                    ] );
                } else {
                    $stat = str_pad ( '', $length, '0' ) . $stat;
                    $this->getOne ()->insert ( $this->tableName, [ 
                        'uid' => $userinfo ['id'],
                        'stat' => $stat,
                        'timestamp' => TIMESTAMP 
                    ] );
                }
                parent::finished ( $userinfo, $task, $user_task );
            }
            $this->redis ()->set ( 'task_daily_' . $userinfo ['id'], 1, self::DAILY - TIMESTAMP );
        }
    }
    public function stat($uid) {
        $stat = $this->getOne ()->selectOne ( $this->tableName, '*', [ 
            'uid' => $uid 
        ] );
        
        if ($stat ['rownum']) {
            preg_match_all ( '/(1{1,})$/', $stat ['data'] ['stat'], $match );
            return strlen ( $match [1] [0] );
        } else {
            return 0;
        }
    }
}