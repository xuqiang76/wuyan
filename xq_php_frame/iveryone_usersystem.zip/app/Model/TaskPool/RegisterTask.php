<?php

namespace HttpApi\Model\TaskPool;

use HttpApi\Model\Wallet\Balance;
use HttpApi\Model\Wallet\Details;

class RegisterTask extends TaskBase {
    public function expired($data, $task) {
        if ($data ['create_timestamp'] + 86400 * 5 <= TIMESTAMP) {
            $taskStat = $this->getOne ()->selectOne ( 'users_tasks', '*', [
                'uid' => $data ['id'],
                'tid' => $task ['id']
            ] );
            if ($taskStat ['rownum']) {
                if ($taskStat ['data'] ['status'] == 1) {
                    $this->user_task_set_expired ( $taskStat ['data'] );
                }
                return true;
            }
            $taskid = $this->create ( [
                'uid' => $data ['id'],
                'tid' => $task ['id'],
                'create_timestamp' => $data ['create_timestamp'],
                'expired_timestamp' => self::ONCE,
                'status' => 0
            ] );
            $balance = Balance::getInstance ()->query ( [
                'uid' => $data ['id']
            ] );
            if ($balance ['token'] > 0) {
                $this->process ( $data ['id'], __CLASS__ );
                Details::getInstance ()->confirm ( [
                    'id' => Details::getInstance ()->create ( [
                        'recorder' => $data ['id'],
                        'receiver' => 'system',
                        'category' => Details::Battery_Clean,
                        'uniqid' => $taskid,
                        'amount' => - 1 * $balance ['token']
                    ] )
                ] );
            }
            return true;
        }
        return false;
    }
    function finished($data, $task, $user_task) {
    }
}