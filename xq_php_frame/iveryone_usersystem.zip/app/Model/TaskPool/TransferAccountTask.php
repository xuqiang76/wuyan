<?php

namespace HttpApi\Model\TaskPool;

class TransferAccountTask extends TaskBase {
    public function finished($userinfo, $task, $user_task) {
        if ($this->disabeCache || ! $this->redis ()->get ( 'task_transfer_account_' . $userinfo ['id'] )) {
            if ($user_task ['total'] != $user_task ['current']) {
                return false;
            }
            if ($this->daily ( $userinfo ['id'] ) < 10) {
                return false;
            }
            
            parent::finished ( $userinfo, $task, $user_task );
            $this->redis ()->set ( 'task_transfer_account_' . $userinfo ['id'], 1, self::DAILY - TIMESTAMP );
        }
        return true;
    }
    public function receive($data) {
        $this->getOne ()->update ( 'wallet', [ 
            'transfer' => 1 
        ], [ ], [ 
            'uid' => $data ['uid'] 
        ] );
    }
    public function daily($uid) {
        $stat = $this->getOne ()->selectOne ( 'task_daily', '*', [ 
            'uid' => $uid 
        ] );
        $daily = [ 
            'total' => 10,
            'current' => DailyTask::getInstance ()->stat ( $uid ) 
        ];
        if ($stat ['rownum']) {
            preg_match_all ( '/(1{1,})/', $stat ['data'] ['stat'], $match );
            $history = array_reduce ( $match [1], function ($sum, $item) {
                return max ( $sum, strlen ( $item ) );
            }, 0 );
            $daily ['current'] = $daily ['total'] <= $history ? $daily ['total'] : $daily ['current'];
        }
        return $daily;
    }
}