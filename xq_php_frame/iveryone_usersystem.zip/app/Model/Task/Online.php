<?php

namespace HttpApi\Model\Task;

use Beahoo\Model\Base;
use HttpApi\Model\User\User;
use HttpApi\Tool\Cache;

class Online extends Base
{
    private static $instance;

    private $tableName = 'task_online';

    public static function getInstance()
    {
        if (empty(self::$instance)) {
            self::$instance = new Online();
        }
        return self::$instance;
    }

    public function getTableName()
    {
        return $this->tableName;
    }

    public function getStat($uid, $month)
    {
        $stat = $this->getOne()->selectOne($this->tableName, '*', [
            'uid' => $uid,
            'month' => $month
        ])['data'];
        if(empty($stat)) {
            return [
                'uid' => $uid,
                'month' => $month,
                'stat' => [],
            ];
        }
        $stat['stat'] = json_decode($stat['stat'], true);
        return $stat;
    }

    public function newStat($stat)
    {
        if(Cache::CheckFrequncy('updatestat', $stat['uid'], 2)) {
            $stat['stat'] = json_encode($stat['stat']);
            $stat['timestamp'] = TIMESTAMP;
            $this->getOne()->insert($this->tableName, $stat, [
                'stat',
                'timestamp'
            ]);
            User::getInstance()->updateFields(['update_timestamp' => TIMESTAMP], ['id' => $stat['uid']]);
        }
    }
}