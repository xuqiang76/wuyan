<?php

namespace HttpApi\Model;

use Beahoo\Exception;
use Beahoo\Model\Base;
use Beahoo\Tool\ArrayTool;
use Beahoo\Tool\Config;
use bigcatorm\BaseFunction;
use bigcatorm\BitMap;
use bigcatorm\CatRedis;
use bigcatorm\ListCommonFactory;
use HttpApi\Model\TaskPool\AdwordsFollowTask;
use HttpApi\Model\TaskPool\NoviceGiftTask;
use HttpApi\Model\TaskPool\ReceiveGiftTask;
use HttpApi\Model\User\Service;
use HttpApi\Model\User\User;
use HttpApi\Model\Wallet\Details;
use HttpApi\puremodel\AdIncome;
use HttpApi\puremodel\AdIncomeFactory;
use HttpApi\puremodel\AdMaterial;
use HttpApi\puremodel\AdMaterialFactory;
use HttpApi\puremodel\AdMaterialListFactory;
use HttpApi\puremodel\AdMaterialMultiFactory;
use HttpApi\puremodel\AdScheme;
use HttpApi\puremodel\AdSchemeFactory;
use HttpApi\puremodel\AdSchemeListFactory;
use HttpApi\puremodel\AdSchemeMultiFactory;
use HttpApi\puremodel\Adsense;
use HttpApi\puremodel\AdsenseFactory;
use HttpApi\puremodel\AdsenseListFactory;
use HttpApi\puremodel\AdsenseMultiFactory;
use HttpApi\puremodel\AdsenseOverFactory;
use HttpApi\puremodel\AdsenseOverListFactory;
use HttpApi\puremodel\AdsenseOverMultiFactory;
use HttpApi\puremodel\AdStrategy;
use HttpApi\puremodel\AdStrategyFactory;
use HttpApi\puremodel\AdStrategyListFactory;
use HttpApi\puremodel\AdStrategyMultiFactory;
use HttpApi\puremodel\Adwords;
use HttpApi\puremodel\AdwordsFactory;
use HttpApi\puremodel\AdwordsListFactory;
use HttpApi\puremodel\AdwordsMultiFactory;
use HttpApi\puremodel\UserinfoFactory;
use HttpApi\puremodel\UserinfoListFactory;
use HttpApi\puremodel\UserinfoMultiFactory;
use HttpApi\Tool\Format;
use HttpApi\Tool\Times;

//use HttpApi\Model\Battery;
//WalletBase

class Ad extends Base {
    public static $instance = null;
    public static $int_bit = 64; //用于 BitMap 每64位二进制记录1个int整数，因为 php 64位

    protected $cache_handler = null;
    protected $db_handler = null;

    //看广告用户互斥条件
    public static $ad_plan_struct = [
        1, 2, 3//注册时间 1：0-3天； 2：4-7天； 3：大于7天；
        , 65, 66//被投放用户是否认证 65：认证用户； 66：未认证用户
        , 129, 130, //被投放用户是否匿名 129：非匿名： 130：匿名
    ];

    // 客户端输入的策略转成策略数组格式
    // 广告位置 type : feed 动态广告 / follow 关注广告
    // 注册时间 plan :   1, 3天内 / 2, 7天内 / 3, 所有时间
    // 是否去掉非认证用户 privilege : 1 是 / 0 否
    // 是否去掉匿名用户 ad_anonymous : 1 是 / 0 否
    public static function input2strategy($data = ['plan' => null, 'privilege' => null, 'ad_anonymous' => null]) {
        $strategy_arr = [];
        if ($data['plan'] === null) {
            ;
        } else if ($data['plan'] == 1 || $data['plan'] == 10001) {
            array_push($strategy_arr, 1);
        } else if ($data['plan'] == 2 || $data['plan'] == 10002) {
            array_push($strategy_arr, 1, 2);
        } else if ($data['plan'] == 3 || $data['plan'] == 10003) {
            array_push($strategy_arr, 1, 2, 3);
        } else {
            array_push($strategy_arr, 1, 2, 3);
        }

        if ($data['privilege'] === null) {
            ;
        } else if ($data['privilege'] == 1) {
            array_push($strategy_arr, 65);
        } else {
            array_push($strategy_arr, 65, 66);
        }

        if ($data['ad_anonymous'] === null) {
            ;
        } else if ($data['ad_anonymous'] == 1) {
            array_push($strategy_arr, 129);
        } else {
            array_push($strategy_arr, 129, 130);
        }

        return $strategy_arr;
    }

    public static function strategy2input($strategy_arr, $type) {
        $data = [];

        if (in_array(1, $strategy_arr) && in_array(2, $strategy_arr) && in_array(3, $strategy_arr)) {
            //$data['plan'] = 10003;
            $data['plan'] = 3;
        } else if (in_array(1, $strategy_arr) && in_array(2, $strategy_arr)) {
            //$data['plan'] = 10002;
            $data['plan'] = 2;
        } else if (in_array(1, $strategy_arr)) {
            //$data['plan'] = 10001;
            $data['plan'] = 1;
        } else {
            $data['plan'] = null;
        }
        // if ($type == 'follow') {
        //  $data['plan'] -= 10000;
        // }

        if (in_array(65, $strategy_arr) && in_array(66, $strategy_arr)) {
            $data['privilege'] = 0;
        } else if (in_array(65, $strategy_arr)) {
            $data['privilege'] = 1;
        } else {
            $data['privilege'] = null;
        }

        if (in_array(129, $strategy_arr) && in_array(130, $strategy_arr)) {
            $data['ad_anonymous'] = 0;
        } else if (in_array(129, $strategy_arr)) {
            $data['ad_anonymous'] = 1;
        } else {
            $data['ad_anonymous'] = null;
        }

        return $data;
    }

    //整理用户信息， 取得缓存队列key
    public static function user2cache_key($create_timestamp = 0, $privilege = 0, $ad_anonymous = 0) {
        $cache_key = '';
        //注册时长
        $reg_time = TIMESTAMP - $create_timestamp;
        if ($reg_time <= 86400 * 3) {
            $cache_key = '1';
        } else if ($reg_time <= 86400 * 7) {
            $cache_key = '2';
        } else {
            $cache_key = '3';
        }
        // 认证用户 0认证用户 1非认证用户
        if (empty($privilege)) {
            $cache_key .= '_65';
        } else {
            $cache_key .= '_66';
        }
        //匿名用户 0非匿名 1匿名
        if (empty($ad_anonymous)) {
            $cache_key .= '_129';
        } else {
            $cache_key .= '_130';
        }

        return $cache_key;

    }

    public static function getInstance() {
        $class = get_called_class();
        if (empty(self::$instance)) {
            self::$instance = new $class();
        }
        return self::$instance;
    }

    public static function format_ad($adwords, $is_short = false, $adsense_version = 0, $force_v = false) {
        $adwords_arr = BaseFunction::object_to_array($adwords);
        $return = ['price' => '', 'unit' => ''];
        //新发布的广告和新撮合的广告都用V点
        if ((isset($adwords_arr['version']) && $adwords_arr['version'] > 0) || $adsense_version > 0 || $force_v) {
            if ($is_short) {
                $return['price'] = Format::amount_k($adwords_arr['price'], 1);
            } else {
                $return['price'] = Format::amount_k($adwords_arr['price']);
            }
            $return['currency'] = Details::AdSense_V;
            $return['unit'] = 'V点';
        } else {
            if ($is_short) {
                $return['price'] = Format::amount($adwords_arr['price'], 3);
            } else {
                $return['price'] = Format::amount($adwords_arr['price']);
            }
            $return['currency'] = Details::AdSense;
            $return['unit'] = 'VRY';
        }
        return $return;
    }

    public function __construct() {
        //缓存服务器 redis
        if (empty($this->cache_handler)) {
            $config_redis = Config::read('redis');

            $redis_options['scheme'] = $config_redis['Parameters']['scheme'];
            $redis_options['host'] = $config_redis['Parameters']['host'];
            $redis_options['port'] = $config_redis['Parameters']['port'];
            $redis_options['password'] = $config_redis['Parameters']['password'];
            $redis_options['db'] = $config_redis['db'];
            $redis_options['cachedb'] = $config_redis['cachedb'];

            $this->cache_handler = CatRedis::get_instance($redis_options);
            if (!$this->cache_handler) {
                throw new Exception('Redis 连接失败', 4990);
            }
        }

        //数据库配置
        BaseFunction::set_db($this->getDb()); //兼容 Beahoo\Model\Base 的数据库连接
        //BaseFunction::set_db_options(Config::read('mysql'));

        $this->db_handler = BaseFunction::get_db();
        if (!$this->db_handler) {
            throw new Exception(__CLASS__ . __LINE__, 1002);
        }

        //配置 BitMap
        BitMap::$int_bit = self::$int_bit;
    }

    //创建广告
    public function create($data = ['uid' => '1', 'number' => 0, 'price' => 0, 'type' => '', 'strategy' => '', 'description' => ''], $plus_sql_arr = []) {
        $sql_arr = [];

        if (strlen(trim($data['description'])) == 0
            || empty($data['price'])
            || empty($data['number'])
            || empty($data['uid'])
            || empty($data['type'])

            || (empty($data['strategy']) && $data['type'] != 'novice_gift')
        ) {
            throw new Exception(__CLASS__ . __LINE__, 4003);
        }

        // if (empty($data['free_num'])) {
        //  $data['free_num'] = 0;
        // }

        //数据库事务处理start
        if (!$this->db_handler->inTransaction() && !$this->db_handler->beginTransaction()) {
            throw new Exception(__CLASS__ . __LINE__, 1002);
        }

        // follow / novice_gift 广告不能重复发
        if ($data['type'] == 'follow' || $data['type'] == 'novice_gift') {
            $obj_adwords_list_factory = new ListCommonFactory($this->cache_handler, null, [" select `id` from `adwords`  where advertisers=? and status=? and type=? ", [$data['uid'], 1, $data['type']]]);
            if ($obj_adwords_list = BaseFunction::get_from_factory($obj_adwords_list_factory)) {
                $this->db_handler->inTransaction() && $this->db_handler->rollBack();
                throw new Exception('', 4002);
            }
        }

        // if ($data['type'] == 'novice_gift') {
        //  //每天发没费新人礼的限制
        //  $re_get_adwords_info = $this->get_adwords_info(['uid' => $data['uid'], 'status' => null, 'type' => 'novice_gift', 'start_time' => strtotime(date('Y-m-d 00:00:00')), 'end_time' => null]);
        //  if (isset($re_get_adwords_info['free_num']) && ($data['free_num'] + $re_get_adwords_info['free_num']) > 3) {
        //      throw new Exception('今日免费机会已经用完', 4002);
        //  }
        // }

        $obj_adwords = new Adwords();

        $obj_adwords->advertisers = $data['uid'];
        //$obj_adwords->price = in_array($data['type'], ['novice_gift']) ? abs($data['price'] * 1000) : abs($data['price'] * 1000000);
        $obj_adwords->price = abs(intval($data['price'] * 1000));
        $obj_adwords->number = abs(intval($data['number']));
        $obj_adwords->quota = abs(intval($data['number']));
        //$obj_adwords->free_num = abs(intval($data['free_num']));
        $obj_adwords->version = 20180625; //记录广告版本，处理逻辑区别对待
        $obj_adwords->start_timestamp = TIMESTAMP;

        $obj_adwords->end_timestamp = TIMESTAMP + 356 * 86400;
        $obj_adwords->remark = $data['description'];
        $obj_adwords->type = $data['type'];
        $obj_adwords->status = 1;
        $obj_adwords->strategy = $data['strategy'];

        $obj_adwords->material_title = empty($data['material_title']) ? '' : $data['material_title'];
        $obj_adwords->strategy_title = empty($data['strategy_title']) ? '' : $data['strategy_title'];
        $obj_adwords->scheme_title = empty($data['scheme_title']) ? '' : $data['scheme_title'];
        $obj_adwords->privilege = empty($data['privilege']) ? '' : $data['privilege'];
        $obj_adwords->plan = empty($data['plan']) ? '' : $data['plan'];

        $last_insert_id = $obj_adwords->insert();
        if (!$last_insert_id) {
            $this->db_handler->inTransaction() && $this->db_handler->rollBack();
            throw new Exception(__CLASS__ . __LINE__, 1002);
        }

        $ad_param = [
            'recorder' => $data['uid'],
            'receiver' => 'system',
            //'amount' => abs(intval($data['number'] - $data['free_num']) * $data['price']) * -1,
            'amount' => abs(intval($data['number']) * $data['price']) * (-1),
            'category' => Details::AdWords_V,
            'uniqid' => $last_insert_id,
            'remark' => '',
        ];

        try {
            /////////////////////////////
            $wallet_result = Details::getInstance()->create($ad_param, true);

            //////////////////////////////

        } catch (Exception $e) {
            \HttpApi\Tool\Log::debug('新建广告付费异常_' . var_export($ad_param, TRUE) . "\n", 'panic');
            $this->db_handler->inTransaction() && $this->db_handler->rollBack();
            throw new Exception($e->getMessage(), 4002);
        }

        $sql_arr = array_merge($sql_arr, $plus_sql_arr);

        //执行sql
        BaseFunction::execute_sql_no_transation_throw($sql_arr);

        //提交事务
        $this->db_handler->inTransaction() && $this->db_handler->commit();

        $cache_keys_arr = BitMap::bitmap2keys(explode('_', $data['strategy']));
        foreach ($cache_keys_arr as $cache_key) {
            $tmp_price = $obj_adwords->price / 1000;
            $this->cache_handler->conn->zAdd('adwords_' . $data['type'] . '_' . $cache_key, intval($tmp_price) . BaseFunction::invert_time(TIMESTAMP), $last_insert_id);
        }
        $this->cache_handler->conn->zAdd('adwords_adsense_' . $data['type'] . '_' . $data['uid'], 0, $last_insert_id);

        $obj_adwords->id = $last_insert_id;
        return $obj_adwords;
    }

    // 取得广告
    public function query($data = ['id' => 1, 'all_type' => false]) {
        $return = [];
        $weight_arr = [];

        if (!empty($data['id']) && !is_array($data['id'])) {
            $ids = $data['id'];
        } else if (!empty($data['id']) && is_array($data['id'])) {
            $ids = implode(',', $data['id']);
        } else if (!empty($data['advertisers'])) {
            $where = [" select `id` from `adwords` where advertisers=? ", [$data['advertisers']]];
            if (!empty($data['type'])) {
                $where[0] .= " and type=? ";
                $where[1][] = $data['type'];
            }
            if (!empty($data['status']) && is_array($data['status'])) {
                $where[0] .= " and status in (" . implode(',', $data['status']) . ") ";
            }
        }

        if (isset($ids) && $ids) {
            $obj_adwords_list_factory = new ListCommonFactory($this->cache_handler, $ids);
        } else if (isset($where) && $where) {
            $obj_adwords_list_factory = new ListCommonFactory($this->cache_handler, null, $where);
        }

        if (BaseFunction::get_from_factory($obj_adwords_list_factory)) {
            $obj_adwords_multi_factory = new AdwordsMultiFactory($this->cache_handler, $obj_adwords_list_factory, null, '', 86400);

            if ($obj_adwords_multi = BaseFunction::get_from_factory($obj_adwords_multi_factory)) {

                foreach ($obj_adwords_multi as $item) {
                    if ($item->type == 'novice_gift' && empty($data['all_type'])) {
                        continue;
                    }
                    $return[] = $this->_format_query_adwords($item);
                    $weight_arr[] = $item->id;
                }
            }
            array_multisort($weight_arr, SORT_DESC, $return);

            return $return;
        }

        throw new Exception('', 4000);
        //return [];
    }

    //取消广告
    public function cancel($data) {

        if (!isset($data['id']) || !isset($data['uid'])) {
            throw new Exception(__CLASS__ . __LINE__, 1001);
        }

        //数据库事务处理start
        if (!$this->db_handler->inTransaction() && !$this->db_handler->beginTransaction()) {
            throw new Exception(__CLASS__ . __LINE__, 1002);
        }

        //获取对象
        $obj_adwords_factory = new AdwordsFactory($this->cache_handler, $data['id'], 86400);
        if (!$obj_adwords = BaseFunction::get_from_factory($obj_adwords_factory)) {
            $this->db_handler->inTransaction() && $this->db_handler->rollBack();
            $obj_adwords_factory->clear();
            throw new Exception(__CLASS__ . __LINE__, 4005);
        }

        //处理对象数据 组织sql
        if ($obj_adwords->quota <= 0 || $obj_adwords->status != 1 || (!empty($data['uid']) && $obj_adwords->advertisers != $data['uid'])) {
            $this->db_handler->inTransaction() && $this->db_handler->rollBack();
            throw new Exception('记录状态异常', 4005);
        }
        $obj_adwords->status = 3;

        //兼容后台管理调用
        if (empty($data['uid'])) {
            $data['uid'] = $obj_adwords->advertisers;
        }

        $obj_adwords->update();

        $tmp_ad = self::format_ad($obj_adwords);

        $amount = $obj_adwords->quota * intval($tmp_ad['price']);

        $ad_param = [
            'recorder' => $data['uid'],
            'receiver' => 'system',
            'amount' => $amount,
            'category' => Details::AdWords_Cancel,
            'uniqid' => $data['id'],
            'remark' => '',
        ];

        try {

            //////////////////////////////////////
            if ($amount) {
                $wallet_result = Details::getInstance()->create($ad_param);
            }
            ///////////////////////////////////////

        } catch (Exception $e) {
            \HttpApi\Tool\Log::debug('取消广告付费异常_' . var_export($ad_param, TRUE) . "\n", 'panic');

            $this->db_handler->inTransaction() && $this->db_handler->rollBack();
            throw new Exception($e->getMessage(), 4002);
        }

        //提交事务
        $this->db_handler->inTransaction() && $this->db_handler->commit();

        //缓存
        $obj_adwords_factory->writeback();

        $cache_keys_arr = BitMap::bitmap2keys(explode('_', $obj_adwords->strategy));
        foreach ($cache_keys_arr as $cache_key) {
            $this->cache_handler->conn->zDelete('adwords_' . $obj_adwords->type . '_' . $cache_key, $obj_adwords->id);
        }

        return true;
    }

    //暂停广告
    public function pause($data) {

        if (!isset($data['id']) || !isset($data['uid'])) {
            throw new Exception(__CLASS__ . __LINE__, 1001);
        }

        //数据库事务处理start
        if (!$this->db_handler->inTransaction() && !$this->db_handler->beginTransaction()) {
            throw new Exception(__CLASS__ . __LINE__, 1002);
        }

        //获取对象
        $obj_adwords_factory = new AdwordsFactory($this->cache_handler, $data['id'], 86400);
        if (!$obj_adwords = BaseFunction::get_from_factory($obj_adwords_factory)) {
            $this->db_handler->inTransaction() && $this->db_handler->rollBack();
            $obj_adwords_factory->clear();
            throw new Exception(__CLASS__ . __LINE__, 4005);
        }

        //处理对象数据 组织sql
        if ($obj_adwords->quota <= 0 || $obj_adwords->status != 1 || $obj_adwords->advertisers != $data['uid']) {
            $this->db_handler->inTransaction() && $this->db_handler->rollBack();
            throw new Exception(__CLASS__ . __LINE__, 4005);
        }
        $obj_adwords->status = 4;
        $obj_adwords->update();

        //提交事务
        $this->db_handler->inTransaction() && $this->db_handler->commit();

        //缓存
        $obj_adwords_factory->writeback();

        $cache_keys_arr = BitMap::bitmap2keys(explode('_', $obj_adwords->strategy));
        foreach ($cache_keys_arr as $cache_key) {
            $this->cache_handler->conn->zDelete('adwords_' . $obj_adwords->type . '_' . $cache_key, $obj_adwords->id);
        }
    }

    //继续广告
    public function go_on($data) {

        if (!isset($data['id']) || !isset($data['uid'])) {
            throw new Exception(__CLASS__ . __LINE__, 1001);
        }

        //数据库事务处理start
        if (!$this->db_handler->inTransaction() && !$this->db_handler->beginTransaction()) {
            throw new Exception(__CLASS__ . __LINE__, 1002);
        }

        //获取对象
        $obj_adwords_factory = new AdwordsFactory($this->cache_handler, $data['id'], 86400);
        if (!$obj_adwords_factory->initialize() || !$obj_adwords = $obj_adwords_factory->get()) {
            $this->db_handler->inTransaction() && $this->db_handler->rollBack();
            $obj_adwords_factory->clear();
            throw new Exception(__CLASS__ . __LINE__, 4005);
        }

        //处理对象数据 组织sql
        if ($obj_adwords->quota <= 0 || $obj_adwords->status != 4 || $obj_adwords->advertisers != $data['uid']) {
            $this->db_handler->inTransaction() && $this->db_handler->rollBack();
            throw new Exception(__CLASS__ . __LINE__, 4005);
        }
        $obj_adwords->status = 1;
        $obj_adwords->update();

        //提交事务
        $this->db_handler->inTransaction() && $this->db_handler->commit();

        //缓存
        $obj_adwords_factory->writeback();

        $cache_keys_arr = BitMap::bitmap2keys(explode('_', $obj_adwords->strategy));
        foreach ($cache_keys_arr as $cache_key) {
            $tmp_price = $obj_adwords->price / 1000;
            $this->cache_handler->conn->zAdd('adwords_' . $obj_adwords->type . '_' . $cache_key, intval($tmp_price) . BaseFunction::invert_time(TIMESTAMP), $obj_adwords->id);
        }

    }

    //撮合新手礼广告
    public function query_adsense_gift($data = ['type' => '', 'uid' => 0, 'limit' => 15]) {
        $resulte = [];

        if (empty($data['type']) || !in_array($data['type'], ['novice_gift'])) {
            throw new Exception(__CLASS__ . __LINE__, 1001);
        }

        //整理用户信息， 取得队列key
        if ($data['type'] == 'novice_gift') {
            $cache_key_user = '';
        }
        $cache_key = 'adwords_' . $data['type'] . '_' . $cache_key_user;

        //数据库事务处理start
        if (!$this->db_handler->inTransaction() && !$this->db_handler->beginTransaction()) {
            throw new Exception(__CLASS__ . __LINE__, 1002);
        }

        //新用户24小时内有限观看次数
        $count_adsense = 0;
        if ($data['type'] == 'novice_gift') {

            $ad_click_arr = [];
            $adsense_version_arr = [];
            $adsense_deal_price_arr = [];
            $fix_adwords_arr = [];
            $obj_adsense_arr = BaseFunction::select(" select `adwords`, `is_click`, `version`, `deal_price` from `adsense` where uid = ? and type = ? and timestamp >= ? ", [$data['uid'], $data['type'], TIMESTAMP - 86400]);
            foreach ($obj_adsense_arr as $item) {
                $ad_click_arr[$item['adwords']] = $item['is_click'];
                $adsense_version_arr[$item['adwords']] = $item['version'];
                $adsense_deal_price_arr[$item['adwords']] = $item['deal_price'];
            }

            if ($ad_click_arr) {
                $obj_adsense_list_factory_count = new ListCommonFactory($this->cache_handler, implode(',', array_keys($ad_click_arr)));
                $obj_adwords_multi_factory = new AdwordsMultiFactory($this->cache_handler, $obj_adsense_list_factory_count, null, '', 86400);
                if ($obj_adwords_multi = BaseFunction::get_from_factory($obj_adwords_multi_factory)) {
                    foreach ($obj_adwords_multi as &$item) {
                        if ($item->type == $data['type']) {
                            if (($item->status == 1 || $item->status == 4) && $item->push_num >= $item->number && TIMESTAMP - $item->update_time > 3600) {
                                //if (($item->status == 1 || $item->status == 4) && TIMESTAMP - $item->update_time > 3600) {    //测试用
                                $fix_adwords_arr[$item->id] = $item; // push_num 已满还未完成的广告
                            }
                            array_push($resulte, $this->_format_query_adwords($item, $ad_click_arr[$item->id], 0, false, ['fee' => Format::amount($adsense_deal_price_arr[$item->id]), 'unit' => 'VRY']));
                            $count_adsense++;
                        }
                    }
                }
            }
            if (intval($count_adsense) >= $data['limit']) {
                $this->db_handler->inTransaction() && $this->db_handler->rollBack();
                return $resulte;
            }

            // 非新手撤回广告（用户未点击领取的） 用户注册过了24小时 不算新手  /////////////////////////////////////
            $fix_adsense_id_arr = [];
            $fix_uid_arr = [];
            $self_user_time_out = false;

            if ($fix_adwords_arr) {
                // 满 push_num 的广告之推广记录
                $obj_adsense_arr_fix = BaseFunction::select(" select `id`, `uid`, `adwords`, `is_click` from `adsense` where adwords in (" . implode(',', array_keys($fix_adwords_arr)) . ") and is_click=0  ", []);
                foreach ($obj_adsense_arr_fix as &$item_adsense) {
                    if ($item_adsense['is_click'] == 0) {
                        //未点击成交的
                        $fix_adsense_id_arr[$item_adsense['id']] = &$item_adsense;
                        $fix_uid_arr[] = $item_adsense['uid'];
                    }
                }
                $black_uid = [];
                if ($fix_uid_arr) {
                    $tmp_user_arr_fix = BaseFunction::select(" select `id`, `create_timestamp` from `userinfo` where id in (" . implode(',', $fix_uid_arr) . ")  and create_timestamp<" . (TIMESTAMP - 86400) . " ", []);
                    foreach ($tmp_user_arr_fix as &$item_userinfo) {
                        if (TIMESTAMP - $item_userinfo['create_timestamp'] > 86400) {
                            $black_uid[] = $item_userinfo['id']; //非新手用户数组
                            if ($item_userinfo['id'] == $data['uid']) {
                                $self_user_time_out = true;
                            }
                        }
                    }
                }

                $adsense_del_sql = [];
                $del_adsense_id_arr = [];
                if ($black_uid && $fix_adsense_id_arr) {
                    foreach ($fix_adsense_id_arr as &$item_adsense) {
                        if (in_array($item_adsense['uid'], $black_uid)) {
                            $del_adsense_id_arr[] = $item_adsense['id'];
                            //处理广告里的 push_num 等信息
                            $fix_adwords_arr[$item_adsense['adwords']]->push_num = $fix_adwords_arr[$item_adsense['adwords']]->push_num < 1 ? 0 : $fix_adwords_arr[$item_adsense['adwords']]->push_num - 1;
                            $fix_adwords_arr[$item_adsense['adwords']]->update_time = TIMESTAMP;
                            $adsense_del_sql[] = $fix_adwords_arr[$item_adsense['adwords']]->getUpdateSql();
                        }
                    }
                }

                if ($del_adsense_id_arr) {
                    $obj_list_del_adsense_factory = new ListCommonFactory($this->cache_handler, implode(',', $del_adsense_id_arr));
                    $obj_del_adsense_multi_factory = new AdsenseMultiFactory($this->cache_handler, $obj_list_del_adsense_factory);
                    if ($obj_del_adsense_multi = BaseFunction::get_from_factory($obj_del_adsense_multi_factory)) {
                        foreach ($obj_del_adsense_multi as &$item_del_adsense) {
                            $adsense_del_sql[] = $item_del_adsense->getDelSql();
                        }
                    }
                }

                if ($adsense_del_sql && !BaseFunction::execute_sql_no_transation($this->db_handler, $adsense_del_sql)) {
                    $this->db_handler->inTransaction() && $this->db_handler->rollBack();
                    return $resulte;
                }
            }
        }

        //不是新手了 不让看新人礼包
        if (isset($self_user_time_out) && $self_user_time_out) {
            $resulte = [];
            $this->db_handler->commit();
            return $resulte;
        }

        //看过的广告
        $adwords_show = 'adwords_adsense_' . $data['type'] . '_' . $data['uid'];
        $this->_adwords_adsense_trim(['adwords_show' => $adwords_show, 'uid' => $data['uid']]);

        //去除看过的广告
        $union = 'adwords_union_' . $data['type'] . $data['uid'];
        $this->cache_handler->conn->zunionstore($union, [$cache_key, $adwords_show], [1, 0], 'MIN');
        $this->cache_handler->conn->zRemRangeByScore($union, 0, 0);

        $adwords = $this->cache_handler->conn->zRevRangeByScore($union, '+inf', '-inf', ['limit' => [0, 100]]);
        if (empty($adwords)) {
            $this->db_handler->commit(); //此处之前除了优化adsense表的操作；没有其他 insert update 等业务功能的操作，使用commit 结束事物
            return $resulte;
        }

        $new_result = [];
        foreach ($adwords as $adwords_id) {

            if (($count_adsense + count($new_result)) >= $data['limit']) {
                break;
            }

            //点击付费的广告 插入观看记录 不结算费用
            $re_ad_cost = $this->_ad_cost_per($adwords_id, $data['uid'], $data['type'], [], false);
            if ($re_ad_cost) {
                array_push($new_result, $re_ad_cost);
            } else {
                $this->db_handler->inTransaction() && $this->db_handler->rollBack();
                throw new Exception(__CLASS__ . __LINE__, 1002);
            }

        }

        //提交事务
        $this->db_handler->commit();

        isset($obj_adwords_multi_factory) && $obj_adwords_multi_factory->writeback();
        isset($obj_list_del_adsense_factory) && $obj_list_del_adsense_factory->clear();

        foreach ($new_result as $v) {
            $this->cache_handler->conn->zAdd($adwords_show, 0, $v['id']);
        }
        $this->cache_handler->conn->delete($union);

        return array_merge($resulte, $new_result);
    }

    //广告点击付费成交
    public function ad_click_pay($data = ['uid' => 0, 'adwords_id' => 0, 'type' => '']) {

        if (!in_array($data['type'], ['novice_gift'])
            || empty($data['uid'])
            || empty($data['adwords_id'])
        ) {
            throw new Exception(__CLASS__ . __LINE__, 1001);
        }

        //数据库事务处理start
        if (!$this->db_handler->inTransaction() && !$this->db_handler->beginTransaction()) {
            throw new Exception(__CLASS__ . __LINE__, 1002);
        }

        $return = $this->_ad_cost_per($data['adwords_id'], $data['uid'], $data['type'], [], true);
        ReceiveGiftTask::getInstance()->finish($data['uid']);
        //提交事务
        $this->db_handler->inTransaction() && $this->db_handler->commit();

        return $return;
    }

    //获取每天发布的新手礼信息（free_num 汇总）
    public function get_adwords_info($data = ['uid' => 0, 'status' => null, 'type' => '', 'start_time' => null, 'end_time' => null]) {
        if (!isset($data['uid'])) {
            throw new Exception(__CLASS__ . __LINE__, 1001);
        }

        $return = ['adwords' => [], 'count' => 0, 'free_num' => 0, 'quota_all' => 0, 'send_gift' => 0];

        //是否可以发放新人礼物
        $obj_user_info_factory = new UserinfoFactory($this->cache_handler, $data['uid']);
        if ($obj_user_info = BaseFunction::get_from_factory($obj_user_info_factory)) {
            if (TIMESTAMP - $obj_user_info->create_timestamp > 86400) {
                $return['send_gift'] = 1;
            }
        }

        $bind_arr[] = $data['uid'];
        $sqlraw = " select `id` from `adwords`  where advertisers=? ";
        if (!empty($data['status'])) {
            $sqlraw .= " and status=? ";
            $bind_arr[] = $data['status'];
        }
        if (!empty($data['type'])) {
            $sqlraw .= " and type=? ";
            $bind_arr[] = $data['type'];
        }
        if (!empty($data['start_time'])) {
            $sqlraw .= " and start_timestamp>=? ";
            $bind_arr[] = $data['start_time'];
        }
        if (!empty($data['end_time'])) {
            $sqlraw .= " and start_timestamp=<? ";
            $bind_arr[] = $data['end_time'];
        }

        $obj_adwords_list_factory = new ListCommonFactory($this->cache_handler, null, [$sqlraw, $bind_arr]);
        if (BaseFunction::get_from_factory($obj_adwords_list_factory)) {

            $obj_adwords_multi_factory = new AdwordsMultiFactory($this->cache_handler, $obj_adwords_list_factory, null, '', 86400);
            if ($obj_adwords_multi = BaseFunction::get_from_factory($obj_adwords_multi_factory)) {

                $return['adwords'] = BaseFunction::object_to_array($obj_adwords_multi);
                $return['count'] = count($obj_adwords_multi);

                $tmp_reduce = array_reduce($obj_adwords_multi
                    , function ($carry, $item) {
                        $carry[0] += $item->free_num;
                        $carry[1] += ($item->number - $item->quota);

                        return $carry;
                    }
                    , [0, 0]
                );

                $return['free_num'] = $tmp_reduce[0];
                $return['quota_all'] = $tmp_reduce[1];

            }
        }

        return $return;
    }

    //撮合展示付费广告
    public function query_adsense($data = []) {

        if (empty($data['type'])) {
            \HttpApi\Tool\Log::debug('' . var_export(__CLASS__ . __LINE__, TRUE) . "\n", 'info');
            throw new Exception(__CLASS__ . __LINE__, 1001);
        }

        $userinfo = $data['userinfo'];

        if (($userinfo['ad_follow_switch'] == 0 && $data['type'] == 'follow')
            || ($userinfo['ad_feed_switch'] == 0 && $data['type'] == 'feel')
        ) {
            \HttpApi\Tool\Log::debug('' . var_export(__CLASS__ . __LINE__, TRUE) . "\n", 'info');
            return [];
        }

        //整理用户信息， 取得队列key
        $cache_key_user = self::user2cache_key($userinfo['create_timestamp'], $data['privilege'], $userinfo['ad_anonymous']);
        $cache_key = 'adwords_' . $data['type'] . '_' . $cache_key_user;

        //每N秒看一次广告 follow
        $adsense_timer = 'adsense_timer_' . $data['type'] . $userinfo['id'];
        if (intval($this->cache_handler->conn->get($adsense_timer))) {
            \HttpApi\Tool\Log::debug('' . var_export(__CLASS__ . __LINE__, TRUE) . "\n", 'info');
            return [];
        }

        //数据库事务处理start
        if (!$this->db_handler->inTransaction() && !$this->db_handler->beginTransaction()) {
            \HttpApi\Tool\Log::debug('' . var_export(__CLASS__ . __LINE__, TRUE) . "\n", 'info');
            throw new Exception(__CLASS__ . __LINE__, 1002);
        }

        //一小时内有限观看次数
        $adsense_stat = 'adsense_statkey_' . $userinfo['id'];
        $count_adsense = $this->cache_handler->conn->get($adsense_stat);

        if ($count_adsense === false) {
            $obj_adsense_list_factory_count = new AdsenseListFactory($this->cache_handler, null, [" where uid = ? and timestamp >= ? ", [$userinfo['id'], strtotime(date('Y-m-d H:00:00'))]]);
            if ($obj_adsense_list_count = BaseFunction::get_from_factory($obj_adsense_list_factory_count)) {
                $count_adsense = count($obj_adsense_list_count);
                $this->cache_handler->conn->set($adsense_stat, $count_adsense, strtotime(date('Y-m-d H:00:00')) + 3600 - TIMESTAMP);
            }
        }
        if (intval($count_adsense) >= Config::read('adsense')['quota']) {
            $this->db_handler->inTransaction() && $this->db_handler->rollBack();
            \HttpApi\Tool\Log::debug('' . var_export(__CLASS__ . __LINE__, TRUE) . "\n", 'info');
            return [];
        }

        //看过的广告
        $adwords_show = 'adwords_adsense_' . $data['type'] . '_' . $userinfo['id'];
        $this->_adwords_adsense_trim(['adwords_show' => $adwords_show, 'uid' => $userinfo['id']]);

        //去除看过的广告
        $union = 'adwords_union_' . $data['type'] . $userinfo['id'];
        $this->cache_handler->conn->zunionstore($union, [$cache_key, $adwords_show], [1, 0], 'MIN');
        $this->cache_handler->conn->zRemRangeByScore($union, 0, 0);

        //用户接收广告的价格限额,此处注意限额是V点还是VRY
        $end = '-inf';
        if ($data['type'] == 'follow' && !empty($userinfo['ad_follow_minimal'])) {
            $end = intval($userinfo['ad_follow_minimal']) . '0000000000';
        } else if ($data['type'] == 'feed' && !empty($userinfo['ad_feed_minimal'])) {
            $end = intval($userinfo['ad_feed_minimal']) . '0000000000';
        }
        $adwords = $this->cache_handler->conn->zRevRangeByScore($union, '+inf', $end, ['limit' => [0, 100]]);

        if (empty($adwords)) {
            $this->db_handler->inTransaction() && $this->db_handler->commit(); //此处之前除了优化adsense表的操作；没有其他 insert update 等业务功能的操作，使用commit 结束事物
            \HttpApi\Tool\Log::debug('' . var_export(__CLASS__ . __LINE__, TRUE) . "\n", 'info');
            return [];
        }

        $obj_contacts_list_contactuid = [];
        if ($data['type'] == 'follow') {
            //关注的用户 , 包括自己
            $obj_contacts_list_contactuid_factory = new ListCommonFactory($this->cache_handler, null, [" select `contact_uid` from `contacts` where uid=? and contact_status=1 ", [$userinfo['id']]], 600);
            $obj_contacts_list_contactuid = BaseFunction::get_from_factory($obj_contacts_list_contactuid_factory);
            $obj_contacts_list_contactuid[] = $userinfo['id'];
        }

        $resulte = [];
        foreach ($adwords as $adwords_id) {

            if (count($resulte) >= $data['limit']) {
                break;
            }

            $re_ad_cost = $this->_ad_cost_per($adwords_id, $userinfo['id'], $data['type'], $obj_contacts_list_contactuid);
            if ($re_ad_cost) {
                array_push($resulte, $re_ad_cost);
            } else {
                $this->db_handler->inTransaction() && $this->db_handler->rollBack();
                \HttpApi\Tool\Log::debug('' . var_export(__CLASS__ . __LINE__, TRUE) . "\n", 'info');
                return [];
            }

        }

        foreach ($resulte as $v) {
            //任务
            if ($v['type'] == 'follow' && $v['timestamp'] > strtotime(date('Y-m-d 00:00:00'))) {
                AdwordsFollowTask::getInstance()->show($v['uid']);
            }
        }

        //提交事务
        $this->db_handler->inTransaction() && $this->db_handler->commit();

        foreach ($resulte as $v) {
            $this->cache_handler->conn->incr($adsense_stat);
            $this->cache_handler->conn->zAdd($adwords_show, 0, $v['id']);
        }

        $this->cache_handler->conn->delete($union);

        $data['type'] == 'follow' && $this->cache_handler->conn->set($adsense_timer, 1, 10);

        return $resulte;
    }

    //------------------------------------

    //整理看过的广告 redis 队列缓存
    private function _adwords_adsense_trim($data = ['adwords_show' => '', 'uid' => 0]) {
        $adwords_show = $data['adwords_show'];
        //$this->cache_handler->conn->delete($adwords_show); //测试

        if (!$this->cache_handler->conn->exists($adwords_show)) {
            $tmp[] = $adwords_show;

            //自己发的广告
            $obj_adwords_list_factory = new ListCommonFactory($this->cache_handler, null, [" select `id` from `adwords` where advertisers=? and status=1 ", [$data['uid']]]);
            if ($obj_adwords_list = BaseFunction::get_from_factory($obj_adwords_list_factory)) {
                foreach ($obj_adwords_list as $v) {
                    $tmp[] = 0;
                    $tmp[] = $v;
                }
            }

            //看过的广告
            $obj_adsense_list_adwords_factory = new ListCommonFactory($this->cache_handler, null, [" select `adwords` from `adsense` where uid = ? ", [$data['uid']]]);
            if ($obj_adsense_list_adwords = BaseFunction::get_from_factory($obj_adsense_list_adwords_factory)) {
                foreach ($obj_adsense_list_adwords as $v) {
                    $tmp[] = 0;
                    $tmp[] = $v;
                }
            }
            if (count($tmp) > 2) {
                call_user_func_array([$this->cache_handler->conn, 'zAdd'], $tmp);
                $this->cache_handler->conn->expireAt($adwords_show, time() + 86400); //
            }

            // 优化：备份去除 已经结束或取消的广告
            $over_adwords = [];
            if ($obj_adsense_list_adwords && is_array($obj_adsense_list_adwords)) {
                shuffle($obj_adsense_list_adwords);
                //乱序 然后取有限数量 100
                $obj_adwords_list_deal_factory = new ListCommonFactory($this->cache_handler, implode(',', array_slice($obj_adsense_list_adwords, 0, 100)));
                $obj_adwords_multi_deal_factory = new AdwordsMultiFactory($this->cache_handler, $obj_adwords_list_deal_factory, null, '', 86400);
                //$obj_adwords_multi_deal_factory->clear();
                if ($obj_adwords_multi_deal = BaseFunction::get_from_factory($obj_adwords_multi_deal_factory)) {
                    foreach ($obj_adwords_multi_deal as $val) {
                        //新人礼物领取数量有限，保留在快表
                        if ($val && ($val->status == 2 || $val->status == 3) && $val->type != 'novice_gift') {
                            $over_adwords[] = $val->id;
                        }
                    }
                }
            }
            $move_sql = [];
            if ($over_adwords && is_array($over_adwords)) {
                $in_str = implode(',', $over_adwords);
                $move_sql[] = [" insert into `adsense_over` select * from `adsense` where adwords in (" . $in_str . ") ;", []];
                $move_sql[] = [" delete from `adsense` where adwords in (" . $in_str . ") ;", []];
                BaseFunction::execute_sql_no_transation_throw($move_sql);
            }
        }
        return true;
    }

    //组织广告数据返回值格式
    private function _format_query_adwords($obj_adwords, $is_click = 0, $adsense_version = 0, $force_v = false, $force_fee_unit = ['fee' => 0, 'unit' => '']) {
        $ad_remark = json_decode($obj_adwords->remark, true);
        $description = '';
        if (isset($ad_remark['description'])) {
            $description = $ad_remark['description'];
        } else if (isset($ad_remark['remark'])) {
            $description = $ad_remark['remark'];
        } else {
            $description = $ad_remark;
        }

        $type_str = '';
        switch ($obj_adwords->type) {
            case 'feed':
                $type_str = '[动态广告]';
                break;
            case 'follow':
                $type_str = '[关注广告]';
                break;
            case 'novice_gift':
                $type_str = '[新人礼包]';
                break;
            default:
                $type_str = '[关注广告]';
                break;
        }

        $strategy = self::strategy2input(BitMap::bitmap2arr(explode('_', $obj_adwords->strategy)), $obj_adwords->type);

        $tmp_ad = self::format_ad($obj_adwords, true, $adsense_version, $force_v);
        if (isset($force_fee_unit['fee']) && $force_fee_unit['fee'] > 0) {
            $tmp_ad['price'] = $force_fee_unit['fee'];
            $tmp_ad['unit'] = $force_fee_unit['unit'];
        }

        $return = [
            'id' => $obj_adwords->id,
            'uid' => $obj_adwords->advertisers,
            'fee' => $tmp_ad['price'],
            'unit' => $tmp_ad['unit'],
            'type' => $obj_adwords->type,

            'type_str' => $type_str,
            'price' => $obj_adwords->price,
            'number' => $obj_adwords->number,
            'quota' => $obj_adwords->quota,
            'sold' => $obj_adwords->number - $obj_adwords->quota,

            'version' => $obj_adwords->version,
            'strategy' => $strategy,
            'status' => $obj_adwords->status,
            'description' => $description,
            'assets' => in_array($obj_adwords->type, ['feed', 'novice_gift']) ? $ad_remark['assets'] : [],
            'url' => in_array($obj_adwords->type, ['feed']) ? @$ad_remark['url'] : '',

            'title' => json_decode($obj_adwords->scheme_title),
            'scheme_title' => json_decode($obj_adwords->scheme_title),
            'material_title' => json_decode($obj_adwords->material_title),
            'strategy_title' => json_decode($obj_adwords->strategy_title),

            'timestamp' => $obj_adwords->start_timestamp,
            'timestamp_format' => times::format_date($obj_adwords->start_timestamp),
            'is_click' => $is_click,
        ];
        return $return;
    }

    // 广告成交钱款处理 记录广告成交 处理状态,新撮合的广告 $adsense_version = 20180625
    private function _ad_cost_per($adwords_id, $uid, $type, $black_uid = [], $is_pay = true, $adsense_version = 20180625) {

        $return = [];

        //获取广告对象 以后优化每次取N个
        $obj_adwords_factory = new AdwordsFactory($this->cache_handler, $adwords_id, 86400);
        if ($obj_adwords = BaseFunction::get_from_factory($obj_adwords_factory)) {

            if (!$obj_adwords || $obj_adwords->status != 1) {
                return $return;
            }
            if ($black_uid && in_array($obj_adwords->advertisers, $black_uid)) {
                return $return;
            }
            if ($obj_adwords->type == 'novice_gift' && $obj_adwords->start_timestamp >= strtotime(date('Y-m-d 00:00:00'))) {
                NoviceGiftTask::getInstance()->finish($obj_adwords->advertisers);
            }

            ///////////////////////////////// 以后增加更多广告投放条件 需要计算匹配广告策略
            //$cache_keys_arr = BitMap::bitmap2keys(explode('_', $obj_adwords->strategy));

            //处理对象 执行sql
            if ($obj_adwords->quota > 0 && $obj_adwords->status == 1) {
                if ($is_pay) {
                    $obj_adwords->quota -= 1; //不结算钱的不更新 quota
                    $obj_adwords->click_number += 1;
                }
                if (!$is_pay) {
                    $obj_adwords->push_num += 1; //不结算的广告 push_num 累加；结算的时候不累加
                    // if ($obj_adwords->push_num > $obj_adwords->number) {
                    //     $obj_adwords->push_num;
                    // }
                }
                // if ($obj_adwords->push_num > $obj_adwords->number) {
                //     $this->db_handler->inTransaction() && $this->db_handler->rollBack();
                //     \HttpApi\Tool\Log::debug('' . var_export(__CLASS__ . __LINE__, TRUE) . "\n", 'info');
                //     return $return; //推送过多的广告，rerurn []
                // }
                $obj_adwords->update_time = TIMESTAMP;
                $obj_adwords->status = $obj_adwords->quota > 0 ? 1 : 2;

                if (!$upodate_return = $obj_adwords->update()) {
                    $this->db_handler->inTransaction() && $this->db_handler->rollBack();
                    throw new Exception(__CLASS__ . __LINE__, 1002);
                }
            }

            $adsense_id = 0;
            $obj_adsense_list_factory = new ListCommonFactory($this->cache_handler, null, [" select `id` from `adsense` where uid=? and adwords=? ", [$uid, $adwords_id]]);
            if ($obj_adsense_list = BaseFunction::get_from_factory($obj_adsense_list_factory)) {
                $adsense_id = $obj_adsense_list[0];
            }

            //组织数据
            $tmp_is_click = 0;
            if ($adsense_id && $is_pay) {
                $tmp_is_click = 1;
            }

            //观看广告记录
            if ($adsense_id) {
                $obj_adsense_factory = new AdsenseFactory($this->cache_handler, $adsense_id, 86400);
                $obj_adsense_factory->clear();
                if ($obj_adsense_factory->initialize() && $obj_adsense = $obj_adsense_factory->get()) {
                    if ($is_pay && $obj_adsense->uid == $uid && $obj_adsense->adwords == $adwords_id) {
                        if ($obj_adsense->is_click == 0) {
                            $obj_adsense->is_click = 1;
                        } else if ($is_pay) {
                            $this->db_handler->inTransaction() && $this->db_handler->rollBack();
                            throw new Exception(__CLASS__ . __LINE__, 1002);
                        }
                        if (!$obj_adsense->update()) {
                            $this->db_handler->inTransaction() && $this->db_handler->rollBack();
                            throw new Exception(__CLASS__ . __LINE__, 1002);
                        }
                    }
                }
            } else {
                //插入 广告记录
                $obj_adsense = new Adsense();
                $obj_adsense->uid = $uid;
                $obj_adsense->adwords = $obj_adwords->id;
                $obj_adsense->advertisers = $obj_adwords->advertisers;
                $obj_adsense->timestamp = TIMESTAMP;
                $obj_adsense->version = $adsense_version;
                $obj_adsense->type = $obj_adwords->type;
                if ($is_pay) {
                    $obj_adsense->is_click = 1;
                }

                if (!$adsense_id = $obj_adsense->insert()) {
                    $this->db_handler->inTransaction() && $this->db_handler->rollBack();
                    throw new Exception(__CLASS__ . __LINE__, 1002);
                }
                $obj_adsense->id = $adsense_id;
            }

            if ($is_pay) {

                $ad_param = [
                    'recorder' => $uid,
                    'receiver' => $obj_adwords->advertisers,
                    'amount' => Format::amount_k($obj_adwords->price),
                    'category' => Details::AdSense_V,
                    'uniqid' => $adsense_id,
                    'remark' => '',
                ];

                try {

                    //////////////////////////////// 币处理
                    //[  "orderID"=> 123212,  "currencyType"=>"vry", "amount"=>0.2]
                    $wallet_result = Details::getInstance()->create($ad_param);
                    ///////////////////////////////

                } catch (Exception $e) {
                    \HttpApi\Tool\Log::debug($e->getMessage() . "\t" . $e->getCode() . "\t" . $e->getFile() . "\t" . $e->getLine() . "\n", 'panic');
                    \HttpApi\Tool\Log::debug('广告付费异常_' . var_export($ad_param, TRUE) . "\n", 'panic');

                    $this->db_handler->rollBack();
                    throw new Exception('', 4000);
                }

                $tmp_param = ['uid' => $uid, 'adwords' => 0, 'adwords_v' => 0];
                $tmp_deal_price = 0;
                $tmp_ad_format_fee = ['fee' => 0, 'unit' => 'VRY'];
                if (isset($wallet_result['amount']) && !empty($wallet_result['currencyType'])) {
                    if ('vry' == $wallet_result['currencyType']) {

                        $tmp_param['adwords'] = $tmp_deal_price = intval($wallet_result['amount'] * 1000000);
                        $tmp_ad_format_fee = ['fee' => Format::amount($tmp_deal_price), 'unit' => 'VRY'];
                    } else {
                        $tmp_param['adwords_v'] = $tmp_deal_price = intval($wallet_result['amount'] * 1000);
                        $tmp_ad_format_fee = ['fee' => Format::amount_k($tmp_deal_price), 'unit' => 'V点'];
                    }

                    $obj_adsense->deal_price = $tmp_deal_price;

                    if (!$obj_adsense->update()) {
                        $this->db_handler->inTransaction() && $this->db_handler->rollBack();
                        throw new Exception(__CLASS__ . __LINE__, 1002);
                    }
                }

                //记录广告收入
                $this->_ad_income($tmp_param);
            }

            //展示广告
            $return = $this->_format_query_adwords($obj_adwords, $tmp_is_click, 0, false, ['fee' => Format::amount($obj_adwords->price), 'unit' => 'VRY']);

            //处理已经结束的广告
            if ($obj_adwords->quota == 0) {
                $cache_keys_arr = BitMap::bitmap2keys(explode('_', $obj_adwords->strategy));
                foreach ($cache_keys_arr as $cache_key) {
                    $this->cache_handler->conn->zDelete('adwords_' . $obj_adwords->type . '_' . $cache_key, $obj_adwords->id);
                }
            }

            //缓存
            $obj_adwords_factory->writeback();
            isset($obj_adsense_factory) && $obj_adsense_factory->writeback();

        }
        return $return;
    }

    private function _ad_income($data = ['uid' => 0, 'adwords' => 0, 'adwords_v' => 0]) {

        if (empty($data['uid'])) {
            throw new Exception(__CLASS__ . __LINE__, 1001);
        }

        $sql_arr = [];
        $obj_ad_income_arr = [];

        $sql_ad_income_arr = " select `id` from `ad_income`  where uid=? ";
        $sql_adwords_bind = [$data['uid']];
        if ($result = BaseFunction::select($sql_ad_income_arr, $sql_adwords_bind)) {
            $result_one = current($result);
            $obj_ad_income_factory = new AdIncomeFactory($this->cache_handler, $result_one['id']);
            if ($obj_ad_income = BaseFunction::get_from_factory($obj_ad_income_factory)) {
                if (!empty($data['adwords'])) {
                    $obj_ad_income->adwords += $data['adwords'];
                }
                if (!empty($data['adwords_v'])) {
                    $obj_ad_income->adwords_v += $data['adwords_v'];
                }
                if (!empty($data['adwords_v']) || !empty($data['adwords'])) {
                    $sql_arr[] = $obj_ad_income->getUpdateSql();
                }
            }
        }
        if (empty($obj_ad_income)) {

            $obj_ad_income = new AdIncome();
            $obj_ad_income->uid = $data['uid'];
            $obj_ad_income->init_time = TIMESTAMP;
            $obj_ad_income->update_time = TIMESTAMP;

            $sql_wallet_arr = " select `adwords` from `wallet`  where uid=? ";
            $sql_wallet_bind = [$data['uid']];
            if ($result_wallet = BaseFunction::select($sql_wallet_arr, $sql_wallet_bind)) {
                $result_wallet_one = current($result_wallet);
                $obj_ad_income->adwords = $result_wallet_one['adwords'];
            }

            if (!empty($data['adwords'])) {
                $obj_ad_income->adwords += $data['adwords'];
            }
            if (!empty($data['adwords_v'])) {
                $obj_ad_income->adwords_v += $data['adwords_v'];
            }

            $sql_arr[] = $obj_ad_income->getInsertSql();

        }

        //执行sql
        BaseFunction::execute_sql_no_transation_throw($sql_arr);

        return $obj_ad_income;
    }

    //-------------------------------------

    //广告收入
    public function ad_income($data = ['uid' => 0, 'adwords' => 0, 'adwords_v' => 0]) {

        //数据库事务处理start
        if (!$this->db_handler->inTransaction() && !$this->db_handler->beginTransaction()) {
            throw new Exception(__CLASS__ . __LINE__, 1002);
        }

        $obj_ad_income = $this->_ad_income($data);

        //提交事务
        $this->db_handler->inTransaction() && $this->db_handler->commit();

        return $obj_ad_income;

    }

    // 供给 HttpApi\Controller\Action\Api\Shadow\DetailsAction
    public function details($data) {
        $return_arr = [];
        $weight_arr = [];

        $where_lastid = "";
        $bind = [$data['uid']];

        if (!empty($data['lastid'])) {
            $where_lastid = " and id < ? ";
            $bind = [$data['uid'], $data['lastid']];
        }

        $where = [" select `id` from `adsense`  where uid=? " . $where_lastid . " order by id desc limit 0, 50 ", $bind];
        $where_over = [" select `id` from `adsense_over`  where uid=? " . $where_lastid . " order by id desc limit 0, 50 ", $bind];

        $obj_adsense_list_factory = new ListCommonFactory($this->cache_handler, null, $where);
        if (BaseFunction::get_from_factory($obj_adsense_list_factory)) {
            $obj_adsense_multi_factory = new AdsenseMultiFactory($this->cache_handler, $obj_adsense_list_factory);
            if ($obj_adsense_multi = BaseFunction::get_from_factory($obj_adsense_multi_factory)) {
                $return_arr = array_merge($return_arr, $obj_adsense_multi);
            }
        }

        $obj_adsense_over_list_factory = new ListCommonFactory($this->cache_handler, null, $where_over);
        if (BaseFunction::get_from_factory($obj_adsense_over_list_factory)) {
            $obj_adsense_over_multi_factory = new AdsenseMultiFactory($this->cache_handler, $obj_adsense_over_list_factory);
            if ($obj_adsense_over_multi = BaseFunction::get_from_factory($obj_adsense_over_multi_factory)) {
                $return_arr = array_merge($return_arr, $obj_adsense_over_multi);
            }
        }

        $weight_arr = array_map(
            function ($adsense) {return $adsense->id;}
            , $return_arr
        );

        array_multisort($weight_arr, SORT_DESC, $return_arr);

        $details = BaseFunction::object_to_array($return_arr);
        $details_adsense_version = [];
        foreach ($details as $item) {
            $details_adsense_version[$item['adwords']] = $item;
        }

        $list = [];
        $adwords_arr = [];
        if (!empty($details)) {
            $userinfos = ArrayTool::list2Map(Service::formatSimples(User::getInstance()->getUserinfoByUids(ArrayTool::getFields($details, 'advertisers'))), 'id');

            $adword_id_arr = array_keys($details_adsense_version);
            $obj_adwords_list_factory = new ListCommonFactory($this->cache_handler, implode(',', $adword_id_arr));
            $obj_adwords_multi_factory = new AdwordsMultiFactory($this->cache_handler, $obj_adwords_list_factory);
            if ($obj_adwords_multi = BaseFunction::get_from_factory($obj_adwords_multi_factory)) {
                foreach ($obj_adwords_multi as $adwords_item) {
                    $adwords_arr[$adwords_item->id] = $adwords_item;
                }
            }

            foreach ($details as $key => $detail) {
                if (!isset($adwords_arr[$detail['adwords']]) || $adwords_arr[$detail['adwords']]->type == 'novice_gift') {
                    continue;
                }

                $tmp_adwors = $this->_format_query_adwords($adwords_arr[$detail['adwords']], $detail['is_click'], 0, false, ['fee' => Format::amount($detail['deal_price']), 'unit' => 'VRY']);

                $adword = [
                    'plan_str' => $tmp_adwors['type_str'],
                    'price' => $tmp_adwors['fee'],
                    'unit' => $tmp_adwors['unit'],
                    'receive_time' => Times::format_date($detail['timestamp']),
                ];
                $list[] = [
                    'userinfo' => $userinfos[$detail['advertisers']],
                    'adwords' => $adword,
                    'id' => $detail['id'],
                ];
            }
        }

        return $list;

    }

    //重建广告匹配缓存
    public function set_cache() {

        $i = 0;
        $is_del_cache = [];
        do {
            $cache_key_arr = [];
            $sql_arr = " select id, price, type, strategy, start_timestamp from `adwords` where status=1 order by id limit " . intval($i * 100000) . ", 100000 ";

            if ($result = BaseFunction::select($sql_arr)) {

                foreach ($result as $val) {

                    if (!empty($val['id']) && !empty($val['type']) && isset($val['strategy'])) {
                        $list_cache_keys_arr = BitMap::bitmap2keys(explode('_', $val['strategy']));
                        foreach ($list_cache_keys_arr as $cache_key) {
                            $cache_key_arr['adwords_' . $val['type'] . '_' . $cache_key][] = intval($val['price'] / 1000) . BaseFunction::invert_time(intval($val['start_timestamp']));
                            $cache_key_arr['adwords_' . $val['type'] . '_' . $cache_key][] = $val['id'];
                        }
                    }
                }

                foreach ($cache_key_arr as $cache_key => $cache_val) {
                    if (!$cache_val) {
                        continue;
                    }
                    if (empty($is_del_cache[$cache_key])) {
                        //只删除一次
                        $this->cache_handler->conn->del($cache_key);
                        $is_del_cache[$cache_key] = true;
                    }
                    call_user_func_array([$this->cache_handler->conn, 'zAdd'], array_merge([$cache_key], $cache_val));
                }
                if (RUN_ENV == 'test') {
                    \HttpApi\Tool\Log::debug(var_export($cache_key_arr, TRUE) . "\n", 'info');
                }
                //\HttpApi\Tool\Log::debug(var_export($result, TRUE) . "\n", 'info');

            } else {
                break;
            }
            $i++;

        } while (true);

        return true;
    }

    //重建用户信息对应广告选项的缓存
    public function get_user_strategy_count() {

        $cache_key = 'iveryad_user_strategy_count';
        $get_all_arr = $this->cache_handler->conn->hGetAll($cache_key);
        if (!$get_all_arr || empty($get_all_arr['init_time']) || TIMESTAMP - $get_all_arr['init_time'] > 86400) {
            $this->cache_handler->conn->delete($cache_key);
        } else {
            return $get_all_arr;
        }

        $set_arr = ['init_time' => TIMESTAMP];
        $i = 0;
        do {
            //从数据库分批取数据,尽量把计算放在web端
            //用户量大的时候需要清理僵尸用户
            $sql = ' SELECT w.status, u.create_timestamp, u.ad_anonymous FROM `userinfo` as u LEFT JOIN `wallet` as w on u.id = w.uid order by u.id limit ' . ($i * 1000000) . ', 1000000;';
            $result = BaseFunction::query_sql_backend($sql);

            if ($result && $result['row_count'] > 0) {

                $list_arr = $result['sth']->fetchAll(\PDO::FETCH_NUM);
                if (!$list_arr) {continue;}

                foreach ($list_arr as $val) {
                    if (is_null($val[0])) {
                        continue;
                    }

                    //经过测试php单进程，计算400万条记录需要3秒钟
                    $cache_count_key = self::user2cache_key($val[1], $val[0], $val[2]);
                    if (empty($set_arr[$cache_count_key])) {
                        $set_arr[$cache_count_key] = 1;
                    } else {
                        $set_arr[$cache_count_key] += 1;
                    }
                }

            } else {
                break;
            }

            $i++;
        } while (true);

        $this->cache_handler->conn->hMSet($cache_key, $set_arr);
        $this->cache_handler->conn->expireAt($cache_key, TIMESTAMP + (3 * 86400));

        return $set_arr;
    }

    //---------------------------------------
    //新建素材
    public function material_create($data) {
        $sql_arr = [];

        if (strlen(trim($data['description'])) == 0
            || empty($data['uid'])
            || empty(trim($data['title']))
            || empty($data['type'])
            || empty($data['remark'])
        ) {
            throw new Exception(__CLASS__ . __LINE__, 4003);
        }

        //数据库事务处理start
        if (!$this->db_handler->beginTransaction()) {
            throw new Exception(__CLASS__ . __LINE__, 1002);
        }

        // 不能重复
        $obj_ad_material_list_all_factory = new AdMaterialListFactory($this->cache_handler, null, [" where uid=? and type=? and title=? ", [$data['uid'], $data['type'], $data['title']]]);
        if ($obj_ad_material_list_all_factory->initialize() && $obj_ad_material_list_all_factory->get()) {
            $this->db_handler->inTransaction() && $this->db_handler->rollBack();
            throw new Exception('名称重复', 4004);
        }

        $obj_ad_material = new AdMaterial();

        $obj_ad_material->uid = $data['uid'];
        $obj_ad_material->title = $data['title'];
        $obj_ad_material->description = $data['description'];
        $obj_ad_material->type = $data['type'];

        $obj_ad_material->remark = $data['remark'];
        $obj_ad_material->init_time = TIMESTAMP;
        $obj_ad_material->update_time = TIMESTAMP;

        $sql_arr[] = $obj_ad_material->getInsertSql();

        //执行sql
        BaseFunction::execute_sql_no_transation_throw($sql_arr);

        //提交事务
        $this->db_handler->commit();
    }

    //修改素材
    public function material_update($data) {
        $sql_arr = [];

        if (strlen(trim($data['description'])) == 0
            || empty($data['id'])
            || empty($data['uid'])
            || empty(trim($data['title']))
            || empty($data['type'])
            || empty($data['remark'])
        ) {
            throw new Exception(__CLASS__ . __LINE__, 4003);
        }

        //数据库事务处理start
        if (!$this->db_handler->beginTransaction()) {
            throw new Exception(__CLASS__ . __LINE__, 1002);
        }

        // 不能重复
        // $obj_ad_material_list_all_factory = new AdMaterialListFactory($this->cache_handler, null, [" where uid=? and type=? and title=? ", [$data['uid'], $data['type'], $data['title']]]);
        // if ($obj_ad_material_list_all_factory->initialize() && $obj_ad_material_list_all_factory->get()) {
        //  $this->db_handler->rollBack();
        //  throw new Exception('名称重复', 4004);
        // }

        //获取对象
        $obj_ad_material_factory = new AdMaterialFactory($this->cache_handler, $data['id']);
        if (!$obj_ad_material_factory->initialize() || !$obj_ad_material = $obj_ad_material_factory->get()) {
            $this->db_handler->inTransaction() && $this->db_handler->rollBack();
            $obj_ad_material_factory->clear();
            throw new Exception(__CLASS__ . __LINE__, 4005);
        }

        $obj_ad_material->uid = $data['uid'];
        $obj_ad_material->title = $data['title'];
        $obj_ad_material->description = $data['description'];
        $obj_ad_material->type = $data['type'];

        $obj_ad_material->remark = $data['remark'];
        //$obj_ad_material->init_time = TIMESTAMP;
        $obj_ad_material->update_time = TIMESTAMP;

        $sql_arr[] = $obj_ad_material->getUpdateSql();

        //执行sql
        BaseFunction::execute_sql_no_transation_throw($sql_arr);

        //提交事务
        $this->db_handler->commit();

        $obj_ad_material_factory->writeback();
    }

    //删除素材
    public function material_del($data) {
        $sql_arr = [];

        if (empty($data['id'])
            || empty($data['uid'])
        ) {
            throw new Exception(__CLASS__ . __LINE__, 4003);
        }

        //数据库事务处理start
        if (!$this->db_handler->beginTransaction()) {
            throw new Exception(__CLASS__ . __LINE__, 1002);
        }

        //获取对象
        $obj_ad_material_factory = new AdMaterialFactory($this->cache_handler, $data['id']);
        if (!$obj_ad_material_factory->initialize() || !$obj_ad_material = $obj_ad_material_factory->get()) {
            $this->db_handler->inTransaction() && $this->db_handler->rollBack();
            $obj_ad_material_factory->clear();
            throw new Exception(__CLASS__ . __LINE__, 4005);
        }

        if ($obj_ad_material->uid != $data['uid']) {
            $this->db_handler->inTransaction() && $this->db_handler->rollBack();
            throw new Exception(__CLASS__ . __LINE__, 4005);
        }

        $sql_arr[] = $obj_ad_material->getDelSql();

        //执行sql
        BaseFunction::execute_sql_no_transation_throw($sql_arr);

        //提交事务
        $this->db_handler->commit();

        $obj_ad_material_factory->clear();
    }

    //查询素材
    public function material_query($data) {
        if (empty($data['uid'])
            || empty($data['page'])
            || empty($data['num_per_page'])
            || !isset($data['order']) // 1最新优先 0古老优先
        ) {
            throw new Exception(__CLASS__ . __LINE__, 4003);
        }

        $return_arr = [];
        $all_count = 0;
        $weight_arr = [];
        $order_arr = $data['order'] == 1 ? ['desc', SORT_DESC] : ['', SORT_ASC];

        if (!empty($data['id'])) {
            $where = " where id=? and uid=? ";
            $bind = [$data['id'], $data['uid']];
        } else if (empty($data['type'])) {
            $where = " where uid=? order by id  " . $order_arr[0] . " ";
            $bind = [$data['uid']];
        } else {
            $where = " where uid=? and type=? order by id  " . $order_arr[0] . " ";
            $bind = [$data['uid'], $data['type']];
        }
        $obj_ad_material_list_all_factory = new AdMaterialListFactory($this->cache_handler, null, [$where, $bind]);
        if ($obj_ad_material_list_all_factory->initialize() && $obj_ad_material_list_all = $obj_ad_material_list_all_factory->get()) {
            $all_count = count($obj_ad_material_list_all);

            $list_multi_str = implode(',', array_slice($obj_ad_material_list_all, (intval($data['page']) - 1) * (intval($data['num_per_page'])), intval($data['num_per_page'])));
            if ($list_multi_str) {
                $obj_ad_material_list_factory = new AdMaterialListFactory($this->cache_handler, $list_multi_str);

                $obj_ad_material_multi_factory = new AdMaterialMultiFactory($this->cache_handler, $obj_ad_material_list_factory);
                if ($obj_ad_material_multi_factory->initialize() && $obj_ad_material_multi = $obj_ad_material_multi_factory->get()) {
                    $obj_ad_material_multi_arr = BaseFunction::object_to_array($obj_ad_material_multi);
                    foreach ($obj_ad_material_multi_arr as $key => $val) {
                        $obj_ad_material_multi_arr[$key]['init_time'] = Times::format_date($obj_ad_material_multi_arr[$key]['init_time']);
                        $obj_ad_material_multi_arr[$key]['update_time'] = Times::format_date($obj_ad_material_multi_arr[$key]['update_time']);
                        $obj_ad_material_multi_arr[$key]['description'] = json_decode($obj_ad_material_multi_arr[$key]['description']);
                        $obj_ad_material_multi_arr[$key]['title'] = json_decode($obj_ad_material_multi_arr[$key]['title']);
                        $obj_ad_material_multi_arr[$key]['remark'] = json_decode($obj_ad_material_multi_arr[$key]['remark']);

                        $weight_arr[] = $obj_ad_material_multi_arr[$key]['id'];
                        $return_arr[] = $obj_ad_material_multi_arr[$key];
                    }
                }
            }
        }

        array_multisort($weight_arr, $order_arr[1], $return_arr);

        return ['result' => $return_arr, 'page' => $data['page'], 'num_per_page' => $data['num_per_page'], 'all_count' => $all_count];

    }

    //---------------------------------------
    //新建策略
    public function strategy_create($data) {
        $sql_arr = [];

        if (strlen(trim($data['description'])) == 0
            || empty($data['uid'])
            || empty(trim($data['title']))
            || empty($data['type'])

            || empty($data['price'])
            || empty($data['number'])
            || empty($data['strategy'])
        ) {
            throw new Exception(__CLASS__ . __LINE__, 4003);
        }

        //数据库事务处理start
        if (!$this->db_handler->beginTransaction()) {
            throw new Exception(__CLASS__ . __LINE__, 1002);
        }

        // 不能重复
        $obj_ad_strategy_list_factory = new AdStrategyListFactory($this->cache_handler, null, [" where uid=? and type=? and title=? ", [$data['uid'], $data['type'], $data['title']]]);
        if ($obj_ad_strategy_list_factory->initialize() && $obj_ad_strategy_list_factory->get()) {
            $this->db_handler->inTransaction() && $this->db_handler->rollBack();
            throw new Exception('名称重复', 4004);
        }

        $obj_ad_strategy = new AdStrategy();

        $obj_ad_strategy->uid = $data['uid'];
        $obj_ad_strategy->title = $data['title'];
        $obj_ad_strategy->description = $data['description'];
        $obj_ad_strategy->type = $data['type'];

        $obj_ad_strategy->price = intval($data['price'] * 1000);
        $obj_ad_strategy->number = $data['number'];
        $obj_ad_strategy->strategy = $data['strategy'];
        $obj_ad_strategy->init_time = TIMESTAMP;
        $obj_ad_strategy->update_time = TIMESTAMP;

        $sql_arr[] = $obj_ad_strategy->getInsertSql();

        //执行sql
        BaseFunction::execute_sql_no_transation_throw($sql_arr);

        //提交事务
        $this->db_handler->commit();
    }

    //修改策略
    public function strategy_update($data) {
        $sql_arr = [];

        if (strlen(trim($data['description'])) == 0
            || empty($data['id'])
            || empty($data['uid'])
            || empty(trim($data['title']))
            || empty($data['type'])

            || empty($data['price'])
            || empty($data['number'])
            || empty($data['strategy'])
        ) {
            throw new Exception(__CLASS__ . __LINE__, 4003);
        }

        //数据库事务处理start
        if (!$this->db_handler->beginTransaction()) {
            throw new Exception(__CLASS__ . __LINE__, 1002);
        }

        // 不能重复
        // $obj_ad_strategy_list_factory = new AdStrategyListFactory($this->cache_handler, null, [" where uid=? and type=? and title=? ", [$data['uid'], $data['type'], $data['title']]]);
        // if ($obj_ad_strategy_list_factory->initialize() && $obj_ad_strategy_list_factory->get()) {
        //  $this->db_handler->inTransaction() && $this->db_handler->rollBack();
        //  throw new Exception('名称重复', 4004);
        // }

        //获取对象
        $obj_ad_strategy_factory = new AdStrategyFactory($this->cache_handler, $data['id']);
        if (!$obj_ad_strategy_factory->initialize() || !$obj_ad_strategy = $obj_ad_strategy_factory->get()) {
            $this->db_handler->inTransaction() && $this->db_handler->rollBack();
            $obj_ad_strategy_factory->clear();
            throw new Exception(__CLASS__ . __LINE__, 4005);
        }

        $obj_ad_strategy->uid = $data['uid'];
        $obj_ad_strategy->title = $data['title'];
        $obj_ad_strategy->description = $data['description'];
        $obj_ad_strategy->type = $data['type'];

        $obj_ad_strategy->price = intval($data['price'] * 1000);
        $obj_ad_strategy->number = $data['number'];
        $obj_ad_strategy->strategy = $data['strategy'];
        //$obj_ad_strategy->init_time = TIMESTAMP;
        $obj_ad_strategy->update_time = TIMESTAMP;

        $sql_arr[] = $obj_ad_strategy->getUpdateSql();

        //执行sql
        BaseFunction::execute_sql_no_transation_throw($sql_arr);

        //提交事务
        $this->db_handler->commit();

        $obj_ad_strategy_factory->writeback();
    }

    //删除策略
    public function strategy_del($data) {
        $sql_arr = [];

        if (empty($data['id'])
            || empty($data['uid'])
        ) {
            throw new Exception(__CLASS__ . __LINE__, 4003);
        }

        //数据库事务处理start
        if (!$this->db_handler->beginTransaction()) {
            throw new Exception(__CLASS__ . __LINE__, 1002);
        }

        //获取对象
        $obj_ad_strategy_factory = new AdStrategyFactory($this->cache_handler, $data['id']);
        if (!$obj_ad_strategy_factory->initialize() || !$obj_ad_strategy = $obj_ad_strategy_factory->get()) {
            $this->db_handler->inTransaction() && $this->db_handler->rollBack();
            $obj_ad_strategy_factory->clear();
            throw new Exception(__CLASS__ . __LINE__, 4005);
        }

        if ($obj_ad_strategy->uid != $data['uid']) {
            $this->db_handler->inTransaction() && $this->db_handler->rollBack();
            throw new Exception(__CLASS__ . __LINE__, 4005);
        }

        $sql_arr[] = $obj_ad_strategy->getDelSql();

        //执行sql
        BaseFunction::execute_sql_no_transation_throw($sql_arr);

        //提交事务
        $this->db_handler->commit();

        $obj_ad_strategy_factory->clear();
    }

    //查询策略
    public function strategy_query($data) {
        if (empty($data['uid'])
            || empty($data['page'])
            || empty($data['num_per_page'])
            || !isset($data['order']) // 1最新优先 0古老优先
        ) {
            throw new Exception(__CLASS__ . __LINE__, 4003);
        }

        $return_arr = [];
        $all_count = 0;
        $weight_arr = [];
        $order_arr = $data['order'] == 1 ? ['desc', SORT_DESC] : ['', SORT_ASC];

        if (!empty($data['id'])) {
            $where = " where id=? and uid=? ";
            $bind = [$data['id'], $data['uid']];
        } else if (empty($data['type'])) {
            $where = " where uid=? order by id " . $order_arr[0] . " ";
            $bind = [$data['uid']];
        } else {
            $where = " where uid=? and type=? order by id " . $order_arr[0] . " ";
            $bind = [$data['uid'], $data['type']];
        }
        $obj_ad_strategy_list_all_factory = new AdStrategyListFactory($this->cache_handler, null, [$where, $bind]);
        if ($obj_ad_strategy_list_all_factory->initialize() && $obj_ad_strategy_list_all = $obj_ad_strategy_list_all_factory->get()) {
            $all_count = count($obj_ad_strategy_list_all);

            $list_multi_str = implode(',', array_slice($obj_ad_strategy_list_all, (intval($data['page']) - 1) * (intval($data['num_per_page'])), intval($data['num_per_page'])));
            if ($list_multi_str) {
                $obj_ad_strategy_list_factory = new AdStrategyListFactory($this->cache_handler, $list_multi_str);

                $obj_ad_strategy_multi_factory = new AdStrategyMultiFactory($this->cache_handler, $obj_ad_strategy_list_factory);
                if ($obj_ad_strategy_multi_factory->initialize() && $obj_ad_strategy_multi = $obj_ad_strategy_multi_factory->get()) {

                    //用于计算本策略覆盖的用户量
                    $user_strategy_count = $this->get_user_strategy_count();

                    $obj_ad_strategy_multi_arr = BaseFunction::object_to_array($obj_ad_strategy_multi);
                    foreach ($obj_ad_strategy_multi_arr as $key => $val) {
                        $obj_ad_strategy_multi_arr[$key] = array_merge(self::strategy2input(BitMap::bitmap2arr(explode('_', $val['strategy'])), $val['type']), $obj_ad_strategy_multi_arr[$key]);
                        $obj_ad_strategy_multi_arr[$key]['price'] = Format::amount_k($obj_ad_strategy_multi_arr[$key]['price']);
                        $obj_ad_strategy_multi_arr[$key]['init_time'] = Times::format_date($obj_ad_strategy_multi_arr[$key]['init_time']);
                        $obj_ad_strategy_multi_arr[$key]['update_time'] = Times::format_date($obj_ad_strategy_multi_arr[$key]['update_time']);
                        $obj_ad_strategy_multi_arr[$key]['title'] = json_decode($obj_ad_strategy_multi_arr[$key]['title']);
                        $obj_ad_strategy_multi_arr[$key]['description'] = json_decode($obj_ad_strategy_multi_arr[$key]['description']);

                        $obj_ad_strategy_multi_arr[$key]['user_count'] = 0;
                        $cache_keys_arr = BitMap::bitmap2keys(explode('_', $val['strategy']));

                        foreach ($cache_keys_arr as $cache_key) {
                            if (isset($user_strategy_count[$cache_key])) {
                                $obj_ad_strategy_multi_arr[$key]['user_count'] += $user_strategy_count[$cache_key];
                            }
                        }

                        $weight_arr[] = $obj_ad_strategy_multi_arr[$key]['id'];
                        $return_arr[] = $obj_ad_strategy_multi_arr[$key];
                    }
                }
            }

        }

        array_multisort($weight_arr, $order_arr[1], $return_arr);

        return ['result' => $return_arr, 'page' => $data['page'], 'num_per_page' => $data['num_per_page'], 'all_count' => $all_count];
    }

    //---------------------------------------
    //新建方案
    public function scheme_create($data) {
        $sql_arr = [];
        $id = 0;

        if (strlen(trim($data['description'])) == 0
            || empty($data['uid'])
            || empty(trim($data['title']))
            || empty($data['type'])

            || empty($data['material_id'])
            || empty($data['strategy_id'])
        ) {
            throw new Exception(__CLASS__ . __LINE__, 4003);
        }

        //数据库事务处理start
        if (!$this->db_handler->beginTransaction()) {
            throw new Exception(__CLASS__ . __LINE__, 1002);
        }

        // 不能重复
        $obj_ad_scheme_list_all_factory = new AdSchemeListFactory($this->cache_handler, null, [" where uid=? and type=? and title=? ", [$data['uid'], $data['type'], $data['title']]]);
        if ($obj_ad_scheme_list_all_factory->initialize() && $obj_ad_scheme_list_all_factory->get()) {
            $this->db_handler->inTransaction() && $this->db_handler->rollBack();
            throw new Exception('名称重复', 4004);
        }

        //获取对象
        $obj_ad_material_factory = new AdMaterialFactory($this->cache_handler, $data['material_id']);
        if (!$obj_ad_material_factory->initialize() || !$obj_ad_material = $obj_ad_material_factory->get()) {
            $this->db_handler->inTransaction() && $this->db_handler->rollBack();
            $obj_ad_material_factory->clear();
            throw new Exception(__CLASS__ . __LINE__, 4005);
        }
        $obj_ad_strategy_factory = new AdStrategyFactory($this->cache_handler, $data['strategy_id']);
        if (!$obj_ad_strategy_factory->initialize() || !$obj_ad_strategy = $obj_ad_strategy_factory->get()) {
            $this->db_handler->inTransaction() && $this->db_handler->rollBack();
            $obj_ad_strategy_factory->clear();
            throw new Exception(__CLASS__ . __LINE__, 4005);
        }

        if ($obj_ad_material->uid != $data['uid'] || $obj_ad_strategy->uid != $data['uid'] || $obj_ad_material->type != $data['type'] || $obj_ad_strategy->type != $data['type']) {
            $this->db_handler->inTransaction() && $this->db_handler->rollBack();
            throw new Exception('广告位置不匹配', 4005);
        }

        $obj_ad_scheme = new AdScheme();

        $obj_ad_scheme->uid = $data['uid'];
        $obj_ad_scheme->title = $data['title'];
        $obj_ad_scheme->description = $data['description'];
        $obj_ad_scheme->type = $data['type'];

        $obj_ad_scheme->remark = $obj_ad_material->remark;
        $obj_ad_scheme->price = $obj_ad_strategy->price;
        $obj_ad_scheme->number = $obj_ad_strategy->number;
        $obj_ad_scheme->strategy = $obj_ad_strategy->strategy;
        $obj_ad_scheme->init_time = TIMESTAMP;

        $obj_ad_scheme->update_time = TIMESTAMP;
        $obj_ad_scheme->material_title = $obj_ad_material->title;
        $obj_ad_scheme->strategy_title = $obj_ad_strategy->title;

        $sql_arr[] = $obj_ad_scheme->getInsertSql();

        //执行sql
        $sql_result_arr = BaseFunction::execute_sql_no_transation_throw($sql_arr);

        //提交事务
        $this->db_handler->commit();

        if ($sql_result_arr && isset($sql_result_arr[0]['last_insert_id'])) {
            $id = $sql_result_arr[0]['last_insert_id'];
        }
        return $id;
    }

    //删除方案
    public function scheme_del($data) {
        $sql_arr = [];

        if (empty($data['id'])
            || empty($data['uid'])
        ) {
            throw new Exception(__CLASS__ . __LINE__, 4003);
        }

        //数据库事务处理start
        if (!$this->db_handler->beginTransaction()) {
            throw new Exception(__CLASS__ . __LINE__, 1002);
        }

        //获取对象
        $obj_ad_scheme_factory = new AdSchemeFactory($this->cache_handler, $data['id']);
        if (!$obj_ad_scheme_factory->initialize() || !$obj_ad_scheme = $obj_ad_scheme_factory->get()) {
            $this->db_handler->inTransaction() && $this->db_handler->rollBack();
            $obj_ad_scheme_factory->clear();
            throw new Exception(__CLASS__ . __LINE__, 4005);
        }
        if ($obj_ad_scheme->uid != $data['uid']) {
            throw new Exception(__CLASS__ . __LINE__, 4005);
        }

        $sql_arr[] = $obj_ad_scheme->getDelSql();

        //执行sql
        if ($sql_arr && !BaseFunction::execute_sql_no_transation($this->db_handler, $sql_arr)) {
            $this->db_handler->inTransaction() && $this->db_handler->rollBack();
            throw new Exception(__CLASS__ . __LINE__, 1002);
        }

        //提交事务
        $this->db_handler->commit();

        $obj_ad_scheme_factory->clear();
    }

    //查询方案
    public function scheme_query($data) {
        if (empty($data['uid'])
            || empty($data['page'])
            || empty($data['num_per_page'])
            || !isset($data['status']) // 0未投放 1进行中 2已完成 3被取消 4暂停
             || !isset($data['order']) // 1最新优先 0古老优先
        ) {
            throw new Exception(__CLASS__ . __LINE__, 4003);
        }

        $return_arr = [];
        $all_count = 0;
        $weight_arr = [];
        $order_arr = $data['order'] == 1 ? ['desc', SORT_DESC] : ['', SORT_ASC];

        if ($data['status'] == 0) {
            // 取 scheme 表
            if (!empty($data['id'])) {
                $where = " where id=? and uid=? ";
                $bind = [$data['id'], $data['uid']];
            } else if (empty($data['type'])) {
                $where = " where uid=? order by id " . $order_arr[0] . " ";
                $bind = [$data['uid']];
            } else {
                $where = " where uid=? and type=? order by id " . $order_arr[0] . " ";
                $bind = [$data['uid'], $data['type']];
            }
            $obj_ad_scheme_list_all_factory = new AdSchemeListFactory($this->cache_handler, null, [$where, $bind]);
            if ($obj_ad_scheme_list_all_factory->initialize() && $obj_ad_scheme_list_all = $obj_ad_scheme_list_all_factory->get()) {
                $all_count = count($obj_ad_scheme_list_all);

                $list_multi_str = implode(',', array_slice($obj_ad_scheme_list_all, (intval($data['page']) - 1) * (intval($data['num_per_page'])), intval($data['num_per_page'])));
                if ($list_multi_str) {
                    $obj_ad_scheme_list_factory = new AdSchemeListFactory($this->cache_handler, $list_multi_str);

                    $obj_ad_scheme_multi_factory = new AdSchemeMultiFactory($this->cache_handler, $obj_ad_scheme_list_factory);
                    if ($obj_ad_scheme_multi_factory->initialize() && $obj_ad_scheme_multi = $obj_ad_scheme_multi_factory->get()) {
                        $obj_ad_scheme_multi_arr = BaseFunction::object_to_array($obj_ad_scheme_multi);
                        foreach ($obj_ad_scheme_multi_arr as $key => $val) {
                            if (!empty($data['type_in']) && !in_array($val['type'], $data['type_in'])) {
                                continue;
                            }
                            $obj_ad_scheme_multi_arr[$key] = array_merge($obj_ad_scheme_multi_arr[$key], self::strategy2input(BitMap::bitmap2arr(explode('_', $val['strategy'])), $val['type']));

                            $obj_ad_scheme_multi_arr[$key]['price'] = Format::amount_k($obj_ad_scheme_multi_arr[$key]['price']);

                            $obj_ad_scheme_multi_arr[$key]['init_time'] = Times::format_date($obj_ad_scheme_multi_arr[$key]['init_time']);
                            $obj_ad_scheme_multi_arr[$key]['remark'] = json_decode($obj_ad_scheme_multi_arr[$key]['remark']);
                            $obj_ad_scheme_multi_arr[$key]['title'] = json_decode($obj_ad_scheme_multi_arr[$key]['title']);
                            $obj_ad_scheme_multi_arr[$key]['material_title'] = json_decode($obj_ad_scheme_multi_arr[$key]['material_title']);
                            $obj_ad_scheme_multi_arr[$key]['strategy_title'] = json_decode($obj_ad_scheme_multi_arr[$key]['strategy_title']);
                            $obj_ad_scheme_multi_arr[$key]['description'] = json_decode($obj_ad_scheme_multi_arr[$key]['description']);
                            $obj_ad_scheme_multi_arr[$key]['status'] = 0; //未投放的方案，补一个默认状态

                            $weight_arr[] = $obj_ad_scheme_multi_arr[$key]['id'];
                            $return_arr[] = $obj_ad_scheme_multi_arr[$key];

                        }
                    }
                }
            }
        } else if (in_array($data['status'], [1, 2, 3, 4]) || (is_array($data['status']) && $data['status'] == array_intersect($data['status'], [1, 2, 3, 4]))) {
            //把 $data['status'] 变成数组
            if (!$data['status']) {
                throw new Exception('参数错误' . __CLASS__ . __LINE__, 4004);
            } else if (!is_array($data['status'])) {
                $data['status'] = [intval($data['status'])];
            }

            $where_status = " status in (" . implode(',', $data['status']) . ")";

            //取 adwords 表
            if (!empty($data['id'])) {
                $where = " where id=? and advertisers=? ";
                $bind = [$data['id'], $data['uid']];
            } else if (empty($data['type'])) {
                $where = " where advertisers=? and " . $where_status . " order by id " . $order_arr[0] . " ";
                $bind = [$data['uid']];
            } else {
                $where = " where advertisers=? and  " . $where_status . " and type=? order by id " . $order_arr[0] . " ";
                $bind = [$data['uid'], $data['type']];
            }

            $obj_adwords_list_all_factory = new AdWordsListFactory($this->cache_handler, null, [$where, $bind]);
            if ($obj_adwords_list_all_factory->initialize() && $obj_adwords_list_all = $obj_adwords_list_all_factory->get()) {
                $all_count = count($obj_adwords_list_all);

                $list_multi_str = implode(',', array_slice($obj_adwords_list_all, (intval($data['page']) - 1) * (intval($data['num_per_page'])), intval($data['num_per_page'])));
                if ($list_multi_str) {
                    $obj_adwords_list_factory = new AdWordsListFactory($this->cache_handler, $list_multi_str);

                    $obj_adwords_multi_factory = new AdwordsMultiFactory($this->cache_handler, $obj_adwords_list_factory, null, '', 86400);
                    if ($obj_adwords_multi_factory->initialize() && $obj_adwords_multi = $obj_adwords_multi_factory->get()) {

                        $obj_adwords_multi_arr = BaseFunction::object_to_array($obj_adwords_multi);

                        foreach ($obj_adwords_multi_arr as $key => $val) {
                            if (!empty($data['type_in']) && !in_array($val['type'], $data['type_in'])) {
                                continue;
                            }
                            $obj_adwords_multi_arr[$key] = array_merge($obj_adwords_multi_arr[$key], self::strategy2input(BitMap::bitmap2arr(explode('_', $val['strategy'])), $val['type']));

                            $obj_adwords_multi_arr[$key]['price'] = Format::amount_k($obj_adwords_multi_arr[$key]['price']);

                            $obj_adwords_multi_arr[$key]['init_time'] = Times::format_date($obj_adwords_multi_arr[$key]['start_timestamp']);
                            $obj_adwords_multi_arr[$key]['uid'] = $obj_adwords_multi_arr[$key]['advertisers'];

                            $obj_adwords_multi_arr[$key]['remark'] = json_decode($obj_adwords_multi_arr[$key]['remark']);
                            $obj_adwords_multi_arr[$key]['title'] = json_decode($obj_adwords_multi_arr[$key]['scheme_title']);
                            $obj_adwords_multi_arr[$key]['scheme_title'] = json_decode($obj_adwords_multi_arr[$key]['scheme_title']);
                            $obj_adwords_multi_arr[$key]['material_title'] = json_decode($obj_adwords_multi_arr[$key]['material_title']);
                            $obj_adwords_multi_arr[$key]['strategy_title'] = json_decode($obj_adwords_multi_arr[$key]['strategy_title']);

                            $weight_arr[] = $obj_adwords_multi_arr[$key]['id'];
                            $return_arr[] = $obj_adwords_multi_arr[$key];

                        }
                    }
                }
            }
        }

        array_multisort($weight_arr, $order_arr[1], $return_arr);

        return ['result' => $return_arr, 'page' => $data['page'], 'num_per_page' => $data['num_per_page'], 'all_count' => $all_count];

    }

    //投放方案
    public function scheme_put($data) {
        if (empty($data['id'])
            || empty($data['uid'])
        ) {
            throw new Exception(__CLASS__ . __LINE__, 4003);
        }

        //获取对象
        $obj_ad_scheme_factory = new AdSchemeFactory($this->cache_handler, $data['id']);
        if (!$obj_ad_scheme_factory->initialize() || !$obj_ad_scheme = $obj_ad_scheme_factory->get()) {
            $obj_ad_scheme_factory->clear();
            throw new Exception('', 4005);
        }
        if ($obj_ad_scheme->uid != $data['uid']) {
            throw new Exception(__CLASS__ . __LINE__, 4005);
        }
        $plus_sql_arr[] = $obj_ad_scheme->getDelSql();
        $obj_ad_scheme_factory->clear();

        $data = ['uid' => $obj_ad_scheme->uid
            , 'number' => $obj_ad_scheme->number
            , 'price' => Format::amount_k($obj_ad_scheme->price)
            , 'type' => $obj_ad_scheme->type
            , 'strategy' => $obj_ad_scheme->strategy

            , 'description' => $obj_ad_scheme->remark
            , 'scheme_title' => $obj_ad_scheme->title
            , 'material_title' => $obj_ad_scheme->material_title
            , 'strategy_title' => $obj_ad_scheme->strategy_title,
        ];
        $this->create($data, $plus_sql_arr);

    }

    public function scheme_create_put($data) {
        $id = $this->scheme_create($data);
        if ($id) {
            $this->scheme_put(['id' => $id, 'uid' => $data['uid']]);
        }
    }

    //---------------------------------------
    //观看广告的用户列表 分页
    public function adsense_user($data) {

        if (empty($data['id'])
            || empty($data['uid'])
            || empty($data['page'])
            || empty($data['num_per_page'])
            || !isset($data['order']) // 1最新优先 0古老优先
        ) {
            throw new Exception(__CLASS__ . __LINE__, 4003);
        }

        $return = [];
        $all_count = 0;
        $weight_arr = [];
        $order_arr = $data['order'] == 1 ? ['desc', SORT_DESC] : ['', SORT_ASC];

        $obj_adwords_factory = new AdwordsFactory($this->cache_handler, $data['id'], 86400);
        if (!$obj_adwords_factory->initialize() || !$obj_adwords = $obj_adwords_factory->get()) {
            $obj_adwords_factory->clear();
            throw new Exception(__CLASS__ . __LINE__, 4005);
        }
        //作者和广告状态验证
        if ($obj_adwords->advertisers != $data['uid'] || ($obj_adwords->status != 2 && $obj_adwords->status != 3)) {
            throw new Exception(__CLASS__ . __LINE__, 4005);
        }

        $where = [" where adwords=? order by id  " . $order_arr[0] . " ", [$data['id']]];

        $obj_adsense_over_list_all_factory = new AdsenseOverListFactory($this->cache_handler, null, $where);
        if ($obj_adsense_over_list_all_factory->initialize() && $obj_adsense_over_list_all = $obj_adsense_over_list_all_factory->get()) {

            $all_count = count($obj_adsense_over_list_all);

            $list_multi_str = implode(',', array_slice($obj_adsense_over_list_all, (intval($data['page']) - 1) * (intval($data['num_per_page'])), intval($data['num_per_page'])));
            if ($list_multi_str) {
                $obj_adsense_over_list_factory = new AdsenseOverListFactory($this->cache_handler, $list_multi_str);

                $obj_adsense_over_multi_factory = new AdsenseOverMultiFactory($this->cache_handler, $obj_adsense_over_list_factory);
                if ($obj_adsense_over_multi_factory->initialize() && $obj_adsense_over_multi = $obj_adsense_over_multi_factory->get()) {
                    //取用户
                    $adsense_uid = [];
                    foreach ($obj_adsense_over_multi as $key => $val) {
                        $adsense_uid[] = $val->uid;
                        $tmp_val = BaseFunction::object_to_array($val);

                        $tmp_val['timestamp'] = Times::format_date($tmp_val['timestamp']);
                        $weight_arr[] = $tmp_val['id'];

                        $return['adsense'][] = $tmp_val;

                    }
                    $return['ad_user'] = [];
                    $obj_userinfo_list_factory = new UserinfoListFactory($this->cache_handler, implode(',', $adsense_uid));
                    if ($obj_userinfo_list_factory->initialize() && $obj_userinfo_list_factory->get()) {
                        $obj_userinfo_multi_factory = new UserinfoMultiFactory($this->cache_handler, $obj_userinfo_list_factory);
                        if ($obj_userinfo_multi_factory->initialize() && $obj_userinfo_multi = $obj_userinfo_multi_factory->get()) {
                            foreach ($obj_userinfo_multi as $user_val) {
                                $return['ad_user'][$user_val->id] = ['id' => $user_val->id, 'nickname' => $user_val->nickname, 'avatar' => $user_val->avatar];
                            }
                        }
                    }

                    foreach ($return['adsense'] as $key => $value) {
                        if (isset($return['adsense'][$key]['uid']) && isset($return['ad_user'][$return['adsense'][$key]['uid']])) {
                            $return['adsense'][$key]['user'] = $return['ad_user'][$return['adsense'][$key]['uid']];
                        }
                    }
                }
            }
        }

        array_multisort($weight_arr, $order_arr[1], $return['adsense']);

        return ['result' => $return['adsense'], 'title' => json_decode($obj_adwords->scheme_title), 'type' => $obj_adwords->type, 'page' => $data['page'], 'num_per_page' => $data['num_per_page'], 'all_count' => $all_count];

    }

    //广告点击、关注反馈
    public function adwords_click($data) {
        $sql_arr = [];

        if (empty($data['id'])
            || empty($data['adsense_id'])
            || empty($data['uid'])
        ) {
            throw new Exception(__CLASS__ . __LINE__, 4003);
        }

        if (empty($data['page'])) {
            $data['page'] = 1;
        }
        if (empty($data['num_per_page'])) {
            $data['num_per_page'] = 50;
        }

        //数据库事务处理start
        if (!$this->db_handler->beginTransaction()) {
            throw new Exception(__CLASS__ . __LINE__, 1002);
        }

        $obj_adwords_factory = new AdwordsFactory($this->cache_handler, $data['id'], 86400);
        if (!$obj_adwords_factory->initialize() || !$obj_adwords = $obj_adwords_factory->get()) {
            $this->db_handler->inTransaction() && $this->db_handler->rollBack();
            $obj_adwords_factory->clear();
            throw new Exception(__CLASS__ . __LINE__, 4005);
        }
        if (empty($obj_adwords->status)) {
            $this->db_handler->inTransaction() && $this->db_handler->rollBack();
            throw new Exception(__CLASS__ . __LINE__, 4005);
        }

        $obj_adwords->click_number += 1;
        $sql_arr[] = $obj_adwords->getUpdateSql();

        $obj_adsense_factory = new AdsenseFactory($this->cache_handler, $data['adsense_id']);
        if (!$obj_adsense_factory->initialize() || !$obj_adsense = $obj_adsense_factory->get()) {
            //慢表
            $obj_adsense_factory = new AdsenseOverFactory($this->cache_handler, $data['adsense_id']);
            if (!$obj_adsense_factory->initialize() || !$obj_adsense = $obj_adsense_factory->get()) {
                $this->db_handler->inTransaction() && $this->db_handler->rollBack();
                $obj_adsense_factory->clear();
                throw new Exception(__CLASS__ . __LINE__, 4005);
            }
        }

        //每用户只算一次
        if ($obj_adsense->is_click >= 1 || empty($obj_adsense->uid) || $obj_adsense->uid != $data['uid'] || empty($obj_adsense->adwords) || $obj_adsense->adwords != $data['id']) {
            $this->db_handler->inTransaction() && $this->db_handler->rollBack();
            throw new Exception(__CLASS__ . __LINE__, 4005);
        }

        if ($obj_adwords->type != 'novice_gift') {
            $obj_adsense->is_click += 1;
            $sql_arr[] = $obj_adsense->getUpdateSql();
        }

        //执行sql
        BaseFunction::execute_sql_no_transation_throw($sql_arr);

        //提交事务
        $this->db_handler->commit();

        $obj_adwords_factory->writeback();
        $obj_adsense_factory->writeback();

    }

}
