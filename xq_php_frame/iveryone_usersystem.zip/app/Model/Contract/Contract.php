<?php

namespace HttpApi\Model\Contract;

use Beahoo\Model\Base;

class Contract extends Base
{
    private static $instance;

    private $tableName = 'contract';
    // 合约类型
    const CONSTRACT_TYPE_NEW_USER_INVITE=1; // 新用户邀请合约
    const CONSTRACT_TYPE_AD=2; // 广告合约
    const CONSTRACT_TYPE_NEWS_TRANSFER=3; // 内容转发激励合约
    const CONSTRACT_TYPE_GAME=4; // 游戏推广激励合约
    const CONSTRACT_TYPE_MESSAGE=5; // 消息合约
    // 跳转类型
    const JUMP_TYPE_MESSAGE=1; // 跳转至消息合约列表
    const JUMP_TYPE_DETAIL=2; // 跳转至合约详情页
    const JUMP_TYPE_NEXT_LEVEL=3; // 跳转到下一级合约列表

    public static function getInstance()
    {
        if(empty(self::$instance))
        {
            self::$instance = new Contract();
        }
        return self::$instance;
    }

    public function add($setarr)
    {
        $setarr['create_timestamp']=time();
        $res = $this->getOne()->insert($this->tableName, $setarr);
        return $res['insertid'];
    }

    public function update($setarr, $where)
    {
        $setarr['update_timestamp']=time();
        return $this->getOne()->update($this->tableName, $setarr, [], $where);
    }

    public function getContractById($id)
    {
        return $this->getContract(['id' => $id]);
    }

    public function getContract($where,$fields='*'){
        $res = $this->getOne()->selectOne($this->tableName, $fields, $where);
        return $res['data'];
    }

    public function getContracts($where,$fields='*', $start = 0, $limit = 0) {
        $res = $this->getOne()->select($this->tableName, $fields, $where, 'ORDER BY sort ASC', $start, $limit);
        return $res['data'];
    }

    public function getCount($where){

        $res = $this->getOne()->select($this->tableName,'count(*) as count', $where);

        return $res['data']?$res['data'][0]['count']:0;
    }
}