<?php

namespace HttpApi\Model\Contract;

use Beahoo\Model\Base;

class Message extends Base
{
    private static $instance;

    /**
     * 倍率：1000
     * @var integer
     */
    private $base=1000;

    private $tableName = 'user_message_contract';

    public static function getInstance()
    {
        if(empty(self::$instance))
        {
            self::$instance = new Message();
        }
        return self::$instance;
    }

    public function add($setarr)
    {
        $setarr=$this->resetContractPrice($setarr);
        $setarr['create_timestamp']=time();
        $res = $this->getOne()->insert($this->tableName, $setarr);
        return $res['insertid'];
    }

    public function update($setarr, $where)
    {
        $setarr=$this->resetContractPrice($setarr);
        $setarr['update_timestamp']=time();
        return $this->getOne()->update($this->tableName, $setarr, [], $where);
    }

    public function del($where)
    {
        $setarr['status']=0;
        $setarr['update_timestamp']=time();
        return $this->getOne()->update($this->tableName, $setarr, [], $where);
    }

    public function getMessageContractById($id)
    {
        return $this->getMessageContract(['id' => $id]);
    }

    public function getMessageContract($where,$fields='*'){
        $res = $this->getOne()->selectOne($this->tableName, $fields, $where);
        return $this->calContractPrice($res['data']);
    }



    public function getMessageContracts($where,$fields='*', $start = 0, $limit = 0) {

        $res = $this->getOne()->select($this->tableName, $fields, $where, 'ORDER BY is_default desc, id ASC', $start, $limit);
        $message_contracts=[];
        foreach ($res['data'] as $data) {
            
            $message_contracts[]=$this->calContractPrice($data);
        }
        return $message_contracts;
    }

    public function getCount($where){

        $res = $this->getOne()->select($this->tableName,'count(*) as count', $where);

        return $res['data']?$res['data'][0]['count']:0;
    }

    public function resetContractPrice($setarr){
        $setarr['message_price']*=$this->base;
        $setarr['audio_price']*=$this->base;
        $setarr['video_price']*=$this->base;
        return $setarr;
    }

    public function calContractPrice($message_contract){
        if(empty($message_contract)) return [];
        $message_contract['message_price']=(string)($message_contract['message_price']/$this->base);
        $message_contract['audio_price']=(string)($message_contract['audio_price']/$this->base);
        $message_contract['video_price']=(string)($message_contract['video_price']/$this->base);
        return $message_contract;
    }
}