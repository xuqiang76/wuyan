<?php

namespace HttpApi\Model\Contract;

use Beahoo\Model\Base;

class Message extends Base
{
    private static $instance;

    private $tableName = 'user_message_contract';

    public static function getInstance()
    {
        if(empty(self::$instance))
        {
            self::$instance = new Message();
        }
        return self::$instance;
    }

    public function add($setarr)
    {
        $setarr['create_timestamp']=time();
        $res = $this->getOne()->insert($this->tableName, $setarr);
        return $res['insertid'];
    }

    public function update($setarr, $where)
    {
        $setarr['update_timestamp']=time();
        return $this->getOne()->update($this->tableName, $setarr, [], $where);
    }

    public function del($where)
    {
        $setarr['status']=0;
        $setarr['update_timestamp']=time();
        return $this->getOne()->update($this->tableName, $setarr, [], $where);
    }

    public function getMessageContractById($id)
    {
        return $this->getMessageContract(['id' => $id]);
    }

    public function getMessageContract($where,$fields='*'){
        $res = $this->getOne()->selectOne($this->tableName, $fields, $where);
        return $res['data'];
    }
    
    public function getMessageContracts($where,$fields='*', $start = 0, $limit = 0) {

        $res = $this->getOne()->select($this->tableName, $fields, $where, 'ORDER BY is_default desc, id ASC', $start, $limit);

        return $res['data'];
    }

    public function getCount($where){

        $res = $this->getOne()->select($this->tableName,'count(*) as count', $where);

        return $res['data']?$res['data'][0]['count']:0;
    }
}