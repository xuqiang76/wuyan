<?php

namespace HttpApi\Model\Contract;

use Beahoo\Model\Base;
use HttpApi\Model\Contract\Contract;
use HttpApi\Model\Contract\Message as MessageContract;
use HttpApi\Model\Contacts;
use Beahoo\Exception;
use HttpApi\Tool\SDKs;

class User extends Base {

    private static $instance;

    public static function getInstance()
    {
        if(empty(self::$instance))
        {
            self::$instance = new User();
        }
        return self::$instance;
    }

    /**
     * 获取针对对方设定的合约
     * @param  int $uid          
     * @param  int $contract_uid 
     * @return array
     */
    public function getBothContactMssageContract($uid,$contact_uid){

        $usera_contract=$this->getContactMessageContract($uid,$contact_uid);
        $userb_contract=$this->getContactMessageContract($contact_uid,$uid);

        return [$uid=>$usera_contract,$contact_uid=>$userb_contract];
    }

    /**
     * 获取针对某个联系人设定的消息合约
     * @param  int $uid        
     * @param  int $contact_uid 
     * @return array
     */
    public function getContactMessageContract($uid,$contact_uid){

        $user=Contacts::getInstance()->getContact($uid,$contact_uid);

        if($user && $user['message_contract_id']){

            $user_contract=MessageContract::getInstance()->getMessageContract(['id'=>$user['message_contract_id'],'status'=>1]);
        }else{

            $user_contract=$this->getUserDefaultMessageContract($uid);
        }

        return $user_contract;
    }

    /**
     * 给某个用户的联系人绑定消息合约
     * @param int $uid                 
     * @param int $contact_uid         
     * @param int $message_contract_id
     * @return
     */
    public function setContractMessageContract($uid,$contact_uid,$message_contract_id){

        $user_contract=MessageContract::getInstance()->getMessageContract(['uid'=>$uid,'id'=>$message_contract_id,'status'=>1]);

        if(empty($user_contract)) throw new Exception('该消息合约不存在', -1);

        $exists_contact=Contacts::getInstance()->getCount(['uid'=>$uid,'contact_uid'=>$contact_uid]);

        try{

            if(!$exists_contact){

                $setarr = [
                    'uid' => $uid,
                    'contact_uid' => $contact_uid,
                    'suggest_set_contract'=>0,
                    'message_contract_id'=>$message_contract_id
                ];

                Contacts::getInstance()->add($setarr, $setarr);
            }else{

                Contacts::getInstance()->update(['message_contract_id'=>$message_contract_id,'suggest_set_contract'=>0],['uid'=>$uid,'contact_uid'=>$contact_uid]);
            }
        }catch(Exception $e){
            
            return 0;
        }

        return 1;
    }

    /**
     * 获取用户的默认消息合约
     * @param  int $uid 
     * @return array
     */
    public function getUserDefaultMessageContract($uid){

        $default_message_contract=MessageContract::getInstance()->getMessageContract(['uid'=>$uid,'is_default'=>1,'status'=>1]);

        if(empty($default_message_contract)){
            
            $default_message_contract=$this->createUserDefaultMessageContract($uid);

            $this->createUserFreeMessageContract($uid);
        }

        return $default_message_contract;
    }

    /**
     * 给用户创建默认合约
     * @param  int $uid 
     * @return array 返回创建后的合约对象
     */
    public function createUserDefaultMessageContract($uid){

        $contract_no_suffix=$this->getLatestContractNoSuffix($uid);

        $default_contract=[
            'uid'=>$uid,
            'name'=>'默认合约',
            'contract_no'=>'IM-'.$uid.'-'.$contract_no_suffix,
            'message_price'=>0.1,
            'audio_price'=>0.5,
            'video_price'=>1,
            'audio_status'=>1,
            'video_status'=>1,
            'is_default'=>1,
            'status'=>1,
            'create_timestamp'=>time()
        ];

        $id=MessageContract::getInstance()->add($default_contract);

        $default_contract['id']=(string)$id;
        // $default_contract['contract_no']
        return $default_contract;
    }

    /**
     * 给用户创建免费合约
     * @param  int $uid 
     * @return array 返回创建后的合约对象
     */
    public function createUserFreeMessageContract($uid){

        $contract_no_suffix=$this->getLatestContractNoSuffix($uid);

        $free_contract=[
            'uid'=>$uid,
            'name'=>'免费合约',
            'contract_no'=>'IM-'.$uid.'-'.$contract_no_suffix,
            'message_price'=>0,
            'audio_price'=>0,
            'video_price'=>0,
            'audio_status'=>1,
            'video_status'=>1,
            'is_default'=>0,
            'status'=>1,
            'create_timestamp'=>time()
        ];

        $id=MessageContract::getInstance()->add($free_contract);

        $free_contract['id']=(string)$id;

        return $free_contract;
    }

    /**
     * 判断用户是否存在默认合约
     * @param  int $uid 
     * @return boolean
     */
    public function existDefaultMessageContract($uid){

        $default_message_contract=MessageContract::getInstance()->getMessageContract(['uid'=>$uid,'is_default'=>1,'status'=>1]);

        return !empty($default_message_contract);
    }

    /**
     * 获取最新的用户合约id
     * @param  int $uid 
     * @return int
     */
    public function getLatestContractNoSuffix($uid){

        return SDKs::getRedis()->incr('message_contract_no_suffix_'.$uid);
    }

    /**
     * 回滚由操作失败导致增长的suffix
     * @param  int $uid 
     * @return 
     */
    public function rollbackContractNoSuffix($uid){

        SDKs::getRedis()->decr('message_contract_no_suffix_'.$uid);
    }
}

