<?php

namespace HttpApi\Model;

use Beahoo\Model\Base;
use Beahoo\Tool\Config;
use Beahoo\Exception;

class BaseModel extends Base {
    protected static $redis;
    protected $transaction = false;
    
    public function transaction_start() {
        if ($this->transaction === false) {
            $this->getOne ()->exec ( 'start transaction' );
            $this->autocommit ( 0 );
            $this->transaction = true;
        }
    }
    public function transaction_commit() {
        $this->transaction = false;
        $this->getOne ()->exec ( 'commit' );
        $this->autocommit ();
    }
    public function transaction_rollback() {
        $this->transaction = false;
        $this->getOne ()->exec ( 'rollback' );
        $this->autocommit ();
    }
    public function autocommit($flag = 1) {
        $this->getOne ()->exec ( 'set autocommit = ' . intval ( boolval ( $flag ) ) );
    }
    public function redis(): \Redis {
        if (empty ( self::$redis )) {
            $config = Config::read ( 'redis' );
            self::$redis = new \Redis ();
            self::$redis->connect ( $config ['Parameters'] ['host'], $config ['Parameters'] ['port'] );
            if (isset ( $config ['Parameters'] ['password'] )) {
                if (! self::$redis->auth ( $config ['Parameters'] ['password'] )) {
                    throw new Exception ( 'Redis 连接失败', 4990 );
                }
            }
            self::$redis->select ( $config ['db'] );
        }
        return self::$redis;
    }
}