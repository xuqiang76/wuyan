<?php

namespace HttpApi\Model\User;

use Beahoo\Exception;
use Beahoo\Model\Base;
use Beahoo\Tool\Config;
use bigcatorm\BaseFunction;
use bigcatorm\CatRedis;
use bigcatorm\ListCommonFactory;
use HttpApi\puremodel\AdMaterialMultiFactory;
use HttpApi\puremodel\Bbs as BbsModel;
use HttpApi\puremodel\BbsFactory;
use HttpApi\Tool\Times;

//use HttpApi\Model\Battery;
//WalletBase

class Bbs extends Base {
	public static $instance = null;

	protected $cache_handler = null;
	protected $db_handler = null;

	public static function getInstance() {
		$class = get_called_class();
		if (empty(self::$instance)) {
			self::$instance = new $class();
		}
		return self::$instance;
	}

	public function __construct() {
		//缓存服务器 redis
		if (empty($this->cache_handler)) {
			$config_redis = Config::read('redis');

			$redis_options['scheme'] = $config_redis['Parameters']['scheme'];
			$redis_options['host'] = $config_redis['Parameters']['host'];
			$redis_options['port'] = $config_redis['Parameters']['port'];
			$redis_options['password'] = $config_redis['Parameters']['password'];
			$redis_options['db'] = $config_redis['db'];
			$redis_options['cachedb'] = $config_redis['cachedb'];

			$this->cache_handler = CatRedis::get_instance($redis_options);
			if (!$this->cache_handler) {
				throw new Exception('Redis 连接失败', 4990);
			}
		}

		//数据库配置
		BaseFunction::set_db($this->getDb()); //兼容 Beahoo\Model\Base 的数据库连接
		//BaseFunction::set_db_options(Config::read('mysql'));

		$this->db_handler = BaseFunction::get_db();
		if (!$this->db_handler) {
			throw new Exception(__CLASS__ . __LINE__, 1002);
		}

	}

	//---------------------------------------
	//新建bbs
	public function bbs_create($data) {
		$sql_arr = [];

		if (strlen(trim($data['content'])) == 0
			|| empty(trim($data['title']))
			|| empty(trim($data['url']))
		) {
			throw new Exception(__CLASS__ . __LINE__, 4003);
		}

		//数据库事务处理start
		if (!$this->db_handler->inTransaction() && !$this->db_handler->beginTransaction()) {
			throw new Exception(__CLASS__ . __LINE__, 1002);
		}

		// 不能重复
		$obj_bbs_list_all_factory = new ListCommonFactory($this->cache_handler, null, [" select `id` from `bbs` where  title=? ", [$data['title']]]);
		if ($obj_bbs_list_all_factory->initialize() && $obj_bbs_list_all_factory->get()) {
			$this->db_handler->rollBack();
			throw new Exception('名称重复', 4004);
		}

		$obj_bbs = new BbsModel();

		$obj_bbs->title = json_encode($data['title']);
		$obj_bbs->content = json_encode($data['content']);
		$obj_bbs->url = json_encode($data['url']);
		$obj_bbs->init_time = TIMESTAMP;
		$obj_bbs->start_time = TIMESTAMP;
		$obj_bbs->end_time = TIMESTAMP + (86400 * 365);

		$result = BaseFunction::execute_one($this->db_handler, $obj_bbs->getInsertSql());
		if (!$result || empty($result['last_insert_id'])) {
			$this->db_handler->rollBack();
			return null;
		}

		//提交事务
		$this->db_handler->commit();

		$obj_bbs->id = $result['last_insert_id'];
		return $obj_bbs;
	}

	//删除素材
	public function bbs_del($data) {
		$sql_arr = [];

		if (empty($data['id'])
		) {
			throw new Exception(__CLASS__ . __LINE__, 4003);
		}

		//数据库事务处理start
		if (!$this->db_handler->beginTransaction()) {
			throw new Exception(__CLASS__ . __LINE__, 1002);
		}

		//获取对象
		$obj_bbs_factory = new BbsFactory($this->cache_handler, $data['id']);
		if (!$obj_bbs_factory->initialize() || !$obj_bbs = $obj_bbs_factory->get()) {
			$this->db_handler->rollBack();
			$obj_bbs_factory->clear();
			throw new Exception(__CLASS__ . __LINE__, 4000);
		}

		//提交事务
		$this->db_handler->commit();

		$obj_bbs_factory->clear();
	}

	//查询素材
	public function bbs_query($data) {
		if (empty($data['page'])
			|| empty($data['num_per_page'])
			|| !isset($data['order']) // 1最新优先 0古老优先
		) {
			throw new Exception(__CLASS__ . __LINE__, 4003);
		}

		$return_arr = [];
		$all_count = 0;
		$weight_arr = [];
		$order_arr = $data['order'] == 1 ? ['desc', SORT_DESC] : ['', SORT_ASC];

		if (!empty($data['id'])) {
			$where = " select `id` from `bbs`  where id=? ";
			$bind = [$data['id']];
		} else {
			$where = " select `id` from `bbs` order by id  " . $order_arr[0] . " ";
			$bind = [];
		}
		$obj_bbs_list_all_factory = new ListCommonFactory($this->cache_handler, null, [$where, $bind]);
		if ($obj_bbs_list_all_factory->initialize() && $obj_bbs_list_all = $obj_bbs_list_all_factory->get()) {
			$all_count = count($obj_bbs_list_all);

			$list_multi_str = implode(',', array_slice($obj_bbs_list_all, (intval($data['page']) - 1) * (intval($data['num_per_page'])), intval($data['num_per_page'])));

			$obj_bbs_list_factory = new ListCommonFactory($this->cache_handler, $list_multi_str);

			$obj_ad_material_multi_factory = new AdMaterialMultiFactory($this->cache_handler, $obj_ad_material_list_factory);
			if ($obj_bbs_list_factory->initialize() && $obj_bbs_list = $obj_bbs_list_factory->get()) {
				$obj_bbs_list_arr = BaseFunction::object_to_array($obj_bbs_list);
				foreach ($obj_ad_material_multi_arr as $key => $val) {
					$obj_bbs_list_arr[$key]['init_time'] = Times::format_date($obj_bbs_list_arr[$key]['init_time']);
					$obj_bbs_list_arr[$key]['start_time'] = Times::format_date($obj_bbs_list_arr[$key]['start_time']);
					$obj_bbs_list_arr[$key]['end_time'] = Times::format_date($obj_bbs_list_arr[$key]['end_time']);
					$obj_bbs_list_arr[$key]['title'] = json_decode($obj_bbs_list_arr[$key]['title']);
					$obj_bbs_list_arr[$key]['content'] = json_decode($obj_bbs_list_arr[$key]['content']);
					$obj_bbs_list_arr[$key]['url'] = json_decode($obj_bbs_list_arr[$key]['url']);

					$weight_arr[] = $obj_bbs_list_arr[$key]['id'];
					$return_arr[] = $obj_bbs_list_arr[$key];
				}
			}
		}

		array_multisort($weight_arr, $order_arr[1], $return_arr);

		return ['result' => $return_arr, 'page' => $data['page'], 'num_per_page' => $data['num_per_page'], 'all_count' => $all_count];

	}

}
