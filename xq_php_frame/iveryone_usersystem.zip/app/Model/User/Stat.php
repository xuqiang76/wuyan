<?php

namespace HttpApi\Model\User;

use Beahoo\Model\Base;


class Stat extends Base
{

    private static $instance;

    private $tableName = 'user_stat';

    public static function getInstance()
    {
        if (empty(self::$instance)) {
            self::$instance = new Stat();
        }
        return self::$instance;
    }

    public function getTableName()
    {
        return $this->tableName;
    }

    public function add($stat)
    {
        $this->getOne()->insert($this->tableName, $stat, array_keys($stat));
    }
}