<?php

namespace HttpApi\Model\User;

use Beahoo\Model\Base;

class PersonalContent extends Base
{
    private static $instance;

    private $tableName = 'personalcontent';

    public static function getInstance()
    {
        if (empty(self::$instance)) {
            self::$instance = new PersonalContent();
        }
        return self::$instance;
    }

    public function add($setarr) {
        $setarr['timestamp'] = TIMESTAMP;
        $res = $this->getOne()->insert($this->tableName, $setarr);
        return $res['insertid'];
    }

    public function getItem($where, $order = 'ORDER BY id DESC') {
        $res = $this->getOne()->selectOne($this->tableName, '*', $where, $order);
        return $res['data'];
    }
}