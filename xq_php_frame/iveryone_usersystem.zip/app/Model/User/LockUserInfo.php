<?php
namespace HttpApi\Model\User;
use Beahoo\Model\Base;
use Beahoo\Exception;
use HttpApi\Model\Wallet\Details;
use HttpApi\Tool\Format;

class LockUserInfo extends Base
{

    /**
     * @param $uid
     * @return array
     * @throws Exception
     */
    private static $instance;
    private $tableName = 'danger_user_lock';
    public static function getInstance()
    {
        if (empty(self::$instance)) {
            self::$instance = new LockUserInfo();
        }
        return self::$instance;
    }

    /**
     * @param $ruid 锁定关联人uid
     * @param $lock_uid 被锁定人uid
     * @param $amount
     * @throws \Exception
     */
    public function DoLock($ruid, $lock_uid, $amount)
    {
        try {
            $this->getOne()->insert($this->tableName, [
                'ruid' => $ruid,
                'lock_uid' => $lock_uid,
                'lock_amount' => $amount*1000000,
                'islock' => 'Y'
            ]);
        } catch (\Exception $e) {
            if($e->getCode() != 4224 && $e->getCode() != 23000) {
                throw new \Exception($e->getMessage(), $e->getCode(), $e);
            }
        }
    }

    public function UnlockByRuid($ruid)
    {
        $locks = $this->getOne()->select($this->tableName, '*', ['ruid' => $ruid, 'islock' => 'Y'])['data'];
        foreach ($locks as $lock) {
            try {
                $level = $this->getOne ()->selectOne ( 'genealogy', '*', [
                    'uid' => $ruid,
                    'freeze' => 1,
                    'referer' => $lock ['lock_uid']
                ] ) ['data'];
                if (empty ( $level )) {
                    throw new Exception ( '', 4000 );
                }
                Details::getInstance ()->confirm ( [
                    'id' => Details::getInstance ()->create ( [
                        'recorder' => $lock ['lock_uid'],
                        'receiver' => 'system',
                        'amount' => Format::amount($lock ['lock_amount']),
                        'category' => Details::Candy_Level,
                        'uniqid' => 'candy-register-' . $ruid . '-' . $level ['level']
                    ] )
                ] );
            } catch (Exception $e) {
                if($e->getCode() != 4225) {
                    throw new Exception($e->getMessage(), $e->getCode(), $e);
                }
            }

            $this->getOne()->update($this->tableName, ['islock' => 'N'], [], ['id' => $lock['id']]);
        }
    }

    public function getItem($where){
        if(empty($where)) {
            return [];
        }
        return $this->getOne()->selectOne($this->tableName, '*', $where)['data'];
    }

    /**
     * 
     * get all the user who have locked
     */
    public function get($uid, $lastid = 0, $limit = 50)
    {
        $sql = "select l.ruid,l.lock_amount,l.islock,w.status from ".$this->tableName." l left join wallet w on l.ruid = w.uid where l.lock_uid ={$uid} AND l.islock = 'Y'";
        if(!empty($lastid)) {
            $sql .= " and l.ruid < $lastid";
        }
        $sql .= " order by l.ruid desc limit 0," . $limit;
        $query = $this->getDb()->query($sql);
        return $query->fetchAll(\PDO::FETCH_ASSOC);
    }
    /**
     * get total amount in all locked user
     * @return [type] [description]
     */
    public function getSum($uid)
    {
        $where = "uid = " . $uid ." and islock='Y'";
        $sql = "select sum(lock_amount) as amount from ".$this->tableName;
        $query = $this->getDb()->query($sql);
        return $query->fetchAll(\PDO::FETCH_ASSOC);
        //$res = $this->getOne()->selectOne($this->tableName,"sum(lock_amount) as amount",$where);
        //return $res;
    }
}