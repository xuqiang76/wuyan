<?php
namespace HttpApi\Model\User;
use Beahoo\Model\Base;
use Beahoo\Tool\Config;
use Beahoo\Exception;
class LockUserFlows extends Base
{

    /**
     * @param $uid
     * @return array
     * @throws Exception
     */
    private static $instance;
    private $tableName = 'danger_user_flows';
    public static function getInstance()
    {
        if (empty(self::$instance)) {
            self::$instance = new LockUserFlows();
        }
        return self::$instance;
    }
    /**
     * 
     * get all the user who have locked
     */
    public function getDetail($uid,$referer,$start=0,$limit=50){
        $sql = "select a.sid,a.referer,a.amount,b.category,b.create_timestamp,b.remark,c.nickname,c.avatar from ".$this->tableName." a left join wallet_details b on b.id=a.sid  left join userinfo c on c.id=a.referer where a.uid={$uid} and a.referer={$referer} and islock='Y' order by sid desc";
        $query = $this->getDb()->query($sql);
        return $query->fetchAll(\PDO::FETCH_ASSOC);

    }
}