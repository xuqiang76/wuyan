<?php

namespace HttpApi\Model\User;

use Beahoo\Model\Base;


class InviteCode extends Base
{
    private static $instance;

    private $tableName = 'invite_code';

    public static function getInstance()
    {
        if (empty(self::$instance)) {
            self::$instance = new InviteCode();
        }
        return self::$instance;
    }

    public function getTableName()
    {
        return $this->tableName;
    }

    public function add($invite_code)
    {
        $setarr = [
            'invite_code' => $invite_code
        ];
        $res = $this->getOne()->insert($this->tableName, $setarr);
        return $res['insertid'];
    }

    public function get($invite_code)
    {
        return $this->getOne()->selectOne($this->tableName, '*', [
            'invite_code' => $invite_code
        ])['data'];
    }
}