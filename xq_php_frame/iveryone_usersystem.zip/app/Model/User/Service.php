<?php

namespace HttpApi\Model\User;

use Beahoo\Exception;
use HttpApi\Model\Battery;
use HttpApi\Tool\Format;
use HttpApi\Model\WalletNew\WalletNew;
use HttpApi\Model\TaskPool\Task;
use HttpApi\Model\TaskPool\LoginTask;

class Service {
	/**
	 * @param $uid
	 * @return array
	 * @throws Exception
	 */
	public static function GetRichInfo($uid, $checkrechrage = true, $is_own = false) {
		$userinfo = User::getInstance()->getUserinfoByUid($uid, [], $is_own);
		if (empty($userinfo)) {
			throw new Exception("", 2001);
		}

		$userinfo['unreadbill'] = 0;
		$userinfo['ad_feed_minimal'] = '' . (floatval($userinfo['ad_feed_minimal']) * 1000);
		$userinfo['ad_follow_minimal'] = '' . (floatval($userinfo['ad_follow_minimal']) * 1000);

		//$wallet = Balance::getInstance()->query(['uid' => $uid]);
        $walletInfo = WalletNew::getInstance()->getWalletInfo($userinfo['id']);
        if(\App::getGlobal('device_platform') == 'ios') {
            $v = $walletInfo['balance_apple_v'];
        } else {
            $v = $walletInfo['balance_v'];
        }
        $wallet =  [
            'wallet_id' => $walletInfo['id'],
            'balance_vry' => Format::amount($walletInfo['balance_vry']),
            'balance_v'   => Format::decodeV($v),
            'balance_coupon' => Format::decodeV($walletInfo['balance_coupon']),
            'old_lock' => Format::amount($walletInfo['old_lock']),
            'old_freeze' => Format::amount($walletInfo['old_freeze']),
            'transfer'   => $walletInfo['transfer'],
            'status'    => $walletInfo['status'],
            'adwords'    => Format::amount($walletInfo['adwords']),
            'not_enabled_vry' => Format::amount($walletInfo['old_lock'] + $walletInfo['old_freeze'])
        ];
		$batteryinfo = Battery::getInstance()->getBatteryInfo($uid);

		$capacity = $batteryinfo['capacity'] * 1000000;
		
        Task::getInstance ()->task ( $userinfo );
        LoginTask::getInstance ()->check ( $userinfo );
		
		return [
			'userinfo' => $userinfo,
			'wallet' => $wallet,
			'battery' => $batteryinfo,
			'battery_expired' => 0,
		];
	}

	public static function formatSimples($userinfos) {
		$list = [];
		foreach ($userinfos as $userinfo) {
			$list[] = [
				'id' => $userinfo['id'],
				'nickname' => $userinfo['nickname'],
				'avatar' => $userinfo['avatar'],
			];
		}
		return $list;
	}
}