<?php

namespace HttpApi\Model\User;

use Beahoo\Exception;
use HttpApi\Model\Battery;
use HttpApi\Model\TaskPool\LoginTask;
use HttpApi\Model\TaskPool\Task;
use HttpApi\Model\WalletNew\WalletNew;

class Service {
	/**
	 * @param $uid
	 * @return array
	 * @throws Exception
	 */
	public static function GetRichInfo($uid, $checkrechrage = true, $is_own = false) {
		$userinfo = User::getInstance()->getUserinfoByUid($uid, [], $is_own);
		if (empty($userinfo)) {
			throw new Exception("", 2001);
		}

		$userinfo['unreadbill'] = 0;
		$userinfo['ad_feed_minimal'] = '' . (floatval($userinfo['ad_feed_minimal']) * 1000);
		$userinfo['ad_follow_minimal'] = '' . (floatval($userinfo['ad_follow_minimal']) * 1000);

		//$wallet = Balance::getInstance()->query(['uid' => $uid]);
		$wallet = WalletNew::getInstance()->getWalletInfo($userinfo['id']);
		$batteryinfo = Battery::getInstance()->getBatteryInfo($uid);

		$capacity = $batteryinfo['capacity'] * 1000000;
		//$token = $wallet['token'] * 1000000;

		Task::getInstance()->task($userinfo);
		LoginTask::getInstance()->check($userinfo);
		$task = Task::getInstance()->process($userinfo['id']);

		if ($task == 'Register') {
			/*  电池逻辑暂时不用
				if (Cache::rechargeCheckfrequncy($uid) && TIMESTAMP - $batteryinfo['last_charge_timestamp'] > 3600 && $token < $capacity) {
					$hours = floor((TIMESTAMP - $batteryinfo['last_charge_timestamp']) / 3600);
					$tokenperhour = ceil($capacity / 20);

					if ($wallet['token'] + ($hours * $tokenperhour) < $capacity) {
						$amount = ($hours * $tokenperhour) / 1000000;
						Details::getInstance()->confirm([
							'id' => Details::getInstance()->create([
								'recorder' => $uid,
								'receiver' => 'system',
								'amount' => $amount,
								'category' => Details::Battery,
								'uniqid' => uniqid('battery_'),
							]),
						]);
					} else {
						$amount = ($capacity - $token) / 1000000;
						Details::getInstance()->confirm([
							'id' => Details::getInstance()->create([
								'recorder' => $uid,
								'receiver' => 'system',
								'amount' => $amount,
								'category' => Details::Battery,
								'uniqid' => uniqid('battery_'),
							]),
						]);
					}
					Battery::getInstance()->UpdateLastChargeTimestamp($uid);
					$wallet['token'] += $amount;
					$batteryinfo['last_charge_timestamp'] = TIMESTAMP;
				}
			*/
		}

		return [
			'userinfo' => $userinfo,
			'wallet' => $wallet,
			'battery' => $batteryinfo,
			'battery_expired' => 0,
		];
	}

	public static function formatSimples($userinfos) {
		$list = [];
		foreach ($userinfos as $userinfo) {
			$list[] = [
				'id' => $userinfo['id'],
				'nickname' => $userinfo['nickname'],
				'avatar' => $userinfo['avatar'],
			];
		}
		return $list;
	}
}