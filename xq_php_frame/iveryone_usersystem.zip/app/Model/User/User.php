<?php

namespace HttpApi\Model\User;

use Beahoo\Exception;
use Beahoo\Model\Base;
use Beahoo\Tool\Config;
use bigcatorm\BaseFunction;
use HttpApi\Model\Ad;
use HttpApi\Model\Battery;
use HttpApi\Model\Wallet\RegisterActivity;
use HttpApi\Model\Wallet\Wallet;
use HttpApi\Tool\SDKs;
use HttpApi\Utility;
use Overtrue\Pinyin\Pinyin;

class User extends Base {
	private static $usercaches = [];

	private static $instance;

	private $tableName = 'userinfo';

	public static function getInstance() {
		if (empty(self::$instance)) {
			self::$instance = new User();
		}
		return self::$instance;
	}

	public function getTableName() {
		return $this->tableName;
	}

	/**
	 * @param $country_code
	 * @param $phone
	 * @param $nickname
	 * @param $avatar_url
	 * @param int $invite_uid
	 * @return mixed|null
	 * @throws \Exception
	 */
	public function newuser($country_code, $phone, $nickname, $avatar_url, $invite_uid = 0, $invite_code = '') {
		$setarr = [
			'nickname' => $nickname,
			'avatar' => $avatar_url,
			'create_timestamp' => TIMESTAMP,
			'update_timestamp' => TIMESTAMP,
			'last_login_timestamp' => TIMESTAMP,
			'country_code' => $country_code,
			'phone' => $phone,
			'invite_code' => $invite_code,
			'register_ip' => Utility::getIP(),
		];
		$setarr = $this->setarrDecorator($setarr);
		$res = $this->getOne()->insert($this->tableName, $setarr);
		try {
			Battery::getInstance()->initBattery($res['insertid']);
			// 改回原有逻辑 新用户注册默认 1015 人脸完成改为 0 其他时候才是高危
			Wallet::getInstance()->create([
				'uid' => $res['insertid'],
				'status' => 1016,
			]);
			RegisterActivity::getInstance()->insert(['uid' => $res['insertid'], 'referer' => $invite_uid]);
		} catch (\Exception $e) {
			$this->getOne()->delete($this->tableName, ['id' => $res['insertid']]);
			throw new Exception($e->getMessage(), $e->getCode());
		}

		return $res['insertid'];
	}
	public function getPureUserInfo($uid) {
		return $this->getOne()->selectOne($this->tableName, '*', [
			'id' => $uid,
		])['data'];
	}
	public function getNoCacheUserInfo($uid, $filter = []) {
		$res = $this->getOne()->selectOne($this->tableName, '*', [
			'id' => $uid,
		])['data'];
		return $this->dataFormat($res, $filter);
	}
	public function getUserinfoByUid($uid, $filter = [], $is_own = false) {
		if (empty(self::$usercaches[$uid])) {
			$res = $this->getOne()->selectOne($this->tableName, '*', [
				'id' => $uid,
			])['data'];

			if ($is_own) {
				// bbs新公告通知
				BaseFunction::set_db($this->getDb());
				$result_bbs_arr = BaseFunction::select(" select `id`, `title`, `content`, `url`, `start_time`, `end_time` from `bbs` order by id desc limit 10 ");
				if ($result_bbs_arr) {
					$last_bbs = current($result_bbs_arr);
					$res['new_bbs'] = null;
					if ($res['bbs_id'] < $last_bbs['id']) {
						$last_bbs['title'] = json_decode($last_bbs['title']);
						$last_bbs['content'] = json_decode($last_bbs['content']);
						$last_bbs['url'] = json_decode($last_bbs['url']);

						$res['new_bbs'] = $last_bbs;
					}

					$re_db_userinfo = BaseFunction::query_sql_backend(" update `userinfo` set `bbs_id`=? where `id`=? ", [$last_bbs['id'], $uid]);
				}

				//新人礼物通知
				$res['new_novice_gift'] = 0;

				$tmp_param = ['uid' => $uid
					, 'type' => 'novice_gift'
					, 'limit' => 15,
				];

				$re_data = [];
				if (TIMESTAMP - $res['create_timestamp'] < 86400) {
					$re_data = Ad::getInstance()->query_adsense_gift($param);
				}

				foreach ($re_data as $item) {
					if (isset($item['is_click']) && $item['is_click'] == 0) {
						$res['new_novice_gift'] += 1;
					}
				}

			}

			self::$usercaches[$uid] = $this->dataFormat($res, $filter);
		}
		return self::$usercaches[$uid];
	}

	public function getUserinfoByUids($uids) {
		$res = $this->getOne()->select($this->tableName, '*', [
			'id' => $uids,
		])['data'];
		return $this->dataFormatMulti($res);
	}

	public function getUserinfoByPhone($country_code, $phone) {
		$res = $this->getOne()->selectOne($this->tableName, '*', [
			'country_code' => $country_code,
			'phone' => $phone,
		])['data'];
		return $this->dataFormat($res);
	}

	public function getCountByIp($ip) {
		$res = $this->getOne()->selectOne($this->tableName, 'count(*) as num', [
			'register_ip' => $ip,
		])['data'];
		return !empty($res['num']) ? $res['num'] : 0;
	}

	public function getUserinfoByNickname($nickname) {
		$res = $this->getOne()->selectOne($this->tableName, '*', [
			'nickname' => $nickname,
		])['data'];
		return $this->dataFormat($res);
	}

	public function getUserinfoByInvitecode($invite_code) {
		$res = $this->getOne()->selectOne($this->tableName, '*', [
			'invite_code' => $invite_code,
		])['data'];
		return $this->dataFormat($res);
	}

	public function updateFields($setarr, $where, $change = []) {
		$setarr = $this->setarrDecorator($setarr);
		return $this->getOne()->update($this->tableName, $setarr, $change, $where);
	}

	/**
	 * @param $uid
	 * @param $password
	 * @return bool
	 * @throws Exception
	 */
	public function checkpassword($uid, $password, $wrongQuota = 5) {
		$userinfo = $this->getOne()->selectOne($this->tableName, '*', [
			'id' => $uid,
		])['data'];
		if (empty($userinfo)) {
			throw new Exception("", 2001);
		}
		$res = json_decode(SDKs::getRedis()->hget('wrongpassword_count', $uid), true);
		$wrongcount = 0;
		if (!empty($res)) {
			$wrongcount = $res['last_time'] >= $userinfo['last_login_timestamp'] ? $res['count'] : 0;
			if ($wrongcount >= $wrongQuota && ($res['last_time'] + 900) > TIMESTAMP) {
				throw new Exception("", 2016);
			}
			if ($res['last_time'] + 900 < TIMESTAMP) {
				$wrongcount = 0;
			}
		}
		if ($userinfo['password'] != md5(md5($password) . $userinfo['salt'])) {
			$wrongcount++;
			PHP_INT_MAX == $wrongQuota || SDKs::getRedis()->hset('wrongpassword_count', $uid, json_encode(['count' => $wrongcount, 'last_time' => TIMESTAMP]));
			throw new Exception("", 2002);
		} else if ($wrongcount != 0) {
			SDKs::getRedis()->hdel('wrongpassword_count', [$uid]);
		}
		return true;
	}

	/**
	 * @param $uid
	 * @param $password
	 * @return \Beahoo\Tool\Dbresult|bool
	 * @throws Exception
	 */
	public function changePassword($uid, $password) {
		if (strlen($password) < 6 || strlen($password) > 12) {
			throw new Exception("", 2017);
		}
		if (!preg_match('/^(?![a-zA-z]+$)(?!\d+$)(?![!@#$%^&*.，。？！、：；…“‘’”（）《｛［～—·＃＊\|〖【『〔「,?\':~;"\/\(_\-+=`<{¡¿¥£€}>\)\]」〕』】〗］｝》]+$)[a-zA-Z\d!@#$%^&*.，。？！、：；…“‘’”（）《｛［～—·＃＊\|〖【『〔「,?\':~;"\/\(_\-+=`<{¡¿¥£€}>\)\]」〕』】〗］｝》]+$/', $password)) {
			throw new Exception("", 2017);
		}

		$salt = $this->getSalt();
		$setarr = [
			'password' => md5(md5($password) . $salt),
			'salt' => $salt,
		];
		return $this->getOne()->update($this->tableName, $setarr, [], ['id' => $uid]);
	}

	public function getSalt() {
		$str = "0123456789abcdefghijklmnopqrstuvwxyz";
		$str_len = strlen($str) - 1;
		str_shuffle($str);
		$s = '';
		for ($i = 0; $i < 6; $i++) {
			$s .= $str[rand(0, $str_len)];
		}
		return $s;
	}

	private function setarrDecorator($setarr) {
		if (!empty($setarr['nickname'])) {
			$pinyin = new Pinyin();
			$setarr['nickname_pinyin'] = $pinyin->abbr($setarr['nickname']);
			$setarr['nickname_initials'] = strtoupper(substr($setarr['nickname_pinyin'], 0, 1));
			if (!preg_match('/^[A-Za-z]$/', $setarr['nickname_initials'])) {
				$setarr['nickname_initials'] = '#';
			}
			if (strlen($setarr['nickname_pinyin']) == 1) {
				$setarr['nickname_pinyin'] = '';
			}
		}
		return $setarr;
	}

	public function dataFormat($userinfo, $filter = []) {
		if (empty($userinfo)) {
			return $userinfo;
		}

		if (empty($userinfo['avatar'])) {
			$userinfo['avatar'] = 'http://image.ivery.one/default_avatar.png';
		}
		if (!empty($userinfo['avatar']) && $userinfo['avatar'] != 'http://image.ivery.one/default_avatar.png') {
			$urlinfo = parse_url($userinfo['avatar']);
			if (!empty($urlinfo['host']) && in_array($urlinfo['host'], ['avatar.ivery.one', 'avatar.iveryone.wuyan.cn'])) {
				if ($urlinfo['host'] == 'avatar.ivery.one') {
					$ext = substr($userinfo['avatar'], strrpos($userinfo['avatar'], '.'));
					$userinfo['avatar'] = str_replace($ext, "_300x300" . $ext, $userinfo['avatar']);
				} else {
					if (substr($userinfo['avatar'], -7) != '/avatar') {
						$userinfo['avatar'] .= "/avatar";
					}
				}
			}
		}

		$userinfo['setpass'] = 0;
		if (!empty($userinfo['password'])) {
			$userinfo['setpass'] = 1;
		}

		if ($userinfo['im_toll_switch'] == 0) {
			$userinfo['minimal_redenvelope'] = 0;
			$userinfo['minimal_audiochat'] = 0;
			$userinfo['minimal_videochat'] = 0;
			$userinfo['im_member_only'] = 0;
		} else {
			if ($userinfo['minimal_redenvelope'] == -1) {
				$userinfo['minimal_redenvelope'] = Config::read('default_redenvelope');
			}
			if ($userinfo['minimal_audiochat'] == -1) {
				$userinfo['minimal_audiochat'] = Config::read('default_audiochat');
			}
			if ($userinfo['minimal_videochat'] == -1) {
				$userinfo['minimal_videochat'] = Config::read('default_videochat');
			}
		}

		if ($userinfo['nap_end_timestamp'] > TIMESTAMP) {
			$userinfo['nap_status'] = 1;
			$userinfo['nap_notice_string'] = date("H:i", $userinfo['nap_end_timestamp']) . "之前不接收消息提醒";
			$userinfo['nap_opposite_notice_string'] = "休息中，可能无法及时回复";
		}
		$userinfo['isSetPaypass'] = !empty($userinfo['pay_password']) ? 1 : 0;
		$userinfo['format_phone'] = !empty($userinfo['phone']) ? self::formatMobile($userinfo['phone'], $userinfo['country_code']) : "1**********";
		if (!empty($filter)) {
			foreach ($filter as $col) {
				if (isset($userinfo[$col])) {
					unset($userinfo[$col]);
				}
			}
		} else {
			unset($userinfo['phone']);
			unset($userinfo['password']);
			unset($userinfo['salt']);
			unset($userinfo['pay_password']);
		}

		return $userinfo;
	}
	private function formatMobile($mobile, $country_code = '') {
		if (!empty($mobile)) {
			$tmp = '';
			for ($i = 0; $i < strlen($mobile); $i++) {
				if ($i < 3) {
					$tmp .= substr($mobile, $i, 1);
				} elseif ($i >= 3 && $i < strlen($mobile) - 4) {
					$tmp .= '*';
				} else {
					$tmp .= substr($mobile, $i, 1);
				}
			}
			$mobile = $tmp;
			if (strtolower($country_code) == 'cn') {
				$mobile = '+86 ' . $mobile;
			}
		}
		return $mobile;
	}
	private function dataFormatMulti($userinfos) {
		foreach ($userinfos as $key => $userinfo) {
			$userinfos[$key] = $this->dataFormat($userinfo);
		}
		return $userinfos;
	}
	/**
	 * check old pay's password
	 *
	 * @param  [type] $uid      [description]
	 * @param  [type] $password [description]
	 * @return [type]           [description]
	 */
	public function checkPayPassword($uid, $password) {
		$userinfo = $this->getOne()->selectOne($this->tableName, '*', [
			'id' => $uid,
		])['data'];
		if (empty($userinfo)) {
			throw new Exception("", 2001);
		}

		if ($userinfo['pay_password'] != md5(md5($password) . $userinfo['pay_salt'])) {
			throw new Exception("", 2002);
		}
		return true;
	}
	/**
	 * set pay's password
	 * @param [type] $uid      [description]
	 * @param [type] $password [description]
	 */
	public function setPayPassword($uid, $password) {
		if (strlen($password) < 6 || strlen($password) > 12) {
			throw new Exception("", 2017);
		}
		if (!preg_match('/^\d{6}/', $password)) {
			throw new Exception("", 2017);
		}

		$salt = $this->getSalt();
		$setarr = [
			'pay_password' => md5(md5($password) . $salt),
			'pay_salt' => $salt,
		];
		return $this->getOne()->update($this->tableName, $setarr, [], ['id' => $uid]);
	}

	public function getUsers($where, $fields = '*', $start = 0, $limit = 0) {

		$res = $this->getOne()->select($this->tableName, $fields, $where, 'ORDER BY id ASC', $start, $limit);

		return $res['data'];
	}

}