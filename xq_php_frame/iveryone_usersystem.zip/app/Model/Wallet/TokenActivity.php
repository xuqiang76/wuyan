<?php

namespace HttpApi\Model\Wallet;

class TokenActivity extends WalletBase {
    public function balance($uid) {
        return Balance::getInstance ()->query ( $uid ) ['token'];
    }
    public function increase($uid, $fee) {
        $this->transaction_start ();
        $result = Balance::getInstance ()->change ( $uid, 0, abs ( $fee * 1000000 ) );
        $this->transaction_commit ();
        return $result ['token'];
    }
}