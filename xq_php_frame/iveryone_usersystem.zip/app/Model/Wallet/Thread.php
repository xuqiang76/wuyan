<?php

namespace HttpApi\Model\Wallet;

use Beahoo\Tool\Config;
use HttpApi\Tool\SDKs;
use HttpApi\Tool\Format;
use HttpApi\Model\TaskPool\PurchaseThreadTask;

class Thread extends WalletBase {
    public function create($data) {
        $data ['plan'] = intval ( $data ['plan'] ?? 0);
        $this->transaction_start ();
        /*
         * 读取配置数据
         */
        $thread = Config::read ( 'thread' );

        /*
         * 扣除购买者费用
         */
        $param = [ 
            'recorder' => $data ['recorder'],
            'receiver' => $data ['receiver'],
            'amount' => abs ( $data ['amount'] ) * - 1,
            'category' => Details::Thread_Buy,
            'uniqid' => $data ['tid'],
            'remark' => $data ['remark'] 
        ];
        Details::getInstance ()->confirm ( [ 
            'id' => Details::getInstance ()->create ( $param ) 
        ] );
        
        /*
         * 扣除销售者手续费
         */
        if ($thread ['system_fee']) {
            $systemFeeAmount = abs ( $data ['amount'] ) * - 1 * $thread ['system_fee'];
            if($systemFeeAmount != 0) {
                $param = [
                    'recorder' => $data ['receiver'],
                    'receiver' => 'system',
                    'amount' => abs ( $data ['amount'] ) * - 1 * $thread ['system_fee'],
                    'category' => Details::System_Fee,
                    'uniqid' => $data ['tid'] . '-' . $data ['recorder']
                ];
                Details::getInstance ()->confirm ( [
                    'id' => Details::getInstance ()->create ( $param )
                ] );
            }
        }
        try{
            $redis = SDKs::getRedis();
            $dateformat=date('ymd');
            $expireat=strtotime('+1 day',strtotime(date('Y-m-d')))-1;
            $user_all_key_string='user_'.$dateformat.'_all_amount';
        }catch(\Exception $e){
            
        }
        
        /*
         * 扣除销售者应该付出的渠道费用
         */
        if ($data ['plan'] && $data ['channel']) {
            foreach ( $data ['channel'] as $level => $channel ) {
                if ($thread ['channel'] [$data ['plan']] [$level]) {
                    $param = [ 
                        'recorder' => $data ['receiver'],
                        'receiver' => $channel,
                        'amount' => abs ( $data ['amount'] ) * - 1 * $thread ['channel'] [$data ['plan']] [$level],
                        'category' => Details::Thread_Spread,
                        'uniqid' => "{$data['tid']}-{$channel}-{$level}-{$data['recorder']}" 
                    ];
                    Details::getInstance ()->confirm ( [ 
                        'id' => Details::getInstance ()->create ( $param ) 
                    ] );
                    try{
                        // 今日收益
                        $redis->hincrbyfloat($user_all_key_string,$data['receiver'],$param['amount']/1000000);
                        
                        $redis->expireat($user_all_key_string,$expireat);
                    }catch(\Exception $e){
                        
                    }
                }
            }
        }
        $data ['amount'] && PurchaseThreadTask::getInstance ()->finish ( $data ['recorder'] );
        $this->transaction_commit ();
    }
    public function query($data) {
        return Details::getInstance ()->query ( $data );
    }
    public function getCount($params) {
        return Details::getInstance ()->getCount ( $params );
    }
}