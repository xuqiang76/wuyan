<?php

namespace HttpApi\Model\Wallet;

use HttpApi\Model\Ad;

class AdSense extends WalletBase {
	protected $tableName = 'adsense';
	public function query($data = []) {
		return Ad::getInstance()->query_adsense($data); //转到新代码

	}

	public function details($params) {
		return Ad::getInstance()->details($params);

	}
}