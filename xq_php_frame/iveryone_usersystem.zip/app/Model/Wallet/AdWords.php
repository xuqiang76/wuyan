<?php

namespace HttpApi\Model\Wallet;

use Beahoo\Exception;
use HttpApi\Model\Ad;

class AdWords extends WalletBase {
	protected $tableName = 'adwords';

	/**
	 *
	 * @param array $data
	 * @throws Exception
	 */
	public function create($data = ['uid' => '1', 'number' => 0, 'price' => 0, 'plan' => 1]) {
		Ad::getInstance()->create($data);

	}

	public function query($data = ['id' => 1]) {
		return Ad::getInstance()->query($data);

	}

	public function cancel($data) {
		return Ad::getInstance()->cancel($data);

	}

}