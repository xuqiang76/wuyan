<?php

namespace HttpApi\Model\Wallet;

use Beahoo\Exception;
use HttpApi\Tool\Format;

class WorldCup extends WalletBase
{
    protected $tableName = 'wc_schedule';

    public function getSche($params)
    {
        $data = $this->getOne()->select($this->tableName, '*', $params, 'order by start asc' )['data'];
        return $data;
    }

}