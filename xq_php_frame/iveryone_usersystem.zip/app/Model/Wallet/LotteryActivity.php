<?php

namespace HttpApi\Model\Wallet;

use Beahoo\Tool\Config;

class LotteryActivity extends WalletBase {
    /**
     * 生成抽奖记录
     *
     * @param String $uid 用户ID
     * @param String $category 类型 telegram wechat
     */
    public function create($uid, $category, $usermark) {
        $random = Config::read ( 'lottery' );
        $sum = array_sum ( $random );
        $rand = mt_rand ( 0, $sum * 10000 ) / 10000;
        foreach ( $random as $key => $value ) {
            if ($value >= $rand) {
                break;
            } else {
                $rand -= $value;
            }
        }
        $data = [ 
            'recorder' => $uid 
        ];
        $data ['amount'] = $key;
        $data ['uniqid'] = 'candy-lottery-' . $category;
        $data ['category'] = $category == 'telegram' ? Details::Candy_Telegram : Details::Candy_WeChat;
        $data ['receiver'] = 'system';
        $this->transaction_start ();
        CommunityActivity::getInstance()->create($uid, $category == 'telegram'?0:1, $usermark);
        Details::getInstance ()->create ( $data );
        $this->transaction_commit ();
    }
    /**
     * 查询抽奖记录
     *
     * @param String $uid 用户ID
     * @return Array
     */
    public function query($uid) {
        $data = [ 
            'recorder' => $uid,
            'receiver' => 'system',
            'status' => 0,
            'category' => [ 
                Details::Candy_Telegram,
                Details::Candy_WeChat 
            ] 
        ];
        return Details::getInstance ()->query ( $data );
    }
    /**
     * 领取奖品
     * 
     * @param int $id 抽奖记录id
     * @param string $uid 用户id
     */
    public function receive($id, $uid) {
        $this->transaction_start ();
        Details::getInstance ()->confirm ( [ 
            'id' => $id,
            'recorder' => $uid 
        ] );
        $this->transaction_commit ();
    }
}