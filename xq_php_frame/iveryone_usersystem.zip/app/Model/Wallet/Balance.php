<?php

namespace HttpApi\Model\Wallet;

use Beahoo\Exception;
use HttpApi\Model\Battery;
use HttpApi\Tool\Format;

class Balance extends WalletBase
{

    /*
     * $data['uid'] : 用户id
     */
    public function query($data)
    {
        do {
            $result = $this->getOne()->selectOne($this->tableName, '*', $data);
        } while (empty ($result ['data']) && Wallet::getInstance()->create($data));
        return array_merge($result ['data'], [
            'balance' => Format::amount($result ['data'] ['balance'] + $result ['data'] ['freeze'] + $result['data']['lock']),
            'available'=>Format::amount($result['data']['balance']),
            'token' => Format::amount($result['data']['token']),
            'freeze' => Format::amount($result['data']['freeze']),
            'adwords' => Format::amount($result['data']['adwords']),
            'lock' => Format::amount($result['data']['lock']),
            'locktotal' => Format::amount($result['data']['freeze'] + $result['data']['lock']),
            'status' => $result['data']['status'],
            'transfer' => $result['data']['transfer']
        ]);
    }

    /**
     * @param $uid
     * @param int $fee
     * @param int $token
     * @param null $category
     * @return array|bool
     * @throws Exception
     */
    public function change($uid, $fee = 0, $token = 0, $category = null)
    {
        $fee = intval($fee);
        $token = intval($token);
        if (!$fee && !$token) {
            return true;
        }
        $before = $this->query([
            'uid' => $uid
        ]);
        if ($fee > 0) {
            if($this->checkAdWordsIncome($category)) {
                $result = $this->getOne()->exec("update {$this->tableName} set adwords = adwords + {$fee}, balance = balance + {$fee} where uid = '{$uid}'");
            } else {
                $result = $this->getOne()->exec("update {$this->tableName} set balance = balance + {$fee} where uid = '{$uid}'");
            }
        } else if ($token > 0) {
            $result = $this->getOne()->exec("update {$this->tableName} set token = token + {$token} where uid = '{$uid}'");
        } else if ($fee < 0) {
            if ($this->checkOnlyBalance($category, $before)) {
                $result = $this->getOne()->exec("update {$this->tableName} set balance = balance + {$fee} where balance + {$fee} >= 0 and uid = '{$uid}'");
            } else {
                $result = $this->getOne()->exec("update {$this->tableName} set balance = if(token + {$fee} >= 0, balance, balance + token + {$fee}), token = if(token + {$fee}>=0, token + {$fee}, 0) where balance + token + {$fee} >=0 and uid = '{$uid}'");
            }
        }
        if (!$result ['affectedrows']) {
            if ($fee > 0) {
                throw new Exception ('更新余额失败', 4221);
            } else {
                if(($before['available'] + $before['lock'])*1000000 > abs($fee) && $before['status'] != 0) {
                    throw new Exception("", $before['status']);
                }
                throw new Exception ('可用余额不足', 4222);
            }
        }
        $after = $this->query([
            'uid' => $uid
        ]);

        $return = [
            'balance' => $after ['balance'] - $before ['balance'],
            'token' => $after ['token'] - $before ['token']
        ];
        if ($return ['token']) {
            $battryinfo = Battery::getInstance()->getBatteryInfo($uid);
            if ($before ['token'] == $battryinfo ['capacity']) {
                Battery::getInstance()->UpdateLastChargeTimestamp($uid);
            }
        }
        return $return;
    }

    /**
     * 冻结或者解冻相应金额
     *
     * 此方法应该应用在事务内，如果不使用在事务内，则有可能会多次冻结或者解冻
     *
     * @param int $uid 用户id
     * @param float $amount 如果为正数，则为冻结的金额，负数为解冻的金额，0会抛出异常
     * @throws Exception
     */
    public function freeze($uid, $amount)
    {
        $amount *= 1000000;
        if ($amount > 0) {
            $result = $this->getOne()->exec("update {$this->tableName} set balance = balance - {$amount}, freeze = freeze + {$amount} where uid = '{$uid}' and balance >= {$amount}");
        } else if ($amount < 0) {
            $result = $this->getOne()->exec("update {$this->tableName} set balance = balance - {$amount}, freeze = freeze + {$amount} where uid = '{$uid}' and freeze + {$amount} >=0");
        } else {
            return;
        }
        if (!$result ['affectedrows']) {
            if ($amount > 0) {
                throw new Exception ('冻结失败', 4224);
            } else {
                throw new Exception ('解冻失败', 4225);
            }
        }
    }

    public function lockBalance($uid)
    {
        return $this->getOne()->exec("UPDATE {$this->tableName} SET `lock` = `lock` + balance, balance = 0 WHERE uid = '{$uid}'");
    }

    public function unlockBalance($uid)
    {
        return $this->getOne()->exec("UPDATE {$this->tableName} SET balance = balance + `lock`, `lock` = 0 WHERE uid = '{$uid}'");
    }

    public function checkOnlyBalance($category, $wallet)
    {
        if($wallet['status'] != 0) {
            return true;
        }
        return !in_array($category, [Details::Thread_Buy, Details::Battery_Clean]);
    }

    public function checkAdWordsIncome($category)
    {
        return $category == Details::AdSense;
    }
}
