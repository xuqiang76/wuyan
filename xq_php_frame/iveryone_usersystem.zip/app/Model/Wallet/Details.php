<?php

namespace HttpApi\Model\Wallet;

use Beahoo\Exception;
use HttpApi\Model\User\User;
use HttpApi\Tool\Format;
use HttpApi\Model\WalletNew\Bill;
use HttpApi\Tool\iVeryOneApi;
use HttpApi\Model\WalletNew\WalletNew;

class Details extends WalletBase {
    const Candy_Register = 1;
    const Candy_Level = 2;
    const Candy_Follow = 3;
    const Candy_WeChat = 4;
    const Candy_Telegram = 5;
    const Thread_Buy = 6;
    const Thread_Spread = 7;
    const System_Fee = 8;
    const AdWords = 9; //VRY
    const AdWords_V = 1009; //发广告V点
    const AdSense = 10; //VRY
    const AdSense_V = 1010; //观看或点击付费广告V点
    const Battery = 11;
    const Audio = 12;
    const Chat = 13;
    const Video = 14;
    const AdWords_Cancel = 15;
    const Activity = 16;
    const Game_Booking = 17;
    const Game_Booking_Spread = 18;
    const Game_Purchase = 19;
    const Game_Purchase_Spread = 20;
    const Battery_Clean = 21;
    const Transfer = 22;
    const Tips = 23;
    const Feedback = 24;
    const Appeal = 25;
    const Feedback_Cancel = 28;
    const Verification = 26;
    const Power_Auditor = 27;
    const Feedback_Reward = 29;
    const Assets_Purchase = 30;
    const Assets_Spread = 31;
    const Assets_App_Fee = 32;
    const Apple_Recharge = 34;
    const Not_Apple_Recharge = 35;
    const Game_Reward = 36;
    const World_Cup_Back = 33;

    protected $tableName = 'wallet_details';

    public $activity = [
        1 => 'bug、建议提交',
        2 => '母亲节活动奖励',
        3 => '群管奖励',
        4 => '星球提建议奖励',
        5 => '内容发布规则变更补贴',
        6 => [
            '活动奖励',
            '参加活动',
        ],
        7 => '活动返还',
        8 => '活动奖励',
    ];

    /**
     * 新钱包集成
     * @param $data
     * @throws Exception
     */
    private function newWallet($data) {
        $category = $data['category'];
        $incomeId = $data['amount'] > 0 ? $data['recorder'] : $data['receiver']; // 收入方
        $expendId = $data['amount'] <= 0 ? $data['recorder'] : $data['receiver']; // 支出方
        $amount = abs($data['amount']);
        $uniqid = $data['uniqid'];

        $isApple = false;
        if (\App::getGlobal('device_platform') == 'ios') {
            $isApple = true;
        }

        $external = [
            'uniqid' => $uniqid, // 第三方ID
        ];
        if (isset($data['remark'])) {
            $external['remark'] = $data['remark'];
        }
        // 备注（可为

        switch ($category) {
            //注册赠送
            case self::Candy_Register:
                $external['title'] = '注册iVeryOne';
                $external['scene_category'] = 'Candy_Register';
                $billId = Bill::getInstance()->SystemToVry($incomeId, $amount, $external);
                break;
            case self::Candy_Level:
                $external['title'] = '邀请激励';
                $external['scene_category'] = 'Candy_Level';
                $billId = Bill::getInstance()->SystemToVry($incomeId, $amount, $external);
                break;
            case self::Candy_Follow:
                $external['title'] = '关注';
                $external['scene_category'] = 'Candy_Follow';
                $billId = Bill::getInstance()->giveVCoupon($incomeId, $amount, $external);
                break;
            case self::Candy_WeChat:
                $external['title'] = '关注公众号';
                $external['scene_category'] = 'Candy_WeChat';
                $billId = Bill::getInstance()->giveVCoupon($incomeId, $amount, $external);
                break;
            case self::Candy_Telegram:
                $external['title'] = '关注电邮';
                $external['scene_category'] = 'Candy_Telegram';
                $billId = Bill::getInstance()->giveVCoupon($incomeId, $amount, $external);
                break;
            case self::Thread_Buy:
                $threadTitle = iVeryOneApi::Request('Intra/Thread/Detail', [
                    'id' => array_unique(array_values(['id' => $external['uniqid']])),
                ])['data'];
                $external['income_title'] = '内容出售-' . $threadTitle[$external['uniqid']];
                $external['expend_title'] = '购买付费-' . $threadTitle[$external['uniqid']];
                $external['scene_category'] = 'Thread_Buy';
                $billId = Bill::getInstance()->expendVToIncomeVry($incomeId, $expendId, $amount, $external, $isApple);
                break;
            case self::Thread_Spread:
                $tid_tmp = explode('-', $external['uniqid']);
                $threadTitle = iVeryOneApi::Request('Intra/Thread/Detail', [
                    'id' => array_unique(array_values(['id' => $tid_tmp[0]])),
                ])['data'];
                $external['income_title'] = '转发分成-' . $threadTitle[$tid_tmp[0]];
                $external['expend_title'] = '售出分成-' . $threadTitle[$tid_tmp[0]];
                $external['scene_category'] = 'Thread_Buy';
                //转发分成VRY 单位转换 V=>VRY
                $amount = Format::vExchangeVry($amount);
                $billId = Bill::getInstance()->transferVry($incomeId, $expendId, $amount, $external, $isApple);
                break;
            case self::System_Fee:
                $external['title'] = '系统手续费';
                $external['scene_category'] = 'System_Fee';
                $billId = Bill::getInstance()->SystemCharge($expendId, $amount, $external);
                break;
            case self::AdWords:
            case self::AdWords_V:
                $external['title'] = '投放广告';
                $external['scene_category'] = 'AdWords';
                //目前只支持V点投放广告
                $billId = Bill::getInstance()->unconfirmedV($expendId, $amount, $external, $isApple);
                break;
            case self::AdSense:
            case self::AdSense_V:
                $external['title'] = '查看广告';
                $external['scene_category'] = 'AdSense';
                $billId = Bill::getInstance()->unconfirmedVToCoupon($incomeId, $expendId, $amount, $external);
                WalletNew::getInstance()->adSense($incomeId, $amount);
                break;
            case self::Battery: //新钱包不存在补贴
                $external['title'] = '补贴发放';
                $external['scene_category'] = 'Battery';
                $billId = Bill::getInstance()->giveVCoupon($incomeId, $amount, $external);
                break;
            case self::Audio:
                return false;
                break;
            case self::Chat:
                return false;
                break;
            case self::Video:
                return false;
                break;
            case self::AdWords_Cancel:
                $orderinfo = Bill::getInstance()->getOne()->selectOne('bill', '*',
                    ['uniqid' => $data['uniqid'], 'scene_category' => [self::AdWords, self::AdSense_V], 'belong_id' => $incomeId])['data'];
                $external = [
                    'uniqid' => $data['uniqid'],
                    'title' => '广告取消，退款',
                    'remark' => $data['remark'],
                    'scene_category' => 'AdWords_Cancel',
                ];
                //记账的方法需要提供的是已消耗的资金， 在此转换
                $amount = Format::decodeV($orderinfo['amount'] - Format::encodeV($amount));
                $billId = Bill::getInstance()->refundUnconfirmedV($orderinfo['id'], $amount, $external);
                break;
            case self::Activity:
                $external['scene_category'] = 'Activity';
                $negative = intval($external['uniqid']);
                $title = $this->activity[$negative];
                //收入方不为系统的 是参加活动
                switch ($negative) {
                    case Activity::Admin:
                    case Activity::Planet:
                    case Activity::WorldCupRebate:
                        $external['title'] = $title;
                        $billId = Bill::getInstance()->SystemToVry($incomeId, $amount, $external);
                        break;
                    case Activity::WorldCup:
                        if (!is_int($incomeId)) {
                            $external['title'] = $title[0];
                            $billId = Bill::getInstance()->SystemToVry($expendId, $amount, $external);
                        } else {
                            $external['title'] = $title[1];
                            $billId = Bill::getInstance()->SystemCharge($incomeId, $amount, $external);
                        }
                        break;
                    default:
                        if (!is_int($incomeId)) {
                            $external['title'] = $title[0];
                            $billId = Bill::getInstance()->consumeVtoSystem($expendId, $amount, $external);
                        } else {
                            $external['title'] = $title[1];
                            $billId = Bill::getInstance()->giveVCoupon($incomeId, $amount, $external);
                        }
                }
                break;
            case self::Game_Booking:
                break;
            case self::Game_Booking_Spread:
                break;
            case self::Game_Purchase:
                break;
            case self::Game_Purchase_Spread:
                break;
            case self::Battery_Clean: //场景取消
                $external['title'] = '活动奖励';
                $external['scene_category'] = 'Battery_Clean';
                $billId = Bill::getInstance()->giveVCoupon($incomeId, $amount, $external);
                break;
            case self::Transfer:
                $incomeInfo = User::getInstance()->getOne()->selectOne('userinfo', ['nickname'], ['id' => $incomeId])['data'];
                $expendInfo = User::getInstance()->getOne()->selectOne('userinfo', ['nickname'], ['id' => $expendId])['data'];
                $external['uniqid'] = uniqid('transfer_');
                $external['income_title'] = '转账-' . $expendInfo['nickname'];
                $external['expend_title'] = '转账-' . $incomeInfo['nickname'];
                $external['scene_category'] = 'Transfer';
                $billId = Bill::getInstance()->transferVry($incomeId, $external, $amount, $external);
                break;
            case self::Tips: //文章打赏
                $threadTitle = iVeryOneApi::Request('Intra/Thread/Detail', [
                    'id' => array_unique(array_values(['id' => $external['uniqid']])),
                ])['data'];
                $external['title'] = '文章打赏-' . $threadTitle[$external['uniqid']];
                $external['scene_category'] = 'Tips';
                $billId = Bill::getInstance()->expendVToIncomeVry($incomeId, $expendId, $amount, $external, $isApple);
                break;
            case self::Feedback:
                $external['title'] = '举报扣费';
                $external['scene_category'] = 'Feedback';
                $billId = Bill::getInstance()->consumeVtoSystem($expendId, $amount, $external, $isApple);
                break;
            case self::Appeal:
                $external['title'] = '申诉扣费';
                $external['scene_category'] = 'Appeal';
                $billId = Bill::getInstance()->consumeVtoSystem($expendId, $amount, $external, $isApple);
                break;
            case self::Feedback_Cancel:
                //定位到举报时的订单ID
                $orderinfo = Bill::getInstance()->getOne()->selectOne('bill', '*',
                    ['uniqid' => $data['uniqid'], 'scene_category' => self::Feedback, 'belong_id' => $data['uid']])['data'];
                $external['title'] = '举报失败';
                $external['scene_category'] = 'Feedback_Cancel';
                $billId = Bill::getInstance()->refund($expendId, $amount, $external, $orderinfo['id']);
                break;
            case self::Verification:
                $external['title'] = '人脸认证';
                $external['scene_category'] = 'Verification';
                $billId = Bill::getInstance()->giveVCoupon($incomeId, $amount, $external);
                break;
            case self::Power_Auditor:
                $external['title'] = '审核工资';
                $external['scene_category'] = 'Power_Auditor';
                $billId = Bill::getInstance()->SystemToVry($incomeId, $amount, $external);
                break;
            case self::Feedback_Reward:
                $external['title'] = '举报奖励';
                $external['scene_category'] = 'Feedback_Reward';
                $billId = Bill::getInstance()->SystemToVry($incomeId, $amount, $external);
                break;
            case self::Game_Reward:
                $external['income_title'] = '游戏内获取VRY';
                $external['expend_title'] = '游戏奖励发放';
                $external['scene_category'] = 'Game_Reward';
                $billId = Bill::getInstance()->transferVry($incomeId, $expendId, $amount, $external);
                break;
            case self::Assets_Purchase:
                $title =
                $external['title'] = '购买道具';
                $external['scene_category'] = 'Assets_Purchase';
                $billId = Bill::getInstance()->expendVToIncomeVry($incomeId, $expendId, $amount, $external);
                break;
            case self::Assets_Spread:
                $external['title'] = '道具销售分成';
                $external['scene_category'] = 'Assets_Spread';
                $billId = Bill::getInstance()->transferVry($incomeId, $expendId, $amount, $external);
                break;
            case self::Assets_App_Fee:
                $external['title'] = '道具游戏厂商分成';
                $external['scene_category'] = 'Assets_App_Fee';
                $billId = Bill::getInstance()->transferVry($incomeId, $expendId, $amount, $external);
                break;
        }

        return $billId;
    }

    /**
     * @param $data
     * @param bool $onlyBalance
     * @return mixed|null
     * @throws Exception
     */
    public function create($data) {

        return $this->newWallet($data);

        exit;

        $data['amount'] *= 1000000;
        $data['status'] = $data['status'] ?? 0;
        $data['create_timestamp'] = $data['create_timestamp'] ?? TIMESTAMP;
        $data['direction'] = $data['amount'] > 0 ? 'income' : 'outlay';
        $result = $this->getOne()->insert($this->tableName, $data);
        if (!$result['insertid']) {
            throw new Exception('生成明细失败', 4412);
        }
        if ($data['amount'] < 0 && (get_called_class() != __CLASS__ || !in_array($data['category'], [self::Audio, self::Chat, self::Video]))) {
            $wallet = Balance::getInstance()->change($data['recorder'], $data['amount'], 0, $data['category']);
            if ($wallet['token']) {
                $data['status'] = 1;
                $data['confirm_timestamp'] = TIMESTAMP;
                $data['uniqid'] = $result['insertid'];
                $data['receiver'] = 'system_token';
                $data['amount'] = $wallet['token'] * 1000000;
                $this->getOne()->insert($this->tableName, $data);
                if ($wallet['balance']) {
                    $data['receiver'] = 'system_balance';
                    $data['amount'] = $wallet['balance'] * 1000000;
                    $this->getOne()->insert($this->tableName, $data);
                }
            }
        }
        return $result['insertid'];
    }

    /**
     * @param $data
     * @throws Exception
     */
    public function confirm($data) {
        return;
        $data['status'] = 0;
        $confirm = $this->getOne()->update($this->tableName, [
            'confirm_timestamp' => TIMESTAMP,
            'status' => 1,
        ], [], $data);
        if ($confirm['affectedrows']) {
            $data['status'] = 1;
            $detail = $this->query($data)[0];
            $detail['amount'] *= 1000000;
            if ($detail['amount'] > 0) {
                if ($detail['category'] == self::Battery) {
                    Balance::getInstance()->change($detail['recorder'], 0, $detail['amount'], $detail['category']);
                } else {
                    Balance::getInstance()->change($detail['recorder'], $detail['amount'], 0, $detail['category']);
                }
            }
        }
    }

    /**
     * @param $data
     * @param bool $onlyBalance
     * @return mixed|null
     * @throws Exception
     */
    public function autoCreate($data) {
        $data['amount'] *= 1000000;
        $data['status'] = 1;
        $data['create_timestamp'] = $data['create_timestamp'] ?? TIMESTAMP;
        $data['direction'] = $data['amount'] > 0 ? 'income' : 'outlay';
        $result = $this->getOne()->insert($this->tableName, $data);
        if (!$result['insertid']) {
            throw new Exception('生成明细失败', 4412);
        }
        if ($data['amount'] < 0) {
            $wallet = Balance::getInstance()->change($data['recorder'], $data['amount'], 0, $data['category']);
            if ($wallet['token']) {
                $data['status'] = 1;
                $data['confirm_timestamp'] = TIMESTAMP;
                $data['uniqid'] = $result['insertid'];
                $data['receiver'] = 'system_token';
                $data['amount'] = $wallet['token'] * 1000000;
                $this->getOne()->insert($this->tableName, $data);
                if ($wallet['balance']) {
                    $data['receiver'] = 'system_balance';
                    $data['amount'] = $wallet['balance'] * 1000000;
                    $this->getOne()->insert($this->tableName, $data);
                }
            }

            if (strpos($data['receiver'], 'system') === false) {
                list($data['recorder'], $data['receiver']) = [
                    $data['receiver'],
                    $data['recorder'],
                ];
                Balance::getInstance()->change($data['recorder'], $data['amount'] * -1);
                $data['amount'] /= -1000000;
                $this->create($data);
            }
        } elseif ($data['amount'] > 0) {
            $data['category'] == self::Battery ? Balance::getInstance()->change($data['recorder'], 0, $data['amount'], $data['category']) : Balance::getInstance()->change($data['recorder'], $data['amount'], 0, $data['category']);
        }
        return $result['insertid'];
    }

    /**
     * @param $data
     * @return \Beahoo\Tool\Dbresult|mixed|null
     * @throws Exception
     */
    public function query($data) {
        $offset = 0;
        $param = [];
        if (isset($data['category'])) {
            $param['scene_category'] = $data['category'];
        }
        if (isset($data['recorder'])) {
            $param['belong_id'] = $data['recorder'];
        }
        if (isset($data['direction'])) {
            $param['direction_type'] = $data['direction'] == 'income' ? 1 : 2;
        }
        if (isset($data['uniqid'])) {
            $param['uniqid'] = $data['uniqid'];
        }
        foreach (explode(',', 'offset,limit,begin,end') as $key) {
            if (isset($data[$key])) {
                $param[$key] = $data[$key];
                $$key = $data[$key];
            }
        }
        $orderby = '';
        if (isset($data['receiver'])) {
            if (is_numeric($data['receiver'])) {
                $orderby = ($offset ? " and id < {$offset}" : "") . " and (income_id = {$data['receiver']} or expend_id = {$data['receiver']})";
            } else {
                $orderby = ($offset ? " and id < {$offset}" : "") . " and (income_id = {$data['recorder']} or expend_id = {$data['recorder']})";
            }
        }
        $details = [];
        foreach (Bill::getInstance()->queryBill($param, $orderby) as $detail) {
            $details[] = [
                'id' => $detail['id'],
                'recorder' => $detail['belong_id'],
                'receiver' => $detail['direction_type'] == 1 ? $detail['expend_id'] : $detail['income_id'],
                'category' => $detail['scene_category'],
                'uniqid' => $detail['uniqid'],
                'status' => $detail['status'] == 1 ? 0 : ($detail['status'] == 2 ? 1 : -1),
                'amount' => $detail['amount'] * ($detail['direction_type'] == 1 ? 1 : -1),
                'create_timestamp' => $detail['create_timestamp'],
                'confirm_timestamp' => $detail['finish_timestamp'],
                'direction' => $detail['direction_type'] == 1 ? 'income' : 'outlay',
                'remark' => $detail['title'],
            ];
        }
        return $details;
    }

    /**
     * @param $data
     * @param $category
     * @throws Exception
     */
    public function recall($data, $category) {
        $confirm = $this->getOne()->update($this->tableName, [
            'confirm_timestamp' => TIMESTAMP,
            'status' => -1,
        ], [], $data);
        if ($confirm['affectedrows']) {
            $detail = $this->query($data)[0];
            if ($detail['amount'] > 0) {
                throw new Exception('收入项目无法退回', 4100);
            }
            $detail['amount'] *= -1;
            $detail['receiver'] = 'system';
            $detail['status'] = 1;
            $detail['category'] = $category;
            $detailid = $detail['id'];
            unset($detail['id']);
            $recall = $this->create($detail);

            try {
                $token = $this->query([
                    'receiver' => 'system_token',
                    'uniqid' => $detailid,
                ])[0];
                $this->getOne()->update($this->tableName, [
                    'confirm_timestamp' => TIMESTAMP,
                    'status' => -1,
                ], [], [
                    'id' => $token['id'],
                ]);
                $token['confirm_timestamp'] = TIMESTAMP;
                $token['status'] = 1;
                $token['category'] = $category;
                $token['uniqid'] = $recall;
                $token['amount'] *= -1;
                $this->create($token);
                Balance::getInstance()->change($detail['recorder'], $token['amount'] * 1000000);
            } catch (Exception $e) {
                $token = Null;
            }
            if ($token) {
                try {
                    $balance = $this->query([
                        'receiver' => 'system_balance',
                        'uniqid' => $detailid,
                    ])[0];
                    $this->getOne()->update($this->tableName, [
                        'confirm_timestamp' => TIMESTAMP,
                        'status' => -1,
                    ], [], [
                        'id' => $balance['id'],
                    ]);
                    $balance['confirm_timestamp'] = TIMESTAMP;
                    $balance['status'] = 1;
                    $balance['category'] = $category;
                    $balance['uniqid'] = $recall;
                    $balance['amount'] *= -1;
                    $this->create($balance);
                    Balance::getInstance()->change($balance['recorder'], $balance['amount'] * 1000000);
                } catch (Exception $e) {
                    $balance = Null;
                }
            } else {
                $balance = null;
            }
            $token == null && $balance == null && Balance::getInstance()->change($detail['recorder'], $detail['amount'] * 1000000);
        }
    }

    public function getCount($data) {
        $offset = 0;
        $param = [];
        if (isset($data['category'])) {
            $param['scene_category'] = $data['category'];
        }
        if (isset($data['recorder'])) {
            $param['belong_id'] = $data['recorder'];
        }
        if (isset($data['direction'])) {
            $param['scene_category'] = $data['direction'] == 'income' ? 1 : 2;
        }
        if (isset($data['uniqid'])) {
            $param['uniqid'] = $data['uniqid'];
        }
        foreach (explode(',', 'offset,limit,begin,end') as $key) {
            if (isset($data[$key])) {
                $$key = $data[$key];
            }
        }
        $orderby = '';
        if (isset($data['receiver'])) {
            if (is_numeric($data['receiver'])) {
                $orderby = ($offset ? " and id < {$offset}" : "") . " and (income_id = {$data['receiver']} or expend_id = {$data['receiver']})";
            } else {
                $orderby = ($offset ? " and id < {$offset}" : "") . " and (income_id = {$data['recorder']} or expend_id = {$data['recorder']})";
            }
        }
        return Bill::getInstance()->getBillCount($params, $orderby);
    }
}