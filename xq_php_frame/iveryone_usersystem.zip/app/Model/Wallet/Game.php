<?php

namespace HttpApi\Model\Wallet;

class Game extends SpreadBase {
    public function booking($data) {
        $this->transaction_start ();
        $this->spread ( [ 
            'recorder' => $data ['uid'],
            'receiver' => $data ['cp'],
            'amount' => $data ['amount'],
            'category' => Details::Game_Booking,
            'spread' => Details::Game_Booking_Spread,
            'uniqid' => $data ['gameid'],
            'config' => 'game_booking',
            'channel' => $data ['channel'],
            'remark' => $data ['remark'] 
        ] );
        $this->transaction_commit ();
    }
    public function purchase($data) {
        $this->transaction_start();
        $orderid = $this->spread ( [ 
            'recorder' => $data ['uid'],
            'receiver' => $data ['cp'],
            'amount' => $data ['amount'],
            'category' => Details::Game_Purchase,
            'spread' => Details::Game_Purchase_Spread,
            'uniqid' => $data ['gameid'] . "-" . $data ['orderid'],
            'config' => 'game_purchase',
            'channel' => $data ['channel'],
            'remark' => $data ['remark'] 
        ] );
        $this->transaction_commit();
        return $orderid;
    }
    public function query($data) {
        return Details::getInstance ()->query ( $data );
    }
}