<?php

namespace HttpApi\Model\Wallet;

use Beahoo\Tool\Config;

class SpreadBase extends WalletBase {
    function spread($data) {
        $data ['amount'] = abs ( $data ['amount'] ) * - 1;
        /*
         * 读取配置数据
         */
        $config = Config::read ( $data ['config'] );
        
        /*
         * 扣除购买者费用
         */
        $param = [ 
            'recorder' => $data ['recorder'],
            'receiver' => $data ['receiver'],
            'amount' => $data ['amount'],
            'category' => $data ['category'],
            'uniqid' => $data ['uniqid'],
            'remark' => $data ['remark'] 
        ];
        $orderid = Details::getInstance ()->create ( $param ) ;
        Details::getInstance ()->confirm ( [ 
            'id' => $orderid
        ] );
        
        /*
         * 扣除销售者手续费
         */
        if ($config ['system_fee']) {
            $param = [ 
                'recorder' => $data ['receiver'],
                'receiver' => 'system',
                'amount' => $data ['amount'] * $config ['system_fee'],
                'category' => Details::System_Fee,
                'uniqid' => $data ['uniqid'] . '-' . $data ['recorder'] 
            ];
            Details::getInstance ()->confirm ( [ 
                'id' => Details::getInstance ()->create ( $param ) 
            ] );
        }
        
        /*
         * 扣除销售者应该付出的渠道费用
         */
        if ($data ['channel']) {
            foreach ( $data ['channel'] as $level => $channel ) {
                if ($config ['channel'] [$level]) {
                    $param = [ 
                        'recorder' => $data ['receiver'],
                        'receiver' => $channel,
                        'amount' => $data ['amount'] * $config ['channel'] [$level],
                        'category' => $data ['spread'],
                        'uniqid' => "{$data['uniqid']}-{$channel}-{$level}-{$data['recorder']}" 
                    ];
                    Details::getInstance ()->confirm ( [ 
                        'id' => Details::getInstance ()->create ( $param ) 
                    ] );
                }
            }
        }
        return $orderid;
    }
}