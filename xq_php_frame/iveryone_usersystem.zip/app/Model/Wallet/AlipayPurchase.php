<?php

namespace HttpApi\Model\Wallet;

use Beahoo\Model\Base;

class AlipayPurchase extends Base {
    private static $instance;

    private $tableName = 'alipay_purchase';

    public static function getInstance()
    {
        if (empty(self::$instance)) {
            self::$instance = new AlipayPurchase();
        }
        return self::$instance;
    }

    public function getTableName()
    {
        return $this->tableName;
    }

    public function insert($setarr)
    {
        $setarr['create_timestamp'] = TIMESTAMP;
        $setarr['purchase_info'] = json_encode($setarr['purchase_info']);
        return $this->getOne()->insert($this->tableName, $setarr)['insertid'];
    }

    public function getItems($where, $limit = 100)
    {
        $res = $this->getOne()->select($this->tableName, '*', $where, 'order by id asc', 0, $limit)['data'];
        foreach ($res as $key => $item) {
            $res[$key]['purchase_info'] = json_decode($item['purchase_info'], true);
        }
        return $res;
    }

    public function modify($setarr, $where)
    {
        return $this->getOne()->update($this->tableName, $setarr, [], $where);
    }
}