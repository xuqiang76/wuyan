<?php

namespace HttpApi\Model\Wallet;

class Activity extends WalletBase {
    const Debug = 1;
    const Mother = 2;
    const Admin = 3;
    const Planet = 4;
    const Feedback = 5;
    const WorldCup = 6;
    const WorldCupRebate = 7;
    const Sentence = 8;
    public function create($data) {
        Details::getInstance ()->confirm ( [ 
            'id' => Details::getInstance ()->create ( [ 
                'recorder' => $data ['uid'],
                'receiver' => 'system',
                'category' => Details::Activity,
                'amount' => abs ( $data ['amount'] ),
                'uniqid' => "{$data ['category']}_" . ($data ['uniqid'] ?? uniqid ())
            ] ) 
        ] );
    }
}