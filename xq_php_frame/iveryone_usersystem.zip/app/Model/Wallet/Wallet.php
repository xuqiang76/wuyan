<?php

namespace HttpApi\Model\Wallet;

use Beahoo\Exception;
use Beahoo\Tool\Config;
use HttpApi\Model\User\LockUserInfo;

class Wallet extends WalletBase {
    public function create($data) {
        $result = $this->getOne ()->insert ( $this->tableName, $data );
        if (! $result ['insertid']) {
            throw new Exception ( '钱包生成失败', 4412 );
        }
        return $result ['insertid'];
    }
    
    /**
     * 查询或者修改用户钱包状态
     * 
     * @param int $uid 用户ID
     * @param int $status 钱包状态 0为正常，其他为异常，如果不传则为查询当前状态
     * @param boolean $first_auth_face 是否首次人脸认证
     * @throws Exception
     * @return int|boolean
     */
    public function status($uid, $status = null,$first_auth_face = false, $addsetarr = []) {
        if (func_num_args () == 1) {
            return Balance::getInstance ()->query ( $uid ) ['status'];
        }
        $status = abs ( intval ( $status ) );
        $setarr = [
            'status' => $status
        ];
        if($addsetarr) {
            $setarr = array_merge($setarr, $addsetarr);
        }
        $this->getOne ()->update ( $this->tableName, $setarr, [ ], [
            'uid' => $uid 
        ] );
        if($status == 0) {
            Balance::getInstance()->unlockBalance($uid);
            LockUserInfo::getInstance()->UnlockByRuid($uid);
            RegisterActivity::getInstance()->unfreeze(['uid' => $uid]);
            if($first_auth_face) {
                $param = [
                    'recorder' => $uid,
                    'receiver' => 'system',
                    'amount' => Config::read('first_face_auth_amount'),
                    'category' => Details::Verification,
                    'uniqid' => 'candy-verification-' . $uid . '-0'
                ];
                Details::getInstance()->confirm([
                    'id' => Details::getInstance()->create($param)
                ]);
            }
        }
        return true;
    }
}