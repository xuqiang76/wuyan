<?php

namespace HttpApi\Model\Wallet;

use Beahoo\Tool\Config;
use HttpApi\Tool\SDKs;

class Assets extends WalletBase {
    public function create($data) {
        $data ['plan'] = intval ( $data ['plan'] ?? 0);
        $this->transaction_start ();
        /*
         * 读取配置数据
         */
        $thread = Config::read ( 'thread' );
        
        /*
         * 扣除购买者费用
         */
        $param = [ 
            'recorder' => $data ['recorder'],
            'receiver' => $data ['receiver'],
            'amount' => abs ( $data ['amount'] ) * - 1,
            'category' => Details::Assets_Purchase,
            'uniqid' => $data ['aid'],
            'remark' => $data ['remark'] 
        ];
        Details::getInstance ()->confirm ( [ 
            'id' => Details::getInstance ()->create ( $param ) 
        ] );
        
        /*
         * 扣除销售者手续费
         */
        if ($thread ['system_fee']) {
            $param = [ 
                'recorder' => $data ['receiver'],
                'receiver' => 'system',
                'amount' => abs ( $data ['amount'] ) * - 1 * $thread ['system_fee'],
                'category' => Details::System_Fee,
                'uniqid' => $data ['tid'] . '-' . $data ['recorder'] 
            ];
            Details::getInstance ()->confirm ( [ 
                'id' => Details::getInstance ()->create ( $param ) 
            ] );
        }
        try{
            $redis = SDKs::getRedis();
            $dateformat=date('ymd');
            $expireat=strtotime('+1 day',strtotime(date('Y-m-d')))-1;
            $user_all_key_string='user_'.$dateformat.'_all_amount';
        }catch(\Exception $e){
            
        }
        
        /*
         * 扣除销售者应该付出的渠道费用
         */
        if ($data ['plan'] && $data ['channel']) {
            foreach ( $data ['channel'] as $level => $channel ) {
                if ($thread ['channel'] [$data ['plan']] [$level]) {
                    $param = [ 
                        'recorder' => $data ['receiver'],
                        'receiver' => $channel,
                        'amount' => abs ( $data ['amount'] ) * - 1 * $thread ['channel'] [$data ['plan']] [$level],
                        'category' => Details::Assets_Spread,
                        'uniqid' => "{$data['aid']}-{$channel}-{$level}-{$data['recorder']}" 
                    ];
                    Details::getInstance ()->confirm ( [ 
                        'id' => Details::getInstance ()->create ( $param ) 
                    ] );
                    try{
                        // 今日收益
                        $redis->hincrbyfloat($user_all_key_string,$data['receiver'],$param['amount']/1000000);
                        
                        $redis->expireat($user_all_key_string,$expireat);
                    }catch(\Exception $e){
                        
                    }
                }
            }
        }
        /*
         * 扣除游戏商服务费
         */
        $amonut = 1;
        if ($thread ['system_fee']) {
        	$amonut -= $thread ['system_fee'];
        }
        if ($data ['plan'] && $data ['channel']) {
        	$amonut -= array_sum ( array_slice ( $thread ['channel'] [$data ['plan']], 1, count ( $data ['channel'] ) ) );
        }
        $amonut = $amonut < 0 ? 0 : $amonut;
        $param = [
        		'recorder' => $data ['receiver'],
        		'receiver' => $data ['appid'],
        		'amount' => abs ( $data ['amount'] ) * - 1 * $amonut * 0.1,
        		'category' => Details::Assets_App_Fee,
        		'uniqid' => $data ['aid']
        ];
        Details::getInstance ()->confirm ( [
        		'id' => Details::getInstance ()->create ( $param )
        ] );
        $this->transaction_commit ();
    }
    public function query($data) {
        return Details::getInstance ()->query ( $data );
    }
    public function getCount($params) {
        return Details::getInstance ()->getCount ( $params );
    }
}