<?php

namespace HttpApi\Model\Wallet;

use Beahoo\Exception;

class Tips extends WalletBase {
    
    /**
     * 转账
     *
     * 必须使用在事务中，如果不是使用在事务中，则会造成收支不平衡
     *
     * @param Array $data
     *            $data['uid'] 发起转账的用户id
     *            $data['tid'] 接受转账的用户id
     *            $data['author'] 接受转账的用户id
     *            $data['amount'] 转账金额，不可为0，仅为正数，负数会自动转换成正数
     * @throws Exception
     */
    public function create($data) {
        $this->transaction_start();
        $data ['amount'] = - abs ( $data ['amount'] );
        if ($data ['amount'] === 0) {
            throw new Exception ( '转账金额为0', 4031 );
        }
        Details::getInstance ()->confirm ( [ 
            'id' => Details::getInstance ()->create ( [ 
                'recorder' => $data ['uid'],
                'receiver' => $data ['author'],
                'amount' => $data ['amount'],
                'category' => Details::Tips,
                'uniqid' => $data ['tid'] 
            ], true ) 
        ] );
        $this->transaction_commit();
    }
}