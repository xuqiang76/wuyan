<?php

namespace HttpApi\Model\Wallet;

use Beahoo\Tool\Config;
use HttpApi\Model\User\LockUserInfo;
use HttpApi\Model\TaskPool\SpreadRegisterTask;

class RegisterActivity extends WalletBase
{
    protected $tableName = 'genealogy';

    /*
     * $data['uid'] : 用户ID
     * $data['referer'] : 来源用户，如无，为空
     */
    public function insert($data)
    {
        $this->transaction_start();
        $data ['register'] = $data ['register'] ?? TIMESTAMP;
        $data ['freeze'] = $data ['freeze'] ?? 1;
        $data ['level'] = 1;
        $this->getOne()->insert($this->tableName, array_merge($data, [
            'referer' => $data ['uid'],
            'level' => 0
        ]));
        if (isset ($data ['referer']) && $data ['referer']) {
            SpreadRegisterTask::getInstance ()->finish ( $data ['referer'] );
            $this->getOne()->insert($this->tableName, $data);
            $this->getOne()->exec("insert into {$this->tableName} select null, '{$data['uid']}', referer, level + 1, " . TIMESTAMP . ", 1 from {$this->tableName} where uid = '{$data['referer']}' and level > 0 ");
        }
        $freeze = $this->getOne()->select($this->tableName, '*', [
            'uid' => $data ['uid']
        ]);
        if ($freeze ['rownum']) {
            $level = Config::read('level') [TIMESTAMP >= NEW_INVITE_TIMESTAMP];
            foreach ($freeze ['data'] as $item) {
                if ($item['level'] == 0) {
                    continue;
                }
                if (isset ($level [$item ['level']])) {
                    $param = [
                        'recorder' => $item ['referer'],
                        'receiver' => 'system',
                        'amount' => $level [$item ['level']],
                        'category' => Details::Candy_Level,
                        'uniqid' => 'candy-register-' . $item ['uid'] . '-' . $item ['level']
                    ];
                    if ($item ['freeze']) {
                        // 添加用户的操作日志，用于每日统计及逐条推送
                        LockUserInfo::getInstance ()->DoLock ( $data ['uid'], $item ['referer'], $param ['amount'] );
                    } else {
                        Details::getInstance ()->confirm ( [
                            'id' => Details::getInstance ()->create ( $param )
                        ] );
                    }
                }
            }
        }
        $this->transaction_commit();
    }

    public function Reissueinsert($data)
    {
        $this->transaction_start();
        $data ['register'] = TIMESTAMP;
        $data ['freeze'] = $data ['freeze'] ?? 1;
        $data ['level'] = 1;
        if (isset ($data ['referer']) && $data ['referer']) {
            SpreadRegisterTask::getInstance ()->finish ( $data ['referer'] );
            $this->getOne()->insert($this->tableName, $data);
            $this->getOne()->exec("insert into {$this->tableName} select null, '{$data['uid']}', referer, level + 1, " . TIMESTAMP . ", {$data ['freeze']} from {$this->tableName} where uid = '{$data['referer']}' and level > 0 ");
        }
        $freeze = $this->getOne()->select($this->tableName, '*', [
            'uid' => $data ['uid'],
            'freeze' => $data ['freeze']
        ]);
        if ($freeze ['rownum']) {
            $level = Config::read('level') [TIMESTAMP >= NEW_INVITE_TIMESTAMP];
            foreach ($freeze ['data'] as $item) {
                if ($item ['level'] == 0) {
                    continue;
                }
                if (isset ($level [$item ['level']])) {
                    $param = [
                        'recorder' => $item ['referer'],
                        'receiver' => 'system',
                        'amount' => $level [$item ['level']],
                        'category' => $item ['level'] ? Details::Candy_Level : Details::Candy_Register,
                        'uniqid' => 'candy-register-' . $item ['uid'] . '-' . $item ['level']
                    ];
                    if ($item ['freeze']) {
                        // 添加用户的操作日志，用于每日统计及逐条推送
                        LockUserInfo::getInstance ()->DoLock ( $data ['uid'], $item ['referer'], $param ['amount'] );
                    } else {
                        Details::getInstance ()->confirm ( [
                            'id' => Details::getInstance ()->create ( $param )
                        ] );
                    }
                }
            }
        }
        $this->transaction_commit();
    }

    /*
     * $data['uid'] : 用户ID 查上级
     *
     * $data['referer']: 用户id 查下级
     */
    public function query($data)
    {
        $type = $data ['type'] ?? 0;
        unset ($data ['type']);
        return $this->getOne()->select($this->tableName, "level, count(1) as total", $data, " and register " . ($type ? ">=" : "<") . NEW_INVITE_TIMESTAMP . " and level > 0 group by level order by level asc", 0, count(Config::read('level') [$type]) - 1) ['data'];
    }

    /**
     * 更新推广注册信息
     *
     * @param Array $data
     *            $data['uid'] 注册的用户id
     */
    public function unfreeze($data)
    {
        $this->getOne()->update($this->tableName, [
            'freeze' => 0
        ], [], [
            'uid' => $data ['uid'],
            'freeze' => 1
        ]);
    }
}