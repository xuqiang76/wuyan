<?php

namespace HttpApi\Model\Wallet;

use Beahoo\Exception;
use HttpApi\Tool\Format;
use HttpApi\Model\Wallet\Details;
use HttpApi\Model\Wallet\Activity;

class WorldCupUserLogs extends WalletBase
{
    protected $tableName = 'wc_user_logs';


    /**
     * 查询用户投注记录
     * @param array $data
     * @throws Exceptio
     */
    public function getUserLogs($uid)
    {
        $sql = "SELECT *,wc_user_logs.id as log_id FROM wc_user_logs LEFT JOIN wc_schedule ON " . "(" ."wc_user_logs.sche_id = wc_schedule.id" .")" . " where wc_user_logs.uid = ". $uid . ' order by wc_schedule.start desc';

        $data = $this->getOne()->exec($sql)['data'];

        return $data;
    }

    /**
     * 查询用户分享数据
     * @param array $data
     * @throws Exceptio
     */
    public function getUserPic($uid, $log_id)
    {
        $sql = "SELECT *,wc_user_logs.id as log_id FROM wc_user_logs LEFT JOIN wc_schedule ON " . "(" ."wc_user_logs.sche_id = wc_schedule.id" .")" . " where wc_user_logs.id = ". $log_id . " and  wc_user_logs.uid = " . $uid;

        $data = $this->getOne()->exec($sql)['data'];
        return $data;
    }

    /**
     * 根据ID查询用户投注记录
     * @param array $data
     * @throws Exceptio
     */
    public function getUserLogsById($params)
    {
        $data = $this->getOne()->select($this->tableName, '*', $params, 'order by time desc' )['data'];
        return $data;
    }

    public function update($data, $clause) {
        $result = $this->getOne()->update($this->tableName, $data, [ ], $clause);
        if (!$result['affectedrows']) {
            //throw new Exception('没有任何更改', 4123);
        }
    }

    /**
     * 投注下单，并扣除相应VRY
     * @param array $data
     * @throws Exceptio
     */
    public function create($data){

        Details::getInstance()->transaction_start();
        $user_log = $this->getOne()->insert($this->tableName, $data);

        //写钱包
        Details::getInstance()->confirm( [
            'id' => Details::getInstance ()->create ( [
                'recorder' => $data ['uid'],
                'receiver' => 'system',
                'amount' => abs ( $data ['price'] ) * - 1,
                'category' => Details::Activity,
                'uniqid' => Activity::WorldCup . '_' . ($user_log['insertid'] ?? uniqid ())
            ], true )
        ] );
        Details::getInstance()->transaction_commit ();

        return $user_log;
    }
    
}