<?php

namespace HttpApi\Model\Wallet;

use Beahoo\Exception;
use Beahoo\Tool\Config;

class FollowActivity extends WalletBase {
    protected $tableName = 'followActivity';
    public function insert($data) {
        $follow = Config::read ( 'follow' );
        if ($follow ['start'] < TIMESTAMP && TIMESTAMP < $follow ['end']) {
            $data ['quota'] = $follow ['quota'];
            $data ['create_time'] = TIMESTAMP;
            $data ['status'] = 0;
            $this->transaction_start ();
            if ($this->update ( [ 
                'uid' => $data ['uid'],
                'follower' => $data ['uid'] 
            ] )) {
                $this->getOne ()->insert ( $this->tableName, $data );
                Balance::getInstance ()->update ( $data ['follower'], $follow ['quota'] ) && $this->transaction_commit ();
            } else {
                $this->transaction_rollback ();
            }
        }
    }
    private function update($data) {
        if (empty ( $this->getOne ()->select ( $this->tableName, '*', $data ) ['data'] )) {
            $this->getOne ()->insert ( $this->tableName, [ 
                'uid' => $data ['uid'],
                'follower' => $data ['uid'],
                'quota' => Config::read ( 'follow' ) ['total'],
                'status' => 1 
            ] );
        }
        
        $quota = Config::read ( 'follow' ) ['quota'] * 2;
        
        $result = $this->getOne ()->exec ( "update {$this->tableName} set quota = quota - {$quota} where uid = '{$data['uid']}' and follower = '{$data['uid']}' and quota - {$quota} >= 0" );
        return $result ['affectedrows'];
    }
    
    /**
     * 查询未领取的糖果箱
     *
     * @param array $data
     *            $data['uid'] : 糖果箱所有者ID
     * @return array 二维数组，糖果箱详情
     */
    public function query($data) {
        $data ['status'] = 0;
        return $this->getOne ()->select ( $this->tableName, '*', $data ) ['data'];
    }
    
    /**
     * 领取糖果
     *
     * @param array $data
     *            $data['uid'] : 领取人ID
     * @return array [
     *         'num'=>1, //领取的个数
     *         'quota'=>2 //领取的总额
     *         ]
     */
    public function receive($data = ['uid' => 0]) {
        $total = [ 
            'num' => 0,
            'quota' => 0 
        ];
        $this->transaction_start ();
        foreach ( $this->query ( $data ) as $item ) {
            Balance::getInstance ()->update ( $item ['uid'], $item ['quota'] );
            $this->getOne ()->update ( $this->tableName, [ 
                'confirm_time' => TIMESTAMP,
                'status' => 1 
            ], [ ], [ 
                'id' => $item ['id'] 
            ] );
            $total ['num'] ++;
            $total ['quota'] += $item ['quota'];
        }
        $this->transaction_commit ();
        return $total;
    }
}