<?php

namespace HttpApi\Model\Wallet;

use Beahoo\Exception;
use HttpApi\Model\ReadOnly\Bill;
use HttpApi\Model\WalletNew\IM;

class RedPack extends Details {
    const Audio = 1;
    const Audio_Cancel = 2;
    const Chat = 3;
    const Chat_Cancel = 4;
    const Video = 5;
    const Video_Cancel = 6;
    //protected $tableName = 'redpack';

    /**
     * @param $data
     * @param $category
     * @throws Exception
     */
    public function bill($data, $category) {
        $bill = [ ];
        $begin = $data ['begin'];
        $end = $data ['end'];
        unset ( $data ['begin'], $data ['end'] );
        $this->transaction_start ();
        $data['status'] = 2;
        $detail = IM::getInstance()->queryDetail ( $data );
        foreach ($detail  as $key =>  $item ) {
            if(!isset($bill[$item['belong_id']])) {
                $bill[$item['belong_id']] = [];
            }
            if(!isset($bill[$item['belong_id']]['amount'])) {
                $bill[$item['belong_id']]['amount'] = 0;
            }
            $bill[$item['belong_id']]['amount'] += $item['amount'];
            $bill[$item['belong_id']]['income_id'] = $item['income_id'];
            $bill[$item['belong_id']]['chatid'] = $item['chatid'];
        }
        foreach($bill as $expendId => $income) {
            $data = ['category' => $category, 'remark' => ''];
            $orderid = IM::getInstance()->createBill($income['income_id'], $expendId, $income['amount'], $income['chatid'], $data);
        }
        //已经生成账单的状态更改
        foreach($detail as $item) {
            $this->getOne()->update('redpack_detail', [
                'confirm_timestamp' => TIMESTAMP,
                'status' => 3,
            ], [], ['id' => $item ['id']]);
        }
        $this->transaction_commit ();
        return $orderid;
    }
    public function cancel($data, $category)
    {
        $fee = [ ];
        $data ['status'] = 1;
        $Redpacks = IM::getInstance()->queryDetail ( $data );
        $this->transaction_start ();
        try{
            foreach ( $Redpacks as $param ) {
                IM::getInstance()->recall($param['income_id'], $param['belong_id'], $param['amount'], $param['origin']);
                $fee [$param ['recorder']] [] = $param ['amount'];
                $this->getOne()->update('redpack_detail', [
                    'confirm_timestamp' => TIMESTAMP,
                    'status' => 9,
                ], [], ['id' => $param ['id']]);
            }
            $this->transaction_commit ();
            array_walk ( $fee, function (&$value) {
                $value = [
                    'fee' => array_sum ( $value ),
                    'num' => count ( $value )
                ];
            } );
            return $fee;
        }catch(Exception $e){
            throw new Exception('退款失败', 3001);
        }
    }
    public function recevice($data) {

        if (isset ( $data ['receiver'] )) {
            $receiver = $data ['receiver'];
            unset ( $data ['receiver'] );
        } else {
            $receiver = null;
        }
        $fee = [ ];
        $data ['status'] = 1;
        $Redpacks = IM::getInstance()->queryDetail( $data );
        $this->transaction_start ();
        foreach ( $Redpacks as $param ) {
            if (! empty ( $receiver )) {
                if ($receiver != $param ['income_id']) {
                    throw new Exception ( '不是你的红包', 4321 );
                }
            }
            $this->getOne()->update('redpack_detail', [
                'confirm_timestamp' => TIMESTAMP,
                'status' => 2,
            ], [], ['id' => $param ['id']]);

            $fee [$param ['income_id']] [] = $param ['amount'];
        }
        $this->transaction_commit ();
        array_walk ( $fee, function (&$value) {
            $value = [ 
                'fee' => array_sum ( $value ),
                'num' => count ( $value ) 
            ];
        } );
        return empty ( $data ['uniqid'] ) ? $fee : [ 
            'fee' => array_pop ( $fee ) ['fee'] 
        ];
    }
    public function insert($data) {
        $this->transaction_start ();
        $expendid = $data['recorder'];
        $incomeid = $data['receiver'];
        $amount   = $data['amount'];
        $chatid   = $data['chatid'];
        $uniqid   = $data['uniqid'];
        $category = $data['category'];
        $isApple  = \App::getGlobal('device_platform') == 'ios' ? true : false;
        $redpackid = IM::getInstance()->imprest( $expendid, $incomeid, $amount, $chatid, $uniqid, $category, $isApple );
        $this->transaction_commit ();
        return $redpackid;
    }
}