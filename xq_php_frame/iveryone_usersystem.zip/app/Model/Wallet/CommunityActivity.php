<?php

namespace HttpApi\Model\Wallet;

class CommunityActivity extends WalletBase {

    protected $tableName = 'communityMission';

    /**
     * 生成记录
     *
     * @param String $uid 用户ID
     * @param integer $community_type 类型 0telegram 1wechat
     * @param String $community_usermark 第三方用户标识
     */
    public function create($uid, $community_type, $community_usermark, $ext = []) {
        $data = [ 
            'uid' => $uid,
            'community_type' => $community_type,
            'community_usermark' => $community_usermark,
            'ext' => json_encode($ext),
            'create_time' => TIMESTAMP
        ];
        $this->getOne()->insert($this->tableName, $data);
    }

    /**
     * 查询记录
     *
     * @param array $param 查询条件
     */
    public function query($param) {
        $res = $this->getOne()->selectOne($this->tableName, '*', $param )['data'];
        if(!empty($res)) {
            $res['ext'] = json_decode($res['ext'], true);
        }
        return $res;
    }

    public function queryAll($param) {
        $res = $this->getOne()->select($this->tableName, '*', $param )['data'];
        if(!empty($res)) {
            foreach ($res as $key => $item) {
                $res[$key]['ext'] = json_decode($item['ext'], true);
            }
        }
        return $res;
    }
}