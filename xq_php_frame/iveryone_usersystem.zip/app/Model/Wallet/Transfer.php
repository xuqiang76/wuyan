<?php

namespace HttpApi\Model\Wallet;

use Beahoo\Exception;

class Transfer extends WalletBase {
    
    /**
     * 转账
     *
     * 必须使用在事务中，如果不是使用在事务中，则会造成收支不平衡
     *
     * @param Array $data
     *            $data['from'] 发起转账的用户id
     *            $data['to'] 接受转账的用户id
     *            $data['amount'] 转账金额，不可为0，仅为正数，负数会自动转换成正数
     * @throws Exception
     */
    public function create($data) {
        if (Balance::getInstance ()->query ( [ 
            'uid' => $data ['from'] 
        ] ) ['transfer'] == 0) {
            throw new Exception ( '没有转账权限', 4030 );
        }
        $data ['amount'] = - abs ( $data ['amount'] );
        if ($data ['amount'] === 0) {
            throw new Exception ( '转账金额为0', 4031 );
        }
        Details::getInstance ()->confirm ( [ 
            'id' => Details::getInstance ()->create ( [ 
                'recorder' => $data ['from'],
                'receiver' => $data ['to'],
                'amount' => $data ['amount'],
                'category' => Details::Transfer,
                'uniqid' => uniqid ( 'transfer_' ) 
            ], true ) 
        ] );
    }
}