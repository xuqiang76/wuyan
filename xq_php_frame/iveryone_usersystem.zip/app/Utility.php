<?php

namespace HttpApi;

use Beahoo\Tool\Config;

class Utility {
	/**
	 * 渲染返回的异常，输出前端
	 * @param message
	 */
	public static function renderException($message) {
		ob_start();
		$return = array(
			'errno' => 400,
			'errmsg' => $message,
			'time' => time(),
		);
		echo json_encode($return);
		flush();
	}

	/**
	 * @desc   HTTP 错误状态输出
	 * @param  integer $code 错误状态
	 */
	public static function responseHttpError($code = 400) {
		//当前只返回400和500
		$codes = array(
			400 => 'Bad Request',
			500 => 'Internal Server Error',
		);

		if (isset($codes[$code])) {
			header('Access-Control-Allow-Origin: *');
			header("HTTP/1.1 {$code} {$codes[$code]}");
			exit;
		}

		echo $code, "\n";
		exit(1);
	}

	public static function getIP() //取IP函数
	{
		global $_SERVER;
		if (getenv('HTTP_CLIENT_IP')) {
			$ip = getenv('HTTP_CLIENT_IP');
		} else if (getenv('HTTP_X_FORWARDED_FOR')) {
			$ip = getenv('HTTP_X_FORWARDED_FOR');
		} else if (getenv('REMOTE_ADDR')) {
			$ip = getenv('REMOTE_ADDR');
		} else {
			$ip = $_SERVER['REMOTE_ADDR'];
		}
		return $ip;
	}

	public static function renderH5Error($msg) {
		header("Location: " . Config::read('appwv_url') . "Error?msg=" . urlencode($msg));
		exit;
	}
}