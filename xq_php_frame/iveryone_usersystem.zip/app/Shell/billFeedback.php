<?php
/**
 * Created by PhpStorm.
 * User: zhangyuanhao
 * Date: 2018/6/14
 * Time: 20:01
 *
 * sudo php -f app/Shell/billFeedback.php local 0 100
 */
// 设置时间
set_time_limit(0);

// 设置环境变量
$_SERVER['env'] = isset($argv[1]) && $argv[1] ? $argv[1] : 'production';
$_SERVER["SERVER_NAME"] = 'localhost';

require_once __DIR__ . '/../autoload.php';

use HttpApi\Model\WalletNew\Bill as W_Bill;
use HttpApi\Model\ReadOnly\Bill as R_Bill;
use HttpApi\Model\ReadOnly\Threads;
use HttpApi\Model\ReadOnly\Feedback;
use HttpApi\Tool\Format;

if(isset($argv[2])) {
    $startId = $argv[2];
} else {
    $startId = 0;
}

if(isset($argv[3])) {
    $limit = $argv[3];
} else {
    $limit = 100;
}

$countWhereFeild = [
    'scene_category' =>  [
        '$in' => [
            24,28,29
        ]
    ],
    'id' =>  [
        '$gt' => $startId
    ]
];

$one = R_Bill::getInstance()->getOne();

$countData = $one->select('bill', 'count(id) as countNums', $countWhereFeild, 'order by id asc');

$count = $countData['rownum'] ? $countData['data'][0]['countNums'] : 0;

echo "一共".$count."条数据\n";

// 获取需要取多少次
$forNums = ceil($count/$limit);

echo "需要循环执行".$forNums."次,每次".$limit."条，开始时间为".date('Y-m-d H:i:s')."\n";

// 已处理条数
$handleNums = 0;

// 死循环处理
$while = 0;

// 写数据库实例
$w_billOne = W_Bill::getInstance()->getOne();

while(true) {
    $countWhereFeild['id']['$gt'] = $startId;

    // 先获取需要处理的账单列表
    $billDetail = $one->select('bill', 'id, uniqid, title', $countWhereFeild, 'order by id asc', 0, $limit);
    if($billDetail['rownum'] <= 0) {
        exit;
    }

    // 将举报列表的举报ID拿出来
    $tmpBillDetail = [];
    foreach ($billDetail['data'] as $key => $item) {
        $tmpBillDetail[$item['id']]['uniqid'] = intval($item['uniqid']);
        $startId = $item['id'];
    }
    $feedbackList = Feedback::getInstance()->getOne()->select('feedback', 'id, tid', [
        'id' =>  [
            '$in' => array_unique(array_column($tmpBillDetail, 'uniqid'))
        ]
    ], 'order by id asc');

    if(!$feedbackList['rownum']) {
        continue;
    }
    $feedbackList = Format::arrayChangeKey($feedbackList['data'], 'id');

    foreach ($tmpBillDetail as $key => $item) {
        if(isset($feedbackList[$item['uniqid']])) {
            $tmpBillDetail[$key]['tid'] = $feedbackList[$item['uniqid']]['tid'];
        } else {
            $tmpBillDetail[$key]['tid'] = 0;
        }
    }

    // 获取文章
    $threadsList = Threads::getInstance()->getOne()->select('threads', 'id, title', [
        'id' =>  [
            '$in' => array_unique(array_column($tmpBillDetail, 'tid'))
        ]
    ], 'order by id asc');
    if(!$threadsList['rownum']) {
        continue;
    }
    $threadsList = Format::arrayChangeKey($threadsList['data'], 'id');

    foreach ($billDetail['data'] as $k => $v) {
        $threadsId = $tmpBillDetail[$v['id']]['tid'];
        if(!isset($threadsList[$threadsId]) || !$threadsId)
            continue;
        $saveData = [
            'title' => $v['title'] . ' - ' . $threadsList[$threadsId]['title']
        ];
        // 保存账单
        $w_billOne->update('bill', $saveData, [], [
            'id' => $v['id']
        ]);
    }
    $handleNums += $billDetail['rownum'];
    echo "第" . ++$while . "次，执行了".$billDetail['rownum']."条数据\n";
}