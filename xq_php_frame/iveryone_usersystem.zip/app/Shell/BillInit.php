<?php
/**
 * Created by PhpStorm.
 * User: zhangyuanhao
 * Date: 2018/6/14
 * Time: 20:01
 *
 * sudo php -f app/Shell/BillInit.php local 0 100 >> /download/logs/iveryone_usersystem/billData.log
 */

// 设置时间
set_time_limit(0);

// 设置环境变量
$_SERVER['env'] = isset($argv[1]) && $argv[1] ? $argv[1] : 'production';

$_SERVER["SERVER_NAME"] = 'localhost';

require_once __DIR__ . '/../autoload.php';

use HttpApi\Model\ReadOnly\WalletDetails;
use HttpApi\Model\WalletNew\Bill;
use HttpApi\Model\WalletNew\BillDetail;

if(isset($argv[2])) {
    $startId = $argv[2];
} else {
    $startId = 0;
}

if(isset($argv[3])) {
    $limit = $argv[3];
} else {
    $limit = 100;
}

$categorys = [
    1 => [
        'title' => '注册iVeryOne',
        'detail' => false
    ],
    2 => [
        'title' => '邀请激励',
        'detail' => false
    ],
    3 => [
        'title' => '关注',
        'detail' => false
    ],
    4 => [
        'title' => '关注公众号',
        'detail' => false
    ],
    5 => [
        'title' => '关注电邮',
        'detail' => false
    ],
    6 => [
        'title' => [
            '内容售出',
            '购买付费'
        ],
        'detail' => true
    ],
    7 => [
        'title' => [
            '转发分成',
            '售出分成'
        ],
        'detail' => true
    ],
    8 => [
        'title' => '手续费',
        'detail' => false
    ],
    9 => [
        'title' => '投放广告',
        'detail' => false
    ],
    10 => [
        'title' => '查看广告',
        'detail' => false
    ],
    11 => [
        'title' => '消费补贴发放',
        'detail' => false
    ],
    12 => [
        'title' => '语音通话',
        'detail' => true
    ],
    13 => [
        'title' => '聊天',
        'detail' => true
    ],
    14 => [
        'title' => '视频通话',
        'detail' => true
    ],
    15 => [
        'title' => '中止投放广告',
        'detail' => false
    ],
    16 => [
        'title' => '活动奖励',
        'detail' => false
    ],
    17 => [
        'title' => '预约游戏',
        'detail' => false
    ],
    18 => [
        'title' => '游戏推广分成',
        'detail' => false
    ],
    19 => [
        'title' => '游戏消费',
        'detail' => false
    ],
    20 => [
        'title' => '游戏推广分成',
        'detail' => false
    ],
    21 => [
        'title' => '清空补贴',
        'detail' => false
    ],
    22 => [
        'title' => '转账',
        'detail' => true
    ],
    23 => [
        'title' => '文章打赏',
        'detail' => true
    ],
    24 => [
        'title' => '举报',
        'detail' => true
    ],
    25 => [
        'title' => '申诉',
        'detail' => true
    ],
    26 => [
        'title' => '人脸认证奖励',
        'detail' => true
    ],
    27 => [
        'title' => '审核工资',
        'detail' => false
    ],
    28 => [
        'title' => '举报失败',
        'detail' => true
    ],
    29 => [
        'title' => '举报奖励',
        'detail' => true
    ],
    30 => [
        'title' => '购买道具',
        'detail' => true
    ],
    31 => [
        'title' => '道具销售分成',
        'detail' => true
    ],
    32 => [
        'title' => '道具游戏厂商分成',
        'detail' => true
    ],
    1009 => [
        'title' => '投放广告',
        'detail' => false
    ]
];

$activity = [
    1 => 'bug、建议提交',
    2 => '母亲节活动奖励',
    3 => '群管奖励',
    4 => '星球提建议奖励',
    5 => '内容发布规则变更补贴'
];
$auditor = [
    1 => '举报',
    2 => '申诉'
];

$countWhereFeild = [
    'id' =>  [
        '$gt' => $startId
    ]
];

$one = WalletDetails::getInstance()->getOne();

$countData = $one->select('wallet_details', 'count(id) as countNums', $countWhereFeild, 'order by id asc');

$count = $countData['rownum'] ? $countData['data'][0]['countNums'] : 0;

echo "一共".$count."条数据\n";

// 获取需要取多少次
$forNums = ceil($count/$limit);

echo "需要循环执行".$forNums."次,每次".$limit."条，开始时间为".date('Y-m-d H:i:s')."\n";

// 已处理条数
$handleNums = 0;

// 死循环处理
$while = 0;

while (true) {
    $countWhereFeild['id']['$gt'] = $startId;

    $walletDetailList = $one->select('wallet_details', '*', $countWhereFeild, 'order by id asc', 0, $limit);

    if(0 < $walletDetailList['rownum']) {
        $billAllData = [];
        $billDetailAllData = [];

        foreach ($walletDetailList['data'] as $v) {
            if($v['recorder'] == ''
                || $v['recorder'] == 0
                || $v['receiver'] == ''
                || $v['receiver'] == 'system_token'
                || $v['receiver'] == 'system_balance'
                || $v['amount'] == ''
                || $v['amount'] == 0
            ) {
                continue;
            }

            // 先生成账单
            $billData = [
                'id' => $v['id'],
                'bill_type' => $v['receiver'] == 0 || $v['receiver'] == 'system' ? 1 : 2, // 是否系统交易
                'trading_type' => 2, // 转账
                'direction_type' => $v['direction'] == 'income' ? 1 : 2, // 收入
                'belong_role' => 1, // 所属角色是用户
                'belong_id' => $v['recorder'],
                'amount'   => $v['amount'] < 0 ? $v['amount'] * -1 : $v['amount'],
                'create_timestamp' => $v['create_timestamp'],
                'finish_timestamp' => $v['create_timestamp'],
            ];
            if($v['direction'] == 'income') {
                $billData['income_id'] = $v['recorder'];
                $billData['income_role'] = 1;
            } else {
                if($v['receiver'] == 0 || $v['receiver'] == 'system') {
                    $billData['income_id'] = 0;
                    $billData['income_role'] = 2;
                } else {
                    $billData['income_id'] = $v['receiver'];
                    $billData['income_role'] = 1;
                }
            }

            if($v['direction'] == 'outlay') {
                $billData['expend_id'] = $v['recorder'];
                $billData['expend_role'] = 1;
            } else {
                if($v['receiver'] == 0 || $v['receiver'] == 'system') {
                    $billData['expend_id'] = 0;
                    $billData['expend_role'] = 2;
                } else {
                    $billData['expend_id'] = $v['receiver'];
                    $billData['expend_role'] = 1;
                }
            }

            $ortherData = [
                'uniqid' => $v['uniqid'], // 第三方ID
                'remark'  => $v['remark'], // 备注（可为空）
//                    'scene_category_value'  => $v['category'], // 业务场景
                'scene_category'  => $v['category'], // 业务场景
                'status' => 2 // 交易完成
            ];

            // 处理标题
            if($v['category'] == 16) {
                $ortherData['title'] = $categorys [$v ['category']] ['title'] . ' - ' . $activity [intval ( $v ['uniqid'] )];
            } else if($v['category'] == 27) {
                $ortherData['title'] = $categorys [$v ['category']] ['title'] . ' - ' . $auditor [intval ( $v ['uniqid'] )];
            } else {
                $ortherData['title'] = is_array ( $categorys [$v ['category']] ['title'] ) ? $categorys [$v ['category']] ['title'] [intval ( $v ['amount'] < 0 )] : $categorys [$v ['category']] ['title'];
            }

//                Bill::getInstance()->create($billData, $ortherData);

            // 再生成明细
//                BillDetail::getInstance()->create($v['id'], [
//                    [
//                        'belong_role' => 1, // 所属角色是用户
//                        'belong_id' => $v['recorder'],
//                        'currency_type' => 'vry',
//                        'amount' => $v['amount'] < 0 ? $v['amount'] * -1 : $v['amount'],
//                        'origin' => 'general',
//                        'create_timestamp' => $v['create_timestamp'],
//                        'direction_type' => $v['direction'] == 'income' ? 1 : 2 // 收入
//                    ]
//                ]);

            $billAllData[] = array_merge($billData, $ortherData);

            $billDetailAllData[] = [
                    'id'      => $v['id'],
                    'bill_id' => $v['id'],
                    'belong_role' => 1, // 所属角色是用户
                    'belong_id' => $v['recorder'],
                    'currency_type' => 3,
                    'amount' => $v['amount'] < 0 ? $v['amount'] * -1 : $v['amount'],
                    'origin' => 1,
                    'create_timestamp' => $v['create_timestamp'],
                    'direction_type' => $v['direction'] == 'income' ? 1 : 2 // 收入
            ];

            $startId = $v['id'];
        }

        Bill::getInstance()->transaction_start ();
        try {

            Bill::getInstance()->getOne()->batchInsert('bill', $billAllData);
            BillDetail::getInstance()->getOne()->batchInsert('bill_detail', $billDetailAllData);

            Bill::getInstance()->transaction_commit ();
        } catch (Exception $e) {
            Bill::getInstance()->transaction_rollback ();
            throw new Exception($e->getMessage(), $e->getCode());
        }
        $handleNums += $walletDetailList['rownum'];
        echo "第" . ++$while . "次，执行了".$walletDetailList['rownum']."条数据\n";
    } else {
        exit;
    }
}