<?php
/**
 * Created by PhpStorm.
 * User: zhangyuanhao
 * Date: 2018/6/14
 * Time: 20:01
 *
 * sudo php -f app/Shell/billTransfer.php local 0 100
 */
// 设置时间
set_time_limit(0);

// 设置环境变量
$_SERVER['env'] = isset($argv[1]) && $argv[1] ? $argv[1] : 'production';
$_SERVER["SERVER_NAME"] = 'localhost';

require_once __DIR__ . '/../autoload.php';

use HttpApi\Model\WalletNew\Bill as W_Bill;
use HttpApi\Model\ReadOnly\Bill as R_Bill;
use HttpApi\Model\ReadOnly\UserInfo;
use HttpApi\Tool\Format;

if(isset($argv[2])) {
    $startId = $argv[2];
} else {
    $startId = 0;
}

if(isset($argv[3])) {
    $limit = $argv[3];
} else {
    $limit = 100;
}

$countWhereFeild = [
    'scene_category' =>  [
        '$in' => [
            22,12,13,14
        ]
    ],
    'id' =>  [
        '$gt' => $startId
    ]
];

$one = R_Bill::getInstance()->getOne();

$countData = $one->select('bill', 'count(id) as countNums', $countWhereFeild, 'order by id asc');

$count = $countData['rownum'] ? $countData['data'][0]['countNums'] : 0;

echo "一共".$count."条数据\n";

// 获取需要取多少次
$forNums = ceil($count/$limit);

echo "需要循环执行".$forNums."次,每次".$limit."条，开始时间为".date('Y-m-d H:i:s')."\n";

// 已处理条数
$handleNums = 0;

// 死循环处理
$while = 0;

// 写数据库实例
$w_billOne = W_Bill::getInstance()->getOne();

while(true) {
    $countWhereFeild['id']['$gt'] = $startId;

    // 先获取需要处理的账单列表
    $billDetail = $one->select('bill', 'id, income_id, expend_id, title, scene_category, direction_type', $countWhereFeild, 'order by id asc', 0, $limit);
    if($billDetail['rownum'] <= 0) {
        exit;
    }

    // 将用户的ID拿出来
    $tmpBillDetail = [];
    foreach ($billDetail['data'] as $key => $item) {
        $tmpBillDetail[$item['id']]['income_id'] = intval($item['income_id']);
        $tmpBillDetail[$item['id']]['expend_id'] = intval($item['expend_id']);
        $startId = $item['id'];
    }

    $userIds = array_merge(array_column($tmpBillDetail, 'income_id'), array_column($tmpBillDetail, 'expend_id'));

    $userInfo = UserInfo::getInstance()->getOne()->select('userinfo', 'id, nickname', [
        'id' =>  [
            '$in' => array_unique($userIds)
        ]
    ]);

    if(!$userInfo['rownum']) {
        continue;
    }
    $userInfo = Format::arrayChangeKey($userInfo['data'], 'id');

    foreach ($tmpBillDetail as $key => $item) {
        if(isset($userInfo[$item['income_id']])) {
            $tmpBillDetail[$key]['income_nickname'] = $userInfo[$item['income_id']]['nickname'];
        } else {
            $tmpBillDetail[$key]['income_nickname'] = '';
        }

        if(isset($userInfo[$item['expend_id']])) {
            $tmpBillDetail[$key]['expend_nickname'] = $userInfo[$item['expend_id']]['nickname'];
        } else {
            $tmpBillDetail[$key]['expend_nickname'] = '';
        }
    }

    foreach ($billDetail['data'] as $k => $v) {
        if ($v ['scene_category'] == 22) {
            if($v['direction_type'] == 1) {
                $saveData = [
                    'title' => $v['title'] . ' - ID:' .$v['expend_id'] . ' - ' . $tmpBillDetail[$v['id']]['expend_nickname']
                ];
            } else {
                $saveData = [
                    'title' => $v['title'] . ' - ID:' .$v['income_id'] . ' - ' . $tmpBillDetail[$v['id']]['income_nickname']
                ];
            }
        } else {
            if($v['direction_type'] == 1) {
                $saveData = [
                    'title' => $v['title'] . ' - ' . $tmpBillDetail[$v['id']]['expend_nickname']
                ];
            } else {
                $saveData = [
                    'title' => $v['title'] . ' - ' . $tmpBillDetail[$v['id']]['income_nickname']
                ];
            }
        }

        // 保存账单
        $w_billOne->update('bill', $saveData, [], [
            'id' => $v['id']
        ]);
    }
    $handleNums += $billDetail['rownum'];
    echo "第" . ++$while . "次，执行了".$billDetail['rownum']."条数据\n";
}