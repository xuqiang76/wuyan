<?php
/**
 * Created by PhpStorm.
 * User: zhangyuanhao
 * Date: 2018/6/14
 * Time: 20:01
 *
 * sudo php -f app/Shell/NewWalletUserInit.php local 4 100
 */


// 设置时间
set_time_limit(0);

// 设置环境变量
$_SERVER['env'] = isset($argv[1]) && $argv[1] ? $argv[1] : 'production';
$_SERVER["SERVER_NAME"] = 'localhost';

require_once __DIR__ . '/../autoload.php';

use HttpApi\Model\Wallet\Wallet;
use HttpApi\Model\WalletNew\WalletNew;

if(isset($argv[2])) {
    $startId = $argv[2];
} else {
    $startId = 0;
}

if(isset($argv[3])) {
    $limit = $argv[3];
} else {
    $limit = 100;
}

$countWhereFeild = [
    'id' =>  [
        '$gt' => $startId
    ]
];

$one = Wallet::getInstance()->getOne();

$countData = $one->select('wallet', 'count(id) as countNums', $countWhereFeild, 'order by id asc');

$count = $countData['rownum'] ? $countData['data'][0]['countNums'] : 0;

echo "一共".$count."条数据\n";

// 获取需要取多少次
$forNums = ceil($count/$limit);

echo "需要循环执行".$forNums."次,每次".$limit."条，开始时间为".date('Y-m-d H:i:s')."\n";

// 已处理条数
$handleNums = 0;

// 死循环处理
$while = 0;
while (true) {
    $countWhereFeild['id']['$gt'] = $startId;

    $walletList = $one->select('wallet', '*', $countWhereFeild, 'order by id asc', 0, $limit);

    if(0 < $walletList['rownum']) {
        foreach ($walletList['data'] as $v) {
            WalletNew::getInstance()->create(['uid' => $v['uid']]);
            $startId = $v['id'];
        }
        $handleNums += $walletList['rownum'];
        echo "第" . ++$while . "次，执行了".$walletList['rownum']."条数据\n";
    } else {
        exit;
    }
}