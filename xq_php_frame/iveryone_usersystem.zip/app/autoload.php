<?php

define('ROOT', dirname(__DIR__));
define('DS', DIRECTORY_SEPARATOR);

define('TIMESTAMP', time());
define('TIMENOW', date("Y-m-d H:i:s"));
define('MICROTIME', microtime(true));
define('LOGS_DIR', '/download/logs/iveryone_usersystem/');
define('LOGS_PREFIX', 'iveryone_usersystem_');

define('NEW_INVITE_TIMESTAMP', 1524326400);

ini_set('date.timezone', 'Asia/Shanghai');
ini_set('log_errors', 'On');
ini_set('error_log', LOGS_DIR . LOGS_PREFIX . 'php_error.log');

require_once '/download/WuyanLibs/frameworks/Beahoo/Autoloader.php';

require_once ROOT . DS . 'vendor/autoload.php';

$autoloader = new Beahoo\Autoloader;
$autoloader->addNamespace('HttpApi', ROOT . DS . 'app');
$autoloader->addNamespace('bigcatorm', ROOT . DS . 'libs' . DS . 'bigcatorm');
$autoloader->register();

if (PHP_SAPI == 'cli') {

	$request = new Beahoo\Controller\Request\ShellRequest;
	$response = new Beahoo\Controller\Response\ShellResponse;

	$baseURL = 'http';
	if (!empty($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] == "on") {
		$baseURL .= "s";
	}
	$baseURL .= "://" . $_SERVER["SERVER_NAME"] . "/";

	define("BASE_URL", $baseURL);

} else {
	$request = new Beahoo\Controller\Request\HttpRequest;
	$response = new HttpApi\Controller\Response\HttpResponse;

	$request->setQueryArgs($_GET);
	$request->setFormArgs($_POST);
	$request->setCookieArgs($_COOKIE);
	$request->setFileArgs($_FILES);

	$baseURL = 'http';
	if (!empty($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] == "on") {
		$baseURL .= "s";
	}
	$baseURL .= "://" . $_SERVER["SERVER_NAME"] . "/";
	define("BASE_URL", $baseURL);
}

$request->setServerArgs($_SERVER);

$i18n = new i18n(ROOT . '/lang/lang_{LANGUAGE}.ini', LOGS_DIR, 'zh_cn');
$i18n->init();

define('RUN_ENV', $request->getServerArg('env', 'production'));

if (RUN_ENV == 'development') {
	ini_set("display_errors", 1);
	error_reporting(E_ALL ^ E_WARNING ^ E_STRICT);
} elseif (RUN_ENV == 'test') {
	ini_set("display_errors", 1);
	error_reporting(E_ALL ^ E_WARNING ^ E_STRICT);
} else {
	ini_set("display_errors", 0);
	error_reporting(E_ALL ^ E_WARNING ^ E_STRICT);
}

$file = ROOT . DS . 'config' . DS . RUN_ENV . '.php';

Beahoo\Tool\Config::load(call_user_func(function () use ($file) {
	return is_readable($file) ? (include $file) : array();
}));

\App::setRequest($request);

class App {
	/**
	 * @var Beahoo\Controller\Request\HttpRequest
	 */
	public static $request;

	public static $globals;

	public static function setRequest($request) {
		self::$request = $request;
	}

	public static function getRequest() {
		return self::$request;
	}

	public static function setGlobal($key, $item) {
		self::$globals[$key] = $item;
	}

	public static function getGlobal($key) {
		return self::$globals[$key];
	}
}
