<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class FeedAds extends BaseObject {
    const TABLE_NAME = 'feed_ads';

    public $id; //
    public $uid = 0; //
    public $feedid = 0; //
    public $adid = 0; //
    public $content; //

    public $description = ''; //

    public function getUpdateSql() {
        return [
            "update `feed_ads` SET
            `uid`=?
            , `feedid`=?
            , `adid`=?
            , `content`=?

            , `description`=?

            where `id`=?"

            , [
                intval($this->uid)
                , intval($this->feedid)
                , intval($this->adid)
                , $this->content

                , $this->description

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `feed_ads` SET

            `uid`=?
            , `feedid`=?
            , `adid`=?
            , `content`=?

            , `description`=?
            "

            , [
                intval($this->uid)
                , intval($this->feedid)
                , intval($this->adid)
                , $this->content

                , $this->description
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `feed_ads`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

