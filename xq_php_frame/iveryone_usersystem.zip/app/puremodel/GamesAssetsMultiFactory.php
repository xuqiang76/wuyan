<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseFunction;
use bigcatorm\MutiStoreFactory;

class GamesAssetsMultiFactory extends MutiStoreFactory {
    public $key = 'usersystem_games_assets_multi_';
    private $sql;
    private $bind;

    public function __construct($cache_obj, $key_objfactory = null, $assetid = null, $key_add = '', $timeout = 86400) {
        if (!$key_objfactory && !$assetid) {
            return false;
        }
        $this->key = $this->key . $key_add;
        $ids = '';
        if ($key_objfactory) {
            if ($key_objfactory->initialize()) {
                $key_obj = $key_objfactory->get();
                $ids = implode(',', array_fill(0, count($key_obj), '?'));
            }
        }
        $fields = "
            `appid`
            , `assetid`
            , `title`
            , `description`
            , `icon`

            , `image`
            ";

        if ($assetid != null) {
            $this->bInitMuti = false;
            $this->sql = "select $fields from games_assets where `assetid`=?";
            $this->bind = [$assetid];
        } else {
            $this->sql = "select $fields from games_assets ";
            if ($ids) {
                $this->sql = $this->sql . " where `assetid` in ($ids) ";
            }
            $this->bind = $key_obj;
        }
        parent::__construct($cache_obj, $this->key, $this->key, $key_objfactory, $assetid, $timeout);
        return true;
    }

    public function retrive() {
        $res_query = BaseFunction::query_sql_backend($this->sql, $this->bind);
        if (!$res_query) {
            return null;
        }

        $objs = array();
        $result = $res_query['sth']->fetchAll(\PDO::FETCH_CLASS, "HttpApi\puremodel\GamesAssets");
        foreach ($result as $val) {
            $val->before_writeback();
            $objs[$this->key . '_' . $val->assetid] = $val;
        }
        return $objs;

    }
}

