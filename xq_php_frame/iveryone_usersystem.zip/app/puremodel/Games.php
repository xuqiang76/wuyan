<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class Games extends BaseObject {
    const TABLE_NAME = 'games';

    public $id; //
    public $cpid = 0; //
    public $name = ''; //
    public $description; //
    public $icon = ''; //

    public $thumbs; //
    public $timestamp = 0; //
    public $price = 0; //
    public $booking = 0; //
    public $status = 0; //

    public $package = ''; //
    public $private_key; //私钥
    public $public_key; //公钥

    public function getUpdateSql() {
        return [
            "update `games` SET
            `cpid`=?
            , `name`=?
            , `description`=?
            , `icon`=?

            , `thumbs`=?
            , `timestamp`=?
            , `price`=?
            , `booking`=?
            , `status`=?

            , `package`=?
            , `private_key`=?
            , `public_key`=?

            where `id`=?"

            , [
                intval($this->cpid)
                , $this->name
                , $this->description
                , $this->icon

                , $this->thumbs
                , intval($this->timestamp)
                , intval($this->price)
                , intval($this->booking)
                , intval($this->status)

                , $this->package
                , $this->private_key
                , $this->public_key

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `games` SET

            `cpid`=?
            , `name`=?
            , `description`=?
            , `icon`=?

            , `thumbs`=?
            , `timestamp`=?
            , `price`=?
            , `booking`=?
            , `status`=?

            , `package`=?
            , `private_key`=?
            , `public_key`=?
            "

            , [
                intval($this->cpid)
                , $this->name
                , $this->description
                , $this->icon

                , $this->thumbs
                , intval($this->timestamp)
                , intval($this->price)
                , intval($this->booking)
                , intval($this->status)

                , $this->package
                , $this->private_key
                , $this->public_key
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `games`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

