<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class FeedNewcontactfailed extends BaseObject {
    const TABLE_NAME = 'feed_newcontactfailed';

    public $id; //
    public $uid = 0; //
    public $contact_uid = 0; //
    public $lastid = 0; //
    public $failed_timestamp = 0; //

    public $failed_times = 0; //

    public function getUpdateSql() {
        return [
            "update `feed_newcontactfailed` SET
            `uid`=?
            , `contact_uid`=?
            , `lastid`=?
            , `failed_timestamp`=?

            , `failed_times`=?

            where `id`=?"

            , [
                intval($this->uid)
                , intval($this->contact_uid)
                , intval($this->lastid)
                , intval($this->failed_timestamp)

                , intval($this->failed_times)

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `feed_newcontactfailed` SET

            `id`=?
            , `uid`=?
            , `contact_uid`=?
            , `lastid`=?
            , `failed_timestamp`=?

            , `failed_times`=?
            "

            , [
                intval($this->id)
                , intval($this->uid)
                , intval($this->contact_uid)
                , intval($this->lastid)
                , intval($this->failed_timestamp)

                , intval($this->failed_times)
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `feed_newcontactfailed`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

