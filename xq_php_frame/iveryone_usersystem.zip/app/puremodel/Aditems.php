<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class Aditems extends BaseObject {
    const TABLE_NAME = 'aditems';

    public $id; //
    public $advertisers = ''; //广告商
    public $fee = 0; //
    public $start_timestamp = 0; //
    public $end_timestamp = 0; //

    public $status = 0; //
    public $placement = ''; //
    public $placement_timestamp = 0; //
    public $plan = 0; //
    public $adwords = 0; //

    public function getUpdateSql() {
        return [
            "update `aditems` SET
            `advertisers`=?
            , `fee`=?
            , `start_timestamp`=?
            , `end_timestamp`=?

            , `status`=?
            , `placement`=?
            , `placement_timestamp`=?
            , `plan`=?
            , `adwords`=?

            where `id`=?"

            , [
                $this->advertisers
                , intval($this->fee)
                , intval($this->start_timestamp)
                , intval($this->end_timestamp)

                , intval($this->status)
                , $this->placement
                , intval($this->placement_timestamp)
                , intval($this->plan)
                , intval($this->adwords)

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `aditems` SET

            `advertisers`=?
            , `fee`=?
            , `start_timestamp`=?
            , `end_timestamp`=?

            , `status`=?
            , `placement`=?
            , `placement_timestamp`=?
            , `plan`=?
            , `adwords`=?
            "

            , [
                $this->advertisers
                , intval($this->fee)
                , intval($this->start_timestamp)
                , intval($this->end_timestamp)

                , intval($this->status)
                , $this->placement
                , intval($this->placement_timestamp)
                , intval($this->plan)
                , intval($this->adwords)
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `aditems`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

