<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class GamesAssets extends BaseObject {
    const TABLE_NAME = 'games_assets';

    public $appid; //应用id
    public $assetid; //应用物料id，每个应用的物料id应该在该应用内唯一
    public $title = ''; //物料名称
    public $description; //物料描述
    public $icon = ''; //物料图标

    public $image; //物料各个尺寸的宣传页

    public function getUpdateSql() {
        return [
            "update `games_assets` SET
            `title`=?
            , `description`=?
            , `icon`=?

            , `image`=?

            where `assetid`=?"

            , [
                $this->title
                , $this->description
                , $this->icon

                , $this->image

                , $this->assetid
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `games_assets` SET

            `appid`=?
            , `assetid`=?
            , `title`=?
            , `description`=?
            , `icon`=?

            , `image`=?
            "

            , [
                intval($this->appid)
                , $this->assetid
                , $this->title
                , $this->description
                , $this->icon

                , $this->image
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `games_assets`
            where `assetid`=?"

            , [
                $this->assetid
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

