<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class GamesTransfer extends BaseObject {
    const TABLE_NAME = 'games_transfer';

    public $id; //
    public $uid = 0; //用户id
    public $appid = 0; //应用ID
    public $assetid = 0; //物料ID
    public $price = 0; //商品价格

    public $planid = 0; //合约ID
    public $direction = 0; //
    public $specification; //属性
    public $transcode = ''; //
    public $sales_time = 0; //上架时间

    public $create_time = 0; //创建时间
    public $status = 0; //状态 stock:0库存，sold:1售出，sales:2在售

    public function getUpdateSql() {
        return [
            "update `games_transfer` SET
            `uid`=?
            , `appid`=?
            , `assetid`=?
            , `price`=?

            , `planid`=?
            , `direction`=?
            , `specification`=?
            , `transcode`=?
            , `sales_time`=?

            , `create_time`=?
            , `status`=?

            where `id`=?"

            , [
                intval($this->uid)
                , intval($this->appid)
                , intval($this->assetid)
                , intval($this->price)

                , intval($this->planid)
                , intval($this->direction)
                , $this->specification
                , $this->transcode
                , intval($this->sales_time)

                , intval($this->create_time)
                , intval($this->status)

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `games_transfer` SET

            `uid`=?
            , `appid`=?
            , `assetid`=?
            , `price`=?

            , `planid`=?
            , `direction`=?
            , `specification`=?
            , `transcode`=?
            , `sales_time`=?

            , `create_time`=?
            , `status`=?
            "

            , [
                intval($this->uid)
                , intval($this->appid)
                , intval($this->assetid)
                , intval($this->price)

                , intval($this->planid)
                , intval($this->direction)
                , $this->specification
                , $this->transcode
                , intval($this->sales_time)

                , intval($this->create_time)
                , intval($this->status)
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `games_transfer`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

