<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class AdStrategy extends BaseObject {
    const TABLE_NAME = 'ad_strategy';

    public $id; //
    public $uid = ''; //广告商uid
    public $title = ''; //名称
    public $description = ''; //描述
    public $type = ''; //广告类型 feed动态广告 / follow关注广告 /等

    public $price = 0; //广告单价
    public $number = 0; //广告总数
    public $strategy = ''; //广告策略结构体
    public $init_time = 0; //结束时间
    public $update_time = 0; //更新时间

    public function getUpdateSql() {
        return [
            "update `ad_strategy` SET
            `uid`=?
            , `title`=?
            , `description`=?
            , `type`=?

            , `price`=?
            , `number`=?
            , `strategy`=?
            , `init_time`=?
            , `update_time`=?

            where `id`=?"

            , [
                $this->uid
                , $this->title
                , $this->description
                , $this->type

                , intval($this->price)
                , intval($this->number)
                , $this->strategy
                , intval($this->init_time)
                , intval($this->update_time)

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `ad_strategy` SET

            `uid`=?
            , `title`=?
            , `description`=?
            , `type`=?

            , `price`=?
            , `number`=?
            , `strategy`=?
            , `init_time`=?
            , `update_time`=?
            "

            , [
                $this->uid
                , $this->title
                , $this->description
                , $this->type

                , intval($this->price)
                , intval($this->number)
                , $this->strategy
                , intval($this->init_time)
                , intval($this->update_time)
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `ad_strategy`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

