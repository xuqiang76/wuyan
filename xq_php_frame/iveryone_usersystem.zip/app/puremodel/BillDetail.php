<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class BillDetail extends BaseObject {
    const TABLE_NAME = 'bill_detail';

    public $id; //
    public $bill_id = 0; //账单ID
    public $belong_role = 0; //所属人角色
    public $belong_id = 0; //所属人ID
    public $direction_type = 0; //收支类型（1收入、2支出）

    public $currency_type = 0; //货币类型（1 V点  2 V卷  3 VRY）
    public $amount = 0; //金额
    public $origin = 0; //来源 （1 通用 2苹果 3非苹果）
    public $create_timestamp = 0; //创建时间

    public function getUpdateSql() {
        return [
            "update `bill_detail` SET
            `bill_id`=?
            , `belong_role`=?
            , `belong_id`=?
            , `direction_type`=?

            , `currency_type`=?
            , `amount`=?
            , `origin`=?
            , `create_timestamp`=?

            where `id`=?"

            , [
                intval($this->bill_id)
                , intval($this->belong_role)
                , intval($this->belong_id)
                , intval($this->direction_type)

                , intval($this->currency_type)
                , intval($this->amount)
                , intval($this->origin)
                , intval($this->create_timestamp)

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `bill_detail` SET

            `bill_id`=?
            , `belong_role`=?
            , `belong_id`=?
            , `direction_type`=?

            , `currency_type`=?
            , `amount`=?
            , `origin`=?
            , `create_timestamp`=?
            "

            , [
                intval($this->bill_id)
                , intval($this->belong_role)
                , intval($this->belong_id)
                , intval($this->direction_type)

                , intval($this->currency_type)
                , intval($this->amount)
                , intval($this->origin)
                , intval($this->create_timestamp)
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `bill_detail`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

