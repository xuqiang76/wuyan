<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseFunction;
use bigcatorm\MutiStoreFactory;

class ApprovalsMultiFactory extends MutiStoreFactory {
    public $key = 'usersystem_approvals_multi_';
    private $sql;
    private $bind;

    public function __construct($cache_obj, $key_objfactory = null, $uid = null, $key_add = '', $timeout = 86400) {
        if (!$key_objfactory && !$uid) {
            return false;
        }
        $this->key = $this->key . $key_add;
        $ids = '';
        if ($key_objfactory) {
            if ($key_objfactory->initialize()) {
                $key_obj = $key_objfactory->get();
                $ids = implode(',', array_fill(0, count($key_obj), '?'));
            }
        }
        $fields = "
            `id`
            , `tid`
            , `uid`
            , `sid`
            , `timestamp`
            ";

        if ($uid != null) {
            $this->bInitMuti = false;
            $this->sql = "select $fields from approvals where `uid`=?";
            $this->bind = [intval($uid)];
        } else {
            $this->sql = "select $fields from approvals ";
            if ($ids) {
                $this->sql = $this->sql . " where `uid` in ($ids) ";
            }
            $this->bind = $key_obj;
        }
        parent::__construct($cache_obj, $this->key, $this->key, $key_objfactory, $uid, $timeout);
        return true;
    }

    public function retrive() {
        $res_query = BaseFunction::query_sql_backend($this->sql, $this->bind);
        if (!$res_query) {
            return null;
        }

        $objs = array();
        $result = $res_query['sth']->fetchAll(\PDO::FETCH_CLASS, "HttpApi\puremodel\Approvals");
        foreach ($result as $val) {
            $val->before_writeback();
            $objs[$this->key . '_' . $val->uid] = $val;
        }
        return $objs;

    }
}

