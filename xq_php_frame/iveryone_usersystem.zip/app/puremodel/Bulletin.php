<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class Bulletin extends BaseObject {
    const TABLE_NAME = 'bulletin';

    public $id; //
    public $type = 0; //类型
    public $title = ''; //标题
    public $content; //内容
    public $release_time = 0; //发布时间

    public $created_at = 0; //创建时间
    public $updated_at = 0; //
    public $deleted_at = 0; //删除时间

    public function getUpdateSql() {
        return [
            "update `bulletin` SET
            `type`=?
            , `title`=?
            , `content`=?
            , `release_time`=?

            , `created_at`=?
            , `updated_at`=?
            , `deleted_at`=?

            where `id`=?"

            , [
                intval($this->type)
                , $this->title
                , $this->content
                , intval($this->release_time)

                , intval($this->created_at)
                , intval($this->updated_at)
                , intval($this->deleted_at)

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `bulletin` SET

            `type`=?
            , `title`=?
            , `content`=?
            , `release_time`=?

            , `created_at`=?
            , `updated_at`=?
            , `deleted_at`=?
            "

            , [
                intval($this->type)
                , $this->title
                , $this->content
                , intval($this->release_time)

                , intval($this->created_at)
                , intval($this->updated_at)
                , intval($this->deleted_at)
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `bulletin`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

