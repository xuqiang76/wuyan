<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class Approvals extends BaseObject {
    const TABLE_NAME = 'approvals';

    public $id; //
    public $tid; //
    public $uid; //
    public $sid = 0; //
    public $timestamp = 0; //

    public function getUpdateSql() {
        return [
            "update `approvals` SET
            `sid`=?
            , `timestamp`=?

            where `uid`=?"

            , [
                intval($this->sid)
                , intval($this->timestamp)

                , intval($this->uid)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `approvals` SET

            `tid`=?
            , `uid`=?
            , `sid`=?
            , `timestamp`=?
            "

            , [
                intval($this->tid)
                , intval($this->uid)
                , intval($this->sid)
                , intval($this->timestamp)
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `approvals`
            where `uid`=?"

            , [
                intval($this->uid)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

