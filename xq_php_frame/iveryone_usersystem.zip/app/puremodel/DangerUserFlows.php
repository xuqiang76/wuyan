<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class DangerUserFlows extends BaseObject {
    const TABLE_NAME = 'danger_user_flows';

    public $id; //
    public $uid = 0; //
    public $modify_time; //
    public $sid = 0; //
    public $referer = 0; //

    public $islock; //
    public $amount = 0; //

    public function getUpdateSql() {
        return [
            "update `danger_user_flows` SET
            `uid`=?
            , `modify_time`=?
            , `sid`=?
            , `referer`=?

            , `islock`=?
            , `amount`=?

            where `id`=?"

            , [
                intval($this->uid)
                , $this->modify_time
                , intval($this->sid)
                , intval($this->referer)

                , $this->islock
                , intval($this->amount)

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `danger_user_flows` SET

            `uid`=?
            , `modify_time`=?
            , `sid`=?
            , `referer`=?

            , `islock`=?
            , `amount`=?
            "

            , [
                intval($this->uid)
                , $this->modify_time
                , intval($this->sid)
                , intval($this->referer)

                , $this->islock
                , intval($this->amount)
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `danger_user_flows`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

