<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class DangerUser extends BaseObject {
    const TABLE_NAME = 'danger_user';

    public $uid; //
    public $high = 0; //1高危
    public $bigr = 0; //1大R
    public $robot = ''; //1为robot
    public $amount = 0; //lockamout

    public function getUpdateSql() {
        return [
            "update `danger_user` SET
            `high`=?
            , `bigr`=?
            , `robot`=?
            , `amount`=?

            where `uid`=?"

            , [
                intval($this->high)
                , intval($this->bigr)
                , $this->robot
                , intval($this->amount)

                , intval($this->uid)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `danger_user` SET

            `uid`=?
            , `high`=?
            , `bigr`=?
            , `robot`=?
            , `amount`=?
            "

            , [
                intval($this->uid)
                , intval($this->high)
                , intval($this->bigr)
                , $this->robot
                , intval($this->amount)
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `danger_user`
            where `uid`=?"

            , [
                intval($this->uid)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

