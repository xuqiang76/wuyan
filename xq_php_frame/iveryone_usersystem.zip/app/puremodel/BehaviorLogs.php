<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class BehaviorLogs extends BaseObject {
    const TABLE_NAME = 'behavior_logs';

    public $id; //
    public $uid = 0; //
    public $act = 0; //
    public $params; //
    public $description = ''; //

    public $timestamp = 0; //

    public function getUpdateSql() {
        return [
            "update `behavior_logs` SET
            `uid`=?
            , `act`=?
            , `params`=?
            , `description`=?

            , `timestamp`=?

            where `id`=?"

            , [
                intval($this->uid)
                , intval($this->act)
                , $this->params
                , $this->description

                , intval($this->timestamp)

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `behavior_logs` SET

            `uid`=?
            , `act`=?
            , `params`=?
            , `description`=?

            , `timestamp`=?
            "

            , [
                intval($this->uid)
                , intval($this->act)
                , $this->params
                , $this->description

                , intval($this->timestamp)
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `behavior_logs`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

