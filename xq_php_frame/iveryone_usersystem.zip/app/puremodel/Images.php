<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class Images extends BaseObject {
    const TABLE_NAME = 'images';

    public $id; //
    public $uid = 0; //
    public $url = ''; //
    public $info = ''; //
    public $md5 = ''; //

    public $create_timestamp = 0; //

    public function getUpdateSql() {
        return [
            "update `images` SET
            `uid`=?
            , `url`=?
            , `info`=?
            , `md5`=?

            , `create_timestamp`=?

            where `id`=?"

            , [
                intval($this->uid)
                , $this->url
                , $this->info
                , $this->md5

                , intval($this->create_timestamp)

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `images` SET

            `uid`=?
            , `url`=?
            , `info`=?
            , `md5`=?

            , `create_timestamp`=?
            "

            , [
                intval($this->uid)
                , $this->url
                , $this->info
                , $this->md5

                , intval($this->create_timestamp)
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `images`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

