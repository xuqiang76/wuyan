<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class GamesPutvry extends BaseObject {
    const TABLE_NAME = 'games_putvry';

    public $id; //
    public $money = 0; //金额
    public $uid = 0; //用户ID
    public $appid = 0; //appid
    public $transcode = ''; //交易记录

    public $description = ''; //
    public $create_time = 0; //创建时间
    public $status = 0; //状态

    public function getUpdateSql() {
        return [
            "update `games_putvry` SET
            `money`=?
            , `uid`=?
            , `appid`=?
            , `transcode`=?

            , `description`=?
            , `create_time`=?
            , `status`=?

            where `id`=?"

            , [
                intval($this->money)
                , intval($this->uid)
                , intval($this->appid)
                , $this->transcode

                , $this->description
                , intval($this->create_time)
                , intval($this->status)

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `games_putvry` SET

            `money`=?
            , `uid`=?
            , `appid`=?
            , `transcode`=?

            , `description`=?
            , `create_time`=?
            , `status`=?
            "

            , [
                intval($this->money)
                , intval($this->uid)
                , intval($this->appid)
                , $this->transcode

                , $this->description
                , intval($this->create_time)
                , intval($this->status)
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `games_putvry`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

