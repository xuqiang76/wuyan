<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class FeedQueue extends BaseObject {
    const TABLE_NAME = 'feed_queue';

    public $id; //
    public $feedid = 0; //
    public $status = 0; //0等待 1执行中 2执行完毕 3执行错误

    public function getUpdateSql() {
        return [
            "update `feed_queue` SET
            `feedid`=?
            , `status`=?

            where `id`=?"

            , [
                intval($this->feedid)
                , intval($this->status)

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `feed_queue` SET

            `feedid`=?
            , `status`=?
            "

            , [
                intval($this->feedid)
                , intval($this->status)
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `feed_queue`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

