<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseFunction;
use bigcatorm\MutiStoreFactory;

class BillMultiFactory extends MutiStoreFactory {
    public $key = 'usersystem_bill_multi_';
    private $sql;
    private $bind;

    public function __construct($cache_obj, $key_objfactory = null, $id = null, $key_add = '', $timeout = 86400) {
        if (!$key_objfactory && !$id) {
            return false;
        }
        $this->key = $this->key . $key_add;
        $ids = '';
        if ($key_objfactory) {
            if ($key_objfactory->initialize()) {
                $key_obj = $key_objfactory->get();
                $ids = implode(',', array_fill(0, count($key_obj), '?'));
            }
        }
        $fields = "
            `id`
            , `title`
            , `bill_type`
            , `trading_type`
            , `belong_role`

            , `belong_id`
            , `direction_type`
            , `income_role`
            , `expend_role`
            , `income_id`

            , `expend_id`
            , `combine_currency_type`
            , `amount`
            , `scene_category`
            , `status`

            , `remark`
            , `uniqid`
            , `create_timestamp`
            , `finish_timestamp`
            , `fail_timestamp`
            ";

        if ($id != null) {
            $this->bInitMuti = false;
            $this->sql = "select $fields from bill where `id`=?";
            $this->bind = [intval($id)];
        } else {
            $this->sql = "select $fields from bill ";
            if ($ids) {
                $this->sql = $this->sql . " where `id` in ($ids) ";
            }
            $this->bind = $key_obj;
        }
        parent::__construct($cache_obj, $this->key, $this->key, $key_objfactory, $id, $timeout);
        return true;
    }

    public function retrive() {
        $res_query = BaseFunction::query_sql_backend($this->sql, $this->bind);
        if (!$res_query) {
            return null;
        }

        $objs = array();
        $result = $res_query['sth']->fetchAll(\PDO::FETCH_CLASS, "HttpApi\puremodel\Bill");
        foreach ($result as $val) {
            $val->before_writeback();
            $objs[$this->key . '_' . $val->id] = $val;
        }
        return $objs;

    }
}

