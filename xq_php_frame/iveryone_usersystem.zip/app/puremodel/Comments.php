<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class Comments extends BaseObject {
    const TABLE_NAME = 'comments';

    public $id; //
    public $tid; //
    public $cid = 0; //
    public $uid = 0; //
    public $content; //

    public $timestamp = 0; //
    public $status = 0; //
    public $sid = 0; //
    public $unread = 0; //
    public $reply = 0; //

    public $cuid = 0; //

    public function getUpdateSql() {
        return [
            "update `comments` SET
            `cid`=?
            , `uid`=?
            , `content`=?

            , `timestamp`=?
            , `status`=?
            , `sid`=?
            , `unread`=?
            , `reply`=?

            , `cuid`=?

            where `tid`=?"

            , [
                intval($this->cid)
                , intval($this->uid)
                , $this->content

                , intval($this->timestamp)
                , intval($this->status)
                , intval($this->sid)
                , intval($this->unread)
                , intval($this->reply)

                , intval($this->cuid)

                , intval($this->tid)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `comments` SET

            `tid`=?
            , `cid`=?
            , `uid`=?
            , `content`=?

            , `timestamp`=?
            , `status`=?
            , `sid`=?
            , `unread`=?
            , `reply`=?

            , `cuid`=?
            "

            , [
                intval($this->tid)
                , intval($this->cid)
                , intval($this->uid)
                , $this->content

                , intval($this->timestamp)
                , intval($this->status)
                , intval($this->sid)
                , intval($this->unread)
                , intval($this->reply)

                , intval($this->cuid)
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `comments`
            where `tid`=?"

            , [
                intval($this->tid)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

