<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class ChatInfo extends BaseObject {
    const TABLE_NAME = 'chat_info';

    public $id; //
    public $recorder = 0; //
    public $receiver = 0; //
    public $chat_status = 0; //0:已结束，1:等待开始，2:聊天中
    public $initiated_time = 0; //

    public $reply_time = 0; //
    public $refresh_time = 0; //

    public function getUpdateSql() {
        return [
            "update `chat_info` SET
            `recorder`=?
            , `receiver`=?
            , `chat_status`=?
            , `initiated_time`=?

            , `reply_time`=?
            , `refresh_time`=?

            where `id`=?"

            , [
                intval($this->recorder)
                , intval($this->receiver)
                , intval($this->chat_status)
                , intval($this->initiated_time)

                , intval($this->reply_time)
                , intval($this->refresh_time)

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `chat_info` SET

            `recorder`=?
            , `receiver`=?
            , `chat_status`=?
            , `initiated_time`=?

            , `reply_time`=?
            , `refresh_time`=?
            "

            , [
                intval($this->recorder)
                , intval($this->receiver)
                , intval($this->chat_status)
                , intval($this->initiated_time)

                , intval($this->reply_time)
                , intval($this->refresh_time)
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `chat_info`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

