<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class Contacts extends BaseObject {
    const TABLE_NAME = 'contacts';

    public $id; //
    public $uid = 0; //主体用户.
    public $contact_uid = 0; //关注用户.
    public $contact_status = 0; //关注状态, 1是 0否
    public $star_status = 0; //特别关注, 1是 0 否

    public $create_timestamp = 0; //
    public $update_timestamp = 0; //
    public $contact_timestamp = 0; //
    public $bilateral = 0; //双边关注, 1是 0否
    public $message_contract_id = 0; //消息合约id.

    public $suggest_set_contract = 0; //
    public $disturb = 0; //防打扰, 1防 0不防

    public function getUpdateSql() {
        return [
            "update `contacts` SET
            `uid`=?
            , `contact_uid`=?
            , `contact_status`=?
            , `star_status`=?

            , `create_timestamp`=?
            , `update_timestamp`=?
            , `contact_timestamp`=?
            , `bilateral`=?
            , `message_contract_id`=?

            , `suggest_set_contract`=?
            , `disturb`=?

            where `id`=?"

            , [
                intval($this->uid)
                , intval($this->contact_uid)
                , intval($this->contact_status)
                , intval($this->star_status)

                , intval($this->create_timestamp)
                , intval($this->update_timestamp)
                , intval($this->contact_timestamp)
                , intval($this->bilateral)
                , intval($this->message_contract_id)

                , intval($this->suggest_set_contract)
                , intval($this->disturb)

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `contacts` SET

            `uid`=?
            , `contact_uid`=?
            , `contact_status`=?
            , `star_status`=?

            , `create_timestamp`=?
            , `update_timestamp`=?
            , `contact_timestamp`=?
            , `bilateral`=?
            , `message_contract_id`=?

            , `suggest_set_contract`=?
            , `disturb`=?
            "

            , [
                intval($this->uid)
                , intval($this->contact_uid)
                , intval($this->contact_status)
                , intval($this->star_status)

                , intval($this->create_timestamp)
                , intval($this->update_timestamp)
                , intval($this->contact_timestamp)
                , intval($this->bilateral)
                , intval($this->message_contract_id)

                , intval($this->suggest_set_contract)
                , intval($this->disturb)
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `contacts`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

