<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class Feed9 extends BaseObject {
    const TABLE_NAME = 'feed_9';

    public $id; //
    public $uid = 0; //
    public $feedid = 0; //
    public $content_type = 0; //内容类型 0文章
    public $content_id = 0; //内容id

    public $retweet_status = 0; //0不是最新的转发 1是最新的转发

    public function getUpdateSql() {
        return [
            "update `feed_9` SET
            `uid`=?
            , `feedid`=?
            , `content_type`=?
            , `content_id`=?

            , `retweet_status`=?

            where `id`=?"

            , [
                intval($this->uid)
                , intval($this->feedid)
                , intval($this->content_type)
                , intval($this->content_id)

                , intval($this->retweet_status)

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `feed_9` SET

            `uid`=?
            , `feedid`=?
            , `content_type`=?
            , `content_id`=?

            , `retweet_status`=?
            "

            , [
                intval($this->uid)
                , intval($this->feedid)
                , intval($this->content_type)
                , intval($this->content_id)

                , intval($this->retweet_status)
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `feed_9`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

