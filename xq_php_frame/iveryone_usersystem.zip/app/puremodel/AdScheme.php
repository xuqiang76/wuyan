<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class AdScheme extends BaseObject {
    const TABLE_NAME = 'ad_scheme';

    public $id; //
    public $uid = ''; //广告商uid
    public $title = ''; //名称
    public $description = ''; //描述
    public $type = ''; //广告类型 feed动态广告 / follow关注广告 /等

    public $remark = ''; //内容
    public $price = 0; //广告单价
    public $number = 0; //广告总数
    public $strategy = ''; //广告策略结构体
    public $init_time = 0; //结束时间

    public $update_time = 0; //更新时间
    public $material_title = ''; //素材名称
    public $strategy_title = ''; //策略名称

    public function getUpdateSql() {
        return [
            "update `ad_scheme` SET
            `uid`=?
            , `title`=?
            , `description`=?
            , `type`=?

            , `remark`=?
            , `price`=?
            , `number`=?
            , `strategy`=?
            , `init_time`=?

            , `update_time`=?
            , `material_title`=?
            , `strategy_title`=?

            where `id`=?"

            , [
                $this->uid
                , $this->title
                , $this->description
                , $this->type

                , $this->remark
                , intval($this->price)
                , intval($this->number)
                , $this->strategy
                , intval($this->init_time)

                , intval($this->update_time)
                , $this->material_title
                , $this->strategy_title

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `ad_scheme` SET

            `uid`=?
            , `title`=?
            , `description`=?
            , `type`=?

            , `remark`=?
            , `price`=?
            , `number`=?
            , `strategy`=?
            , `init_time`=?

            , `update_time`=?
            , `material_title`=?
            , `strategy_title`=?
            "

            , [
                $this->uid
                , $this->title
                , $this->description
                , $this->type

                , $this->remark
                , intval($this->price)
                , intval($this->number)
                , $this->strategy
                , intval($this->init_time)

                , intval($this->update_time)
                , $this->material_title
                , $this->strategy_title
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `ad_scheme`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

