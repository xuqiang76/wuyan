<?php
namespace HttpApi\puremodel;

use bigcatorm\ListFactory;

class Feed2ListFactory extends ListFactory {
    public $key = 'usersystem_feed_2_list_';

    //$id_multi_str 是用,分隔的字符串
    //select_option : [ "where uid=? and id=? order by ? limit ?", [123, 321, 'uid', '100']]
    public function __construct($cache_obj, $id_multi_str = null, $select_option = null, $timeout = null) {
        if ($id_multi_str == null && $select_option == null) {
            $this->key = $this->key . '_all';
            $this->sql = "select `id` from `feed_2` ";
            $this->bind = [];
            parent::__construct($cache_obj, $this->key, $timeout);
            return true;
        } elseif ($id_multi_str && $select_option == null) {
            $this->key = $this->key . md5($id_multi_str);
            parent::__construct($cache_obj, $this->key, $timeout, $id_multi_str);
            return true;
        } elseif (is_array($select_option) && $id_multi_str == null) {
            $this->key = $this->key . $select_option[0] . implode('_', $select_option[1]);
            $this->sql = "select `id` from `feed_2` " . $select_option[0];
            $this->bind = $select_option[1];
            parent::__construct($cache_obj, $this->key, $timeout);
            return true;
        }
        return false;
    }
}

