<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class Batteryinfo extends BaseObject {
    const TABLE_NAME = 'batteryinfo';

    public $uid; //
    public $capacity = 0; //
    public $last_charge_timestamp = 0; //
    public $mission1_finish; //
    public $mission1_finishtimestamp = 0; //

    public $mission2_finish = 0; //
    public $mission2_finishtimestamp = 0; //
    public $mission3_finish = 0; //
    public $mission3_finishtimestamp = 0; //
    public $mission4_finish = 0; //

    public $mission4_finishtimestamp = 0; //

    public function getUpdateSql() {
        return [
            "update `batteryinfo` SET
            `capacity`=?
            , `last_charge_timestamp`=?
            , `mission1_finishtimestamp`=?

            , `mission2_finish`=?
            , `mission2_finishtimestamp`=?
            , `mission3_finish`=?
            , `mission3_finishtimestamp`=?
            , `mission4_finish`=?

            , `mission4_finishtimestamp`=?

            where `mission1_finish`=?"

            , [
                intval($this->capacity)
                , intval($this->last_charge_timestamp)
                , intval($this->mission1_finishtimestamp)

                , intval($this->mission2_finish)
                , intval($this->mission2_finishtimestamp)
                , intval($this->mission3_finish)
                , intval($this->mission3_finishtimestamp)
                , intval($this->mission4_finish)

                , intval($this->mission4_finishtimestamp)

                , intval($this->mission1_finish)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `batteryinfo` SET

            `uid`=?
            , `capacity`=?
            , `last_charge_timestamp`=?
            , `mission1_finish`=?
            , `mission1_finishtimestamp`=?

            , `mission2_finish`=?
            , `mission2_finishtimestamp`=?
            , `mission3_finish`=?
            , `mission3_finishtimestamp`=?
            , `mission4_finish`=?

            , `mission4_finishtimestamp`=?
            "

            , [
                intval($this->uid)
                , intval($this->capacity)
                , intval($this->last_charge_timestamp)
                , intval($this->mission1_finish)
                , intval($this->mission1_finishtimestamp)

                , intval($this->mission2_finish)
                , intval($this->mission2_finishtimestamp)
                , intval($this->mission3_finish)
                , intval($this->mission3_finishtimestamp)
                , intval($this->mission4_finish)

                , intval($this->mission4_finishtimestamp)
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `batteryinfo`
            where `mission1_finish`=?"

            , [
                intval($this->mission1_finish)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

