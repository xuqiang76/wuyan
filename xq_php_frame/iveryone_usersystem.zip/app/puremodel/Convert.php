<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class Convert extends BaseObject {
    const TABLE_NAME = 'convert';

    public $id; //
    public $uid = 0; //用户ID
    public $amount = 0; //兑换金额
    public $orderid = 0; //订单ID
    public $create_time = 0; //时间

    public function getUpdateSql() {
        return [
            "update `convert` SET
            `uid`=?
            , `amount`=?
            , `orderid`=?
            , `create_time`=?

            where `id`=?"

            , [
                intval($this->uid)
                , intval($this->amount)
                , intval($this->orderid)
                , intval($this->create_time)

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `convert` SET

            `uid`=?
            , `amount`=?
            , `orderid`=?
            , `create_time`=?
            "

            , [
                intval($this->uid)
                , intval($this->amount)
                , intval($this->orderid)
                , intval($this->create_time)
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `convert`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

