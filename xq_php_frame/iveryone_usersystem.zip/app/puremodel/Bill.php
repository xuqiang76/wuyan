<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class Bill extends BaseObject {
    const TABLE_NAME = 'bill';

    public $id; //
    public $title = ''; //账单标题
    public $bill_type = 0; //账单类型（1系统、2非系统）
    public $trading_type = 0; //交易类型（1消费、2转账、3充值、4提现）
    public $belong_role = 0; //所属人角色（1用户、2系统）

    public $belong_id = 0; //所属人
    public $direction_type = 0; //收支类型（1收入、2支出）
    public $income_role = 0; //收入角色（1用户、2系统）
    public $expend_role = 0; //支出角色（1用户、2系统）
    public $income_id = 0; //收入ID

    public $expend_id = 0; //支出ID
    public $combine_currency_type = 0; //账单对应的资产类型 1. V点   5. VRY
    public $amount = 0; //金额
    public $scene_category = 0; //业务场景分类（详见配置文件）
    public $status = 0; //状态（1正在交易、2交易完成、3交易失败）

    public $remark = ''; //备注
    public $uniqid = ''; //外部订单ID
    public $create_timestamp = 0; //创建时间
    public $finish_timestamp = 0; //完成时间
    public $fail_timestamp = 0; //失败时间

    public function getUpdateSql() {
        return [
            "update `bill` SET
            `title`=?
            , `bill_type`=?
            , `trading_type`=?
            , `belong_role`=?

            , `belong_id`=?
            , `direction_type`=?
            , `income_role`=?
            , `expend_role`=?
            , `income_id`=?

            , `expend_id`=?
            , `combine_currency_type`=?
            , `amount`=?
            , `scene_category`=?
            , `status`=?

            , `remark`=?
            , `uniqid`=?
            , `create_timestamp`=?
            , `finish_timestamp`=?
            , `fail_timestamp`=?

            where `id`=?"

            , [
                $this->title
                , intval($this->bill_type)
                , intval($this->trading_type)
                , intval($this->belong_role)

                , intval($this->belong_id)
                , intval($this->direction_type)
                , intval($this->income_role)
                , intval($this->expend_role)
                , intval($this->income_id)

                , intval($this->expend_id)
                , intval($this->combine_currency_type)
                , intval($this->amount)
                , intval($this->scene_category)
                , intval($this->status)

                , $this->remark
                , $this->uniqid
                , intval($this->create_timestamp)
                , intval($this->finish_timestamp)
                , intval($this->fail_timestamp)

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `bill` SET

            `title`=?
            , `bill_type`=?
            , `trading_type`=?
            , `belong_role`=?

            , `belong_id`=?
            , `direction_type`=?
            , `income_role`=?
            , `expend_role`=?
            , `income_id`=?

            , `expend_id`=?
            , `combine_currency_type`=?
            , `amount`=?
            , `scene_category`=?
            , `status`=?

            , `remark`=?
            , `uniqid`=?
            , `create_timestamp`=?
            , `finish_timestamp`=?
            , `fail_timestamp`=?
            "

            , [
                $this->title
                , intval($this->bill_type)
                , intval($this->trading_type)
                , intval($this->belong_role)

                , intval($this->belong_id)
                , intval($this->direction_type)
                , intval($this->income_role)
                , intval($this->expend_role)
                , intval($this->income_id)

                , intval($this->expend_id)
                , intval($this->combine_currency_type)
                , intval($this->amount)
                , intval($this->scene_category)
                , intval($this->status)

                , $this->remark
                , $this->uniqid
                , intval($this->create_timestamp)
                , intval($this->finish_timestamp)
                , intval($this->fail_timestamp)
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `bill`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

