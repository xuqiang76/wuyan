<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class FeedPushfailed extends BaseObject {
    const TABLE_NAME = 'feed_pushfailed';

    public $id; //
    public $feedid = 0; //
    public $lastid = 0; //
    public $failed_timestamp = 0; //
    public $failed_times = 0; //

    public function getUpdateSql() {
        return [
            "update `feed_pushfailed` SET
            `feedid`=?
            , `lastid`=?
            , `failed_timestamp`=?
            , `failed_times`=?

            where `id`=?"

            , [
                intval($this->feedid)
                , intval($this->lastid)
                , intval($this->failed_timestamp)
                , intval($this->failed_times)

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `feed_pushfailed` SET

            `id`=?
            , `feedid`=?
            , `lastid`=?
            , `failed_timestamp`=?
            , `failed_times`=?
            "

            , [
                intval($this->id)
                , intval($this->feedid)
                , intval($this->lastid)
                , intval($this->failed_timestamp)
                , intval($this->failed_times)
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `feed_pushfailed`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

