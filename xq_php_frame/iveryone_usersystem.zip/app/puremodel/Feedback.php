<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class Feedback extends BaseObject {
    const TABLE_NAME = 'feedback';

    public $id; //
    public $tid = 0; //
    public $uid = 0; //
    public $type = 0; //
    public $remark; //

    public $timestamp = 0; //
    public $status = 0; //
    public $amount = 0; //
    public $category = 0; //
    public $assets; //

    public function getUpdateSql() {
        return [
            "update `feedback` SET
            `tid`=?
            , `uid`=?
            , `type`=?
            , `remark`=?

            , `timestamp`=?
            , `status`=?
            , `amount`=?
            , `category`=?
            , `assets`=?

            where `id`=?"

            , [
                intval($this->tid)
                , intval($this->uid)
                , intval($this->type)
                , $this->remark

                , intval($this->timestamp)
                , intval($this->status)
                , intval($this->amount)
                , intval($this->category)
                , $this->assets

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `feedback` SET

            `tid`=?
            , `uid`=?
            , `type`=?
            , `remark`=?

            , `timestamp`=?
            , `status`=?
            , `amount`=?
            , `category`=?
            , `assets`=?
            "

            , [
                intval($this->tid)
                , intval($this->uid)
                , intval($this->type)
                , $this->remark

                , intval($this->timestamp)
                , intval($this->status)
                , intval($this->amount)
                , intval($this->category)
                , $this->assets
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `feedback`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

