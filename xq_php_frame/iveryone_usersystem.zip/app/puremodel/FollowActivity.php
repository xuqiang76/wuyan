<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class FollowActivity extends BaseObject {
    const TABLE_NAME = 'followActivity';

    public $id; //
    public $uid = ''; //
    public $follower = ''; //
    public $quota = 0; //
    public $status = 0; //

    public $create_time = 0; //
    public $confirm_time = 0; //

    public function getUpdateSql() {
        return [
            "update `followActivity` SET
            `uid`=?
            , `follower`=?
            , `quota`=?
            , `status`=?

            , `create_time`=?
            , `confirm_time`=?

            where `id`=?"

            , [
                $this->uid
                , $this->follower
                , intval($this->quota)
                , intval($this->status)

                , intval($this->create_time)
                , intval($this->confirm_time)

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `followActivity` SET

            `uid`=?
            , `follower`=?
            , `quota`=?
            , `status`=?

            , `create_time`=?
            , `confirm_time`=?
            "

            , [
                $this->uid
                , $this->follower
                , intval($this->quota)
                , intval($this->status)

                , intval($this->create_time)
                , intval($this->confirm_time)
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `followActivity`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

