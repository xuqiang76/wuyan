<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class CallInfo extends BaseObject {
    const TABLE_NAME = 'call_info';

    public $id; //
    public $callid = ''; //
    public $calltype = ''; //
    public $call_fee = ''; //
    public $call_status = 0; //0:已结束，1:等待开始，2:聊天中，3:扣费失败结束，4:已完成抄送数据检验处理

    public $finish_status = 0; //1挂断 2未接通 3挂断但时间不正常
    public $recorder = 0; //
    public $receiver = 0; //
    public $dail_timestamp = 0; //
    public $recorder_connected_timestamp = 0; //

    public $receiver_connected_timestamp = 0; //
    public $recorder_finish_timestamp = 0; //
    public $receiver_finish_timestamp = 0; //
    public $recorder_active_timestamp = 0; //
    public $receiver_active_timestamp = 0; //

    public $imservice_recorder_duration = 0; //
    public $imservice_receiver_duration = 0; //
    public $update_timestamp = 0; //
    public $redenvelopes; //
    public $canceled_redenvelopes; //

    public $spend = ''; //
    public $total_minutes = 0; //
    public $spend_minutes = 0; //

    public function getUpdateSql() {
        return [
            "update `call_info` SET
            `callid`=?
            , `calltype`=?
            , `call_fee`=?
            , `call_status`=?

            , `finish_status`=?
            , `recorder`=?
            , `receiver`=?
            , `dail_timestamp`=?
            , `recorder_connected_timestamp`=?

            , `receiver_connected_timestamp`=?
            , `recorder_finish_timestamp`=?
            , `receiver_finish_timestamp`=?
            , `recorder_active_timestamp`=?
            , `receiver_active_timestamp`=?

            , `imservice_recorder_duration`=?
            , `imservice_receiver_duration`=?
            , `update_timestamp`=?
            , `redenvelopes`=?
            , `canceled_redenvelopes`=?

            , `spend`=?
            , `total_minutes`=?
            , `spend_minutes`=?

            where `id`=?"

            , [
                $this->callid
                , $this->calltype
                , $this->call_fee
                , intval($this->call_status)

                , intval($this->finish_status)
                , intval($this->recorder)
                , intval($this->receiver)
                , intval($this->dail_timestamp)
                , intval($this->recorder_connected_timestamp)

                , intval($this->receiver_connected_timestamp)
                , intval($this->recorder_finish_timestamp)
                , intval($this->receiver_finish_timestamp)
                , intval($this->recorder_active_timestamp)
                , intval($this->receiver_active_timestamp)

                , intval($this->imservice_recorder_duration)
                , intval($this->imservice_receiver_duration)
                , intval($this->update_timestamp)
                , $this->redenvelopes
                , $this->canceled_redenvelopes

                , $this->spend
                , intval($this->total_minutes)
                , intval($this->spend_minutes)

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `call_info` SET

            `callid`=?
            , `calltype`=?
            , `call_fee`=?
            , `call_status`=?

            , `finish_status`=?
            , `recorder`=?
            , `receiver`=?
            , `dail_timestamp`=?
            , `recorder_connected_timestamp`=?

            , `receiver_connected_timestamp`=?
            , `recorder_finish_timestamp`=?
            , `receiver_finish_timestamp`=?
            , `recorder_active_timestamp`=?
            , `receiver_active_timestamp`=?

            , `imservice_recorder_duration`=?
            , `imservice_receiver_duration`=?
            , `update_timestamp`=?
            , `redenvelopes`=?
            , `canceled_redenvelopes`=?

            , `spend`=?
            , `total_minutes`=?
            , `spend_minutes`=?
            "

            , [
                $this->callid
                , $this->calltype
                , $this->call_fee
                , intval($this->call_status)

                , intval($this->finish_status)
                , intval($this->recorder)
                , intval($this->receiver)
                , intval($this->dail_timestamp)
                , intval($this->recorder_connected_timestamp)

                , intval($this->receiver_connected_timestamp)
                , intval($this->recorder_finish_timestamp)
                , intval($this->receiver_finish_timestamp)
                , intval($this->recorder_active_timestamp)
                , intval($this->receiver_active_timestamp)

                , intval($this->imservice_recorder_duration)
                , intval($this->imservice_receiver_duration)
                , intval($this->update_timestamp)
                , $this->redenvelopes
                , $this->canceled_redenvelopes

                , $this->spend
                , intval($this->total_minutes)
                , intval($this->spend_minutes)
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `call_info`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

