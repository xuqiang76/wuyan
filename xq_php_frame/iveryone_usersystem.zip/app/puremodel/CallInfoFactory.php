<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseFunction;
use bigcatorm\Factory;

class CallInfoFactory extends Factory {
    const objkey = 'usersystem_call_info_multi_';
    private $sql;
    private $bind;
    public function __construct($cache_obj, $id, $timeout = 86400) {
        $serverkey = self::objkey;
        $objkey = self::objkey . "_" . $id;
        $this->sql = "select
            `id`
            , `callid`
            , `calltype`
            , `call_fee`
            , `call_status`

            , `finish_status`
            , `recorder`
            , `receiver`
            , `dail_timestamp`
            , `recorder_connected_timestamp`

            , `receiver_connected_timestamp`
            , `recorder_finish_timestamp`
            , `receiver_finish_timestamp`
            , `recorder_active_timestamp`
            , `receiver_active_timestamp`

            , `imservice_recorder_duration`
            , `imservice_receiver_duration`
            , `update_timestamp`
            , `redenvelopes`
            , `canceled_redenvelopes`

            , `spend`
            , `total_minutes`
            , `spend_minutes`

            from `call_info`
            where `id`=?";
        $this->bind = [intval($id)];

        parent::__construct($cache_obj, $serverkey, $objkey, $timeout);
        return true;
    }

    public function retrive() {
        $res_query = BaseFunction::query_sql_backend($this->sql, $this->bind);
        if (!$res_query) {
            return null;
        }

        $obj = null;
        $result = $res_query['sth']->fetchAll(\PDO::FETCH_CLASS, "HttpApi\puremodel\CallInfo");

        if ($result) {
            $obj = $result[0];
            $obj->before_writeback();
        }
        return $obj;
    }
}

