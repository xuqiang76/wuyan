<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class GamesTags extends BaseObject {
    const TABLE_NAME = 'games_tags';

    public $gid; //
    public $tid; //

    public function getUpdateSql() {
        return [
            "update `games_tags` SET

            where `tid`=?"

            , [

                , intval($this->tid)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `games_tags` SET

            `gid`=?
            , `tid`=?
            "

            , [
                intval($this->gid)
                , intval($this->tid)
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `games_tags`
            where `tid`=?"

            , [
                intval($this->tid)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

