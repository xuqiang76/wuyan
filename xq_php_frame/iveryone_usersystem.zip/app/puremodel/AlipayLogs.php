<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class AlipayLogs extends BaseObject {
    const TABLE_NAME = 'alipay_logs';

    public $id; //logs id
    public $order_id = 0; //
    public $trade_no_id = ''; //交易ID
    public $uid = 0; //用户ID
    public $trade_status = ''; //交易状态

    public $total_amount = ''; //
    public $data; //支付宝请求的所有数据
    public $create_timestamp = 0; //创建时间

    public function getUpdateSql() {
        return [
            "update `alipay_logs` SET
            `order_id`=?
            , `trade_no_id`=?
            , `uid`=?
            , `trade_status`=?

            , `total_amount`=?
            , `data`=?
            , `create_timestamp`=?

            where `id`=?"

            , [
                intval($this->order_id)
                , $this->trade_no_id
                , intval($this->uid)
                , $this->trade_status

                , $this->total_amount
                , $this->data
                , intval($this->create_timestamp)

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `alipay_logs` SET

            `order_id`=?
            , `trade_no_id`=?
            , `uid`=?
            , `trade_status`=?

            , `total_amount`=?
            , `data`=?
            , `create_timestamp`=?
            "

            , [
                intval($this->order_id)
                , $this->trade_no_id
                , intval($this->uid)
                , $this->trade_status

                , $this->total_amount
                , $this->data
                , intval($this->create_timestamp)
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `alipay_logs`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

