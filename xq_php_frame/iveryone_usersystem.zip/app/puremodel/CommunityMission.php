<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class CommunityMission extends BaseObject {
    const TABLE_NAME = 'communityMission';

    public $id; //
    public $uid = 0; //
    public $community_type = 0; //0telegram 1wechat 2alipay
    public $community_usermark = ''; //
    public $create_time = 0; //

    public $ext; //

    public function getUpdateSql() {
        return [
            "update `communityMission` SET
            `uid`=?
            , `community_type`=?
            , `community_usermark`=?
            , `create_time`=?

            , `ext`=?

            where `id`=?"

            , [
                intval($this->uid)
                , intval($this->community_type)
                , $this->community_usermark
                , intval($this->create_time)

                , $this->ext

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `communityMission` SET

            `uid`=?
            , `community_type`=?
            , `community_usermark`=?
            , `create_time`=?

            , `ext`=?
            "

            , [
                intval($this->uid)
                , intval($this->community_type)
                , $this->community_usermark
                , intval($this->create_time)

                , $this->ext
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `communityMission`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

