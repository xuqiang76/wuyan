<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class Genealogy extends BaseObject {
    const TABLE_NAME = 'genealogy';

    public $id; //
    public $uid = ''; //
    public $referer = ''; //
    public $level = 0; //
    public $register = 0; //

    public $freeze = 0; //注册推广奖励是否冻结未发放

    public function getUpdateSql() {
        return [
            "update `genealogy` SET
            `uid`=?
            , `referer`=?
            , `level`=?
            , `register`=?

            , `freeze`=?

            where `id`=?"

            , [
                $this->uid
                , $this->referer
                , intval($this->level)
                , intval($this->register)

                , intval($this->freeze)

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `genealogy` SET

            `uid`=?
            , `referer`=?
            , `level`=?
            , `register`=?

            , `freeze`=?
            "

            , [
                $this->uid
                , $this->referer
                , intval($this->level)
                , intval($this->register)

                , intval($this->freeze)
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `genealogy`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

