<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class AdsenseOver extends BaseObject {
    const TABLE_NAME = 'adsense_over';

    public $id; //
    public $uid = ''; //用户id
    public $adwords = 0; //广告id
    public $timestamp = 0; //时间
    public $advertisers = ''; //广告商

    public $is_click = 0; //观看付费广告是否被点击, 0否 1是 ；点击付费广告是否被付费， 0 否 1是
    public $version = 0; //版本号，用于控制程序逻辑
    public $type = ''; //广告类型 feed动态广告 / follow关注广告 /novice_gift新手礼/等
    public $deal_price = 0; //成交价格

    public function getUpdateSql() {
        return [
            "update `adsense_over` SET
            `uid`=?
            , `adwords`=?
            , `timestamp`=?
            , `advertisers`=?

            , `is_click`=?
            , `version`=?
            , `type`=?
            , `deal_price`=?

            where `id`=?"

            , [
                $this->uid
                , intval($this->adwords)
                , intval($this->timestamp)
                , $this->advertisers

                , intval($this->is_click)
                , intval($this->version)
                , $this->type
                , intval($this->deal_price)

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `adsense_over` SET

            `uid`=?
            , `adwords`=?
            , `timestamp`=?
            , `advertisers`=?

            , `is_click`=?
            , `version`=?
            , `type`=?
            , `deal_price`=?
            "

            , [
                $this->uid
                , intval($this->adwords)
                , intval($this->timestamp)
                , $this->advertisers

                , intval($this->is_click)
                , intval($this->version)
                , $this->type
                , intval($this->deal_price)
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `adsense_over`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

