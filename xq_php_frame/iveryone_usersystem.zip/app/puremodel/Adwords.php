<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class Adwords extends BaseObject {
    const TABLE_NAME = 'adwords';

    public $id; //
    public $advertisers = ''; //广告商
    public $quota = 0; //广告剩余数量,（未成交）
    public $plan = 0; //（新版不用此字段）广告方案  关注广告 1 2 3 ；动态广告 10001 10002 10003
    public $start_timestamp = 0; //开始时间

    public $end_timestamp = 0; //结束时间
    public $status = 0; //状态, 1正常 2完成 3取消 4暂停.
    public $remark = ''; //备注内容
    public $price = 0; //广告单价.
    public $number = 0; //广告总数.

    public $privilege = 0; //（新版不用此字段）,投递给 0所有人 1认证的用户 
    public $type = ''; //广告类型 feed动态广告 / follow关注广告 /novice_gift新手礼/等
    public $strategy = ''; //广告策略结构体.
    public $click_number = 0; //点击数,（统计用）
    public $scheme_title = ''; //方案名称.

    public $material_title = ''; //素材名称.
    public $strategy_title = ''; //策略名称.
    public $free_num = 0; //(本字段废弃)免费条数, 小于总数 number 字段（提前结束退款）
    public $push_num = 0; //广告推送数.
    public $update_time = 0; //更新时间，比如更新 push_num 时候

    public $version = 0; //广告需求版本，区别对待不同版本的广告

    public function getUpdateSql() {
        return [
            "update `adwords` SET
            `advertisers`=?
            , `quota`=?
            , `plan`=?
            , `start_timestamp`=?

            , `end_timestamp`=?
            , `status`=?
            , `remark`=?
            , `price`=?
            , `number`=?

            , `privilege`=?
            , `type`=?
            , `strategy`=?
            , `click_number`=?
            , `scheme_title`=?

            , `material_title`=?
            , `strategy_title`=?
            , `free_num`=?
            , `push_num`=?
            , `update_time`=?

            , `version`=?

            where `id`=?"

            , [
                $this->advertisers
                , intval($this->quota)
                , intval($this->plan)
                , intval($this->start_timestamp)

                , intval($this->end_timestamp)
                , intval($this->status)
                , $this->remark
                , intval($this->price)
                , intval($this->number)

                , intval($this->privilege)
                , $this->type
                , $this->strategy
                , intval($this->click_number)
                , $this->scheme_title

                , $this->material_title
                , $this->strategy_title
                , intval($this->free_num)
                , intval($this->push_num)
                , intval($this->update_time)

                , intval($this->version)

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `adwords` SET

            `advertisers`=?
            , `quota`=?
            , `plan`=?
            , `start_timestamp`=?

            , `end_timestamp`=?
            , `status`=?
            , `remark`=?
            , `price`=?
            , `number`=?

            , `privilege`=?
            , `type`=?
            , `strategy`=?
            , `click_number`=?
            , `scheme_title`=?

            , `material_title`=?
            , `strategy_title`=?
            , `free_num`=?
            , `push_num`=?
            , `update_time`=?

            , `version`=?
            "

            , [
                $this->advertisers
                , intval($this->quota)
                , intval($this->plan)
                , intval($this->start_timestamp)

                , intval($this->end_timestamp)
                , intval($this->status)
                , $this->remark
                , intval($this->price)
                , intval($this->number)

                , intval($this->privilege)
                , $this->type
                , $this->strategy
                , intval($this->click_number)
                , $this->scheme_title

                , $this->material_title
                , $this->strategy_title
                , intval($this->free_num)
                , intval($this->push_num)
                , intval($this->update_time)

                , intval($this->version)
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `adwords`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

