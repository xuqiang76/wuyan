<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class Bbs extends BaseObject {
    const TABLE_NAME = 'bbs';

    public $id; //
    public $title = ''; //标题
    public $content = ''; //内容
    public $init_time = 0; //创建时间
    public $start_time = 0; //发布时间

    public $end_time = 0; //结束时间
    public $url = ''; //链接地址

    public function getUpdateSql() {
        return [
            "update `bbs` SET
            `title`=?
            , `content`=?
            , `init_time`=?
            , `start_time`=?

            , `end_time`=?
            , `url`=?

            where `id`=?"

            , [
                $this->title
                , $this->content
                , intval($this->init_time)
                , intval($this->start_time)

                , intval($this->end_time)
                , $this->url

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `bbs` SET

            `title`=?
            , `content`=?
            , `init_time`=?
            , `start_time`=?

            , `end_time`=?
            , `url`=?
            "

            , [
                $this->title
                , $this->content
                , intval($this->init_time)
                , intval($this->start_time)

                , intval($this->end_time)
                , $this->url
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `bbs`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

