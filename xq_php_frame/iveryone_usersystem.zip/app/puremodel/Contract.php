<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class Contract extends BaseObject {
    const TABLE_NAME = 'contract';

    public $id; //
    public $name = ''; //合约名称
    public $partya = ''; //甲方
    public $partyb = ''; //乙方
    public $remark = ''; //合约简介

    public $content; //合约内容详情
    public $status = 0; //1 正常 0: 删除
    public $create_timestamp = 0; //
    public $update_timestamp = 0; //
    public $is_parent = 0; //是否是父合约

    public $parent_id = 0; //子合约对应的父合约id
    public $type = 0; //合约类型 1:新用户邀请激励合约 2:广告合约 3:内容转发合约 4:游戏推广合约 5:消息合约
    public $sort = 0; //
    public $contract_no = ''; //合约编号
    public $detail_url = ''; //

    public function getUpdateSql() {
        return [
            "update `contract` SET
            `name`=?
            , `partya`=?
            , `partyb`=?
            , `remark`=?

            , `content`=?
            , `status`=?
            , `create_timestamp`=?
            , `update_timestamp`=?
            , `is_parent`=?

            , `parent_id`=?
            , `type`=?
            , `sort`=?
            , `contract_no`=?
            , `detail_url`=?

            where `id`=?"

            , [
                $this->name
                , $this->partya
                , $this->partyb
                , $this->remark

                , $this->content
                , intval($this->status)
                , intval($this->create_timestamp)
                , intval($this->update_timestamp)
                , intval($this->is_parent)

                , intval($this->parent_id)
                , intval($this->type)
                , intval($this->sort)
                , $this->contract_no
                , $this->detail_url

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `contract` SET

            `name`=?
            , `partya`=?
            , `partyb`=?
            , `remark`=?

            , `content`=?
            , `status`=?
            , `create_timestamp`=?
            , `update_timestamp`=?
            , `is_parent`=?

            , `parent_id`=?
            , `type`=?
            , `sort`=?
            , `contract_no`=?
            , `detail_url`=?
            "

            , [
                $this->name
                , $this->partya
                , $this->partyb
                , $this->remark

                , $this->content
                , intval($this->status)
                , intval($this->create_timestamp)
                , intval($this->update_timestamp)
                , intval($this->is_parent)

                , intval($this->parent_id)
                , intval($this->type)
                , intval($this->sort)
                , $this->contract_no
                , $this->detail_url
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `contract`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

