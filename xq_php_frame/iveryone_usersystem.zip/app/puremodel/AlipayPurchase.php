<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class AlipayPurchase extends BaseObject {
    const TABLE_NAME = 'alipay_purchase';

    public $id; //
    public $uid = 0; //
    public $purchase_info; //
    public $create_timestamp = 0; //
    public $status = 0; //0未验证入账 1已验证入账

    public $refund = 0; //0未退款 1退款中 2已退款

    public function getUpdateSql() {
        return [
            "update `alipay_purchase` SET
            `uid`=?
            , `purchase_info`=?
            , `create_timestamp`=?
            , `status`=?

            , `refund`=?

            where `id`=?"

            , [
                intval($this->uid)
                , $this->purchase_info
                , intval($this->create_timestamp)
                , intval($this->status)

                , intval($this->refund)

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `alipay_purchase` SET

            `uid`=?
            , `purchase_info`=?
            , `create_timestamp`=?
            , `status`=?

            , `refund`=?
            "

            , [
                intval($this->uid)
                , $this->purchase_info
                , intval($this->create_timestamp)
                , intval($this->status)

                , intval($this->refund)
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `alipay_purchase`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

