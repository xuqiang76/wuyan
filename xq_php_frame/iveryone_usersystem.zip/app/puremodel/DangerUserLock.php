<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class DangerUserLock extends BaseObject {
    const TABLE_NAME = 'danger_user_lock';

    public $id; //
    public $ruid = 0; //
    public $lock_uid = 0; //
    public $lock_amount = 0; //
    public $islock; //

    public $create_time; //

    public function getUpdateSql() {
        return [
            "update `danger_user_lock` SET
            `ruid`=?
            , `lock_uid`=?
            , `lock_amount`=?
            , `islock`=?

            , `create_time`=?

            where `id`=?"

            , [
                intval($this->ruid)
                , intval($this->lock_uid)
                , intval($this->lock_amount)
                , $this->islock

                , $this->create_time

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `danger_user_lock` SET

            `ruid`=?
            , `lock_uid`=?
            , `lock_amount`=?
            , `islock`=?

            , `create_time`=?
            "

            , [
                intval($this->ruid)
                , intval($this->lock_uid)
                , intval($this->lock_amount)
                , $this->islock

                , $this->create_time
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `danger_user_lock`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

