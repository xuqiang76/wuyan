<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseFunction;
use bigcatorm\MutiStoreFactory;

class Feed8MultiFactory extends MutiStoreFactory {
    public $key = 'usersystem_feed_8_multi_';
    private $sql;
    private $bind;

    public function __construct($cache_obj, $key_objfactory = null, $id = null, $key_add = '', $timeout = 86400) {
        if (!$key_objfactory && !$id) {
            return false;
        }
        $this->key = $this->key . $key_add;
        $ids = '';
        if ($key_objfactory) {
            if ($key_objfactory->initialize()) {
                $key_obj = $key_objfactory->get();
                $ids = implode(',', array_fill(0, count($key_obj), '?'));
            }
        }
        $fields = "
            `id`
            , `uid`
            , `feedid`
            , `content_type`
            , `content_id`

            , `retweet_status`
            ";

        if ($id != null) {
            $this->bInitMuti = false;
            $this->sql = "select $fields from feed_8 where `id`=?";
            $this->bind = [intval($id)];
        } else {
            $this->sql = "select $fields from feed_8 ";
            if ($ids) {
                $this->sql = $this->sql . " where `id` in ($ids) ";
            }
            $this->bind = $key_obj;
        }
        parent::__construct($cache_obj, $this->key, $this->key, $key_objfactory, $id, $timeout);
        return true;
    }

    public function retrive() {
        $res_query = BaseFunction::query_sql_backend($this->sql, $this->bind);
        if (!$res_query) {
            return null;
        }

        $objs = array();
        $result = $res_query['sth']->fetchAll(\PDO::FETCH_CLASS, "HttpApi\puremodel\Feed8");
        foreach ($result as $val) {
            $val->before_writeback();
            $objs[$this->key . '_' . $val->id] = $val;
        }
        return $objs;

    }
}

