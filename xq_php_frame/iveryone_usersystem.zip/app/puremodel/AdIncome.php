<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class AdIncome extends BaseObject {
    const TABLE_NAME = 'ad_income';

    public $id; //
    public $uid = ''; //用户id
    public $adwords = 0; //广告vry收入
    public $adwords_v = 0; //广告V点收入
    public $init_time = 0; //创建时间

    public $update_time = 0; //更新时间

    public function getUpdateSql() {
        return [
            "update `ad_income` SET
            `uid`=?
            , `adwords`=?
            , `adwords_v`=?
            , `init_time`=?

            , `update_time`=?

            where `id`=?"

            , [
                $this->uid
                , intval($this->adwords)
                , intval($this->adwords_v)
                , intval($this->init_time)

                , intval($this->update_time)

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `ad_income` SET

            `uid`=?
            , `adwords`=?
            , `adwords_v`=?
            , `init_time`=?

            , `update_time`=?
            "

            , [
                $this->uid
                , intval($this->adwords)
                , intval($this->adwords_v)
                , intval($this->init_time)

                , intval($this->update_time)
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `ad_income`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

