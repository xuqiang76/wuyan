<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseObject;

class AdMaterial extends BaseObject {
    const TABLE_NAME = 'ad_material';

    public $id; //
    public $uid = ''; //广告商uid
    public $title = ''; //名称
    public $description = ''; //描述
    public $type = ''; //广告类型 feed动态广告 / follow关注广告 /等

    public $remark = ''; //内容
    public $init_time = 0; //结束时间
    public $update_time = 0; //更新时间

    public function getUpdateSql() {
        return [
            "update `ad_material` SET
            `uid`=?
            , `title`=?
            , `description`=?
            , `type`=?

            , `remark`=?
            , `init_time`=?
            , `update_time`=?

            where `id`=?"

            , [
                $this->uid
                , $this->title
                , $this->description
                , $this->type

                , $this->remark
                , intval($this->init_time)
                , intval($this->update_time)

                , intval($this->id)
            ]
        ];
    }

    public function getInsertSql() {
        return [
            "insert into `ad_material` SET

            `uid`=?
            , `title`=?
            , `description`=?
            , `type`=?

            , `remark`=?
            , `init_time`=?
            , `update_time`=?
            "

            , [
                $this->uid
                , $this->title
                , $this->description
                , $this->type

                , $this->remark
                , intval($this->init_time)
                , intval($this->update_time)
            ]
        ];
    }

    public function getDelSql() {
        return [
            "delete from `ad_material`
            where `id`=?"

            , [
                intval($this->id)
            ]
        ];
    }

    public function before_writeback() {
        parent::before_writeback();
        return true;
    }

}

