<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseFunction;
use bigcatorm\Factory;

class AlipayPurchaseFactory extends Factory {
    const objkey = 'usersystem_alipay_purchase_multi_';
    private $sql;
    private $bind;
    public function __construct($cache_obj, $id, $timeout = 86400) {
        $serverkey = self::objkey;
        $objkey = self::objkey . "_" . $id;
        $this->sql = "select
            `id`
            , `uid`
            , `purchase_info`
            , `create_timestamp`
            , `status`

            , `refund`

            from `alipay_purchase`
            where `id`=?";
        $this->bind = [intval($id)];

        parent::__construct($cache_obj, $serverkey, $objkey, $timeout);
        return true;
    }

    public function retrive() {
        $res_query = BaseFunction::query_sql_backend($this->sql, $this->bind);
        if (!$res_query) {
            return null;
        }

        $obj = null;
        $result = $res_query['sth']->fetchAll(\PDO::FETCH_CLASS, "HttpApi\puremodel\AlipayPurchase");

        if ($result) {
            $obj = $result[0];
            $obj->before_writeback();
        }
        return $obj;
    }
}

