<?php
namespace HttpApi\puremodel;

use bigcatorm\BaseFunction;
use bigcatorm\Factory;

class DangerUserFactory extends Factory {
    const objkey = 'usersystem_danger_user_multi_';
    private $sql;
    private $bind;
    public function __construct($cache_obj, $uid, $timeout = 86400) {
        $serverkey = self::objkey;
        $objkey = self::objkey . "_" . $uid;
        $this->sql = "select
            `uid`
            , `high`
            , `bigr`
            , `robot`
            , `amount`

            from `danger_user`
            where `uid`=?";
        $this->bind = [intval($uid)];

        parent::__construct($cache_obj, $serverkey, $objkey, $timeout);
        return true;
    }

    public function retrive() {
        $res_query = BaseFunction::query_sql_backend($this->sql, $this->bind);
        if (!$res_query) {
            return null;
        }

        $obj = null;
        $result = $res_query['sth']->fetchAll(\PDO::FETCH_CLASS, "HttpApi\puremodel\DangerUser");

        if ($result) {
            $obj = $result[0];
            $obj->before_writeback();
        }
        return $obj;
    }
}

