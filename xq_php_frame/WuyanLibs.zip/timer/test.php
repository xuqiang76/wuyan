<?php

require_once __DIR__ . "/timer.php";

echo \Timer\Timer::make_timer(5, 'http://www.wuyan.cn');