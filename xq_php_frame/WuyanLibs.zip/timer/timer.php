<?php
namespace Timer;

use Beahoo\Exception\SDKsException;
use Beahoo\Tool\Network;

require_once dirname(__DIR__) . "/frameworks/Beahoo/Autoloader.php";

class Timer {
    public static function make_timer($time, $callback, $timerid = '')
    {
        $newtimerid = Network::post("http://timer.api.wuyan.cn/", [
            'act' => 'make_timer',
            'time' => $time,
            'callback' => $callback,
            'timerid' => $timerid
        ]);
        if(empty($newtimerid))
        {
            throw new SDKsException("make timer error", 9001);
        }
        return $newtimerid;
    }
}