<?php

echo "ok";