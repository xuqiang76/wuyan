<?php
/**
 * Created by PhpStorm.
 * @author wuxin
 * @date 2016 16/1/13 上午11:20
 * @copyright 7659.com
 */
include  './Email.php';

//test send
//$res = SMS::send(array('tel'=>13810994585,'msg'=>888888,'template_code'=>'SMS_61235070'));
//test sendCaptcha
//$res = Email::sendCaptcha(array('email'=>'yizhouli@outlook.com','template_code'=>'1'));
//test verifyCaptcha
$res = Email::verifyCaptcha(array('email'=>'yizhouli@outlook.com','template_code'=>'1','msg'=>'257656','doexpire'=>1));


var_dump($res);














//分隔区
function icurl($url, $data = "", $opts = array(), $type = "get"){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    if ($type == "post") {
        curl_setopt($ch, CURLOPT_POST, 'application/x-www-form-urlencoded');
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    }
    if (isset($opts["referer"]))
        curl_setopt($ch, CURLOPT_REFERER, $opts["referer"]);
    if (isset($opts["agent"]))
        curl_setopt($ch, CURLOPT_USERAGENT, $opts["agent"]);
    if (isset($opts["cookie"]))
        curl_setopt($ch, CURLOPT_COOKIE, $opts["cookie"]);
    if (isset($opts["header"]))
        curl_setopt($ch, CURLOPT_HTTPHEADER, $opts["header"]);
    $output = curl_exec($ch);
    curl_close($ch);
    return $output;
}