<?php
define('EMAIL_API','http://email.api.wuyan.cn/');

define('EMAIL_MCRYPT','SsCNkmIxL5KsRCo442djHhT');