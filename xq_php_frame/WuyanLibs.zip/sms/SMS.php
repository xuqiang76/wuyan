<?php
/**
 * 短信发送平台.
 * @author wuxin
 * @date 2016 16/1/13 上午10:15
 * @copyright 7659.com
 */

require_once __DIR__ . "/config/config.php";

class SMS{

    private static $params = array(
        //普通短信发送所需参数
        'send' => array('country_code' => 'CN', 'tel', 'template_code', 'msg'),
        //短信验证码发送所需参数
        'sendCaptcha' => array('country_code' => 'CN', 'tel', 'template_code', 'product_name', 'risk'),
        //短信验证码校验所需参数
        'verifyCaptcha' => array('country_code' => 'CN', 'tel', 'template_code', 'msg', 'doexpire'),
    );

    //普通短信发送
    static function send(array $params){
        $params  = self::getParams(__FUNCTION__,$params);
        if(!$params){
            return array('code'=>-1,'msg'=>'参数错误');
        }
        $params['tel'] = trim($params['tel'],',');
        return self::getData($params);
    }
    //短信验证码发送
    static function sendCaptcha(array $params){
        $params  = self::getParams(__FUNCTION__,$params);
        if(!$params){
            return array('code'=>-1,'msg'=>'参数错误');
        }
        return self::getData($params);
    }
    //短信验证码校验
    static function verifyCaptcha(array $params){
        if(!isset($params['doexpire']))
        {
            $params['doexpire'] = 1;
        }
        $params  = self::getParams(__FUNCTION__,$params);
        if(!$params){
            return array('code'=>-1,'msg'=>'参数错误');
        }
        return self::getData($params);
    }

    private static function getData($data, $script = 'send.php'){
        ksort($data);
        $post_str = implode('',array_values($data));
        $data['sign'] = md5($post_str.SMS_MCRYPT);//签名校验
        //发送请求
        $obj = self::icurl(SMS_API . $script . '?' . http_build_query($data));
        $res = json_decode($obj,true);
        if(!$res) {
            @file_put_contents("/download/logs/sms_curl_error." . date("Ymd") . ".log", date("Y-m-d H:i:s") . " timeout or no return", FILE_APPEND);
            return array('code'=>-1,'msg'=>$obj);
        }
        if($res['code'] != 0) {
            @file_put_contents("/download/logs/sms_curl_error." . date("Ymd") . ".log", date("Y-m-d H:i:s") . " " . json_encode($res) . " " . $post_str . " " . $data['sign'], FILE_APPEND);
        }
        return $res;
    }

    private static function getParams($group, array $params){
        $data = array();
        foreach(self::$params[$group] as $key => $item){
            if(is_int($key)) {
                if(!isset($params[$item])){
                    return false;
                }
                $data[$item] = $params[$item];
            } else {
                if(!isset($params[$key])){
                    $data[$key] = $item;
                } else {
                    $data[$key] = $params[$key];
                }
            }
        }
        $data['action'] = $group;
        return $data;
    }

    private static function icurl($url,$data = "",$opts = array(),$type = "get"){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);

        if($type == "post"){
            curl_setopt($ch, CURLOPT_POST, 'application/x-www-form-urlencoded');
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        }
        if(isset($opts["referer"]))
            curl_setopt($ch, CURLOPT_REFERER, $opts["referer"]);
        if(isset($opts["agent"]))
            curl_setopt($ch, CURLOPT_USERAGENT, $opts["agent"]);
        if(isset($opts["cookie"]))
            curl_setopt($ch, CURLOPT_COOKIE, $opts["cookie"]);
        if(isset($opts["header"]))
            curl_setopt ( $ch, CURLOPT_HTTPHEADER,$opts["header"]);
        $output = curl_exec($ch);
        $httpinfo = curl_getinfo($ch);
        curl_close($ch);
        if($httpinfo['http_code'] == 200) {
            return $output;
        }
        @file_put_contents("/download/logs/sms_curl_error." . date("Ymd") . ".log", date("Y-m-d H:i:s") . " " . json_encode($httpinfo) . " " . json_encode($output), FILE_APPEND);
        return false;
    }

}
