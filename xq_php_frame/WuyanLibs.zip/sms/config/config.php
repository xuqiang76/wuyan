<?php
define('SMS_API','http://sms.api.wuyan.cn/');

define('SMS_MCRYPT','SsCNkmIxL5KsRCo442djHhT');