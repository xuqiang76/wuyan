<?php
/**
 * Created by PhpStorm.
 * @author wuxin
 * @date 2016 16/1/13 上午11:20
 * @copyright 7659.com
 */
include  './SMS.php';

//test send
//$res = SMS::send(array('tel'=>13810994585,'msg'=>888888,'template_code'=>'SMS_61235070'));
//test sendCaptcha
$res = SMS::sendCaptcha(array('country_code'=>'US','tel'=>8633335318,'template_code'=>'5','product_name'=>"iVeryOne社区"));
//test verifyCaptcha
//$res = SMS::verifyCaptcha(array('type'=>2,'from'=>'kuaiyong','tel'=>'13001928646,18610952662','event'=>'test','msg'=>873363));


var_dump($res);














//分隔区
function icurl($url, $data = "", $opts = array(), $type = "get"){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    if ($type == "post") {
        curl_setopt($ch, CURLOPT_POST, 'application/x-www-form-urlencoded');
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    }
    if (isset($opts["referer"]))
        curl_setopt($ch, CURLOPT_REFERER, $opts["referer"]);
    if (isset($opts["agent"]))
        curl_setopt($ch, CURLOPT_USERAGENT, $opts["agent"]);
    if (isset($opts["cookie"]))
        curl_setopt($ch, CURLOPT_COOKIE, $opts["cookie"]);
    if (isset($opts["header"]))
        curl_setopt($ch, CURLOPT_HTTPHEADER, $opts["header"]);
    $output = curl_exec($ch);
    curl_close($ch);
    return $output;
}