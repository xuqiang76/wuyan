<?php

namespace Beahoo\Tool;

class Url
{
    public static function getCurentUrl($newparams = array(), $unsetkeys = array())
    {
        $params = $_GET;
        if(!empty($unsetkeys))
        {
            $params = array_diff_key($params, array_flip($unsetkeys));
        }
        $params = array_merge($params, $newparams);
        return $_SERVER['SCRIPT_URL'] . "?" . http_build_query($params);
    }
    
    /**
    *
    * makeUrl
    *
    * URL模式的构建函数
    *
    * @param project        模块名称，默认为配置'default_project'
    * @param controller     控制器名称，默认为配置'default_controller'
    * @param action         动作名称，默认为配置'default_action' 
    * @param args           传递的参数，数组形式
    * @param anchor         跳转锚点
    */
    public static function makeUrl($project = null,$controller = null,$action = null,$args = array(), $anchor = null)
    {
        $default    = Config::read("decorator.router.default");
        $project    = is_null($project) ? $default['project'] : $project;
        $controller = is_null($controller) ? $default['controller'] : $controller;
        $action     = is_null($action) ? $default['action'] : $action;
        
        $uri    = "/{$project}/{$controller}/{$action}";
        if(!empty($args))
        {
            $uri .= "?".http_build_query($args);
        }
        if(!is_null($anchor))
        {
            $uri .= "#{$anchor}";
        }
        return $uri;
    }
}