<?php

namespace Beahoo\Tool;

class Channel
{
    public static function getGHChannel($channelID)
    {
        if(stristr($channelID, "WB") || stristr($channelID, "MT") || stristr($channelID, "GH") || stristr($channelID, "GT") || stristr($channelID, "CT") || stristr($channelID, "SY") || stristr($channelID,"YJG") || stristr($channelID,"1000"))
        {
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    public static function getBigChannel($channelID)
    {
        $channelIDs = array("testDemo","test","gamebox","wmzs","vc01","taigpro11","XKHS");
        if(in_array($channelID,$channelIDs) || empty($channelID) || (stristr($channelID, "ky") && stripos($channelID,"ky") == 0) || stristr($channelID, "3k") || stristr($channelID, "7659") || stristr($channelID, "kuaiyong"))
        {
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
}