<?php

namespace Beahoo\Tool;

/**
 * 通用的网络调用方法封装
 *
 * @package PKGSign
 */
class Network
{
    public static $lasterror = array();

    public static $lastcontent = "";

    public static $lasthttpinfo = array();

    /**
     * 执行一个GET请求
     *
     * @param string $url
     * @param array $headers
     * @param int $timeout
     *
     * @return string|null
     */
    public static function get($url, array $headers = array(), $timeout = 5)
    {
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $url);

        if ($headers) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        }

        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        if (substr($url, 0, 5) == 'https') {
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        }

        $content = curl_exec($ch);
        $response = curl_getinfo($ch);

        self::$lasterror['errno'] = curl_errno($ch);
        self::$lasterror['error'] = curl_error($ch);
        self::$lasterror['response'] = $response;

        if ($response['http_code'] == 200) {
            return $content;
        }

        curl_close($ch);

        return null;
    }

    /**
     * 执行一个POST请求
     *
     * @param string $url
     * @param array $fields
     * @param array $headers
     * @param int $timeout
     *
     * @return string|null
     */
    public static function post($url, array $fields, array $headers = array(), $timeout = 5, $nobuildquery = false)
    {
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $url);

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers + array('Expect:'));

        if(!$nobuildquery)
        {
            $fields = http_build_query($fields);
        }

        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);

        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        if (substr($url, 0, 5) == 'https') {
            //curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            //curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        }

        self::$lastcontent = $content = curl_exec($ch);
        self::$lasthttpinfo = $response = curl_getinfo($ch);

        self::$lasterror['errno'] = curl_errno($ch);
        self::$lasterror['error'] = curl_error($ch);
        self::$lasterror['response'] = $response;

        curl_close($ch);

        if ($response['http_code'] == 200) {
            return $content;
        }

        return null;
    }

    public static function head($url, $timeout = 5)
    {
        $ch = curl_init($url);

        curl_setopt($ch, CURLOPT_TIMEOUT,  $timeout);
        curl_setopt($ch, CURLOPT_HEADER, true);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_NOBODY, true);

        $content = curl_exec($ch);

        curl_close($ch);

        return $content;
    }

    public static function getClientIp()
    {
        $onlineIp = '';
        if(getenv('HTTP_CLIENT_IP') && strcasecmp(getenv('HTTP_CLIENT_IP'), 'unknown')) {
            $onlineIp = getenv('HTTP_CLIENT_IP');
        } elseif(getenv('HTTP_X_FORWARDED_FOR') && strcasecmp(getenv('HTTP_X_FORWARDED_FOR'), 'unknown')) {
            $onlineIp = getenv('HTTP_X_FORWARDED_FOR');
        } elseif(getenv('REMOTE_ADDR') && strcasecmp(getenv('REMOTE_ADDR'), 'unknown')) {
            $onlineIp = getenv('REMOTE_ADDR');
        } elseif(isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], 'unknown')) {
            $onlineIp = $_SERVER['REMOTE_ADDR'];
        }
        list($finalIp) = explode(',', $onlineIp);
        return trim($finalIp);
    }

    public static function getCliMacIp(){
        exec('/sbin/ifconfig en0 | sed -n \'s/^ *.*inet \\([0-9.]\\{7,\\}\\) .*$/\\1/p\'',$arr);
        $ret = $arr[0];
        return $ret;
    }

    public static function getCliLinuxIp(){
        exec('/sbin/ifconfig em1 | sed -n \'s/^ *.* addr:\\([0-9.]\\{7,\\}\\) .*$/\\1/p\'',$arr);
        $ret = $arr[0];
        return $ret;
    }
}
