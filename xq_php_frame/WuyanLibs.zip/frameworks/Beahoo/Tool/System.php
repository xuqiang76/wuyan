<?php

namespace Beahoo\Tool;

class System
{
    public static function ServerOS()
    {
        $s = php_uname('s');
        if($s == 'Darwin')
        {
            $system = 'mac';
        } elseif (substr(strtolower($s), 0, 3) == 'win')
        {
            $system = 'windows';
        } else {
            $system = 'linux';
        }
        return $system;
    }
}