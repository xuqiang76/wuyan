<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016-05-16
 * Time: 10:34
 */
namespace Beahoo\Tool;

class Timer
{
    public static function getDayList($startDay = "",$endDay = "")
    {
        $return     = array();
        $timeStamp  = time();
        $startTime  = empty($startDay)  ?   $timeStamp : strtotime($startDay);
        $endTime    = empty($endDay)    ?   $timeStamp : strtotime($endDay);
        $startDay   = date("Y-m-01",$startTime);

        $return[]   = $startDay;
        $i = 1;
        while (TRUE)
        {
            $time   = strtotime("{$startDay} + {$i} month");
            if($time > $endTime)
            {
                break;
            }
            $return[] = date("Y-m-01",$time);
            $i++;
        }
        return $return;
    }
}