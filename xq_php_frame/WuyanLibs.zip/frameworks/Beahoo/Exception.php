<?php

namespace Beahoo;

class Exception extends \Exception
{

}
