<?php

namespace Beahoo\Model;

use Beahoo\Tool\FunTool;

class User extends Base
{
    
    protected $dbname = 'mysql_user';

    /**
     * 用户信息By ID      
     */
    public function getUserInfo($ids)
    {
        if(is_array($ids)){
            $condition = "id in (".implode($ids, ',').")";
        }else{
            $condition = "id={$ids}";
        }
        $sql    = "SELECT * FROM {$this->prefix}user_list WHERE {$condition}";
        $query  = $this->getDb()->query($sql); 
        $rs     = $query->fetchAll(\PDO::FETCH_ASSOC);
        return is_array($ids) ? $rs : $rs[0];
    }
    
    /**
     * 用户信息By ID
     * $data 为属性和值 键值对     
     */
    public function getUserInfoByAttr($data)
    {
        if(empty($data)) return FALSE;
        $condition = '';
        foreach ($data as $k => $v){
            $condition .=" and {$k}='{$v}'";
        }
        $sql = "SELECT * FROM {$this->prefix}user_list WHERE 1=1 {$condition}";
        $query  = $this->getDb()->query($sql); 
        $rs     = $query->fetchAll(\PDO::FETCH_ASSOC);
        return $rs;
    }
    
    /**
     * 用户总数      
     */
    public function getTotal($params = array())
    {
        if(is_string($params))
        {
            $params['kw'] = $params;
        }
        $sql    = "SELECT count(*) AS total FROM {$this->prefix}user_list where 1=1";
        if(!empty($params['kw'])){
            $sql .=" and (username like '{$params['kw']}%' or email like '{$params['kw']}%')";
        }
        $query  = $this->getDb()->query($sql);
        $rs     = $query->fetch(\PDO::FETCH_ASSOC);
        return $rs['total'];
    }

    public function getList($params = array()){
        $sql    = "SELECT * FROM {$this->prefix}user_list where 1=1";
        if(!empty($params['kw']))
        {
            $sql .=" and (username like '{$params['kw']}%' or email like '{$params['kw']}%')";
        }
        $sql .=" ORDER BY addtime DESC";
        if(isset($params['start']) && !empty($params['count']))
        {
            $sql .= " LIMIT " . $params['start'] . "," . $params['count'];
        }
        $query  = $this->getDb()->query($sql);
        $rs     = $query->fetchAll(\PDO::FETCH_ASSOC);
        return $rs;
    }

    /**
     * 用户添加      
     */
    public function add($data)
    {
        unset($data['role']);
        $data['addtime'] = time();
        if(empty($data['email']))
        {
            $data['email'] = $data['username'] . '@kuaiyong.net';
        }
        $one = $this->getOne();
        $res = $one->insert("{$this->prefix}user_list", $data);
        return $res['insertid'];
    }
    
    /**
     * 用户修改      
     */
    public function modify($uid,$data)
    {
        unset($data['role']);
        $one = $this->getOne();
        return $one->update("{$this->prefix}user_list", $data, array(), array('id'=>$uid));
    }
    
    /**
     * 用户删除      
     */
    public function del($uid){
        $sql = "DELETE FROM {$this->prefix}user_list WHERE id={$uid}";
        return $this->getDb()->exec($sql);
    }

    public static function getUser()
    {
        $user = array(
            'uid'=>$_SESSION['uid'],
            'username'=>$_SESSION['username'],
            'email'=>$_SESSION['email'],
            'tel'=>$_SESSION['tel'],
            'addtime'=>$_SESSION['addtime'],
        );
        return $user;
    }
    
}