<?php

namespace Beahoo\Model;

class User_role extends Base
{
    
    protected $dbname = 'mysql_user';

    public function getAllMap()
    {
        $roleList   = array();
        $sql = "SELECT a.id,a.name,b.user_id as uid FROM {$this->prefix}role as a LEFT JOIN {$this->prefix}user_role as b";
        $sql .= " ON a.id = b.role_id ORDER BY a.id ASC";
        $query  = $this->getDb()->query($sql);
        $rs     = $query->fetchAll(\PDO::FETCH_ASSOC);

        foreach ($rs as $v){
            $roleList[$v['uid']] = $v['name'];
        }
        return $roleList;
    }

    /**
     * 获取列表      
     */
    public function getUserRoleList()
    {
        $sql    = "SELECT * FROM {$this->prefix}user_role";
        $query  = $this->getDb()->query($sql);
        $rs     = $query->fetchAll(\PDO::FETCH_ASSOC);
        return $rs;
    }
    
    public function getUserRole($ids)
    {
        if(is_array($ids)){
            $condition = "user_id in (".implode($ids, ',').")";
        }else{
            $condition = "user_id = {$ids}";
        }
        $sql    = "SELECT * FROM {$this->prefix}user_role WHERE {$condition}";
        $query  = $this->getDb()->query($sql);
        $rs     = $query->fetchAll(\PDO::FETCH_ASSOC);
        return $rs;
    }

    /**
     * 添加信息     
     */
    public function add($data){
        $sql = "INSERT INTO {$this->prefix}user_role (user_id,role_id)";
        if(is_array($data['role_id']))
        {
            $sql .= " value";
            $dot = "";
            foreach($data['role_id'] as $role_id)
            {
                $sql .= $dot . "({$data['user_id']},{$role_id})";
                $dot = ",";
            }
        } else {
            $sql .=" value ({$data['user_id']},{$data['role_id']})";
        }

        $this->getDb()->exec($sql);
    }
    
    /**
     * 用户组修改      
     */
    public function modify($data){
        $this->del($data['user_id']);
        $this->add($data);
    }
    
    /**
     * 用户组删除      
     */
    public function del($uid){
        $sql = "DELETE FROM {$this->prefix}user_role WHERE user_id={$uid}";
        return $this->getDb()->exec($sql);
    }
    
}