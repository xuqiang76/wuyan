<?php

namespace Beahoo\Model;

use Beahoo\Exception;
use Beahoo\Tool\Config;
use Beahoo\Tool\One;

abstract class Base
{
    /**
     * 实例
     *
     * @var $instance array
     */
    protected static $instances;

    protected $dbname = 'mysql';

    protected $prefix;

    public function __construct()
    {
        $config = Config::read($this->dbname);
        if(empty($config))
        {
            throw new Exception("no " . $this->dbname . " conf");
        }

        if(!empty($config['prefix']))
        {
            $this->prefix = $config['prefix'];
        }
    }

    /**
     * 创建连接
     *
     * @return \PDO
     */
    public function getDb($checkalive = false)
    {
        if (isset(static::$instances[$this->dbname])) {
            if($checkalive)
            {
                try {
                    static::$instances[$this->dbname]->query('SELECT 1');
                    return static::$instances[$this->dbname];
                } catch (\PDOException $e) {
                    //do nothing
                }
            } else {
                return static::$instances[$this->dbname];
            }

        }

        $config = Config::read($this->dbname);
        if(empty($config))
        {
            throw new Exception("no " . $this->dbname . " conf");
        }

        $dsn = 'mysql:' . implode(';', array(
                'host='    . $config['host'],
                'port='    . $config['port'],
                'dbname='  . $config['dbname'],
                'charset=' . $config['charset'],
            ));

        $options = array(
            \PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES {$config['charset']}",
            \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION,
            \PDO::ATTR_TIMEOUT => 2,
        );

        static::$instances[$this->dbname] = new \PDO(
            $dsn, $config['username'], $config['password'], $options
        );

        return static::$instances[$this->dbname];
    }

    /**
     * @var \Beahoo\Tool\One
     */
    private static $one;

    public function getOne($checkalive=false)
    {
        if(PHP_SAPI == 'cli')
        {
            $checkalive = true;
        }
        $pdo = $this->getDb($checkalive);
        if(isset(self::$one))
        {
            self::$one->setPdo($pdo);
        }
        else
        {
            self::$one = new One($pdo);
        }
        return self::$one;
    }

    public function transaction_start() {
        $this->getOne ()->exec ( 'start transaction' );
        $this->autocommit ( 0 );
    }
    public function transaction_commit() {
        $this->getOne ()->exec ( 'commit' );
        $this->autocommit ();
    }
    public function transaction_rollback() {
        $this->getOne ()->exec ( 'rollback' );
        $this->autocommit ();
    }
    public function autocommit($flag = 1) {
        $this->getOne ()->exec ( 'set autocommit = ' . intval ( boolval ( $flag ) ) );
    }
}