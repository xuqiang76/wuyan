<?php
namespace Beahoo\Controller;

trait ApiActionTrait
{
    /**
     * @desc:渲染变量到模版,目前仅考虑最简单的渲染变量到类中供页面使用,在模版中通过$this->key 使用
    */
    protected function assign($key,$value)
    {
        $this->$key = $value;
    }

    protected function format($data, $callback = null) {
        if ($callback && preg_match('/^[a-z\._0-9]+$/i', $callback)) {
            return $callback . '(' . json_encode($data) . ')';
        } else {
            return json_encode($data);
        }
    }

    protected function formatData($param){
        $param = array_merge(array('errno'=>0,'errmsg'=>'','time'=>time(),'callback'=>null,'decode'=>true),$param);
        $data = array(
            'errno' => $param['errno'],
            'errmsg' => $param['errmsg'],
            'time' => $param['time']
        );
        if(isset($param['data'])) {
            $data['data'] = $param['data'];
        }
        if(!$param['decode']){
            return $data;
        }else{
            return $this->format($data,$param['callback']);
        }
    }
}
