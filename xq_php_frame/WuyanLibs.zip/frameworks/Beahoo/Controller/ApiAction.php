<?php
namespace Beahoo\Controller;
/**
 * 所有不需要验证相关Action的父类
 *
 * @package Beahoo\Controller
 */
abstract class ApiAction extends Action
{
    /**
     * @desc:渲染变量到模版,目前仅考虑最简单的渲染变量到类中供页面使用,在模版中通过$this->key 使用
     */
    protected function assign($key,$value)
    {
        $this->$key = $value;
    }
}
