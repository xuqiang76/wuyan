<?php

namespace Beahoo\Controller\Response;

class ShellResponse extends \Beahoo\Controller\Response
{
    protected $body;

    public function setBody($body)
    {
        $this->body = $body;
    }

    public function send($body = null)
    {
        if(empty($body))
        {
            echo $this->body . PHP_EOL;
        } else {
            echo $body . PHP_EOL;
        }
    }
}
