<?php

namespace Beahoo\Controller\Decorator;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Tool\Config;

/**
 * 路由装饰器
 */
trait RouterDecoratorTrait
{
    public $project     = '';
    public $controller  = '';
    public $actionName  = '';

    /**
     * 匹配
     *
     * @param string $uri
     *
     * @result string
     */
    protected function match($uri)
    {
        if(trim($uri, "\\") == 'favicon.ico')
        {
            throw new \Exception("favicon.ico");
        }
        if(!empty($this->project))
        {
            $project = $this->project;
        }
        elseif(strpos($uri, '/')) {
            $project = substr($uri, 0, strpos($uri, '/'));
            $uri = substr($uri, strpos($uri, '/')+1);
        } else {
            $project = $uri;
            $uri = "";
        }
        
        if (!$project) {
            $project = Config::read('decorator.router.default.project');
        }

        $this->project = $project;
        $prefix = Config::read('decorator.router.prefix.'.$project);
        if(empty($prefix))
        {
            $prefix = Config::read('decorator.router.default_prefix');
            if(empty($prefix))
            {
                $prefix = Config::read('decorator.router.prefix');
            }
        }
        $prefix .= '\\' . $project;

        return $this->getClass($uri, $prefix);
    }

    /**
     * 获取action
     *
     * @param string $router
     *
     * @result string
     */
    protected function getClass($router, $prefix)
    {   
        $default = Config::read('decorator.router.default');

        $path = explode('/', ltrim($router, '/'));

        $controller = $this->controller = !empty($path[0]) ? $path[0] : $default['controller'];
        $action     = $this->actionName = !empty($path[1]) ? $path[1] : $default['action'];
        $action     = $action . 'Action';

        if (PHP_SAPI == 'cli') {
            return "{$prefix}\\{$controller}\\Shell\\{$action}";
        }

        return "{$prefix}\\{$controller}\\{$action}";
    }
}
