<?php

namespace Beahoo\Controller\Decorator;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;
use Beahoo\Tool\Config;

/**
 * 路由装饰器
 */
class RouterDecorator extends \Beahoo\Controller\Decorator
{
    use RouterDecoratorTrait;
    /**
     * 执行
     *
     * @param \Beahoo\Controller\Request $request
     * @param \Beahoo\Controller\Response $response
     *
     * @result void
     */
    public function execute(Request $request, Response $response)
    {
        $uri = $request->getServerArg('REQUEST_URI');
        $uri = ltrim(strstr($uri . '?', '?', true), '/');
        $this->project = $request->getServerArg('REQUEST_PROJECT');

        if ($action = $this->match($uri)) {
            $this->getLastAction()->setAction($action);
        }

        $request->setServerArg('project', $this->project);
        $request->setServerArg('controller', $this->controller);
        $request->setServerArg('action', $this->actionName);
        
        parent::execute($request, $response);
    }
}
