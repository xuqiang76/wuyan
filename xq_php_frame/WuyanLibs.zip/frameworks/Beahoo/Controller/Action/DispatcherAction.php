<?php

namespace Beahoo\Controller\Action;

use Beahoo\Controller\Request;
use Beahoo\Controller\Response;

class DispatcherAction extends \Beahoo\Controller\Action
{

}
