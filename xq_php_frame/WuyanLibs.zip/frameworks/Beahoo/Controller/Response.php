<?php

namespace Beahoo\Controller;

abstract class Response
{

}
