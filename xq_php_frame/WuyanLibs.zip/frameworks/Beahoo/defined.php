<?php

define("BEAHOO_ROOT", __DIR__);