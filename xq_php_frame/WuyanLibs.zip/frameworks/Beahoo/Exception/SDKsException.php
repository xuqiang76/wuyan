<?php

namespace Beahoo\Exception;

class SDKsException extends \Beahoo\Exception
{

}
