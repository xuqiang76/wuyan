<?php

namespace Beahoo\Exception;

class ClassNotFoundException extends \Beahoo\Exception
{

}
