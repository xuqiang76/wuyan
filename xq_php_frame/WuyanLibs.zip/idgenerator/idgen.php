<?php
namespace IDGEN;

use Beahoo\Exception\SDKsException;
use Beahoo\Tool\Network;

require_once dirname(__DIR__) . "/frameworks/Beahoo/Autoloader.php";

class IDGEN {
    public static function get()
    {
        $id = Network::get("http://idgen.api.wuyan.cn/genid");
        if(empty($id))
        {
            throw new SDKsException("genid error", 9000);
        }
        return $id;
    }
}