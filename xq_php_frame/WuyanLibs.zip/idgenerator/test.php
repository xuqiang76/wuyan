<?php

require_once __DIR__ . "/idgen.php";

echo \IDGEN\IDGEN::get();